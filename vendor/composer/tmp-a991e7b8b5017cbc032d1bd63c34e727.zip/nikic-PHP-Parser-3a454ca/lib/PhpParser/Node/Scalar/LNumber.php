<?php declare(strict_types=1);

namespace PhpParser\Node\Scalar;

require __DIR__ . '/Int_.php';

if (false) {
    /**
     * For classmap-authoritative support.
     *
     * @deprecated use \PhpParser\Node\Scalar\Int_ instead.
     */
    class LNumber extends Int_ {
    }
}
