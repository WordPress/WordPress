<?php declare(strict_types=1);

namespace PhpParser\Node\Scalar;

require __DIR__ . '/InterpolatedString.php';

if (false) {
    /**
     * For classmap-authoritative support.
     *
     * @deprecated use \PhpParser\Node\Scalar\InterpolatedString instead.
     */
    class Encapsed extends InterpolatedString {
    }
}
