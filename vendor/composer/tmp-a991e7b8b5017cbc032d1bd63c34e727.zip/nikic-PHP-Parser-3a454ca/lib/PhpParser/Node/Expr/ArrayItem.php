<?php declare(strict_types=1);

namespace PhpParser\Node\Expr;

require __DIR__ . '/../ArrayItem.php';

if (false) {
    /**
     * For classmap-authoritative support.
     *
     * @deprecated use \PhpParser\Node\ArrayItem instead.
     */
    class ArrayItem extends \PhpParser\Node\ArrayItem {
    }
}
