/*
	Javascript: Event Tickets Calendar
	version: 0.1
*/
jQuery(document).ready(function($){
	
	init();	
	
	
	// INITIATE script
	function init(){

	}

	
	
	
});