=====================================
How to install EventON Extensions
=====================================
EventON extensions can be installed just like a normal plugin unlike EventON Addons.

Step 1:
Go to WP Admin > Plugins > Add New

Step 2: 
Select "Upload" and choose the zip file of the extension (ONLY) 

Step 3:
Click Install Now and follow the screen to activate.


-------

You can also install this EventON Extension by upzipping the file content and uploading the content to "wp-content/plugins/" directory. 

