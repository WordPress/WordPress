=== Kirki ===
Contributors: aristath, fovoc
Donate link: http://kirki.org
Tags: customizer
Requires at least: 3.8
Tested up to: 3.9.1
Stable tag: 0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tired of all the bloated options frameworks? You can use the WordPress Customizer instead, and extend it using Kirki!

== Description ==

This plugin empowers theme developers making it easier to implement advanced features:

* Use [additional controls](http://kirki.org/#fields) on the WordPress Customizer.
* Easier definition of customizer controls.
* Advanced settings on each controls (such as subtitles and help popovers).

The plugin has extensive and thorough documentation available on [kirki.org](http://kirki.org).
Please visit the [usage and implementation advice](http://kirki.org/#configuration).

== Installation ==

Just install this plugin and activate it.
For configuration instructions please visit http://kirki.org/#configuration

== Changelog ==

= 0.3 =
* new: added background field
* new: added 'output' argument to directly output the CSS

= 0.2 =
* Initial version
