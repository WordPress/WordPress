/*
	Javascript code for single event page
	version: 0.2
*/
jQuery(document).ready(function($){
	$('.evo_sin_page ').each(function(){
		$(this).find('.desc_trig ').attr({'data-ux_val':'none'});
	});
});