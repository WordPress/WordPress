<?php
echo "
<p>
	<b>How to add social media:</b> Go to <b>\"myEventON > Settings > Social Media\"</b> and select the social media share services you would like to add to event page.
</p><br/>
<h2>How to customize the single event page</h2>
<p>
	Copy the file <b>single-ajde_events.php</b> and <b>content-event.php</b> (from eventon-single-events/templates directory) <br/>to <b>..wp-content/themes/your-theme-name/eventon/</b> directory (in your site) and feel free to customize the way this template looks.
</p>
<p>
	<i>EventON will look for the above mentioned 2 PHP files in below order:<br/>
	..wp-content/themes/your-theme/eventon/</br>
	..wp-content/plugins/eventon-single-event/templates/</br>
	..wp-content/plugins/eventon/templates/	
	</i>
</p>

<br/>
";
?>