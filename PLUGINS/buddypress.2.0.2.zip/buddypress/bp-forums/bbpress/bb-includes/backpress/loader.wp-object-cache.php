<?php

require_once( 'class.wp-object-cache.php' );
require_once( 'functions.wp-object-cache.php' );
