/*
	Javascript: Eventon Active User - Front end script
*/
jQuery(document).ready(function($){
	
	// all day event
		$('#evoAU_all_day').on('click',function(){
			if ($('input#evoAU_all_day').is(':checked')) {
				$('.evoau_tpicker').hide();
			}else{
				$('.evoau_tpicker').show();
			}
		});

	// no time event
		$('#evoAU_hide_ee').on('click',function(){
			if ($('input#evoAU_hide_ee').is(':checked')) {
				$('#evoAU_endtime_row').hide();
			}else{
				$('#evoAU_endtime_row').show();
			}
		});

	var dateformat__ = $('#_evo_date_format').attr('jq');
	date_format = (typeof dateformat__ !== 'undefined' && dateformat__ !== false)?	
		dateformat__: 'dd/mm/yy';
	
	//alert(dateformat__);
	
	//$('.evoau_dpicker').datepicker({ dateFormat: dateformat });

	$('#evoAU_start_date').datepicker({ 
		dateFormat: date_format,
		numberOfMonths: 2,
		onClose: function( selectedDate ) {
	        $( "#evoAU_end_date" ).datepicker( "option", "minDate", selectedDate );
	    }
	});
	$('#evoAU_end_date').datepicker({ 
		dateFormat: date_format,
		numberOfMonths: 2,
		onClose: function( selectedDate ) {
        	$( "#evoAU_start_date" ).datepicker( "option", "maxDate", selectedDate );
      	}
	});

	var time_format__ = $('#_evo_time_format').val();
	time_format__ = (time_format__=='24h')? 'H:i':'h:i:A';
	$('.evoau_tpicker').timepicker({ 'step': 15,'timeFormat': time_format__ });

	// color picker
	$('.color_circle').ColorPicker({
		onBeforeShow: function(){
			$(this).ColorPickerSetColor( $(this).data('hex'));
		},	
		onChange:function(hsb, hex, rgb,el){
			//console.log(hex);
			$(el).attr({'backgroundColor': '#' + hex});
			//$(el).html( hex);
		},	
		onSubmit: function(hsb, hex, rgb, el) {
			var sibb = $(el).siblings('.evoau_color_picker');
			sibb.find('.evcal_event_color').attr({'value':hex});
			$(el).css('backgroundColor', '#' + hex);

		
			$(el).ColorPickerHide();
		}
	});


	// form submission
	//$('#evoau_submit').on('click',function(){
	$('#evoau_form').submit(function(e){
		
		var form = $(this);
		var errors = 0;
		//var form = obj.closest('form');

		reset_form(form);

		form.find('.req').each(function(i, el){
			var el = $(this);
			var val = el.val();
			var name = el.attr('name');

			
			// Filter values
			if( $('#evoAU_hide_ee').is(':checked') && el.hasClass('end')){
				// no end time event
			}else if( $('#evoAU_all_day').is(':checked') && el.hasClass('time')){
				// all day event
			}else{
				if(val.length==0){
					errors++;
					el.closest('.row').addClass('err');				
				}
			}
		});
		

		if(errors==0){
			//obj.submit();
			//$('#evoau_form').submit();
			//$('#evoau_submit').submit();
			console.log('44');
			return;
		}else{

			e.preventDefault();
			var msg = form.find('.form_msg').data('m1');
			form.find('.eventon_form_message').addClass('error_message').html(msg).slideDown('fast');
			return false;
		}
	});

	// reset values in the form
	function reset_form(form){
		form.find('.eventon_form_message').removeClass('error_message').fadeOut();
		form.find('.row').removeClass('err');
	}
});