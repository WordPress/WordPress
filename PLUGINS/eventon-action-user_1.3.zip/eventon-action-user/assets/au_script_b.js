/*
	Javascript: Eventon Active User
*/
jQuery(document).ready(function($){

	// add new users to permissions list
	$('.eventon_popup_text').on('click','.evoau_user_list_item',function(){
		var uid = parseInt($(this).val());
		var uname = $(this).attr('uname');
		
			
		if( $(this).is(':checked') ){
			
			
			$('#popup_content').find('#evoau_'+uid).attr('checked','checked');
			
			
		}else{
			$('#popup_content').find('#evoau_'+uid).removeAttr('checked');
			
		}
	});
	
});