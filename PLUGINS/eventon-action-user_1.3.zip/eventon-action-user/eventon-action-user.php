<?php
/*
 * Plugin Name: EventON - Action User
 * Plugin URI: http://www.myeventon.com/
 * Description: Control eventON users and its capabilities
 * Author: Ashan Jay
 * Version: 1.3
 * Author URI: http://www.ashanjay.com/
 * Requires at least: 3.7
 * Tested up to: 3.9.1
 */


 
class eventon_au{
	
	public $version='1.3';
	public $eventon_version = '2.2.13';
	public $name = 'ActionUser';

	public $addon_data = array();
	public $slug, $plugin_slug , $plugin_url , $plugin_path ;

	public $evoau_opt;
	public $evoau_opt_2;
	private $urls;
	var $log= array();
	var $users;

	public $message, $link;

	private $options ='';
	
	
	/*
	 * Construct
	 */
	public function __construct(){

		$this->super_init();

		// get eventon addon class file url if exists
		$url = str_replace($this->addon_data['slug'], 'eventON', $this->addon_data['plugin_path']);
		$url .= '/classes/class-evo-addons.php';

		if(file_exists($url)){
				
			include_once( $url);
			$this->addon = new evo_addon($this->addon_data);

			// if addon class exists
			if($this->addon->requirment_check()){

				$this->options = get_option('evcal_options_evcal_1');			
			
				add_action( 'init', array( $this, 'init' ), 0 );
								
				add_filter('eventon_core_capabilities', array($this, 'add_new_capability_au'),10, 1);	
					
				// scripts and styles 
				add_action( 'eventon_admin_post_script', array( $this, 'backend_post_scripts' ) ,15);		
				
				// ACTIONS
				add_action('admin_menu', array( $this,'evoAU_add_menu_pages'));
				add_action( 'user_row_actions', array( $this,'evoAU_user_row'), 10, 2 );
				
				add_action( 'init', array( $this, 'register_frontend_scripts' ) ,15);
				add_action( 'admin_enqueue_scripts', array($this,'evoau_admin_scripts' ));

				add_action( 'eventon_register_taxonomy', array( $this, 'create_user_tax' ) ,10);
				add_action( 'eventon_cal_variable_action', array( $this, 'eventon_cal_variable_check' ) ,10,1);
				
				//when a new post is published
				add_action('transition_post_status',array($this,'send_approval_email'), 10, 3);
					

				$this->includes();
			}
		}else{
			// if we cant find eventon addon class file show admin notice
			add_action('admin_notices', array($this, '_no_eventon_warning'));
		}
		
	}
	
	// SUPER init
		function super_init(){
			// PLUGIN SLUGS			
			$this->addon_data['plugin_url'] = path_join(WP_PLUGIN_URL, basename(dirname(__FILE__)));
			$this->addon_data['plugin_slug'] = plugin_basename(__FILE__);
			list ($t1, $t2) = explode('/', $this->addon_data['plugin_slug'] );
	        $this->addon_data['slug'] = $t1;
	        $this->addon_data['plugin_path'] = dirname( __FILE__ );
	        $this->addon_data['evo_version'] = '2.2.12';
	        $this->addon_data['version'] = $this->version;
	        $this->addon_data['name'] = 'ActionUser';

	        $this->plugin_url = $this->addon_data['plugin_url'];
	        $this->plugin_slug = $this->addon_data['plugin_slug'];
	        $this->slug = $this->addon_data['slug'];
	        $this->plugin_path = $this->addon_data['plugin_path'];
		}

	// INITIATE action user
		function init(){
			$this->evoau_opt = get_option('evcal_options_evoau_1');
			$this->evoau_opt_2 = get_option('evcal_options_evoau_2');
			
			
			// Activation
			$this->activate();		
			
			// Deactivation
			register_deactivation_hook( __FILE__, array($this,'deactivate'));


			// RUN addon updater only in dedicated pages
			if ( is_admin() ){
				$this->addon->updater();			
			}
		}
	
	/** Include required core files. */
		function includes(){
			global $pagenow;
			include_once( 'admin/eventonAU_shortcode.php' );
			if ( is_admin() ){		
				include_once( 'admin/admin_init.php' );
			}

			if ( defined('DOING_AJAX') ){
				include_once( 'admin/eventonAU_ajax.php' );
			}
			
		}


	
	/*	SHORTCODE processing	*/
		function eventon_cal_variable_check($args){
			
			// check if users variable is present and not empty or not equal to all
			if(isset($args['users']) && !empty($args['users']) && $args['users']!='all'){
				$this->users = $args['users'];
				
				add_filter('eventon_wp_query_args',array($this,'eventon_au_filters'));
				add_action('eventon_sorting_filters', array($this, 'eventon_frontend_filter'),7);
			}		
		}
	
	// ADD filtering values for WP Query argument
		function eventon_au_filters($args){		
			
			$users = explode(',', str_replace(' ','',$this->users) );
			
			$user_filter = array(
				'tax_query'=>array(
					array(
						'taxonomy'=>'event_users',
						'field'=>'slug',
						'terms'=>$users
					)
				)
			);
			$wp_arguments = array_merge($args, $user_filter);
			
			return $wp_arguments;
		}
	
	// Add the user filtering fields to frontend cal
		function eventon_frontend_filter(){
			echo "<div class='eventon_filter' filter_field='event_users' filter_val='{$this->users}' filter_type='tax'></div>";
		}
	
		
	
	// ===============================
	// OUTPUT form
		function output_event_submission_form(){
			$this->print_frontend_scripts();
			$submission_status='';
			
			// form submission
			if( isset($_POST['evoau_noncename']) && isset( $_POST ) ){
				if ( wp_verify_nonce( $_POST['evoau_noncename'], AJDE_EVCAL_BASENAME ) ){			
					
					
					$saved_fields = (!empty($this->evoau_opt['evoau_fields']) && is_array($this->evoau_opt['evoau_fields']) && count($this->evoau_opt['evoau_fields'])>0)? $this->evoau_opt['evoau_fields']: false;
										
					
					if(empty($this->log['error']))
						$submission_status = $this->save_form_submissions();
					
									
					if($submission_status)
						$this->log['msg']= (!empty($this->evoau_opt['evoaun_msg_s']))?
							($this->evoau_opt['evoaun_msg_s'])
							:__('Event Successfully Saved','eventon');
				}
			}
			
			// ACTUAL FORM contnet
			require_once('includes/front_end_form.php');	
		}
		
	// save form submittions UPON submit
		function save_form_submissions(){
			$status= $cu_email='';
			if($created_event_id = $this->create_post()){
				
				// SAVE DATE TIMES and start/end - meta data
				if(isset($_POST['event_start_date']) && isset($_POST['event_end_date']) && isset($_POST['event_start_time']) && isset($_POST['event_end_time']) ){
				
					$start_time = explode(":",$_POST['event_start_time']);
					$end_time = explode(":",$_POST['event_end_time']);

						$__ampm_s = (!empty($start_time[2]))? $start_time[2]: null;
						$__ampm_e = (!empty($end_time[2]))? $end_time[2]: null;
					
					
					
					// all day events
					if(!empty($_POST['event_all_day']) && $_POST['event_all_day']=='yes'){
						$date_array_end = array(
							'evcal_start_date'=>$_POST['event_start_date'],
							'evcal_start_time_hour'=>'12','evcal_start_time_min'=>'00',
							'evcal_st_ampm'=>'AM',
							'evcal_end_date'=>$_POST['event_start_date'],
							'evcal_end_time_hour'=>'12','evcal_end_time_min'=>'59','evcal_et_ampm'=>'PM'
						);
						$this->create_custom_fields($created_event_id, 'evcal_allday', 'yes');
						
						
					// if NO end time
					}elseif(!empty($_POST['evo_hide_endtime']) && $_POST['evo_hide_endtime']=='yes'){
						$date_array_end = array(
							'evcal_start_date'=>$_POST['event_start_date'],
							'evcal_start_time_hour'=>$start_time[0],
							'evcal_start_time_min'=>$start_time[1],
							'evcal_st_ampm'=>$__ampm_s,
							'evcal_end_date'=>$_POST['event_start_date'],
							'evcal_end_time_hour'=>'12','evcal_end_time_min'=>'59','evcal_et_ampm'=>'PM',							
						);
						$this->create_custom_fields($created_event_id, 'evo_hide_endtime', 'yes');

					// not all day event
					}else{
						$date_array_end = array(
							'evcal_end_date'=>$_POST['event_end_date'],
							'evcal_end_time_hour'=>$end_time[0],
							'evcal_end_time_min'=>$end_time[1],
							'evcal_et_ampm'=>$__ampm_e,
							'evcal_start_date'=>$_POST['event_start_date'],
							'evcal_start_time_hour'=>$start_time[0],
							'evcal_start_time_min'=>$start_time[1],
							'evcal_st_ampm'=>$__ampm_s,
						);
					}
					
					

					// merge both start and end time values
					$date_array = $date_array_end;
					
					
					$__evo_date_format = (!empty($_POST['_evo_date_format']))? $_POST['_evo_date_format']: 'd/m/Y';
					$_evo_time_format = (!empty($_POST['_evo_time_format']))? $_POST['_evo_time_format']: '12h';
					$proper_time = eventon_get_unix_time($date_array, $__evo_date_format, $_evo_time_format);
									
					// save required start time variables
					$this->create_custom_fields($created_event_id, 'evcal_srow', $proper_time['unix_start']);
					$this->create_custom_fields($created_event_id, 'evcal_erow', $proper_time['unix_end']);		
				}
				

				
				// create custom meta fields			
				foreach($this->au_form_fields('savefields') as $field=>$fn){

					$__var_name = $fn[1];

					if(isset($_POST[$__var_name])){
						if($fn[2] =='tax' ){	
							// save post terms
							if(count($_POST[$__var_name])>0 && is_array($_POST[$__var_name])){
								
								if($field=='event_type_2'){
									$terms = $_POST[$__var_name];

									// add default event type category tag if enabled
									if(!empty($this->evoau_opt['evoau_set_def_ett']) 
										&& !empty($this->evoau_opt['evoau_def_ett_v']) 
										&& $this->evoau_opt['evoau_def_ett_v']!='-' 
										&& $this->evoau_opt['evoau_set_def_ett']=='yes'
									){
										$terms[] = $this->evoau_opt['evoau_def_ett_v'];
									}	
									wp_set_post_terms($created_event_id, $terms, $field);

								}else{
									wp_set_post_terms($created_event_id, $_POST[$__var_name], $field);
								}
							}
						}else{
							$this->create_custom_fields($created_event_id, $__var_name, $_POST[$__var_name]);
						}						
							
					}

					// set default event type categories if tax is not an option in the form
						if($field=='event_type_2' ){
							if(!empty($this->evoau_opt['evoau_set_def_ett']) 
								&& !empty($this->evoau_opt['evoau_def_ett_v'])
								&& $this->evoau_opt['evoau_def_ett_v']!='-' 
								&& $this->evoau_opt['evoau_set_def_ett']=='yes'
							){
								$terms[] = $this->evoau_opt['evoau_def_ett_v'];
								wp_set_post_terms($created_event_id, $terms, 'event_type_2');	
							}									
						}

					// image
						if($field == 'event_image' ){
							if( !empty( $_FILES ) && 'POST' == $_SERVER['REQUEST_METHOD']  ){

								if ($_FILES[$__var_name]['error'] !== UPLOAD_ERR_OK) __return_false();

								require_once (ABSPATH.'/wp-admin/includes/media.php');
								require_once (ABSPATH.'/wp-admin/includes/file.php');
								require_once (ABSPATH.'/wp-admin/includes/image.php');

								

								$attachmentId = media_handle_upload($__var_name, $created_event_id);
								unset($_FILES);

								set_post_thumbnail($created_event_id, $attachmentId);
								$this->create_custom_fields($created_event_id, 'ftimg', $attachmentId);
								

							}
						}
				}
				
				// current user 
					$current_user = wp_get_current_user();
					// if user is logged in
					if(!empty($current_user)){
						// get the user email if the user is logged in and has email
						$cu_email = $current_user->user_email;						
					}

				// assign author is set to do so
					if(is_user_logged_in() && !empty($this->evoau_opt['evoau_assignu']) && $this->evoau_opt['evoau_assignu']=='yes'){
						
						// if user is logged in
						if(!empty($current_user)){							
							wp_set_object_terms( $created_event_id, array( $current_user->ID ), 'event_users' );
						}
					}

				// generate google maps
					if(!empty($this->evoau_opt['evoau_genGM']) && $this->evoau_opt['evoau_genGM']=='yes' && !empty($_POST['evcal_location'])){					
						$this->create_custom_fields($created_event_id, 'evcal_gmap_gen', $_POST['evcal_location']);
					}
				

				// save submitter email address
					if(!empty($_POST['yourname']) && isset($_POST['yourname']))
						$this->create_custom_fields($created_event_id, '_submitter_name', $_POST['yourname']);

					// save email address for submitter
					if(!empty($_POST['youremail']) && isset($_POST['youremail'])){
						$this->create_custom_fields($created_event_id, '_submitter_email', $_POST['youremail']);
					}elseif(!empty($cu_email)){
						// save current user email if it exist
						$this->create_custom_fields($created_event_id, '_submitter_email', $cu_email);
					}


				// save whether to notify when draft is published if submission saved as draft
					if((empty($this->evoau_opt['evoau_post_status'])) || 
						( !empty($this->evoau_opt['evoau_post_status']) && $this->evoau_opt['evoau_post_status']=='draft' )){
						$this->create_custom_fields($created_event_id, '_send_publish_email', 'true');
					}
				

				// email notification
					$__evo_admin_email = get_option('admin_email');
					$this->send_au_email_notif($created_event_id, $__evo_admin_email);
					$this->send_submitter_email_notif($created_event_id, $__evo_admin_email);
				


				$status=true;
			}else{	$status=false;	}
			
			return $status;
		}
		
	
	// FORM Fields for the front end form
		public function au_form_fields($var=''){
			$evcal_opt = $this->options;

			$et = eventon_get_event_tax_name('et', $evcal_opt);
			$et2 = eventon_get_event_tax_name('et2', $evcal_opt);
			// array format = regular name, metabox variable name, type, placeholder text, lang variable
			
			$event_fields = apply_filters('evoau_form_fields', array(
				
				'event_name'=>array('Event Name', 'event_name', 'text'),
				'event_description'=>array('Event Details', 'event_description', 'textarea','','evcal_evcard_details'),
				'event_start_date'=>array('Event Start Date/Time', 'evcal_start_date', 'select'),
				'event_end_date'=>array('Event End Date/Time', 'event_end_date', 'select'),
				'event_location_name'=>array('Event Location Name', 'evcal_location_name', 'text','', 'evcal_lang_location_name'),
				'event_location'=>array('Event Location Address', 'evcal_location', 'text','','evcal_lang_location'),
				'event_color'=>array('Event Color', 'evcal_event_color', 'color','evoAUL_ec'),
				'event_organizer'=>array('Event Organizer', 'evcal_organizer', 'text','','evoAUL_eo'),
				'event_type'=>array('Select the '. $et, 'event_type', 'tax','','evoAUL_stet'),
				'event_type_2'=>array('Select the '. $et2, 'event_type_2', 'tax','','evoAUL_stet2'),
				'event_image'=>array('Event Image', 'event_image', 'image','','evoAUL_ei'),
				'yourname'=>array('Your Full Name', 'yourname', 'text','','evoAUL_fn','req'),
				'youremail'=>array('Your Email Address', 'youremail', 'text','','evoAUL_ea','req'),
			));

			// get custom meta fields for 
			
			for($x=1; $x<4; $x++){	
				$new_additions='';

				if(eventon_is_custom_meta_field_good($x, $evcal_opt)){

					$index = 'evo_customfield_'.$x;
					$_variable_name = '_evcal_ec_f'.$x.'a1_cus';
					$_field_name = $evcal_opt['evcal_ec_f'.$x.'a1'];

					$new_additions[$index]= array(
						$_field_name, $_variable_name,  'text'
					);

					$event_fields = array_merge($event_fields, $new_additions);
				}
			}
			
			// return certain fields from above list
				if($var=='savefields'){
					unset($event_fields['event_name']);
					unset($event_fields['event_start_date']);
					unset($event_fields['event_end_date']);
					unset($event_fields['event_description']);
					unset($event_fields['yourname']);
					unset($event_fields['youremail']);
				}
				if($var=='additional'){
					unset($event_fields['event_name']);
					unset($event_fields['event_start_date']);
					unset($event_fields['event_end_date']);
				}
				
				if($var=='default'){
					$event_fields = array(
						'event_name'=>'Event Name',
						'event_start_date'=>'Event Start Date/ Time',
						'event_end_date'=>'Event End Date/ Time'
					);
				}
			
			
			return $event_fields;
		}
	
	
	
	// SUPPORT FUNCTIONS

		// USER and CAPABILITIES

			// USERS page: Add capabilities edit button each users line
			function evoAU_user_row($actions, $user)  {
				global $pagenow;
				if ($pagenow == 'users.php') {				
					if (current_user_can( 'manage_eventon' )) {
					  $actions['evo_capabilities'] = '<a href="' . 
						wp_nonce_url("admin.php?page=action_user&tab=evoau_2&"."object=user&amp;user_id={$user->ID}", "evo_user_{$user->ID}") . 
						'">' . __('EventON Capabilities', 'eventon') . '</a>';
					}      
				}
				return $actions;
			}
			// MENUS
			function evoAU_add_menu_pages(){
				add_submenu_page( 'eventon', 'Action User', 'Action User', 'manage_eventon', 'action_user', array($this,'evoAU_action_user_fnct') );
			}
				function evoAU_action_user_fnct(){
					require_once('includes/settings_page.php');
					action_user_settings();
				}

			// UPDATE user/role capabilities
			function update_role_caps($ID, $type='role', $action=''){
				global $_POST;
				
				$caps = eventon_get_core_capabilities();
				
				if($type=='role'){
					global $wp_roles;
					
					$current_role_caps = $wp_roles->get_role($ID);		
					$cur_role_caps = ($current_role_caps->capabilities);
					
					foreach($caps as $capgroupf=>$capgroup){			
						foreach($capgroup as $cap){
							
							// add cap
							// If capability exist currently
							if(array_key_exists($cap, $cur_role_caps)){ 
								if($_POST[$cap]=='no'){
									$wp_roles->remove_cap( $ID, $cap );
								}
							}else{// if capability doesnt exists currently
								if($_POST[$cap]=='yes'){
									$wp_roles->add_cap( $ID, $cap );
								}
							}					
						}
					}		
				}else if($type=='user'){
					$currentuser = new WP_User( $ID );
					$cur_role_caps = $currentuser->allcaps;
					
					foreach($caps as $capgroupf=>$capgroup){			
						foreach($capgroup as $cap){					
							// add cap
							// If capability exist currently
							if(array_key_exists($cap, $cur_role_caps)){ 
								if($_POST[$cap]=='no'){
									$currentuser->remove_cap( $cap );
								}
							}else{// if capability doesnt exists currently
								if($_POST[$cap]=='yes'){
									$currentuser->add_cap( $cap );
								}
							}					
						}
					}
				}
			}
	

		/** Create the event post	 */
			function create_post() {

				//$post_id = -1;
			
				// event post status
				$opt_draft = (!empty($this->evoau_opt['evoau_post_status']))?
					$this->evoau_opt['evoau_post_status']:'draft'; 
					
		        $type = 'ajde_events';
		        $valid_type = (function_exists('post_type_exists') &&  post_type_exists($type));

		        if (!$valid_type) {
		            $this->log['error']["type-{$type}"] = sprintf(
		                'Unknown post type "%s".', $type);
		        }

		        $__post_content = (!empty($_POST['event_description']))?
		        	wpautop(convert_chars(stripslashes($_POST['event_description']))): null;

		        $new_post = array(
		            'post_title'   => wp_strip_all_tags($_POST['event_name']),
		            'post_content' => $__post_content,
		            'post_status'  => $opt_draft,
		            'post_type'    => $type,
		            'post_date'    => $this->get_event_post_date(),
		            'post_name'    => sanitize_title($_POST['event_name']),
		            'post_author'  => $this->get_author_id(),
		        );
		       
		        // create!
		      	$post_id = wp_insert_post($new_post);

		       
		        if ('page' !== $type && !$post_id) {
		            // cleanup new categories on failure
		            foreach ($cats['cleanup'] as $c) {
		                wp_delete_term($c, 'category');
		            }
		        }
		        

		        return $post_id;
		    }	

    	// return HTML content for eventON role editor admin settings
		// type = role, user
		function get_cap_list_admin($ID, $type='role'){
			
			$content = $content_l = $content_r ='';	
			$count=1;
			if($type =='role'){
				global $wp_roles;
				$wp_roles = new WP_Roles();
									
				$current_role_caps = $wp_roles->get_role($ID);			
				$cur_role_caps = ($current_role_caps->capabilities);			
				
			}else if($type=='user'){
				$currentuser = new WP_User( $ID );
				$cur_role_caps = $currentuser->allcaps;
			}
			
			
			$caps = eventon_get_core_capabilities();
			foreach($caps as $capgroupf=>$capgroup){
				
				foreach($capgroup as $cap){
					$rowcap = $cap;
					
					if($capgroupf=='core'){
						$cap = str_replace('eventon','eventon Settings', $cap);
					}else{
						$cap = str_replace('eventon','event', $cap);
					}
					
					$human_nam = ucwords(str_replace('_',' ',$cap));
					
					$yesno_val = (isset($cur_role_caps[$rowcap]))? 'yes':'no';
					$disabled = ($ID=='administrator')?'disable':null;
					
					$yesno_btn = eventon_html_yesnobtn(array('var'=>$yesno_val));

					$content= '<p class="yesno_row">'.$yesno_btn.'<input type="hidden" name="'.$rowcap.'" value="'.$yesno_val.'"><span class="field_name">'.$human_nam.'</span></p>';
					
					if($count >10){
						$content_r .=$content;
					}else{
						$content_l .=$content;
					}
					
					$count++;
				}
			}
			
			$content = "<table width='100%' ><tr><td valign='top'>".$content_l."</td><td valign='top'>".$content_r."</td></tr></table>";
			
			return $content;
		}

    	// send email notification of new events
		function send_au_email_notif($event_id, $admin_email){

			$__evo_admin_email = $admin_email;
			
			$_adminurl = get_admin_url();
			$_live_link = get_permalink($event_id);
			$_title = get_the_title($event_id);

			if(!empty($this->evoau_opt['evoau_notif']) && ($this->evoau_opt['evoau_notif'])=='yes'){
				
				$to = (!empty( $this->evoau_opt['evoau_ntf_admin_to'])) ? htmlspecialchars_decode($this->evoau_opt['evoau_ntf_admin_to']):$__evo_admin_email;

				$from = (!empty( $this->evoau_opt['evoau_ntf_admin_from'])) ? htmlspecialchars_decode($this->evoau_opt['evoau_ntf_admin_from']) : $__evo_admin_email;

				$subject = (!empty( $this->evoau_opt['evoau_ntf_admin_subject'])) ? $this->evoau_opt['evoau_ntf_admin_subject'] : 'New Event Submission';

				$_message = (!empty( $this->evoau_opt['evoau_ntf_admin_msg'])) ? $this->evoau_opt['evoau_ntf_admin_msg'] : 'You have a new event submission!';

				$__link = "<a target='_blank' href='".$_adminurl. "post.php?post=".$event_id."&action=edit'>Edit Event: ".$_title."</a>";

				$message = $this->_get_email_body($__link, $_message);

				$send_wp_mail = $this->send_email($to, $from, $subject, $message);
				
				return $send_wp_mail;

			}
		}

		// send email to event submitter
		function send_submitter_email_notif($event_id, $admin_email){
			$__evo_admin_email = $admin_email;	
			
			if(!empty($this->evoau_opt['evoau_notsubmitter']) && ($this->evoau_opt['evoau_notsubmitter'])=='yes' ){

				
				// current user if there is any
				$current_user = wp_get_current_user();

				if(!empty($current_user->user_email) || (!empty($_POST['youremail']) && isset($_POST['youremail'])) ){

					// use the correct email address logged in email first and then submitted email
					$to = (!empty($current_user->user_email))? $current_user->user_email: $_POST['youremail'];

					$from = (!empty( $this->evoau_opt['evoau_ntf_user_from'])) ? htmlspecialchars_decode($this->evoau_opt['evoau_ntf_user_from']) : $__evo_admin_email;

					$subject = (!empty( $this->evoau_opt['evoau_ntf_drf_subject'])) ? $this->evoau_opt['evoau_ntf_drf_subject'] : 'We have received your event!';

					$_message = (!empty( $this->evoau_opt['evoau_ntf_drf_msg'])) ? $this->evoau_opt['evoau_ntf_drf_msg'] : 'Thank you for submitting your event!';
					
					$message = $this->_get_email_body('', $_message);

					$send_wp_mail = $this->send_email($to, $from, $subject, $message);
					
					return $send_wp_mail;
				}

			}
			
		}

		
		// when event is published or apporved and published
		function send_approval_email($new_status, $old_status, $post){

			$post_type  = get_post_type($post->ID);
			if( $post_type !== 'ajde_events' )
       			return;

			if($old_status == 'draft' && $new_status == 'publish'){

				$pmv = get_post_custom($post->ID);
				$event_id = $post->ID;
				$this->create_custom_fields($event_id, 'tester', 'sendOut');

				// settings set to send approval email notifications and the event is set to notify upon event approval (publish) 
				if(!empty($this->evoau_opt['evoau_notsubmitterAP']) 
					&& ($this->evoau_opt['evoau_notsubmitterAP'])=='yes' 
					&& ( !empty($pmv['_send_publish_email']) && $pmv['_send_publish_email'][0]=='true')
					&&  !empty($pmv['_submitter_email']) 
				){
									

					$_live_link = get_permalink($event_id);
					$_title = get_the_title($event_id);

					$this->create_custom_fields($event_id, 'tester', 'send');


					$to = $pmv['_submitter_email'][0];

					$from = (!empty( $this->evoau_opt['evoau_ntf_pub_from'])) ? htmlspecialchars_decode($this->evoau_opt['evoau_ntf_pub_from']) : $__evo_admin_email;

					$subject = (!empty( $this->evoau_opt['evoau_ntf_pub_subject'])) ? $this->evoau_opt['evoau_ntf_pub_subject'] : 'We have approved your event!';

					$_message = (!empty( $this->evoau_opt['evoau_ntf_pub_msg'])) ? $this->evoau_opt['evoau_ntf_pub_msg'] : 'Thank you for submitting your event and we have approved it!';

					$__link = "<a target='_blank' href='".$_live_link. "'>".$_title."</a>";

					$message = $this->_get_email_body($__link, $_message);

					$send_wp_mail = $this->send_email($to, $from, $subject, $message);

					// set post meta to not send emails again 
					update_post_meta($event_id, '_send_publish_email', 'no');
					
					return $send_wp_mail;

				}
			}
		}

		// ACTUAL SENDING OF EMAIL
			function send_email($to, $from, $subject, $message){
				
				add_filter('wp_mail_content_type',create_function('', 'return "text/html";'));

				$headers = 'From: '.$from;
				$send_wp_mail = wp_mail($to, $subject, $message, $headers);
					
				return $send_wp_mail;
			}
		

		// GET email body for messages
			function _get_email_body($__link, $message){
				global $eventon;

				$this->link = $__link;
				$this->message = $message;
				
				$path = plugin_dir_path( __FILE__ ).'templates/';

				return $eventon->get_email_body('notif_email',$path);
			}
	




		// TAXONOMY 
		// event_users
			function create_user_tax(){
				register_taxonomy( 'event_users', 
					apply_filters( 'eventon_taxonomy_objects_event_users', array('ajde_events') ),
					apply_filters( 'eventon_taxonomy_args_event_users', array(
						'hierarchical' => true, 
						'label' => 'EvenON Users', 
						'show_ui' => false,
						'query_var' => true,
						'capabilities'			=> array(
							'manage_terms' 		=> 'manage_eventon_terms',
							'edit_terms' 		=> 'edit_eventon_terms',
							'delete_terms' 		=> 'delete_eventon_terms',
							'assign_terms' 		=> 'assign_eventon_terms',
						),
						'rewrite' => array( 'slug' => 'event-user' ) 
					)) 
				);
			}
		// add a new capability to be able to manage eventon user capabilities
			function add_new_capability_au($caps){
				$new_caps = $caps;
				
				$new_caps[] = 'manage_eventon_user_capabilities';
				
				return $new_caps;
			}
	
		
		
	
		/* SCRIPTS */
			function evoau_admin_scripts(){
				global $pagenow;
				
				if($pagenow=='admin.php' && $_GET['page']=='action_user'){			
					wp_register_script( 'evo_au_backend_admin',$this->plugin_url.'/assets/au_script_b_admin.js',array('jquery'),'1.0',true);
					wp_localize_script( 'evo_au_backend_admin', 'the_ajax_script', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
					
					wp_enqueue_script('evo_au_backend_admin');
				}
			}
			function backend_post_scripts(){
				wp_enqueue_script( 'evo_au_backend',$this->plugin_url.'/assets/au_script_b.js',array('jquery'),'1.0',true);
			}
		
		//REGISTER scripts
			function register_frontend_scripts(){
				wp_register_script( 'evo_au_frontend',$this->plugin_url.'/assets/au_script_f.js',array('jquery','jquery-ui-core','jquery-ui-datepicker'), 1.0, true );
				wp_register_script( 'evo_au_timepicker',AJDE_EVCAL_URL.'/assets/js/jquery.timepicker.js',array('jquery'), 1.0, true );

				wp_register_script('backender_colorpicker',AJDE_EVCAL_URL.'/assets/js/colorpicker.js' ,array('jquery'),'1.0', true);
				wp_register_style( 'colorpicker_styles',AJDE_EVCAL_URL.'/assets/css/colorpicker_styles.css');

				wp_register_style( 'evo_au_styles_f',$this->plugin_url.'/assets/au_styles.css');


			}
		
		// ENQUEUE
			public function print_frontend_scripts(){
				$calendar_ui_style_src = AJDE_EVCAL_URL.'/assets/css/jquery-ui.min.css';
				
				$eventon_JQ_UI_tp = AJDE_EVCAL_URL.'/assets/css/jquery.timepicker.css';
				wp_enqueue_style( 'eventon_JQ_UI',$calendar_ui_style_src);
				wp_enqueue_style( 'eventon_JQ_UI_tp',$eventon_JQ_UI_tp);
				wp_enqueue_style( 'evo_au_styles_f');
				wp_enqueue_style( 'colorpicker_styles');
				
				wp_enqueue_script('backender_colorpicker');	
				wp_enqueue_script('evo_au_timepicker');	
				wp_enqueue_script('evo_au_frontend');			
			}
		

	// SECONDARY FUNCTIONS
		function create_custom_fields($post_id, $field, $value) {       
	        add_post_meta($post_id, $field, $value);
	    }
    	function get_author_id() {
			$current_user = wp_get_current_user();
	        return (($current_user instanceof WP_User)) ? $current_user->ID : 0;
	    }	
	    function get_event_post_date() {
	        return date('Y-m-d H:i:s', time());        
	    }


		// ACTIVATION
			function activate(){
				// add actionUser addon to eventon addons list
				$this->addon->activate();
			}
			

			// DISPLAY Warning
			function _no_eventon_warning(){
		        ?>
		        <div class="message error"><p><?php printf(__('EventON %s is enabled but not effective. It requires <a href="%s">EventON</a> in order to work.', 'eventon'), $this->name, 
		            'http://www.myeventon.com/'); ?></p></div>
		        <?php
		    }
		   
		
			// Deactivate addon
			function deactivate(){
				$this->addon->remove_addon();
			}
	
}

// Initiate this addon within the plugin
$GLOBALS['eventon_au'] = new eventon_au();




?>