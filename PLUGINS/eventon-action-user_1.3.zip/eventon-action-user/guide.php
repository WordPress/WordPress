<?php
echo "
<p><b>[add_evo_submission_form]</b> - add event submission form to frontend pages<br/><br/>

<b>[add_eventon users='1,2']</b> - Create calendars with events from only certain users.<br/><br/>

You can control the permission for each user role by going to <b>myEventON> Action User> User Capabilities</b>
</p>



<p><b>Requirements:</b> EventON version 2.2 or higher</p>
";
?>