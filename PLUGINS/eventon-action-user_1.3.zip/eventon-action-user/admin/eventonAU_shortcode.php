<?php
/**
 * EventON ActionUser shortcode
 *
 * Handles all shortcode related functions
 *
 * @author 		AJDE
 * @category 	Core
 * @package 	ActionUser/Functions/shortcode
 * @version     0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// user event submission form	
function output_event_submission_form($atts){
	global $eventon_au, $eventon;	
	
	ob_start();
		
	echo $eventon_au->output_event_submission_form();
	
	return ob_get_clean();
			
}
add_shortcode('add_evo_submission_form','output_event_submission_form');


// add new default shortcode arguments
	function evoAU_add_shortcode_defaults($arr){	
		return array_merge($arr, array(
			'users'=>'all',
		));	
	}
	add_filter('eventon_shortcode_defaults', 'evoAU_add_shortcode_defaults', 10, 1);

// Add user IDs field to shordcode basic cal version
	function add_actionuser_fields_to_eventon_basic_cal($array){
		
		$field = array(
				'name'=>'User IDs',
				'placeholder'=>'eg. 8,19',
				'type'=>'text',
				'instruct'=>'Show events below to only these user IDs',
				'var'=>'users',
				'default'=>'all'
			);
		$array[] = $field;
		
		return $array; 
		
	}
	add_filter('eventon_basiccal_shortcodebox','add_actionuser_fields_to_eventon_basic_cal', 10, 1);


/*	ADD shortcode buttons to eventON shortcode popup*/
	function evoAU_add_shortcode_options($shortcode_array){
		global $evo_shortcode_box;
		
		$new_shortcode_array = array(
			array(
				'id'=>'s_AU',
				'name'=>'Action User - event submission form',
				'code'=>'add_evo_submission_form',
				'variables'=>''
			)
		);

		return array_merge($shortcode_array, $new_shortcode_array);
	}
	add_filter('eventon_shortcode_popup','evoAU_add_shortcode_options', 10, 1);

?>