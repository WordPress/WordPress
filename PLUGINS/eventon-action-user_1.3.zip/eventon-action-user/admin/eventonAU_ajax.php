<?php
/**
 * EventON ActionUser Ajax Handlers
 *
 * Handles AJAX requests via wp_ajax hook (both admin and front-end events)
 *
 * @author 		AJDE
 * @category 	Core
 * @package 	ActionUser/Functions/AJAX
 * @version     0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 *	AJAX
 */
function load_new_role_caps_admin(){
	global $eventon_au;
	
	$role = $_POST['role'];		
		
	$content = $eventon_au->get_cap_list_admin($role);
	
	$return_content = array(
		'content'=> $content,
		'status'=>'ok'
	);
	
	echo json_encode($return_content);		
	exit;
}
add_action('wp_ajax_the_ajax_au', 'load_new_role_caps_admin');
add_action('wp_ajax_nopriv_the_ajax_au',  'load_new_role_caps_admin');



// verify license for addon


?>