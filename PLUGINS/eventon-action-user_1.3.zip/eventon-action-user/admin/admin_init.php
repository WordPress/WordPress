<?php
/*
	Action User admin functions
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


function evoAU_admin_init(){

	add_action('eventon_add_meta_boxes', 'evoAU_trigger_meta_box' );
	add_action('eventon_save_meta', 'evoAU_save_meta_box_values', 10, 2);
	add_filter('eventon_settings_lang_tab_content', 'evoAU_language_additions', 10, 1);
	add_filter('eventon_inline_styles_array', 'evoAU_dynamicstyle_insertion', 10, 1);
}
add_action('admin_init', 'evoAU_admin_init');


// Add settings to dynamic styles
	function evoAU_dynamicstyle_insertion($_existen){
		$new= array(
			array(
				'item'=>'#eventon_form .submit_row input',
				'multicss'=>array(
					array('css'=>'color:#$', 'var'=>'evcal_gen_btn_fc',	'default'=>'ffffff'),
					array('css'=>'background:#$', 'var'=>'evcal_gen_btn_bgc',	'default'=>'237ebd')
				)
			),array(
				'item'=>'#eventon_form .submit_row input:hover',
				'multicss'=>array(
					array('css'=>'color:#$', 'var'=>'evcal_gen_btn_fcx',	'default'=>'fff'),
					array('css'=>'background-color:#$', 'var'=>'evcal_gen_btn_bgcx',	'default'=>'237ebd')
				)
			)
		);

		return (is_array($_existen))? array_merge($_existen, $new): $_existen;
	}

// language settings additinos
	function evoAU_language_additions($_existen){
		$new_ar = array(
				array('type'=>'togheader','name'=>'Action User Form Fields'),
				array('label'=>'Event Name','name'=>'evoAUL_evn','legend'=>''),
				array('label'=>'Event Start Date/Time','name'=>'evoAUL_esdt','legend'=>''),
				array('label'=>'Event End Date/Time','name'=>'evoAUL_eedt','legend'=>''),
				array('label'=>'Event Color','name'=>'evoAUL_ec','legend'=>''),
				array('label'=>'Event Organizer','name'=>'evoAUL_eo','legend'=>''),
				array('label'=>'Select the Evnt Type','name'=>'evoAUL_stet','legend'=>''),
				array('label'=>'Select the Evnt Type 2','name'=>'evoAUL_stet2','legend'=>''),
				array('label'=>'Event Image','name'=>'evoAUL_ei','legend'=>''),
				array('label'=>'Submit Event','name'=>'evoAUL_se','legend'=>''),
				array('label'=>'All Day Event','name'=>'evoAUL_001','legend'=>''),
				array('label'=>'No End time','name'=>'evoAUL_002','legend'=>''),
				array('label'=>'Your Full Name','name'=>'evoAUL_fn','legend'=>''),
				array('label'=>'Your Email Address','name'=>'evoAUL_ea','legend'=>''),

				array('label'=>'Form field placeholders','type'=>'subheader'),
					array('label'=>'Start Date','name'=>'evoAUL_phsd','legend'=>''),
					array('label'=>'Start Time','name'=>'evoAUL_phst','legend'=>''),
					array('label'=>'End Date','name'=>'evoAUL_phed','legend'=>''),
					array('label'=>'End Time','name'=>'evoAUL_phet','legend'=>''),
				array('type'=>'togend'),
				array('type'=>'togend'),
			);
			return (is_array($_existen))? array_merge($_existen, $new_ar): $_existen;
	}


// ADD meta box on events page
	function evoAU_trigger_meta_box(){	
		// restrict access to user permission set box only to those can manage eventon
		if ( !current_user_can( 'manage_eventon' ) ) return;
		add_meta_box('ajdeevcal_mb_au','Assign Users',  'evoAU_meta_box','ajde_events', 'side', 'low');	
	}

// ADMIN stylesheet
	function eveoAU_admin_setting_styles(){
		global $eventon_au;
		wp_enqueue_style( 'au_backend_settings',$eventon_au->plugin_url.'/assets/au_styles_settings.css');
	}
	add_action( 'admin_enqueue_scripts', 'eveoAU_admin_setting_styles' );


/*	Action User META BOX for events post page*/
	function evoAU_meta_box(){
		global $eventon; 
		
		$all_users = get_users();
		
		echo $eventon->output_eventon_pop_window( 
			array('content'=>"<p>Loading</p>",
				'title'=>'Select the users you want to assign to this event',
				'type'=>'padded'
				) );
				
		// Use nonce for verification
		//wp_nonce_field( plugin_basename( __FILE__ ), 'evo_noncename_au' );
		
		// The actual fields for data entry
		$p_id = get_the_ID();
		$pmv = get_post_custom($p_id);
		
		$saved_users = wp_get_object_terms($p_id, 'event_users', array('fields'=>'slugs'));
		$saved_users = (!empty($saved_users))? $saved_users:null;
		//print_r($terms);
		
	?>
		<div id='popup_content'>
			<div id='evoau_users' style='display:none'>
				<p><i>NOTE: Assigning events to users will allow you to create calendars with events from certain users.</i></p>
				<div id='evoau_us_list'>
				<?php
					$checkbox_state='';
					foreach($all_users as $uu){
						
						if(is_array($saved_users)){
							$checkbox_state = ( !empty($saved_users) && in_array($uu->ID, $saved_users))?'checked="checked"':null;
						}
						
						echo "<p><input name='evoau_users[]' id='evoau_".$uu->ID."' class='evoau_user_list_item' type='checkbox' value='".$uu->ID."' uname='".$uu->display_name."' ".$checkbox_state."> ".$uu->display_name."</p>";
					}
				?>
				</div>
				<a id='' class='evo_admin_btn btn_prime evo_close_pop_trig'>Save</a>
			</div>
		</div>
		
		
		<table id="meta_tb2" class="form-table meta_tb" >
		<tr><td>				
				<a class='button eventon_popup_trig' content_id='evoau_users' dynamic_c='yes'>Manage Assigned Users</a>				
				<p>Assign users to this event.</p>
				<?php if(!empty($pmv['_submitter_name']) && !empty($pmv['_submitter_email'])):?>
					<p><i>Event submitted by: <b><?php echo $pmv['_submitter_name'][0]?> (<?php echo $pmv['_submitter_email'][0];?>)</b></i></p>
				<?php endif;?>

				<?php //$pmv['_send_publish_email'][0].$pmv['_submitter_email'][0];
				?>
		</td></tr>
		</table>
	<?php
	}
		
// SAVE meta box values for user assignments
function evoAU_save_meta_box_values($fields, $post_id){		
	
	$users = (!empty($_POST['evoau_users']))? $_POST['evoau_users']:null;		
	$tagged = wp_set_object_terms( $post_id, $users, 'event_users' );
	
}