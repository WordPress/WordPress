<?php

/*
	Action User settings page
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function action_user_settings(){
	global $eventon, $eventon_au;
	
	// Settings Tabs array
	$evcal_tabs = array(
		'evoau_1'=>__('General'), 
		'evoau_2'=>__('User Capabilities'),
	);	
	
	$focus_tab = (isset($_GET['tab']) )? sanitize_text_field( urldecode($_GET['tab'])):'evoau_1';
	$settings_page_role = (isset($_POST['current_role']))? $_POST['current_role']: 'administrator';
	
	
	// Update or add options
	if( isset($_POST['evoau_noncename']) && isset( $_POST ) ){
		if ( wp_verify_nonce( $_POST['evoau_noncename'], AJDE_EVCAL_BASENAME ) ){
			
			// update role caps
			if($focus_tab=='evoau_2'){				
				
				// User cap edit
				if(isset($_GET['object']) && isset($_GET['user_id'])){
					
					$current_edit_user = $_GET['user_id'];
					
					if(isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'] , 'evo_user_'.$current_edit_user) ){
						
						$eventon_au->update_role_caps($current_edit_user, 'user','post');
						$_POST['settings-updated']='Capabilities updated successfully.';
					
					}else{
						$_POST['settings-updated']='Could not verify required information.';
					}
					
				// role cap edit
				}else{				
					if($settings_page_role!='administrator'){
						//echo $role;
						$eventon_au->update_role_caps($settings_page_role, 'role','post');
						
						$_POST['settings-updated']=$settings_page_role.' capabilities have been updated.';
					}else{
						$_POST['settings-updated']='You can not change Administrator capabilities.';
					}
				}
			}else{
				foreach($_POST as $pf=>$pv){
					$pv = (is_array($pv))? $pv: (htmlspecialchars ($pv) );
					$evcal_options[$pf] = $pv;					
				}
				update_option('evcal_options_'.$focus_tab, $evcal_options);
				$_POST['settings-updated']='Successfully updated values.';
			}
			
		}else{
			die( __( 'Action failed. Please refresh the page and retry.', 'eventon' ) );
		}	
	}
?>
<div class="wrap" id='evcal_settings'>
	<div id='eventon'><div id="icon-themes" class="icon32"></div></div>
	<h2>Action User Settings </h2>
	<h2 class='nav-tab-wrapper' id='meta_tabs'>
		<?php					
			foreach($evcal_tabs as $nt=>$ntv){
				
				if(($nt=='evoau_2' && current_user_can('manage_eventon_user_capabilities')) || $nt!='evoau_2'){
				
				$evo_notification='';
				echo "<a href='?page=action_user&tab=".$nt."' class='nav-tab ".( ($focus_tab == $nt)? 'nav-tab-active':null)."' evcal_meta='evcal_1'>".$ntv.$evo_notification."</a>";
				}
			}			
		?>
		
	</h2>	
<div class='evo_settings_box'>		
<?php
	
	$updated_code = (isset($_POST['settings-updated']))? '<div class="updated fade"><p>'.$_POST['settings-updated'].'</p></div>':null;
	echo $updated_code;
				
	
	switch ($focus_tab):
	
	case "evoau_1":
		
		$eventon->load_ajde_backender();
		?>
		<form method="post" action=""><?php settings_fields('evoau_field_group'); 
			wp_nonce_field( AJDE_EVCAL_BASENAME, 'evoau_noncename' );
		?>
		<div id="evoau_1" class="evcal_admin_meta evcal_focus">		
			<div class="inside">
				<?php	

					$evcal_opt= get_option('evcal_options_evoau_1');
					$__evo_admin_email = get_option('admin_email');

					foreach($eventon_au->au_form_fields('additional') as $field=>$fn){
						$fieldar[$field]=$fn[0];
					}

					// get all event type categories
					$ett = get_terms('event_type_2');
					if(!empty($ett) && !is_wp_error($ett)){
						foreach($ett as $term){
							$au_ett[ $term->term_id] = $term->name;
						}
					}else{
						$au_ett['-']='None';
					}

					// event type #1 name 
					$ett_name = eventon_get_event_tax_name('et2');
					
					
					$cutomization_pg_array = array(
						array(
							'id'=>'evoAU1',
							'name'=>'Front-end Event Submission form',
							'tab_name'=>'Event Submission Form',
							'display'=>'show',
							'top'=>'4',
							'fields'=>array(
								array('id'=>'evoau_access','type'=>'yesno','name'=>'Block form submissions to logged-in users only','legend'=>'This will allow you to only give event submission form access to loggedin users.'),
								array('id'=>'evo_au_title','type'=>'text','name'=>'Form Header Text',),
								array('id'=>'evo_au_stitle','type'=>'text','name'=>'Form Subheader Text',),
								array('id'=>'evoau_fields', 'type'=>'checkboxes','name'=>'Additional 
								fields for the event submission form: <i>(NOTE: Event Name, Start and End date/time are default fields)</i><br/><a href="'.get_admin_url().'admin.php?page=eventon&tab=evcal_2">Customize text for form field names</a>',
									'options'=> $fieldar,
								),
								array('id'=>'evoau_genGM','type'=>'yesno','name'=>'Generate google maps from submitted location address',),
								array('id'=>'evoau_post_status','type'=>'dropdown','name'=>'Submitted event\'s default post status','width'=>'full',
									'options'=>array(
										'draft'=>'Draft',
										'publish'=>'Publish',
										'private'=>'Private')
									),
								array('id'=>'evoau_assignu','type'=>'yesno','name'=>'Assign logged-in user to event after successful event submission',),
								array('id'=>'evoau_set_def_ett','type'=>'yesno','name'=>'Set default event type category tag for event submissions','afterstatement'=>'evoau_set_def_ett','legend'=>'This will assign a selected event type category tag to the submitted event by default.'),
								array('id'=>'evoau_set_def_ett','type'=>'begin_afterstatement'),
									array('id'=>'evoau_def_ett_v','type'=>'dropdown','name'=>'Select default '.$ett_name.' tag for submitted events','width'=>'full',
									'options'=>$au_ett,),
								array('id'=>'evoau_set_def_ett','type'=>'end_afterstatement'),
																
								
						)),
						array(
							'id'=>'evoAU2',
							'name'=>'Form Notifications',
							'tab_name'=>'Form Notifications',
							'fields'=>array(
								array('id'=>'evoau_notif','type'=>'yesno','name'=>'Notify admin upon new event submission','afterstatement'=>'evoau_notif'),
								array('id'=>'evoau_notif','type'=>'begin_afterstatement'),
									
									array('id'=>'evoau_ntf_admin_to','type'=>'text','name'=>'Email address to send notification. (eg. you@domain.com)', 'legend'=>'You can add multiple email addresses seperated by commas to receive notifications of event submissions.','default'=>$__evo_admin_email),
									array('id'=>'evoau_ntf_admin_from','type'=>'text','name'=>'From eg. My Name &lt;myname@domain.com&gt; - Default will use admin email from this website'),
									array('id'=>'evoau_ntf_admin_subject','type'=>'text','name'=>'Email Subject line','default'=>'New Event Submission'),
									array('id'=>'evoau_ntf_admin_msg','type'=>'textarea','name'=>'Message body',),
								array('id'=>'evoau_notif','type'=>'end_afterstatement'),
								

								array('id'=>'evoau_notsubmitter','type'=>'yesno','name'=>'Notify submitter when they submit an event (if submitter email present)','afterstatement'=>'evoau_notsubmitter'),
								array('id'=>'evoau_notsubmitter','type'=>'begin_afterstatement'),

									array('id'=>'evoau_ntf_user_from','type'=>'text','name'=>'From eg. My Name &lt;myname@domain.com&gt; - Default will use admin email from this website', 'default'=>$__evo_admin_email),

									array('id'=>'evoau_ntf_drf_subject','type'=>'text','name'=>'Email Subject line','default'=>'We have received your event!'),
									array('id'=>'evoau_ntf_drf_msg','type'=>'textarea','name'=>'Message body','default'=>'Thank you for submitting your event!'),									

									
								array('id'=>'evoau_notsubmitterAP','type'=>'end_afterstatement'),


								array('id'=>'evoau_notsubmitterAP','type'=>'yesno','name'=>'Notify submitter when their event is approved (if submitter email present)','afterstatement'=>'evoau_notsubmitterAP','legend'=>'If you set the submitted events to be saved as drafts, you can use this message notifications to let them know when their event is approved'),
								array('id'=>'evoau_notsubmitterAP','type'=>'begin_afterstatement'),

									array('id'=>'evoau_ntf_pub_from','type'=>'text','name'=>'From eg. My Name &lt;myname@domain.com&gt; - Default will use admin email from this website', 'default'=>$__evo_admin_email),

								
									array('id'=>'evoau_ntf_pub_subject','type'=>'text','name'=>'Email Subject line','default'=>'We have approved your event!'),
									array('id'=>'evoau_ntf_pub_msg','type'=>'textarea','name'=>'Message body','default'=>'Thank you for submitting your event and we have approved it!'),

									
								array('id'=>'evoau_notsubmitterAP','type'=>'end_afterstatement'),
								
						)),array(
							'id'=>'evoAU3',
							'name'=>'Front-end form notification Messages',
							'tab_name'=>'Front-end Messages',
							'fields'=>array(
																
								array('id'=>'evoaun_msg_s','type'=>'textarea','name'=>'Successful event submission message',),
								array('id'=>'evoaun_msg_f','type'=>'textarea','name'=>'Required fields missing message',),
						)),
					);
					
					
					$updated_code = (isset($_POST['settings-updated']) && $_POST['settings-updated']=='true')? '<div class="updated fade"><p>Settings Saved</p></div>':null;
					echo $updated_code;
					
					$eventon->load_ajde_backender();		
					
					print_ajde_customization_form($cutomization_pg_array, $evcal_opt);
					
				?>
				
			</div>				
		</div>	
		<div class='evo_diag'>
			<input type="submit" class="evo_admin_btn btn_prime" value="<?php _e('Save Changes') ?>" /><br/><br/>
			<a target='_blank' href='http://www.myeventon.com/support/'><img src='<?php echo AJDE_EVCAL_URL;?>/assets/images/myeventon_resources.png'/></a>
		</div>
		
		</form>	
		
		
<?php  
	break;
	
	// PERMISSIONS TAB
	case "evoau_2":
		
		if(current_user_can('manage_eventon_user_capabilities')):
		
		$eventon->load_ajde_backender();
?>
		<form method="post" action=""><?php settings_fields('evoau_field_group'); wp_nonce_field( AJDE_EVCAL_BASENAME, 'evoau_noncename' );
				?>
		<div id="evoau_2" class="evcal_admin_meta evcal_focus">		
			<div class='postbox'>
			<div class="inside">
				
				<?php
					
					if(isset($_GET['object']) && isset($_GET['user_id'])&& $_GET['object']=='user'):
						
						$this_user_id = $_GET['user_id'];
						$cur_edit_user = new WP_User( $_GET['user_id'] );
						
						if (!is_multisite() || current_user_can('manage_network_users')) {
							$anchor_start = '<a href="' . wp_nonce_url("user-edit.php?user_id={$this_user_id}", 
							  "evo_user_{$this_user_id}") .'" >';
							$anchor_end = '</a>';
						} else {
							$anchor_start = '';
							$anchor_end = '';
						}
						$user_info = ' <span style="font-weight: bold;">'.$anchor_start. $cur_edit_user->user_login; 
						if ($cur_edit_user->display_name!==$cur_edit_user->user_login) {
							$user_info .= ' ('.$cur_edit_user->display_name.')';
						}
						
						$user_info .= $anchor_end.'</span>';
						if (is_multisite() && is_super_admin($this_user_id)) {
							$user_info .= '  <span style="font-weight: bold; color:red;">'. 	esc_html__('Network Super Admin', 'eventon') .'</span>';
						}
						
						
						
				?>
					<h3>Capabilities for user <?php echo $user_info;?></h3>
					<p>Primary Role: <b><?php echo $cur_edit_user->roles[0] ;?></b></p>
				
					<h4>EventON Capabilities</h4>
					
					<em class="hr_line noexpand"></em>
					<div class='capabilities_list evo_backender_uix'>
						<?php						
							echo $eventon_au->get_cap_list_admin($this_user_id, 'user');
						?>
					</div>
				
				<?php					
					else:
				?>
				
					<h3>Select Role and set Capabilities for eventON</h3>
					<p>Select Role <select id='evoau_role_selector' name='current_role'>
					<?php
						global $wp_roles;
							
						$roles = $wp_roles->get_names();
						
						//print_r($roles);
						foreach($roles as $role=>$rolev){
							$selected = ($settings_page_role==$role)?'selected':null;
							echo "<option value='{$role}' {$selected}>{$rolev}</option>";
						}
						
					?>
					</select></p>
				
					<em class="hr_line noexpand"></em>
					<p class="evoau_msg" style='display:none; padding-bottom:20px'>Loading..</p>
					<div class='capabilities_list evo_backender_uix'>
						<?php						
							echo $eventon_au->get_cap_list_admin($settings_page_role);
						?>
					</div>
					</p><i>NOTE: Administrator capabilities can not be changed.</i></p>
					
				<?php endif;?>
			</div>
			</div>
		</div>
		<input type="submit" class="evo_admin_btn btn_prime" value="<?php _e('Save Changes') ?>" /></form>
<?php	
		endif;
	break;
	
	
	
	endswitch;
	echo "</div>";
	
}

?>