/*
	Javascript: Eventon event lists
*/
jQuery(document).ready(function($){
	
	init();	
	
	
	// INITIATE script
	function init(){		

	}
	

	
});