<?php

/*
  * Shop breadcrumb
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 *
 * This file is empty on purpose.
 * Shoestrap already has breadcrumbs that are compatible with WooCommerce.
 * Use those instead.
 */