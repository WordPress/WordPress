<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
global $ss_framework;
echo $ss_framework->open_row( 'div', null, 'products', null );
?>