<?php
/*
Template Name: Sidebar - Main - Sidebar
*/

ss_get_template_part( 'page' );