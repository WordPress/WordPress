<?php
/*
Template Name: Full-Screen
*/

ss_get_template_part( 'page' );
