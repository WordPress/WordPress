<?php
/*
Template Name: Main - Sidebar
*/

ss_get_template_part( 'page' );
