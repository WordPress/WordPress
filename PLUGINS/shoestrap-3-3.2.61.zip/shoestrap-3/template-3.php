<?php
/*
Template Name: Sidebar - Sidebar - Main
*/

ss_get_template_part( 'page' );
