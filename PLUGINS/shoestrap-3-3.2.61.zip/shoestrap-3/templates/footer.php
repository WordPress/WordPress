<?php global $ss_framework; ?>
<footer id="page-footer" class="content-info" role="contentinfo">
	<?php echo $ss_framework->open_container( 'div' ); ?>
		<?php shoestrap_footer_content(); ?>
	<?php echo $ss_framework->close_container( 'div' ); ?>
</footer>