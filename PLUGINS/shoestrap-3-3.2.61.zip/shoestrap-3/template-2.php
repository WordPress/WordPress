<?php
/*
Template Name: Sidebar - Main
*/

ss_get_template_part( 'page' );
