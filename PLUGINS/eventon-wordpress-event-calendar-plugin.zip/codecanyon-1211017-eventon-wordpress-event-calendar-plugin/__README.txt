
----------
Installing via ftp

Step 1: Deactivate myEventON
Step 2: From FTP delete the eventON folder
Step 3: unzip the EventON plugin content into "wp-content/plugings/eventON" directory
Step 4: in WP-admin plugins and activate EventON

You should not lose any of your previously saved data in this process.


-----------

*** IMPORTANT --- version 2.2.8
 
After you update eventON make sure to go to myEventON>settings> appearance and click save changes to re-save the dynamic color changes you have made.


-----------

Support please reach us at www.myeventon.com/support