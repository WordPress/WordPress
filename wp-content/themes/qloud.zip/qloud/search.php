<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package WordPress
 * @subpackage qloud
 * @since 1.0
 * @version 1.0
 */

get_header(); 
?>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="container">
            <div class="row">
                <?php if ( ! is_active_sidebar('sidebar-1') ) { ?>
                <div class="col-md-12 col-sm-12">
                    <?php } else{  ?>
                    <div class="col-md-8 col-sm-12">
                        <?php } ?>

                        <?php
					if ( have_posts() ) : 
						/* Start the Loop */
						while ( have_posts() ) : the_post();

							/**
							 * Run the loop for the search to output the results.
							 * If you want to overload this in a child theme then include a file
							 * called content-search.php and that will be used instead.
							 */
							get_template_part( 'template-parts/post/content', 'excerpt' );

						endwhile; // End of the loop.

						qloud_pagination();

					else : ?>
                        <header class="page-header">
                            <h3 class="page-title">
                                <?php
									printf(
										/* translators: %s: search query */
										esc_html__( 'Search Results for: %s', 'qloud' ),
										'<span>' . get_search_query() . '</span>'
									);
								?>
                            </h3>
							<p><?php echo esc_html__( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'qloud' ); ?></p>
                        </header><!-- .page-header -->

                        <?php
							//get_search_form();

					endif;
					?>
                    </div>
                    <?php if ( is_active_sidebar('sidebar-1') ) { ?>
                    <div class="col-md-4 col-sm-12">
                        <?php get_sidebar(); ?>
                    </div>
                    <?php } ?>
                </div>
            </div>
    </main><!-- #main -->
</div><!-- container -->

<?php get_footer();