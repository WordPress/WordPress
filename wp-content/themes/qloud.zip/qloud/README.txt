=== Qloud ===

Contributors: automattic
Tags: one-column, two-columns, right-sidebar, flexible-header, accessibility-ready, custom-colors, custom-header, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, post-formats, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready

Requires at least: 5.0
Tested up to: 5.8
Requires PHP: 5.6+
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

A starter theme called Qloud.

== Description ==

Qloud brings your site to life with header video and immersive featured images. With a focus on business sites, it features multiple sections on the front page as well as widgets, navigation and social menus, a logo, and more. Personalize its asymmetrical grid with a custom color scheme and showcase your multimedia content with post formats. Our default theme for 2017 works great in many languages, for any abilities, and on any device.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Qloud includes support for Elementor.

== Changelog ==

= 2.6 - Nov 06 2021 =
* Bug Fixes

= 2.5 - 9th July 2021 =
* Bug Fixes

= 2.4 - 11May 2021 =
* Bug Fixes

= 1.9.1 - 11 Dec 2020 =
* WHMCS Template
* Bug Fixes

= 1.9 - 24 Nov 2020 =
* Minor Optimization
* Bug Fixes

= 1.8 - 12 Nov 2020 =
* WHMCS Bridge Page Support.

= 1.7 - 11 Nov 2020 =
* WHMCS Support.

= 1.6 - 17 Oct 2020 =
* Mobile Menu Improved. 

= 1.6 - 6 Sept 2020 =
* Code Cleaning.
* Theme options minor bug fixes.

= 1.3 - 1 April 2020 =
* HEALTH CARE Home Page.
* SERVERLESS APPS Home Page.

= 1.2 - 25 March 2020 =
* Footer color change bug fixed.
* Child Theme.se

= 1.2 - 20 March 2020 =
* CLOUD COMPUTE Page Add
* VOICE SERVICES Page Add

= 1.1 - 14 March 20 =
* CLOUD MEDIA SERVICES Page Add
* Portfolio 2 columns Page Add
* Portfolio 3 columns Page Add
* Portfolio 4 columns Page Add
* Portfolio Details Page Add

= 1.1 - 13 March 20 =
* CLOUD MEDIA SERVICES Page Add
* Portfolio 2 columns Page Add
* Portfolio 3 columns Page Add
* Portfolio 4 columns Page Add
* Portfolio Details Page Add

= 1.0 - 25 Feb 2020 =
* Initial release
