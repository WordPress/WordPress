<?php
/**
 * module return as json_encode
 * http://www.aa-team.com
 * =======================
 *
 * @author		Andrei Dinca, AA-Team
 * @version		1.0
 */

global $psp;

echo json_encode(
	array(
		$tryed_module['db_alias'] => array(
			/* define the form_messages box */
			'google_enhancements' => array(
				'title' 	=> __('Google Enhancements', 'psp'),
				'icon' 		=> '{plugin_folder_uri}assets/menu_icon.png',
				'size' 		=> 'grid_4', // grid_1|grid_2|grid_3|grid_4
				'header' 	=> true, // true|false
				'toggler' 	=> false, // true|false
				'buttons' 	=> array(
					'save' => array(
						'value' => __('Save settings', 'psp'),
						'color' => 'success',
						'action'=> 'psp-saveOptions'
					)
				), // true|false
				'style' 	=> 'panel', // panel|panel-widget
				
				// tabs
				'tabs'	=> array(
					'__tab1'	=> array(__('Site Links SearchBox Markup', 'psp'), 'sitelinks_searchbox'),
					'__tab2'	=> array(__('Social Profile Markup', 'psp'), 'type,name,social_facebook,social_twitter,social_googleplus,social_instagram,social_youtube,social_linkedin,social_myspace,social_pinterest,social_soundcloud,social_tumblr'),
				),
				
				// create the box elements array
				'elements'	=> array(
					
					'sitelinks_searchbox' 	=> array(
						'type' 		=> 'select',
						'std' 		=> 'off',
						'size' 		=> 'large',
						'force_width'=> '400',
						'title' 	=> __('Sitelinks Searchbox Markup:', 'psp'),
						'desc' 		=> __('Google Search can expose a search box scoped to your website when it appears as a search result. This search box is powered by Google Search.', 'psp'),
						'options' 	=> array(
							'on'		=> __('ON', 'psp'), 
							'off'		=> __('OFF', 'psp'),
						)
					),
					
					'type' 	=> array(
						'type' 		=> 'select',
						'std' 		=> 'Person',
						'size' 		=> 'large',
						'force_width'=> '400',
						'title' 	=> __('Type:', 'psp'),
						'desc' 		=> __('The social profiles must correspond to what users see on the same page.', 'psp'),
						'options' 	=> array(
							'Person'		=> __('Person', 'psp'), 
							'Organization'		=> __('Organization', 'psp'),
						)
					),
					
					'name' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('Name: ', 'psp'),
						'desc' 		=> __('Name of the Person or of the Organization', 'psp')
					),
					
					'social_facebook' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('Facebook URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_twitter' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('Twitter URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_googleplus' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('Google+ URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_instagram' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('Instagram URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_youtube' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('YouTube URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_linkedin' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('LinkedIn URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_myspace' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('Myspace URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_pinterest' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('Pinterest URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_soundcloud' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('SoundCloud URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					'social_tumblr' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '500',
						'title' 	=> __('Tumblr URL: ', 'psp'),
						'desc' 		=> __('The social profiles in your markup must correspond to what users see on the same page.', 'psp')
					),
					
					
				)
			)
		)
	)
);