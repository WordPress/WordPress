<?php
/**
 * Config file, return as json_encode
 * http://www.aa-team.com
 * =======================
 *
 * @author		Andrei Dinca, AA-Team
 * @version		1.0
 */
 global $psp;
 
 echo json_encode(
	array(
		'file_edit' => array(
			'version' => '1.0',
			'menu' => array(
				'order' => 95,
				'show_in_menu' => false,
				'title' => __('File Editor', 'psp')
				,'icon' => '<i class="' . ( $psp->alias ) . '-icon-files_edit"></i>'
			),
			'in_dashboard' => array(
				'icon' 	=> 'assets/32.png',
				'url'	=> admin_url('admin.php?page=' . $psp->alias . "_massFileEdit")
			),
			'description' => __('Edit important files: .htaccess & robots.txt', 'psp'),
			'module_init' => 'init.php',
      	  	'help' => array(
				'type' => 'remote',
				'url' => 'http://docs.aa-team.com/premium-seo-pack/documentation/files-edit/'
			),
			'load_in' => array(
				'backend' => array(
					'admin.php?page=psp_massFileEdit',
					'admin-ajax.php'
				),
				'frontend' => false
			),
			'javascript' => array(
				'admin',
				'hashchange',
				'tipsy'
			),
			'css' => array(
				'admin'
			)
		)
	)
 );