<?php
/**
 * module return as json_encode
 * http://www.aa-team.com
 * =======================
 *
 * @author		Andrei Dinca, AA-Team
 * @version		1.0
 */
global $psp;
echo json_encode(
	array(
		$tryed_module['db_alias'] => array(
			/* define the form_messages box */
			'gtmetrix' => array(
				'title' 	=> 'GTMetrix',
				'icon' 		=> '{plugin_folder_uri}assets/menu_icon.png',
				'size' 		=> 'grid_4', // grid_1|grid_2|grid_3|grid_4
				'header' 	=> true, // true|false
				'toggler' 	=> false, // true|false
				'buttons' 	=> array(
					'save' => array(
						'value' => __('Save settings', 'psp'),
						'color' => 'success',
						'action'=> 'psp-saveOptions'
					)
				), // true|false
				'style' 	=> 'panel', // panel|panel-widget

				// create the box elements array
				'elements'	=> array(
					array(
						'type' 		=> 'html',

						'html' 		=> '<div class="panel-heading psp-panel-heading">' . __('<h2>Basic Setup</h2>', 'psp') . '</div>',
					),

					'email' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '',
						'size' 		=> 'large',
						'force_width'=> '400',
						'title' 	=> __('GTMetrix E-mail:', 'psp'),
						'desc' 		=> __('GTMetrix E-mail - here you have to insert the e-mail account which you used when you registered on GTMetrix API', 'psp')
					),

					'api_key' 	=> array(
						'type' 		=> 'text',
						'std' 		=> '19a19058aa1b6c84dcaa77f06ecfcc02',
						'size' 		=> 'large',
						'force_width'=> '400',
						'title' 	=> __('GTMetrix API Key:', 'psp'),
						'desc' 		=> __('GTMetrix API Key - manually create one in https://gtmetrix.com/api/ - the default value is a working key that has a limit of 100 credits per day', 'psp')
					),

				)
			)
		)
	)
);
