<?php
if(is_admin())
{
   $blogspotomatic_Main_Settings = get_option('blogspotomatic_Main_Settings', false);
   $redirect = admin_url('admin.php?page=blogspotomatic_blogspot_panel&yt_auth_done=true');
   if(isset($_POST['blogspotomatic_auth']) && isset($_REQUEST['page']) && $_REQUEST['page'] == 'blogspotomatic_blogspot_panel')
   {
       if (session_status() == PHP_SESSION_NONE) {
           session_start();
       }
       try
       {
           require_once(dirname(__FILE__) . "/Google/vendor/autoload.php");
           $client = new Google_Client();
           $client->setClientId($blogspotomatic_Main_Settings['oauth_key']);
           $client->setClientSecret($blogspotomatic_Main_Settings['oauth_secret']);
           $client->setScopes('https://www.googleapis.com/auth/blogger');
           $client->setRedirectUri($redirect);
           $state = mt_rand();
           $client->setState($state);
           $client->setAccessType('offline');
           $client->setApprovalPrompt('force');
           $_SESSION['state'] = $state;
           $authUrl = $client->createAuthUrl();
           if(!function_exists('wp_redirect'))
           {
               include_once( ABSPATH . 'wp-includes/pluggable.php' );
           }
           wp_redirect($authUrl);
           die();
       }
       catch(Exception $e)
       {
           blogspotomatic_log_to_file('Exception thrown in Blogger Auth auth stage 1: ' . $e);
       }
   }  
   else
   {
       if (isset($_GET['code']) && isset($_GET['state']) && isset($_GET['yt_auth_done']) && isset($_GET['page']) && $_GET['page'] == 'blogspotomatic_blogspot_panel') {
           try
           {
               if (session_status() == PHP_SESSION_NONE) {
                   session_start();
               }
               require_once(dirname(__FILE__) . "/Google/vendor/autoload.php");
               $client = new Google_Client();
               $client->setClientId($blogspotomatic_Main_Settings['oauth_key']);
               $client->setClientSecret($blogspotomatic_Main_Settings['oauth_secret']);
               $client->setScopes('https://www.googleapis.com/auth/blogger');
               $client->setRedirectUri($redirect);
               $client->setAccessType('offline');
               $client->setApprovalPrompt('force');
               if (isset($_GET['code'])) {
                 if (strval($_SESSION['state']) !== strval($_GET['state'])) {
                   throw new Exception('The session state did not match.');
                 }
                 $client->authenticate($_GET['code']);
                 $at = $client->getAccessToken();
                 if(!is_array($at) && blogspotomatic_is_json($at))
                 {
                     $at = json_decode($at, true);
                 }
                 if(isset($at['refresh_token']))
                 {
                     update_option('blogspotomatic_refresh_token', $at['refresh_token']);
                 }
                 else
                 {
                     blogspotomatic_log_to_file('blogspotomatic_refresh_token missing: ' . print_r($at, true));
                 }
                 if(isset($at['access_token']))
                 {
                     update_option('blogspotomatic_access_token_auth_id', $blogspotomatic_Main_Settings['oauth_key']);
                     update_option('blogspotomatic_access_token_auth_secret', $blogspotomatic_Main_Settings['oauth_secret']);
                     $at = json_encode($at);
                     update_option('blogspotomatic_access_token_str', $at);
                 }
                 else
                 {
                     blogspotomatic_log_to_file('No valid access token found: ' . print_r($at, true));
                     throw new Exception('No access token found.');
                 }
                 if(!function_exists('wp_redirect'))
                 {
                     include_once( ABSPATH . 'wp-includes/pluggable.php' );
                 }
                 wp_redirect($redirect);
                 die();
               }
           }
           catch(Exception $e)
           {
               blogspotomatic_log_to_file('Exception thrown in Blogspot Auth auth stage 2: ' . $e);
           }
       }
   }
}
   function blogspotomatic_blogspot_panel()
   {
   $blogspotomatic_Main_Settings = get_option('blogspotomatic_Main_Settings', false);
   $authorized = false;
   if(isset($blogspotomatic_Main_Settings['oauth_key']) && $blogspotomatic_Main_Settings['oauth_key'] != '')
   {
       if(isset($blogspotomatic_Main_Settings['oauth_secret']) && $blogspotomatic_Main_Settings['oauth_secret'] != '')
       {
           if(get_option('blogspotomatic_access_token_auth_id', false) !== FALSE)
           {
               if(get_option('blogspotomatic_access_token_auth_secret', false) !== FALSE)
               {
                   if($blogspotomatic_Main_Settings['oauth_key'] == get_option('blogspotomatic_access_token_auth_id', false) && $blogspotomatic_Main_Settings['oauth_secret'] == get_option('blogspotomatic_access_token_auth_secret', false) && get_option('blogspotomatic_access_token_str', false) !== FALSE)
                   {
                       $authorized = true;
                   }
               }
           }
       }
       else
       {
   ?>
<h1><?php echo esc_html__("You must add a Blogspot OAuth2 Secret before you can use this feature!", 'blogspotomatic-blogspot-post-generator');?></h1>
<?php
   update_option('blogspotomatic_access_token_auth_id', 'null');
   update_option('blogspotomatic_access_token_auth_secret', 'null');
   return;
       }
   }
   else
   {
   ?>
<h1><?php echo esc_html__("You must add a Blogspot OAuth2 Key before you can use this feature!", 'blogspotomatic-blogspot-post-generator');?></h1>
<?php
   update_option('blogspotomatic_access_token_auth_id', 'null');
   update_option('blogspotomatic_access_token_auth_secret', 'null');
   return;
   }
   ?>
<div class="wp-header-end"></div>
<div class="wrap gs_popuptype_holder seo_pops">
   <div>
      <?php
         if($authorized === FALSE)
         {
         ?>
      <div class="hideThis">
         <h1><?php echo esc_html__("Some Required Steps Before You Can Use This Feature:", 'blogspotomatic-blogspot-post-generator');?></h1>
         <br><b>1)</b> <?php echo esc_html__("In the", 'blogspotomatic-blogspot-post-generator');?> <a href='https://console.developers.google.com/apis/credentials' target='_blank'><?php echo esc_html__("API Manager", 'blogspotomatic-blogspot-post-generator');?></a> <?php echo esc_html__("settings page in Blogspot ('Credentials' subsection), set the 'Authorized redirect URIs' of your OAuth key to the following URL (otherwise authorization will not work!):", 'blogspotomatic-blogspot-post-generator');?><br/>
         <span class="cr_red"><?php echo site_url() . '/wp-admin/admin.php?page=blogspotomatic_blogspot_panel&yt_auth_done=true';?></span>
         <br/><b>2)</b> <strong><?php echo esc_html__("Authorize Your App to Post on Blogspot with the button below:", 'blogspotomatic-blogspot-post-generator');?></strong>
      </div>
      <br/>
      <form id="myAuthForm" method="post" action=""><input type="submit" name="blogspotomatic_auth" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="<?php if($authorized === TRUE){echo esc_html__('Reauthorize the App', 'blogspotomatic-blogspot-post-generator');}else{echo esc_html__('Authorize the App', 'blogspotomatic-blogspot-post-generator');}?>"/></form>
      <?php
         update_option('blogspotomatic_access_token_auth_id', 'null');
         update_option('blogspotomatic_access_token_auth_secret', 'null');
         ?>
      <h1><?php echo esc_html__("You must authorize your App before using this plugin feature!", 'blogspotomatic-blogspot-post-generator');?></h1>
      <?php
         }
         else
         {
         ?>
      <br/>
      <form id="myAuthForm" method="post" action=""><input type="submit" name="blogspotomatic_auth" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="<?php if($authorized === TRUE){echo esc_html__('Reauthorize the App', 'blogspotomatic-blogspot-post-generator');}else{echo esc_html__('Authorize the App', 'blogspotomatic-blogspot-post-generator');}?>"/></form>
      <form id="myForm" method="post" action="<?php if(is_multisite() && is_network_admin()){echo '../options.php';}else{echo 'options.php';}?>">
         <?php
            settings_fields('blogspotomatic_option_group2');
            do_settings_sections('blogspotomatic_option_group2');
            $blogspotomatic_Blogspot_Settings = get_option('blogspotomatic_Blogspot_Settings', false);
            if (isset($blogspotomatic_Blogspot_Settings['blogspotomatic_posting'])) {
                $blogspotomatic_posting = $blogspotomatic_Blogspot_Settings['blogspotomatic_posting'];
            } else {
                $blogspotomatic_posting = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['blogspot_format'])) {
                $blogspot_format = $blogspotomatic_Blogspot_Settings['blogspot_format'];
            } else {
                $blogspot_format = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['post_posts'])) {
                $post_posts = $blogspotomatic_Blogspot_Settings['post_posts'];
            } else {
                $post_posts = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['blog_list'])) {
                $blog_list = $blogspotomatic_Blogspot_Settings['blog_list'];
            } else {
                $blog_list = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['post_pages'])) {
                $post_pages = $blogspotomatic_Blogspot_Settings['post_pages'];
            } else {
                $post_pages = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['post_custom'])) {
                $post_custom = $blogspotomatic_Blogspot_Settings['post_custom'];
            } else {
                $post_custom = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['disabled_categories'])) {
                $disabled_categories = $blogspotomatic_Blogspot_Settings['disabled_categories'];
            } else {
                $disabled_categories = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['disable_tags'])) {
                $disable_tags = $blogspotomatic_Blogspot_Settings['disable_tags'];
            } else {
                $disable_tags = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['blogspot_title_format'])) {
                $blogspot_title_format = $blogspotomatic_Blogspot_Settings['blogspot_title_format'];
            } else {
                $blogspot_title_format = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['auto_tags'])) {
                $auto_tags = $blogspotomatic_Blogspot_Settings['auto_tags'];
            } else {
                $auto_tags = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['manual_tags'])) {
                $manual_tags = $blogspotomatic_Blogspot_Settings['manual_tags'];
            } else {
                $manual_tags = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['delayed_post'])) {
                $delayed_post = $blogspotomatic_Blogspot_Settings['delayed_post'];
            } else {
                $delayed_post = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['post_metadata'])) {
                $post_metadata = $blogspotomatic_Blogspot_Settings['post_metadata'];
            } else {
                $post_metadata = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['featured_img'])) {
                $featured_img = $blogspotomatic_Blogspot_Settings['featured_img'];
            } else {
                $featured_img = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['image_url'])) {
                $image_url = $blogspotomatic_Blogspot_Settings['image_url'];
            } else {
                $image_url = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['link_back'])) {
                $link_back = $blogspotomatic_Blogspot_Settings['link_back'];
            } else {
                $link_back = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['delay_post'])) {
                $delay_post = $blogspotomatic_Blogspot_Settings['delay_post'];
            } else {
                $delay_post = '';
            }
            if (isset($blogspotomatic_Blogspot_Settings['run_background'])) {
                $run_background = $blogspotomatic_Blogspot_Settings['run_background'];
            } else {
                $run_background = '';
            }
            if (isset($_GET['settings-updated'])) {
            ?>
         <div id="message" class="updated">
            <p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Settings saved.', 'blogspotomatic-blogspot-post-generator');?></strong></p>
         </div>
         <?php
            $get = get_option('coderevolution_settings_changed', 0);
            if($get == 1)
            {
                delete_option('coderevolution_settings_changed');
            ?>
         <div id="message" class="updated">
            <p class="cr_failed_notif"><strong>&nbsp;<?php echo esc_html__('Plugin registration failed!', 'blogspotomatic-blogspot-post-generator');?></strong></p>
         </div>
         <?php 
            }
            elseif($get == 2)
            {
                    delete_option('coderevolution_settings_changed');
            ?>
         <div id="message" class="updated">
            <p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Plugin registration successful!', 'blogspotomatic-blogspot-post-generator');?></strong></p>
         </div>
         <?php 
            }
                }
            ?>
         <div>
            <div class="blogspotomatic_class">
               <table>
                  <tr>
                     <td>
                        <h1>
                           <span class="gs-sub-heading"><b>Blogspotomatic Automatic Post to Blogspot - <?php echo esc_html__('Main Switch:', 'blogspotomatic-blogspot-post-generator');?></b>&nbsp;</span>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Enable or disable automatic posting to Blogspot every time you publish a new post (manually or automatically).", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                        </h1>
                     </td>
                     <td>
                        <div class="slideThree">	
                           <input class="input-checkbox" type="checkbox" id="blogspotomatic_posting" name="blogspotomatic_Blogspot_Settings[blogspotomatic_posting]"<?php
                              if ($blogspotomatic_posting == 'on')
                                  echo ' checked ';
                              ?>>
                           <label for="blogspotomatic_posting"></label>
                        </div>
                     </td>
                  </tr>
               </table>
            </div>
            <div><?php if($blogspotomatic_posting != 'on'){echo '<div class="crf_bord cr_color_red cr_auto_update">' . esc_html__('This feature of the plugin is disabled! Please enable it from the above switch.', 'blogspotomatic-blogspot-post-generator') . '</div>';}?>
               <hr/>
               <table>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want delay posting with this amount of seconds from post publish? This will create a single cron job for each post (cron is a requirement for this to function). If you leave this field blank, posts will be automatically published on post creation.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Delay Posting By (Seconds):", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="number" min="0" step="1" id="delay_post" name="blogspotomatic_Blogspot_Settings[delay_post]" class="cr_450" value="<?php echo esc_html($delay_post);?>" placeholder="Delay posting by X seconds">
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("This option will allow you to select if you want to run posting in async mode. This means that each time you publish a post, the plugin will try to execute it's task in the background - it will no longer block new post posting, while it finishes it's job.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Use Async Posting Method:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="run_background" name="blogspotomatic_Blogspot_Settings[run_background]"<?php
                        if ($run_background == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class="hideGroup">
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Input the blogs where you want to post. You can input a comma separated list of blog IDs or blog URLs. Note that these blogs must be administrated by the currently authenticated user, otherwise posting will not work.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b class="cr_red12"><?php echo esc_html__("Blogs Where To Post:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div class="hideGroup">
                           <textarea rows="2" name="blogspotomatic_Blogspot_Settings[blog_list]" placeholder="Please insert your blog IDs or URLs" required><?php
                              echo esc_textarea($blog_list);
                              ?></textarea>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose the template of your Blogspot posts title. You can use the following shortcodes: %%featured_image%%, %%post_cats%%, %%post_tags%%, %%blog_title%%, %%author_name%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%, %%post_title%%, %%post_content%%, %%post_excerpt%%", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Blogspot Post Title Template:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <textarea rows="2" name="blogspotomatic_Blogspot_Settings[blogspot_title_format]" placeholder="Please insert your Blogspot post title template"><?php
                              echo esc_textarea($blogspot_title_format);
                              ?></textarea>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose the template of your Blogspot posts. You can use the following shortcodes: %%featured_image%%, %%post_cats%%, %%post_tags%%, %%blog_title%%, %%author_name%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%, %%post_title%%, %%post_content%%, %%post_excerpt%%", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Blogspot Post Content Template:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <textarea rows="4" name="blogspotomatic_Blogspot_Settings[blogspot_format]" placeholder="Please insert your Blogspot post template"><?php
                              echo esc_textarea($blogspot_format);
                              ?></textarea>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to automatically set post featured image?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Automatically Set Post Featured Image:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="featured_img" name="blogspotomatic_Blogspot_Settings[featured_img]"<?php
                        if ($featured_img == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to set a default featured image if no image found?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Default Featured Image List:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input class="cr_width_full" type="url" validator="url" name="blogspotomatic_Blogspot_Settings[image_url]" placeholder="Please insert the link to a valid image" value="<?php echo esc_html($image_url);?>"/>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to backlink created Blogspot post title back to the original WordPress article?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Link Blogspot Post Title Back To WordPress Article:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="link_back" name="blogspotomatic_Blogspot_Settings[link_back]"<?php
                        if ($link_back == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "Input a value when you whant to automatically publish the posts. If you leave this field blank, posts will be automatically published instantly. Accepted values for this field are listed: <a href='%s' target='_blank'>here</a>, <a href='%s' target='_blank'>here</a>, <a href='%s' target='_blank'>here</a> and <a href='%s' target='_blank'>here</a>. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'http://php.net/manual/ro/datetime.formats.relative.php' ), esc_url( 'http://php.net/manual/ro/datetime.formats.date.php' ), esc_url( 'http://php.net/manual/ro/datetime.formats.time.php' ), esc_url( 'http://php.net/manual/ro/datetime.formats.compound.php' ) );
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Delayed Publish Posts:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="text" name="blogspotomatic_Blogspot_Settings[delayed_post]" value="<?php echo esc_html($delayed_post);?>" placeholder="Input a delayed posting date" class="cr_width_full">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose what you want to set as generated post labels on Blogspot. You can select between WordPress post's tags, categories, both or none.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Blogspot Post Labels:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <select class="cr_width_full" id="auto_tags" name="blogspotomatic_Blogspot_Settings[auto_tags]">
                              <option value="disabled"<?php if($auto_tags == 'disabled'){echo ' selected';}?>><?php echo esc_html__("Disabled", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value="tags"<?php if($auto_tags == 'tags'){echo ' selected';}?>><?php echo esc_html__("Post Tags", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value="cats"<?php if($auto_tags == 'cats'){echo ' selected';}?>><?php echo esc_html__("Post Categories", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value="both"<?php if($auto_tags == 'both'){echo ' selected';}?>><?php echo esc_html__("Post Tags and Post Categories", 'blogspotomatic-blogspot-post-generator');?></option>
                           </select>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose what labels you want to manually add to generated posts on Blogspot. Separate multiple labels by comma. Ex: flower, green, apple.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Blogspot Post Manual Labels:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="text" name="blogspotomatic_Blogspot_Settings[manual_tags]" value="<?php echo esc_html($manual_tags);?>" placeholder="Input manual labels" class="cr_width_full">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Select if you want to set custom post metadata for generated posts.  You can use the following shortcodes: %%featured_image%%, %%post_cats%%, %%post_tags%%, %%blog_title%%, %%author_name%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%, %%post_title%%, %%post_content%%, %%post_excerpt%%", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Set Custom Post Metadata:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="text" name="blogspotomatic_Blogspot_Settings[post_metadata]" value="<?php echo esc_html($post_metadata);?>" placeholder="Input post metadata" class="cr_width_full">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to disable automatically posting of WordPress 'posts' to Blogspot?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Disable Autoposting of 'Posts':", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="post_posts" name="blogspotomatic_Blogspot_Settings[post_posts]"<?php
                        if ($post_posts == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to disable automatically posting of WordPress 'pages' to Blogspot?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Disable Autoposting of 'Pages':", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="post_pages" name="blogspotomatic_Blogspot_Settings[post_pages]"<?php
                        if ($post_pages == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to disable automatically posting of WordPress 'custom post types' to Blogspot?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Disable Autoposting of 'Custom Post Types':", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="post_custom" name="blogspotomatic_Blogspot_Settings[post_custom]"<?php
                        if ($post_custom == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to disable automatically posting of WordPress 'posts' to Blogspot?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Disable Autoposting of Selected Categories:", 'blogspotomatic-blogspot-post-generator');?></b><br/>
                           <a onclick="toggleCats()" class="cr_pointer"><?php echo esc_html__("Show/Hide Categories List", 'blogspotomatic-blogspot-post-generator');?></a>
                     </td>
                     <td>
                     <br/>
                     <div id="hideCats" class="hideCats">
                     <?php
                        $cat_args   = array(
                            'orderby' => 'name',
                            'hide_empty' => 0,
                            'order' => 'ASC'
                        );
                        $categories = get_categories($cat_args);
                        foreach ($categories as $category) {
                        ?>
                     <div>
                     <label>
                     <input
                        <?php
                           if (isset($blogspotomatic_Blogspot_Settings['disabled_categories']) && !empty($blogspotomatic_Blogspot_Settings['disabled_categories'])) {
                               checked(true, in_array($category->term_id, $blogspotomatic_Blogspot_Settings['disabled_categories']));
                           }
                           ?>
                        type="checkbox" name="blogspotomatic_Blogspot_Settings[disabled_categories][]" value="<?php
                           echo esc_html($category->term_id);
                           ?>" /> 
                     <span><?php
                        echo esc_html(sanitize_text_field($category->name));
                        ?></span>
                     </label>
                     </div>
                     <?php
                        }
                        ?>
                     </div>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Input the tags for which you want to disable posting. You can enter more tags, separated by comma. Ex: cars, vehicles, red, luxury. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Disable Autoposting of Selected Tags:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <textarea rows="1" name="blogspotomatic_Blogspot_Settings[disable_tags]" placeholder="Please insert the tags for which you want to disable posting"><?php
                              echo esc_textarea($disable_tags);
                              ?></textarea>
                        </div>
                     </td>
                  </tr>
               </table>
               <br/><br/>
               <a href="https://www.youtube.com/watch?v=5rbnu_uis7Y" target="_blank"><?php echo esc_html__("Nested Shortcodes also supported!", 'blogspotomatic-blogspot-post-generator');?></a>
            </div>
            <div>
               <p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings", 'blogspotomatic-blogspot-post-generator');?>"/></p>
            </div>
      </form>
      <?php
         }
         ?>
      </div>
   </div>
</div>
<?php
   }
   ?>