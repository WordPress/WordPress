<?php
   function blogspotomatic_admin_settings()
   {
       $language_names = array(
           esc_html__("Disabled", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Afrikaans (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Albanian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Arabic (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Amharic (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Armenian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Belarusian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Bulgarian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Catalan (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Chinese Simplified (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Croatian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Czech (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Danish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Dutch (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("English (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Estonian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Filipino (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Finnish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("French (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Galician (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("German (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Greek (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Hebrew (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Hindi (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Hungarian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Icelandic (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Indonesian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Irish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Italian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Japanese (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Korean (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Latvian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Lithuanian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Norwegian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Macedonian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Malay (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Maltese (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Persian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Polish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Portuguese (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Romanian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Russian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Serbian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Slovak (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Slovenian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Spanish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Swahili (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Swedish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Thai (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Turkish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Ukrainian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Vietnamese (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Welsh (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Yiddish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Tamil (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Azerbaijani (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Kannada (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Basque (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Bengali (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Latin (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Chinese Traditional (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Esperanto (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Georgian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Telugu (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Gujarati (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Haitian Creole (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Urdu (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Burmese (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Bosnian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Cebuano (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Chichewa (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Corsican (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Frisian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Scottish Gaelic (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Hausa (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Hawaian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Hmong (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Igbo (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Javanese (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Kazakh (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Khmer (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Kurdish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Kyrgyz (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Lao (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Luxembourgish (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Malagasy (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Malayalam (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Maori (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Marathi (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Mongolian (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Nepali (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Pashto (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Punjabi (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Samoan (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Sesotho (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Shona (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Sindhi (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Sinhala (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Somali (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Sundanese (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Swahili (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Tajik (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Uzbek (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Xhosa (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Yoruba (Google Translate)", 'blogspotomatic-blogspot-post-generator'),
           esc_html__("Zulu (Google Translate)", 'blogspotomatic-blogspot-post-generator')
       );
       $language_codes = array(
           "disabled",
           "af",
           "sq",
           "ar",
           "am",
           "hy",
           "be",
           "bg",
           "ca",
           "zh-CN",
           "hr",
           "cs",
           "da",
           "nl",
           "en",
           "et",
           "tl",
           "fi",
           "fr",
           "gl",
           "de",
           "el",
           "iw",
           "hi",
           "hu",
           "is",
           "id",
           "ga",
           "it",
           "ja",
           "ko",
           "lv",
           "lt",
           "no",
           "mk",
           "ms",
           "mt",
           "fa",
           "pl",
           "pt",
           "ro",
           "ru",
           "sr",
           "sk",
           "sl",
           "es",
           "sw",
           "sv",   
           "th",
           "tr",
           "uk",
           "vi",
           "cy",
           "yi",
           "ta",
           "az",
           "kn",
           "eu",
           "bn",
           "la",
           "zh-TW",
           "eo",
           "ka",
           "te",
           "gu",
           "ht",
           "ur",
           "my",
           "bs",
           "ceb",
           "ny",
           "co",
           "fy",
           "gd",
           "ha",
           "haw",
           "hmn",
           "ig",
           "jw",
           "kk",
           "km",
           "ku",
           "ky",
           "lo",
           "lb",
           "mg",
           "ml",
           "mi",
           "mr",
           "mn",
           "ne",
           "ps",
           "pa",
           "sm",
           "st",
           "sn",
           "sd",
           "si",
           "so",
           "su",
           "sw",
           "tg",
           "uz",
           "xh",
           "yo",
           "zu"
       );
   ?>
<div class="wp-header-end"></div>
<div class="wrap gs_popuptype_holder seo_pops">
   <div>
      <form id="myForm" method="post" action="<?php if(is_multisite() && is_network_admin()){echo '../options.php';}else{echo 'options.php';}?>">
         <div class="cr_autocomplete">
            <input type="password" id="PreventChromeAutocomplete" 
               name="PreventChromeAutocomplete" autocomplete="address-level4" />
         </div>
         <?php
            settings_fields('blogspotomatic_option_group');
            do_settings_sections('blogspotomatic_option_group');
            $blogspotomatic_Main_Settings = get_option('blogspotomatic_Main_Settings', false);
            if (isset($blogspotomatic_Main_Settings['blogspotomatic_enabled'])) {
                $blogspotomatic_enabled = $blogspotomatic_Main_Settings['blogspotomatic_enabled'];
            } else {
                $blogspotomatic_enabled = '';
            }
            if (isset($blogspotomatic_Main_Settings['enable_metabox'])) {
                $enable_metabox = $blogspotomatic_Main_Settings['enable_metabox'];
            } else {
                $enable_metabox = '';
            }
            if (isset($blogspotomatic_Main_Settings['sentence_list'])) {
                $sentence_list = $blogspotomatic_Main_Settings['sentence_list'];
            } else {
                $sentence_list = '';
            }
            if (isset($blogspotomatic_Main_Settings['gapiKey'])) {
                $gapiKey = $blogspotomatic_Main_Settings['gapiKey'];
            } else {
                $gapiKey = '';
            }
            if (isset($blogspotomatic_Main_Settings['links_hide_google2'])) {
                $links_hide_google2 = $blogspotomatic_Main_Settings['links_hide_google2'];
            } else {
                $links_hide_google2 = '';
            }
            if (isset($blogspotomatic_Main_Settings['links_hide_google'])) {
                $links_hide_google = $blogspotomatic_Main_Settings['links_hide_google'];
            } else {
                $links_hide_google = '';
            }
            if (isset($blogspotomatic_Main_Settings['sentence_list2'])) {
                $sentence_list2 = $blogspotomatic_Main_Settings['sentence_list2'];
            } else {
                $sentence_list2 = '';
            }
            if (isset($blogspotomatic_Main_Settings['variable_list'])) {
                $variable_list = $blogspotomatic_Main_Settings['variable_list'];
            } else {
                $variable_list = '';
            }
            if (isset($blogspotomatic_Main_Settings['enable_detailed_logging'])) {
                $enable_detailed_logging = $blogspotomatic_Main_Settings['enable_detailed_logging'];
            } else {
                $enable_detailed_logging = '';
            }
            if (isset($blogspotomatic_Main_Settings['enable_logging'])) {
                $enable_logging = $blogspotomatic_Main_Settings['enable_logging'];
            } else {
                $enable_logging = '';
            }
            if (isset($blogspotomatic_Main_Settings['auto_clear_logs'])) {
                $auto_clear_logs = $blogspotomatic_Main_Settings['auto_clear_logs'];
            } else {
                $auto_clear_logs = '';
            }
            if (isset($blogspotomatic_Main_Settings['rule_timeout'])) {
                $rule_timeout = $blogspotomatic_Main_Settings['rule_timeout'];
            } else {
                $rule_timeout = '';
            }
            if (isset($blogspotomatic_Main_Settings['strip_links'])) {
                $strip_links = $blogspotomatic_Main_Settings['strip_links'];
            } else {
                $strip_links = '';
            }
            if (isset($blogspotomatic_Main_Settings['full_imgs'])) {
                $full_imgs = $blogspotomatic_Main_Settings['full_imgs'];
            } else {
                $full_imgs = '';
            }
            if (isset($blogspotomatic_Main_Settings['send_email'])) {
                $send_email = $blogspotomatic_Main_Settings['send_email'];
            } else {
                $send_email = '';
            }
            if (isset($blogspotomatic_Main_Settings['email_address'])) {
                $email_address = $blogspotomatic_Main_Settings['email_address'];
            } else {
                $email_address = '';
            }
            if (isset($blogspotomatic_Main_Settings['translate'])) {
                $translate = $blogspotomatic_Main_Settings['translate'];
            } else {
                $translate = '';
            }
            if (isset($blogspotomatic_Main_Settings['translate_source'])) {
                $translate_source = $blogspotomatic_Main_Settings['translate_source'];
            } else {
                $translate_source = '';
            }
            if (isset($blogspotomatic_Main_Settings['spin_text'])) {
                $spin_text = $blogspotomatic_Main_Settings['spin_text'];
            } else {
                $spin_text = '';
            }
            if (isset($blogspotomatic_Main_Settings['google_trans_auth'])) {
                $google_trans_auth = $blogspotomatic_Main_Settings['google_trans_auth'];
            } else {
                $google_trans_auth = '';
            }
            if (isset($blogspotomatic_Main_Settings['best_user'])) {
                $best_user = $blogspotomatic_Main_Settings['best_user'];
            } else {
                $best_user = '';
            }
            if (isset($blogspotomatic_Main_Settings['best_password'])) {
                $best_password = $blogspotomatic_Main_Settings['best_password'];
            } else {
                $best_password = '';
            }
            if (isset($blogspotomatic_Main_Settings['min_word_title'])) {
                $min_word_title = $blogspotomatic_Main_Settings['min_word_title'];
            } else {
                $min_word_title = '';
            }
            if (isset($blogspotomatic_Main_Settings['max_word_title'])) {
                $max_word_title = $blogspotomatic_Main_Settings['max_word_title'];
            } else {
                $max_word_title = '';
            }
            if (isset($blogspotomatic_Main_Settings['min_word_content'])) {
                $min_word_content = $blogspotomatic_Main_Settings['min_word_content'];
            } else {
                $min_word_content = '';
            }
            if (isset($blogspotomatic_Main_Settings['max_word_content'])) {
                $max_word_content = $blogspotomatic_Main_Settings['max_word_content'];
            } else {
                $max_word_content = '';
            }
            if (isset($blogspotomatic_Main_Settings['required_words'])) {
                $required_words = $blogspotomatic_Main_Settings['required_words'];
            } else {
                $required_words = '';
            }
            if (isset($blogspotomatic_Main_Settings['copy_images'])) {
                $copy_images = $blogspotomatic_Main_Settings['copy_images'];
            } else {
                $copy_images = '';
            }
            if (isset($blogspotomatic_Main_Settings['banned_words'])) {
                $banned_words = $blogspotomatic_Main_Settings['banned_words'];
            } else {
                $banned_words = '';
            }
            if (isset($blogspotomatic_Main_Settings['skip_old'])) {
                $skip_old = $blogspotomatic_Main_Settings['skip_old'];
            } else {
                $skip_old = '';
            }
            if (isset($blogspotomatic_Main_Settings['skip_day'])) {
                $skip_day = $blogspotomatic_Main_Settings['skip_day'];
            } else {
                $skip_day = '';
            }
            if (isset($blogspotomatic_Main_Settings['skip_month'])) {
                $skip_month = $blogspotomatic_Main_Settings['skip_month'];
            } else {
                $skip_month = '';
            }
            if (isset($blogspotomatic_Main_Settings['skip_year'])) {
                $skip_year = $blogspotomatic_Main_Settings['skip_year'];
            } else {
                $skip_year = '';
            }
            if (isset($blogspotomatic_Main_Settings['custom_html2'])) {
                $custom_html2 = $blogspotomatic_Main_Settings['custom_html2'];
            } else {
                $custom_html2 = '';
            }
            if (isset($blogspotomatic_Main_Settings['custom_html'])) {
                $custom_html = $blogspotomatic_Main_Settings['custom_html'];
            } else {
                $custom_html = '';
            }
            if (isset($blogspotomatic_Main_Settings['skip_no_img'])) {
                $skip_no_img = $blogspotomatic_Main_Settings['skip_no_img'];
            } else {
                $skip_no_img = '';
            }
            if (isset($blogspotomatic_Main_Settings['strip_by_id'])) {
                $strip_by_id = $blogspotomatic_Main_Settings['strip_by_id'];
            } else {
                $strip_by_id = '';
            }
            if (isset($blogspotomatic_Main_Settings['strip_by_class'])) {
                $strip_by_class = $blogspotomatic_Main_Settings['strip_by_class'];
            } else {
                $strip_by_class = '';
            }
            if (isset($blogspotomatic_Main_Settings['oauth_key'])) {
                $oauth_key = $blogspotomatic_Main_Settings['oauth_key'];
            } else {
                $oauth_key = '';
            }
            if (isset($blogspotomatic_Main_Settings['oauth_secret'])) {
                $oauth_secret = $blogspotomatic_Main_Settings['oauth_secret'];
            } else {
                $oauth_secret = '';
            }
            if (isset($blogspotomatic_Main_Settings['enable_og'])) {
                $enable_og = $blogspotomatic_Main_Settings['enable_og'];
            } else {
                $enable_og = '';
            }
            if (isset($blogspotomatic_Main_Settings['resize_width'])) {
                $resize_width = $blogspotomatic_Main_Settings['resize_width'];
            } else {
                $resize_width = '';
            }
            if (isset($blogspotomatic_Main_Settings['resize_height'])) {
                $resize_height = $blogspotomatic_Main_Settings['resize_height'];
            } else {
                $resize_height = '';
            }
            if (isset($blogspotomatic_Main_Settings['do_not_check_duplicates'])) {
                $do_not_check_duplicates = $blogspotomatic_Main_Settings['do_not_check_duplicates'];
            } else {
                $do_not_check_duplicates = '';
            }
            if (isset($blogspotomatic_Main_Settings['api_key'])) {
                $api_key = $blogspotomatic_Main_Settings['api_key'];
            } else {
                $api_key = '';
            }
            if (isset($_GET['settings-updated'])) {
            ?>
         <div id="message" class="updated">
            <p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Settings saved.', 'blogspotomatic-blogspot-post-generator');?></strong></p>
         </div>
         <?php
            $get = get_option('coderevolution_settings_changed', 0);
            if($get == 1)
            {
                delete_option('coderevolution_settings_changed');
            ?>
         <div id="message" class="updated">
            <p class="cr_failed_notif"><strong>&nbsp;<?php echo esc_html__('Plugin registration failed!', 'blogspotomatic-blogspot-post-generator');?></strong></p>
         </div>
         <?php 
            }
            elseif($get == 2)
            {
                    delete_option('coderevolution_settings_changed');
            ?>
         <div id="message" class="updated">
            <p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Plugin registration successful!', 'blogspotomatic-blogspot-post-generator');?></strong></p>
         </div>
         <?php 
            }
                }
            ?>
         <div>
            <div class="blogspotomatic_class">
               <table>
                  <tr>
                     <td>
                        <h1>
                           <span class="gs-sub-heading"><b>Blogspotomatic Automatic Post Generator Plugin - <?php echo esc_html__('Main Switch:', 'blogspotomatic-blogspot-post-generator');?></b>&nbsp;</span>
                           <span class="cr_07_font">v1.3&nbsp;</span>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Enable or disable this plugin. This acts like a main switch.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                        </h1>
                     </td>
                     <td>
                        <div class="slideThree">	
                           <input class="input-checkbox" type="checkbox" id="blogspotomatic_enabled" name="blogspotomatic_Main_Settings[blogspotomatic_enabled]"<?php
                              if ($blogspotomatic_enabled == 'on')
                                  echo ' checked ';
                              ?>>
                           <label for="blogspotomatic_enabled"></label>
                        </div>
                     </td>
                  </tr>
               </table>
            </div>
            <div><?php if($blogspotomatic_enabled != 'on'){echo '<div class="crf_bord cr_color_red cr_auto_update">' . esc_html__('This feature of the plugin is disabled! Please enable it from the above switch.', 'blogspotomatic-blogspot-post-generator') . '</div>';}?>
               <table>
                  <tr>
                     <td colspan="2">
                        <?php
                           $plugin = plugin_basename(__FILE__);
                           $plugin_slug = explode('/', $plugin);
                           $plugin_slug = $plugin_slug[0]; 
                           $uoptions = get_option($plugin_slug . '_registration', array());
                           if(isset($uoptions['item_id']) && isset($uoptions['item_name']) && isset($uoptions['created_at']) && isset($uoptions['buyer']) && isset($uoptions['licence']) && isset($uoptions['supported_until']))
                           {
                           ?>
                        <h3><b><?php echo esc_html__("Plugin Registration Info - Automatic Updates Enabled:", 'blogspotomatic-blogspot-post-generator');?></b> </h3>
                        <ul>
                           <li><b><?php echo esc_html__("Item Name:", 'blogspotomatic-blogspot-post-generator');?></b> <?php echo esc_html($uoptions['item_name']);?></li>
                           <li>
                              <b><?php echo esc_html__("Item ID:", 'blogspotomatic-blogspot-post-generator');?></b> <?php echo esc_html($uoptions['item_id']);?>
                           </li>
                           <li>
                              <b><?php echo esc_html__("Created At:", 'blogspotomatic-blogspot-post-generator');?></b> <?php echo esc_html($uoptions['created_at']);?>
                           </li>
                           <li>
                              <b><?php echo esc_html__("Buyer Name:", 'blogspotomatic-blogspot-post-generator');?></b> <?php echo esc_html($uoptions['buyer']);?>
                           </li>
                           <li>
                              <b><?php echo esc_html__("License Type:", 'blogspotomatic-blogspot-post-generator');?></b> <?php echo esc_html($uoptions['licence']);?>
                           </li>
                           <li>
                              <b><?php echo esc_html__("Supported Until:", 'blogspotomatic-blogspot-post-generator');?></b> <?php echo esc_html($uoptions['supported_until']);?>
                           </li>
                        </ul>
                        <?php
                           }
                           else
                           {
                           ?>
                        <div class="notice notice-error is-dismissible"><p><?php echo esc_html__("Automatic updates for this plugin are disabled. Please activate the plugin from below, so you can benefit of automatic updates for it!", 'blogspotomatic-blogspot-post-generator');?></p></div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text cr_min_260px">
                              <?php
                                 echo sprintf( wp_kses( __( 'Please input your Envato purchase code, to enable automatic updates in the plugin. To get your purchase code, please follow <a href="%s" target="_blank">this tutorial</a>. Info submitted to the registration server consists of: purchase code, site URL, site name, admin email. All these data will be used strictly for registration purposes.', 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( '//coderevolution.ro/knowledge-base/faq/how-do-i-find-my-items-purchase-code-for-plugin-license-activation/' ) );
                                 ?>
                           </div>
                        </div>
                        <b><?php echo esc_html__("Register Envato Purchase Code To Enable Automatic Updates:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td><input type="text" name="<?php echo esc_html($plugin_slug);?>_register_code" value="" placeholder="<?php echo esc_html__("Envato Purchase Code", 'blogspotomatic-blogspot-post-generator');?>"></td>
                  </tr>
                  <tr>
                     <td></td>
                     <td><input type="submit" name="<?php echo esc_html($plugin_slug);?>_register" id="<?php echo esc_html($plugin_slug);?>_register" class="button button-primary" onclick="unsaved = false;" value="<?php echo esc_html__("Register Purchase Code", 'blogspotomatic-blogspot-post-generator');?>"/>
                        <?php
                           }
                           ?>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <hr/>
                     </td>
                     <td>
                        <hr/>
                     </td>
                  </tr>
               <tr><td colspan="2">
               <h3>
                  <ul>
                     <li><?php echo sprintf( wp_kses( __( 'Need help configuring this plugin? Please check out it\'s <a href="%s" target="_blank">video tutorial</a>.', 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://www.youtube.com/watch?v=rJw19B5vyGc' ) );?>
                     </li>
                     <li><?php echo sprintf( wp_kses( __( 'Having issues with the plugin? Please be sure to check out our <a href="%s" target="_blank">knowledge-base</a> before you contact <a href="%s" target="_blank">our support</a>!', 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( '//coderevolution.ro/knowledge-base' ), esc_url('//coderevolution.ro/support' ) );?></li>
                     <li><?php echo sprintf( wp_kses( __( 'Do you enjoy our plugin? Please give it a <a href="%s" target="_blank">rating</a>  on CodeCanyon, or check <a href="%s" target="_blank">our website</a>  for other cool plugins.', 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( '//codecanyon.net/downloads' ), esc_url( 'https://coderevolution.ro' ) );?></a></li>
                     <li><br/><br/><span class="cr_color_red"><?php echo esc_html__("Are you looking for a cool new theme that best fits this plugin?", 'blogspotomatic-blogspot-post-generator');?></span> <a onclick="revealRec()" class="cr_cursor_pointer"><?php echo esc_html__("Click here for our theme related recommendation", 'blogspotomatic-blogspot-post-generator');?></a>.
                        <br/><span id="diviIdrec"></span>
                     </li>
                  </ul>
               </h3>
               <hr/>
               <div class="hideInfo">
                  <h3><?php echo esc_html__("If you want to post from Blogspot to WordPress you need to get a Blogspot API Key:", 'blogspotomatic-blogspot-post-generator');?></h3>
                  <h4><b><span class="cr_color_red"><?php echo esc_html__("Info: You have to create a Blogspot App before filling the following details (if you do not have one). Please click", 'blogspotomatic-blogspot-post-generator');?> <a href="https://console.cloud.google.com/apis/credentials" target="_blank">here</a> to get a new Blogspot API Key. Go to -> Create Project -> 'Blogger' -> Enable API -> Create Credentials to create new Blogspot API Key.</span></b></h4>
               </div>
               <table>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "Insert your Blogspot API Key. Learn how to get one <a href='%s' target='_blank'>here</a>. This is used when posting from Blogspot to WordPress.", 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://console.cloud.google.com/apis/credentials' ) );
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Blogspot API Key:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="text" id="api_key" name="blogspotomatic_Main_Settings[api_key]" value="<?php
                              echo esc_html($api_key);
                              ?>" placeholder="<?php echo esc_html__("Please insert your Blogspot API Key", 'blogspotomatic-blogspot-post-generator');?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td></td>
                     <td><br/><input type="submit" name="btnSubmitApp" id="btnSubmitApp" class="button button-primary" onclick="unsaved = false;" value="Save API Key Info"/>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <hr/>
                     </td>
                     <td>
                        <hr/>
                     </td>
                  </tr>
                  <tr>
                     <td colspan="2">
                        <div class="hideInfo2">
                           <h3><?php echo esc_html__("If you want to post from WordPress to Blogspot you need to get a Blogspot OAuth Key and Secret:", 'blogspotomatic-blogspot-post-generator');?></h3>
                           <h4><b><span class="cr_color_red"><?php echo sprintf( wp_kses( __( 'Info: You have to create a Blogspot OAuth Key and Secret before filling the following details (if you do not have one). Please click <a href="%s" target="_blank">here</a> to get a new Blogspot OAuth Key. Go to -> Create Project -> \'Blogger\' -> Enable API -> Create Credentials to create new Blogspot API Key. Set the <b>\'Authorized redirect URIs\'</b> of your OAuth key to the following URL (otherwise authorization will not work!):<br/><span class="cr_blue">%s</span>', 'blogspotomatic-blogspot-post-generator'), array(  'span' => array('class' => array()), 'br' => array(), 'b' => array(), 'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://console.cloud.google.com/apis/credentials' ), esc_url( site_url() . '/wp-admin/admin.php?page=blogspotomatic_blogspot_panel&yt_auth_done=true' ) );?></span></span></b></h4>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "Insert your Blogspot OAuth2 Key. Learn how to get one <a href='%s' target='_blank'>here</a>. This is used when posting from WordPress to Blogspot. Please set the <b>'Authorized redirect URIs'</b> of your OAuth key to the following URL (otherwise authorization will not work!):<br/> <span class='cr_red'>%s</span>", 'blogspotomatic-blogspot-post-generator'), array(  'br' => array(), 'span' => array('class' => array()), 'b' => array(), 'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://console.cloud.google.com/apis/credentials' ), esc_url(site_url() . '/wp-admin/admin.php?page=blogspotomatic_blogspot_panel&yt_auth_done=true') );
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Blogspot Oauth Client ID:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="text" id="oauth_key" name="blogspotomatic_Main_Settings[oauth_key]" value="<?php
                              echo esc_html($oauth_key);
                              ?>" placeholder="<?php echo esc_html__("Please insert your Blogspot Oauth Consumer Key", 'blogspotomatic-blogspot-post-generator');?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "Insert your Blogspot OAuth2 Secret. Learn how to get one <a href='%s' target='_blank'>here</a>. This is used when posting from WordPress to Blogspot. Please set the <b>'Authorized redirect URIs'</b> of your OAuth key to the following URL (otherwise authorization will not work!):<br/> <span class='cr_red'>%s</span>", 'blogspotomatic-blogspot-post-generator'), array(  'br' => array(), 'span' => array('class' => array()), 'b' => array(), 'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://console.cloud.google.com/apis/credentials' ), esc_url(site_url() . '/wp-admin/admin.php?page=blogspotomatic_blogspot_panel&yt_auth_done=true') );
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Blogspot Oauth Client Secret:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="password" autocomplete="off" id="oauth_secret" name="blogspotomatic_Main_Settings[oauth_secret]" value="<?php
                              echo esc_html($oauth_secret);
                              ?>" placeholder="<?php echo esc_html__("Please insert your Blogspot Secret Key", 'blogspotomatic-blogspot-post-generator');?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td></td>
                     <td><input type="submit" name="btnSubmitApp" id="btnSubmitApp" class="button button-primary" onclick="unsaved = false;" value="Save OAuth Info"/>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <hr/>
                     </td>
                     <td>
                        <hr/>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <h3><?php echo esc_html__("After you entered the App ID and Secret, you can start creating rules:", 'blogspotomatic-blogspot-post-generator');?></h3>
                     </td>
                  </tr>
                  <tr>
                     <td><a name="newest" href="admin.php?page=blogspotomatic_items_panel">- Blogspot -> WordPress -</a></td>
                     <td>
                        (<?php echo esc_html__("using feeds from Blogspot public groups or pages", 'blogspotomatic-blogspot-post-generator');?>)
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text cr_min_260px">
                              <?php
                                 echo esc_html__("Posts will be generated from the latest entries in Blogspot public posts.", 'blogspotomatic-blogspot-post-generator');
                                 ?>
                           </div>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td><a name="user" href="admin.php?page=blogspotomatic_blogspot_panel">- WordPress -> Blogspot -</a></td>
                     <td>
                        (<?php echo esc_html__("using latest published posts from your blog", 'blogspotomatic-blogspot-post-generator');?>)
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text cr_min_260px">
                              <?php
                                 echo esc_html__("Blogspot posts will be generated from the latest published blog posts. Posts will be posted by the Blogspot user associated with the App ID entered.", 'blogspotomatic-blogspot-post-generator');
                                 ?>
                           </div>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <hr/>
                     </td>
                     <td>
                        <hr/>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <h3><?php echo esc_html__("Plugin Options:", 'blogspotomatic-blogspot-post-generator');?></h3>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to add Open Graph meta tags to your generated pages (this feature will improve page sharing experience on Blogspot).", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Enable Open Graph Meta Tags in Generated Pages:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="enable_og" name="blogspotomatic_Main_Settings[enable_og]"<?php
                        if ($enable_og == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to skip checking for duplicate posts when publishing new posts (check this if you have 10000+ posts on your blog and you are experiencing slowdows when the plugin is running. If you check this, duplicate posts will be posted! So use it only when it is necesarry.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Do Not Check For Duplicate Posts:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="do_not_check_duplicates" name="blogspotomatic_Main_Settings[do_not_check_duplicates]"<?php
                        if ($do_not_check_duplicates == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to strip links from the generated post content.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Strip Links From Generated Post Content:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="strip_links" name="blogspotomatic_Main_Settings[strip_links]"<?php
                        if ($strip_links == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to try to get full size images for imported posts.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Try To Get Full Size Images:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="full_imgs" name="blogspotomatic_Main_Settings[full_imgs]"<?php
                        if ($full_imgs == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "Insert your Bitly API generic access token. To register at Bitly, please visit <a href='%s' target='_blank'>this link</a>. To get a generic access token, please click the menu icon on the top right of the web (after you log in) -> click the '>' sign next to your account name -> click the 'Generic Access Token' menu entry -> enter your password in the 'Password' field and click 'Generate Token'. Copy the resulting token here. To lean more about this, please check <a href='%s' target='_blank'>this video</a>.", 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://bitly.com/a/sign_up?utm_content=site-free-button&utm_source=organic&utm_medium=website&utm_campaign=null&utm_cta=site-free-button' ), esc_url('//www.youtube.com/watch?v=vBfaNbS4xbs') );
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Shorten Imported URLs To WordPress Using Bitly:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="links_hide_google" name="blogspotomatic_Main_Settings[links_hide_google]" onclick="mainChanged()"<?php
                        if ($links_hide_google == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "Insert your Bitly API generic access token. To register at Bitly, please visit <a href='%s' target='_blank'>this link</a>. To get a generic access token, please click the menu icon on the top right of the web (after you log in) -> click the '>' sign next to your account name -> click the 'Generic Access Token' menu entry -> enter your password in the 'Password' field and click 'Generate Token'. Copy the resulting token here. To lean more about this, please check <a href='%s' target='_blank'>this video</a>.", 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://bitly.com/a/sign_up?utm_content=site-free-button&utm_source=organic&utm_medium=website&utm_campaign=null&utm_cta=site-free-button' ), esc_url('//www.youtube.com/watch?v=vBfaNbS4xbs') );
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Shorten Exported URLs To Blogspot Using Bitly:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="links_hide_google2" name="blogspotomatic_Main_Settings[links_hide_google2]" onclick="mainChanged()"<?php
                        if ($links_hide_google2 == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class="hideGoogl">
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "Insert your Bitly API generic access token. To register at Bitly, please visit <a href='%s' target='_blank'>this link</a>. To get a generic access token, please click the menu icon on the top right of the web (after you log in) -> click the '>' sign next to your account name -> click the 'Generic Access Token' menu entry -> enter your password in the 'Password' field and click 'Generate Token'. Copy the resulting token here. To lean more about this, please check <a href='%s' target='_blank'>this video</a>.", 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://bitly.com/a/sign_up?utm_content=site-free-button&utm_source=organic&utm_medium=website&utm_campaign=null&utm_cta=site-free-button' ), esc_url('//www.youtube.com/watch?v=vBfaNbS4xbs') );
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Bitly API key:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div class="hideGoogl">
                           <input type="text" name="blogspotomatic_Main_Settings[gapiKey]" value="<?php echo esc_html($gapiKey);?>" placeholder="<?php echo esc_html__("Please insert your Bitly API key", 'blogspotomatic-blogspot-post-generator');?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to show an extended information metabox under every plugin generated post.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Show Extended Item Information Metabox in Post:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="enable_metabox" name="blogspotomatic_Main_Settings[enable_metabox]"<?php
                        if ($enable_metabox == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                    <td>
                       <div>
                          <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                             <div class="bws_hidden_help_text cr_min_260px">
                                <?php
                                   echo sprintf( wp_kses( __( "If you wish to use the official version of the Google Translator API for translation, you must enter first a Google API Key. Get one <a href='%s' target='_blank'>here</a>.  Please enable the 'Cloud Translation API' in <a href='%s' target='_blank'>Google Cloud Console</a>. Translation will work even without even without entering an API key here, but in this case, an unofficial Google Translate API will be used.", 'blogspotomatic-blogspot-post-generator'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://console.cloud.google.com/apis/credentials' ), esc_url( 'https://console.cloud.google.com/marketplace/browse?q=translate' ) );
                                   ?>
                             </div>
                          </div>
                          <b><a href="https://console.cloud.google.com/apis/credentials" target="_blank"><?php echo esc_html__("Google Translator API Key (Optional)", 'blogspotomatic-blogspot-post-generator');?>:</a></b>
                       </div>
                    </td>
                    <td>
                       <div>
                          <input type="password" autocomplete="off" id="google_trans_auth" placeholder="<?php echo esc_html__("API Key (optional)", 'blogspotomatic-blogspot-post-generator');?>" name="blogspotomatic_Main_Settings[google_trans_auth]" value="<?php
                             echo esc_html($google_trans_auth);
                             ?>"/>
                       </div>
                    </td>
                 </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to enable logging for rules?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Enable Logging for Rules:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="enable_logging" name="blogspotomatic_Main_Settings[enable_logging]" onclick="mainChanged()"<?php
                        if ($enable_logging == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class="hideLog">
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to enable detailed logging for rules? Note that this will dramatically increase the size of the log this plugin generates.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Enable Detailed Logging for Rules:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div class="hideLog">
                           <input type="checkbox" id="enable_detailed_logging" name="blogspotomatic_Main_Settings[enable_detailed_logging]"<?php
                              if ($enable_detailed_logging == 'on')
                                  echo ' checked ';
                              ?>>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class="hideLog">
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to automatically clear logs after a period of time.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Automatically Clear Logs After:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div class="hideLog">
                           <select id="auto_clear_logs" name="blogspotomatic_Main_Settings[auto_clear_logs]" >
                              <option value="No"<?php
                                 if ($auto_clear_logs == "No") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Disabled", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value="monthly"<?php
                                 if ($auto_clear_logs == "monthly") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once a month", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value="weekly"<?php
                                 if ($auto_clear_logs == "weekly") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once a week", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value="daily"<?php
                                 if ($auto_clear_logs == "daily") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once a day", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value="twicedaily"<?php
                                 if ($auto_clear_logs == "twicedaily") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Twice a day", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value="hourly"<?php
                                 if ($auto_clear_logs == "hourly") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once an hour", 'blogspotomatic-blogspot-post-generator');?></option>
                           </select>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Set the timeout (in seconds) for every rule running. I recommend that you leave this field at it's default value (3600).", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Timeout for Rule Running (seconds):", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="number" id="rule_timeout" step="1" min="0" placeholder="<?php echo esc_html__("Input rule timeout in seconds", 'blogspotomatic-blogspot-post-generator');?>" name="blogspotomatic_Main_Settings[rule_timeout]" value="<?php
                              echo esc_html($rule_timeout);
                              ?>"/>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to receive a summary of the rule running in an email.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Send Rule Running Summary in Email:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="send_email" name="blogspotomatic_Main_Settings[send_email]" onchange="mainChanged()"<?php
                        if ($send_email == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class="hideMail">
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Input the email adress where you want to send the report. You can input more email addresses, separated by commas.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Email Address:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div class="hideMail">
                           <input type="email" id="email_address" placeholder="<?php echo esc_html__("Input a valid email adress", 'blogspotomatic-blogspot-post-generator');?>" name="blogspotomatic_Main_Settings[email_address]" value="<?php
                              echo esc_html($email_address);
                              ?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Set the minimum word count for post titles. Items that have less than this count will not be published. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Minimum Title Word Count (Skip Post Otherwise):", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="number" id="min_word_title" step="1" placeholder="<?php echo esc_html__("Input the minimum word count for the title", 'blogspotomatic-blogspot-post-generator');?>" min="0" name="blogspotomatic_Main_Settings[min_word_title]" value="<?php
                              echo esc_html($min_word_title);
                              ?>"/>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Set the maximum word count for post titles. Items that have more than this count will not be published. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Maximum Title Word Count (Skip Post Otherwise):", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="number" id="max_word_title" step="1" min="0" placeholder="<?php echo esc_html__("Input the maximum word count for the title", 'blogspotomatic-blogspot-post-generator');?>" name="blogspotomatic_Main_Settings[max_word_title]" value="<?php
                              echo esc_html($max_word_title);
                              ?>"/>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Set the minimum word count for post content. Items that have less than this count will not be published. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Minimum Content Word Count (Skip Post Otherwise):", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="number" id="min_word_content" step="1" min="0" placeholder="<?php echo esc_html__("Input the minimum word count for the content", 'blogspotomatic-blogspot-post-generator');?>" name="blogspotomatic_Main_Settings[min_word_content]" value="<?php
                              echo esc_html($min_word_content);
                              ?>"/>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Set the maximum word count for post content. Items that have more than this count will not be published. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Maximum Content Word Count (Skip Post Otherwise):", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="number" id="max_word_content" step="1" min="0" placeholder="<?php echo esc_html__("Input the maximum word count for the content", 'blogspotomatic-blogspot-post-generator');?>" name="blogspotomatic_Main_Settings[max_word_content]" value="<?php
                              echo esc_html($max_word_content);
                              ?>"/>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do not include posts that's title or content contains at least one of these words. Separate words by comma. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Banned Words List:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="1" name="blogspotomatic_Main_Settings[banned_words]" placeholder="<?php echo esc_html__("Do not generate posts that contain at least one of these words", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($banned_words);
                        ?></textarea>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do not include posts that's title or content does not contain at least one of these words. Separate words by comma. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Required Words List:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="1" name="blogspotomatic_Main_Settings[required_words]" placeholder="<?php echo esc_html__("Do not generate posts unless they contain all of these words", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($required_words);
                        ?></textarea>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Click this option if your want to save images found in post content locally. Note that this option may be heavy on your hosting free space.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Copy Images From Content Locally:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="copy_images" name="blogspotomatic_Main_Settings[copy_images]"<?php
                        if ($copy_images == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Resize the image that was assigned to be the featured image to the width specified in this text field (in pixels). If you want to disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Featured Image Resize Width:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="number" min="1" step="1" name="blogspotomatic_Main_Settings[resize_width]" value="<?php echo esc_html($resize_width);?>" placeholder="<?php echo esc_html__("Please insert the desired width for featured images", 'blogspotomatic-blogspot-post-generator');?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Resize the image that was assigned to be the featured image to the height specified in this text field (in pixels). If you want to disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Featured Image Resize Height:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="number" min="1" step="1" name="blogspotomatic_Main_Settings[resize_height]" value="<?php echo esc_html($resize_height);?>" placeholder="<?php echo esc_html__("Please insert the desired height for featured images", 'blogspotomatic-blogspot-post-generator');?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Strip HTML elements from final content that have this IDs. You can insert more IDs, separeted by comma. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Strip HTML Elements from Final Content by ID:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="3" cols="70" name="blogspotomatic_Main_Settings[strip_by_id]" placeholder="<?php echo esc_html__("Ids list", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($strip_by_id);
                        ?></textarea>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Strip HTML elements from final content that have this class. You can insert more classes, separeted by comma. To disable this feature, leave this field blank.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Strip HTML Elements from Final Content by Class:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="3" cols="70" name="blogspotomatic_Main_Settings[strip_by_class]" placeholder="<?php echo esc_html__("Class list", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($strip_by_class);
                        ?></textarea>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to skip posts that do not have images.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Skip Posts That Do Not Have Images:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="skip_no_img" name="blogspotomatic_Main_Settings[skip_no_img]"<?php
                        if ($skip_no_img == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to skip posts that are older than a selected date.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Skip Posts Older Than a Selected Date:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="skip_old" name="blogspotomatic_Main_Settings[skip_old]" onchange="mainChanged()"<?php
                        if ($skip_old == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class='hideOld'>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Select the date prior which you want to skip posts.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Select the Date for Old Posts:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div class='hideOld'>
                           <?php echo esc_html__("Day:", 'blogspotomatic-blogspot-post-generator');?>
                           <select class="cr_width_80" name="blogspotomatic_Main_Settings[skip_day]" >
                              <option value='01'<?php
                                 if ($skip_day == '01')
                                     echo ' selected';
                                 ?>>01</option>
                              <option value='02'<?php
                                 if ($skip_day == '02')
                                     echo ' selected';
                                 ?>>02</option>
                              <option value='03'<?php
                                 if ($skip_day == '03')
                                     echo ' selected';
                                 ?>>03</option>
                              <option value='04'<?php
                                 if ($skip_day == '04')
                                     echo ' selected';
                                 ?>>04</option>
                              <option value='05'<?php
                                 if ($skip_day == '05')
                                     echo ' selected';
                                 ?>>05</option>
                              <option value='06'<?php
                                 if ($skip_day == '06')
                                     echo ' selected';
                                 ?>>06</option>
                              <option value='07'<?php
                                 if ($skip_day == '07')
                                     echo ' selected';
                                 ?>>07</option>
                              <option value='08'<?php
                                 if ($skip_day == '08')
                                     echo ' selected';
                                 ?>>08</option>
                              <option value='09'<?php
                                 if ($skip_day == '09')
                                     echo ' selected';
                                 ?>>09</option>
                              <option value='10'<?php
                                 if ($skip_day == '10')
                                     echo ' selected';
                                 ?>>10</option>
                              <option value='11'<?php
                                 if ($skip_day == '11')
                                     echo ' selected';
                                 ?>>11</option>
                              <option value='12'<?php
                                 if ($skip_day == '12')
                                     echo ' selected';
                                 ?>>12</option>
                              <option value='13'<?php
                                 if ($skip_day == '13')
                                     echo ' selected';
                                 ?>>13</option>
                              <option value='14'<?php
                                 if ($skip_day == '14')
                                     echo ' selected';
                                 ?>>14</option>
                              <option value='15'<?php
                                 if ($skip_day == '15')
                                     echo ' selected';
                                 ?>>15</option>
                              <option value='16'<?php
                                 if ($skip_day == '16')
                                     echo ' selected';
                                 ?>>16</option>
                              <option value='17'<?php
                                 if ($skip_day == '17')
                                     echo ' selected';
                                 ?>>17</option>
                              <option value='18'<?php
                                 if ($skip_day == '18')
                                     echo ' selected';
                                 ?>>18</option>
                              <option value='19'<?php
                                 if ($skip_day == '19')
                                     echo ' selected';
                                 ?>>19</option>
                              <option value='20'<?php
                                 if ($skip_day == '20')
                                     echo ' selected';
                                 ?>>20</option>
                              <option value='21'<?php
                                 if ($skip_day == '21')
                                     echo ' selected';
                                 ?>>21</option>
                              <option value='22'<?php
                                 if ($skip_day == '22')
                                     echo ' selected';
                                 ?>>22</option>
                              <option value='23'<?php
                                 if ($skip_day == '23')
                                     echo ' selected';
                                 ?>>23</option>
                              <option value='24'<?php
                                 if ($skip_day == '24')
                                     echo ' selected';
                                 ?>>24</option>
                              <option value='25'<?php
                                 if ($skip_day == '25')
                                     echo ' selected';
                                 ?>>25</option>
                              <option value='26'<?php
                                 if ($skip_day == '26')
                                     echo ' selected';
                                 ?>>26</option>
                              <option value='27'<?php
                                 if ($skip_day == '27')
                                     echo ' selected';
                                 ?>>27</option>
                              <option value='28'<?php
                                 if ($skip_day == '28')
                                     echo ' selected';
                                 ?>>28</option>
                              <option value='29'<?php
                                 if ($skip_day == '29')
                                     echo ' selected';
                                 ?>>29</option>
                              <option value='30'<?php
                                 if ($skip_day == '30')
                                     echo ' selected';
                                 ?>>30</option>
                              <option value='31'<?php
                                 if ($skip_day == '31')
                                     echo ' selected';
                                 ?>>31</option>
                           </select>
                           <?php echo esc_html__("Month:", 'blogspotomatic-blogspot-post-generator');?>
                           <select class="cr_width_80" name="blogspotomatic_Main_Settings[skip_month]" >
                              <option value='01'<?php
                                 if ($skip_month == '01')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("January", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='02'<?php
                                 if ($skip_month == '02')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("February", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='03'<?php
                                 if ($skip_month == '03')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("March", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='04'<?php
                                 if ($skip_month == '04')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("April", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='05'<?php
                                 if ($skip_month == '05')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("May", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='06'<?php
                                 if ($skip_month == '06')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("June", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='07'<?php
                                 if ($skip_month == '07')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("July", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='08'<?php
                                 if ($skip_month == '08')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("August", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='09'<?php
                                 if ($skip_month == '09')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("September", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='10'<?php
                                 if ($skip_month == '10')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("October", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='11'<?php
                                 if ($skip_month == '11')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("November", 'blogspotomatic-blogspot-post-generator');?></option>
                              <option value='12'<?php
                                 if ($skip_month == '12')
                                     echo ' selected';
                                 ?>><?php echo esc_html__("December", 'blogspotomatic-blogspot-post-generator');?></option>
                           </select>
                           <?php echo esc_html__("Year:", 'blogspotomatic-blogspot-post-generator');?><input class="cr_width_70" value="<?php
                              echo esc_html($skip_year);
                              ?>" placeholder="<?php echo esc_html__("year", 'blogspotomatic-blogspot-post-generator');?>" name="blogspotomatic_Main_Settings[skip_year]" type="text" pattern="^\d{4}$">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to automatically translate generated content using Google Translate?", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Automatically Translate Content To:", 'blogspotomatic-blogspot-post-generator');?></b><br/><b><?php echo esc_html__("Info:", 'blogspotomatic-blogspot-post-generator');?></b> <?php echo esc_html__("for translation, the plugin also supports WPML.", 'blogspotomatic-blogspot-post-generator');?> <b><a href="https://wpml.org/?aid=238195&affiliate_key=ix3LsFyq0xKz" target="_blank"><?php echo esc_html__("Get WPML now!", 'blogspotomatic-blogspot-post-generator');?></a></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <select id="translate" name="blogspotomatic_Main_Settings[translate]" >
                           <?php
                              $i = 0;
                              foreach ($language_names as $lang) {
                                  echo '<option value="' . esc_html($language_codes[$i]) . '"';
                                  if ($translate == $language_codes[$i]) {
                                      echo ' selected';
                                  }
                                  echo '>' . esc_html($language_names[$i]) . '</option>';
                                  $i++;
                              }
                              ?>
                           </select>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Specify the translations source language.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Translation Source Language:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <select id="translate_source" name="blogspotomatic_Main_Settings[translate_source]" >
                           <?php
                              $i = 0;
                              foreach ($language_names as $lang) {
                                  echo '<option value="' . esc_html($language_codes[$i]) . '"';
                                  if ($translate_source == $language_codes[$i]) {
                                      echo ' selected';
                                  }
                                  echo '>' . esc_html($language_names[$i]) . '</option>';
                                  $i++;
                              }
                              ?>
                           </select>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div id="bestspin">
                           <p><?php echo esc_html__("Don't have an 'The Best Spinner' account yet? Click here to get one:", 'blogspotomatic-blogspot-post-generator');?> <b><a href="https://paykstrt.com/10313/38910" target="_blank"><?php echo esc_html__("get a new account now!", 'blogspotomatic-blogspot-post-generator');?></a></b></p>
                        </div>
                        <div id="wordai">
                           <p><?php echo esc_html__("Don't have an 'WordAI' account yet? Click here to get one:", 'blogspotomatic-blogspot-post-generator');?> <b><a href="https://wordai.com/?ref=h17f4" target="_blank"><?php echo esc_html__("get a new account now!", 'blogspotomatic-blogspot-post-generator');?></a></b></p>
                        </div>
                        <div id="spinrewriter">
                           <p><?php echo esc_html__("Don't have an 'SpinRewriter' account yet? Click here to get one:", 'blogspotomatic-blogspot-post-generator');?> <b><a href="https://www.spinrewriter.com/?ref=24b18" target="_blank"><?php echo esc_html__("get a new account now!", 'blogspotomatic-blogspot-post-generator');?></a></b></p>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to randomize text by changing words of a text with synonyms using one of the listed methods? Note that this is an experimental feature and can in some instances drastically increase the rule running time!", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Spin Text Using Word Synonyms (for automatically generated posts only):", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <select id="spin_text" name="blogspotomatic_Main_Settings[spin_text]" onchange="mainChanged()">
                     <option value="disabled"
                        <?php
                           if ($spin_text == 'disabled') {
                               echo ' selected';
                           }
                           ?>
                        ><?php echo esc_html__("Disabled", 'blogspotomatic-blogspot-post-generator');?></option>
                     <option value="best"
                        <?php
                           if ($spin_text == 'best') {
                               echo ' selected';
                           }
                           ?>
                        >The Best Spinner - <?php echo esc_html__("High Quality - Paid", 'blogspotomatic-blogspot-post-generator');?></option>
                     <option value="wordai"
                        <?php
                           if($spin_text == 'wordai')
                                   {
                                       echo ' selected';
                                   }
                           ?>
                        >Wordai - <?php echo esc_html__("High Quality - Paid", 'blogspotomatic-blogspot-post-generator');?></option>
                     <option value="spinrewriter"
                        <?php
                           if($spin_text == 'spinrewriter')
                                   {
                                       echo ' selected';
                                   }
                           ?>
                        >SpinRewriter - <?php echo esc_html__("High Quality - Paid", 'blogspotomatic-blogspot-post-generator');?></option>
                     <option value="builtin"
                        <?php
                           if ($spin_text == 'builtin') {
                               echo ' selected';
                           }
                           ?>
                        ><?php echo esc_html__("Built-in - Medium Quality - Free", 'blogspotomatic-blogspot-post-generator');?></option>
                     <option value="wikisynonyms"
                        <?php
                           if ($spin_text == 'wikisynonyms') {
                               echo ' selected';
                           }
                           ?>
                        >WikiSynonyms - <?php echo esc_html__("Low Quality - Free", 'blogspotomatic-blogspot-post-generator');?></option>
                     <option value="freethesaurus"
                        <?php
                           if ($spin_text == 'freethesaurus') {
                               echo ' selected';
                           }
                           ?>
                        >FreeThesaurus - <?php echo esc_html__("Low Quality - Free", 'blogspotomatic-blogspot-post-generator');?></option>
                     </select>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class="hideBest">
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Insert your user name on premium spinner service.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Premium Spinner Service User Name/Email:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div class="hideBest">
                           <input type="text" name="blogspotomatic_Main_Settings[best_user]" value="<?php
                              echo esc_html($best_user);
                              ?>" placeholder="<?php echo esc_html__("Please insert your premium text spinner service user name", 'blogspotomatic-blogspot-post-generator');?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div class="hideBest">
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Insert your password for the selected premium spinner service.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Premium Spinner Service Password/API Key:", 'blogspotomatic-blogspot-post-generator');?></b>
                        </div>
                     </td>
                     <td>
                        <div class="hideBest">
                           <input type="password" autocomplete="off" name="blogspotomatic_Main_Settings[best_password]" value="<?php
                              echo esc_html($best_password);
                              ?>" placeholder="<?php echo esc_html__("Please insert your premium text spinner service password", 'blogspotomatic-blogspot-post-generator');?>">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <hr/>
                     </td>
                     <td>
                        <hr/>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <h3><?php echo esc_html__("Random Sentence Generator Settings:", 'blogspotomatic-blogspot-post-generator');?></h3>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Insert some sentences from which you want to get one at random. You can also use variables defined below. %something ==> is a variable. Each sentence must be separated by a new line.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("First List of Possible Sentences (%%random_sentence%%):", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="8" cols="70" name="blogspotomatic_Main_Settings[sentence_list]" placeholder="<?php echo esc_html__("Please insert the first list of sentences", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($sentence_list);
                        ?></textarea>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Insert some sentences from which you want to get one at random. You can also use variables defined below. %something ==> is a variable. Each sentence must be separated by a new line.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Second List of Possible Sentences (%%random_sentence2%%):", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="8" cols="70" name="blogspotomatic_Main_Settings[sentence_list2]" placeholder="<?php echo esc_html__("Please insert the second list of sentences", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($sentence_list2);
                        ?></textarea>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Insert some variables you wish to be exchanged for different instances of one sentence. Please format this list as follows:<br/>
                                    Variablename => Variables (seperated by semicolon)<br/>Example:<br/>adjective => clever;interesting;smart;huge;astonishing;unbelievable;nice;adorable;beautiful;elegant;fancy;glamorous;magnificent;helpful;awesome<br/>", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("List of Possible Variables:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="8" cols="70" name="blogspotomatic_Main_Settings[variable_list]" placeholder="<?php echo esc_html__("Please insert the list of variables", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($variable_list);
                        ?></textarea>
                     </div></td>
                  </tr>
                  <tr>
                     <td>
                        <hr/>
                     </td>
                     <td>
                        <hr/>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <h3><?php echo esc_html__("Custom HTML Code/ Ad Code:", 'blogspotomatic-blogspot-post-generator');?></h3>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Insert a custom HTML code that will replace the %%custom_html%% variable. This can be anything, even an Ad code.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Custom HTML Code #1:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="3" cols="70" name="blogspotomatic_Main_Settings[custom_html]" placeholder="<?php echo esc_html__("Custom HTML #1", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($custom_html);
                        ?></textarea>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Insert a custom HTML code that will replace the %%custom_html2%% variable. This can be anything, even an Ad code.", 'blogspotomatic-blogspot-post-generator');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Custom HTML Code #2:", 'blogspotomatic-blogspot-post-generator');?></b>
                     </td>
                     <td>
                     <textarea rows="3" cols="70" name="blogspotomatic_Main_Settings[custom_html2]" placeholder="<?php echo esc_html__("Custom HTML #2", 'blogspotomatic-blogspot-post-generator');?>"><?php
                        echo esc_textarea($custom_html2);
                        ?></textarea>
                     </div>
                     </td>
                  </tr>
               </table>
               <hr/>
               <h3><?php echo esc_html__("Affiliate Keyword Replacer Tool Settings:", 'blogspotomatic-blogspot-post-generator');?></h3>
               <div class="table-responsive">
                  <table id="mainRules" class="responsive table cr_main_table">
                     <thead>
                        <tr>
                           <th>
                              <?php echo esc_html__("ID", 'blogspotomatic-blogspot-post-generator');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("This is the ID of the rule.", 'blogspotomatic-blogspot-post-generator');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th class="cr_max_width_40">
                              <?php echo esc_html__("Del", 'blogspotomatic-blogspot-post-generator');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Do you want to delete this rule?", 'blogspotomatic-blogspot-post-generator');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th>
                              <?php echo esc_html__("Search Keyword", 'blogspotomatic-blogspot-post-generator');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("This keyword will be replaced with a link you define.", 'blogspotomatic-blogspot-post-generator');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th>
                              <?php echo esc_html__("Replacement Keyword", 'blogspotomatic-blogspot-post-generator');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("This keyword will replace the search keyword you define. Leave this field blank if you only want to add an URL to the specified keyword.", 'blogspotomatic-blogspot-post-generator');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th>
                              <?php echo esc_html__("Link to Add", 'blogspotomatic-blogspot-post-generator');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Define the link you want to appear the defined keyword. Leave this field blank if you only want to replace the specified keyword without linking from it.", 'blogspotomatic-blogspot-post-generator');
                                       ?>
                                 </div>
                              </div>
                           </th>
                        </tr>
                        <tr>
                           <td>
                              <hr/>
                           </td>
                           <td>
                              <hr/>
                           </td>
                           <td>
                              <hr/>
                           </td>
                           <td>
                              <hr/>
                           </td>
                           <td>
                              <hr/>
                           </td>
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                           echo blogspotomatic_expand_keyword_rules();
                           ?>
                        <tr>
                           <td>
                              <hr/>
                           </td>
                           <td>
                              <hr/>
                           </td>
                           <td>
                              <hr/>
                           </td>
                           <td>
                              <hr/>
                           </td>
                           <td>
                              <hr/>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_short_td">-</td>
                           <td class="cr_shrt_td2"><span class="cr_gray20">X</span></td>
                           <td class="cr_rule_line"><input type="text" name="blogspotomatic_keyword_list[keyword][]"  placeholder="<?php echo esc_html__("Please insert the keyword to be replaced", 'blogspotomatic-blogspot-post-generator');?>" value="" class="cr_width_100" /></td>
                           <td class="cr_rule_line"><input type="text" name="blogspotomatic_keyword_list[replace][]"  placeholder="<?php echo esc_html__("Please insert the keyword to replace the search keyword", 'blogspotomatic-blogspot-post-generator');?>" value="" class="cr_width_100" /></td>
                           <td class="cr_rule_line"><input type="url" validator="url" name="blogspotomatic_keyword_list[link][]" placeholder="<?php echo esc_html__("Please insert the link to be added to the keyword", 'blogspotomatic-blogspot-post-generator');?>" value="" class="cr_width_100" />
                        </tr>
                     </tbody>
                  </table>
               </div>
               </td></tr>
               </table>
            </div>
         </div>
   </div>
   <hr/>
   <p>
   <?php echo esc_html__("Available shortcodes:", 'blogspotomatic-blogspot-post-generator');?> <strong>[blogspotomatic-list-posts]</strong> <?php echo esc_html__("to include a list that contains only posts imported by this plugin, and", 'blogspotomatic-blogspot-post-generator');?> <strong>[blogspotomatic-display-posts]</strong> <?php echo esc_html__("to include a WordPress like post listing. Usage:", 'blogspotomatic-blogspot-post-generator');?> [blogspotomatic-display-posts type='any/post/page/...' title_color='#ffffff' excerpt_color='#ffffff' read_more_text="Read More" link_to_source='yes' order='ASC/DESC' orderby='title/ID/author/name/date/rand/comment_count' title_font_size='19px', excerpt_font_size='19px' posts_per_page=number_of_posts_to_show category='posts_category' ruleid='ID_of_blogspotomatic_rule' ruletype='rule_type_id'].
   <br/><?php echo esc_html__("Example:", 'blogspotomatic-blogspot-post-generator');?> <b>[blogspotomatic-list-posts type='any' order='ASC' orderby='date' posts_per_page=50 category= '' ruleid='0' ruletype='0']</b>
   <br/><?php echo esc_html__("Example 2:", 'blogspotomatic-blogspot-post-generator');?> <b>[blogspotomatic-display-posts include_excerpt='true' image_size='thumbnail' wrapper='div']</b>.
   </p>
   <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings", 'blogspotomatic-blogspot-post-generator');?>"/></p></div>
   </form>
</div>
<?php
   }
   if (isset($_POST['blogspotomatic_keyword_list'])) {
       add_action('admin_init', 'blogspotomatic_save_keyword_rules');
   }
   function blogspotomatic_save_keyword_rules($data2)
   {
       $data2 = $_POST['blogspotomatic_keyword_list'];
       $rules = array();
       if (isset($data2['keyword'][0])) {
           for ($i = 0; $i < sizeof($data2['keyword']); ++$i) {
               if (isset($data2['keyword'][$i]) && $data2['keyword'][$i] != '') {
                   $index         = trim(sanitize_text_field($data2['keyword'][$i]));
                   $rules[$index] = array(
                       trim(sanitize_text_field($data2['link'][$i])),
                       trim(sanitize_text_field($data2['replace'][$i]))
                   );
               }
           }
       }
       update_option('blogspotomatic_keyword_list', $rules);
   }
   function blogspotomatic_expand_keyword_rules()
   {
       $rules  = get_option('blogspotomatic_keyword_list');
       $output = '';
       $cont   = 0;
       if (!empty($rules)) {
           foreach ($rules as $request => $value) {
               $output .= '<tr>
                           <td class="cr_short_td">' . esc_html($cont) . '</td>
                           <td class="cr_shrt_td2"><span class="wpblogspotomatic-delete">X</span></td>
                           <td class="cr_rule_line"><input type="text" placeholder="' . esc_html__('Input the keyword to be replaced. This field is required', 'blogspotomatic-blogspot-post-generator') . '" name="blogspotomatic_keyword_list[keyword][]" value="' . esc_html($request) . '" required class="cr_width_100"></td>
                           <td class="cr_rule_line"><input type="text" placeholder="' . esc_html__('Input the replacement word', 'blogspotomatic-blogspot-post-generator') . '" name="blogspotomatic_keyword_list[replace][]" value="' . esc_html($value[1]) . '" class="cr_width_100"></td>
                           <td class="cr_rule_line"><input type="url" validator="url" placeholder="' . esc_html__('Input the URL to be added', 'blogspotomatic-blogspot-post-generator') . '" name="blogspotomatic_keyword_list[link][]" value="' . esc_html($value[0]) . '" class="cr_width_100"></td>
   					</tr>';
               $cont++;
           }
       }
       return $output;
   }
   ?>