"use strict";
function blogspotomatic_post_now(postId)
{
    if (confirm("Are you sure you want to submit this post now?") == true) {
        document.getElementById('blogspotomatic_submit_post').setAttribute('disabled','disabled');
        document.getElementById("blogspotomatic_span").innerHTML = 'Submitting... (please do not close or refresh this page) ';
        var data = {
             action: 'blogspotomatic_post_now',
             id: postId
        };
        jQuery.post(ajaxurl, data, function(response) {
            document.getElementById('blogspotomatic_submit_post').removeAttribute('disabled');
            document.getElementById("blogspotomatic_span").innerHTML = 'Done! ';
        });
    } else {
        return;
    }
}