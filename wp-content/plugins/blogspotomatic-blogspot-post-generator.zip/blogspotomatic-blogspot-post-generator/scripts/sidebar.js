"use strict";
( function( wp ) {
	var registerPlugin = wp.plugins.registerPlugin;
	var PluginSidebar = wp.editPost.PluginSidebar;
	var el = wp.element.createElement;
    
	registerPlugin( 'blogspotomatic-sidebar', {
		render: function() {
            function updateMessage( ) {
                var postId = wp.data.select("core/editor").getCurrentPostId();
                if (confirm("Are you sure you want to submit this post now?") == true) {
                    document.getElementById('blogspotomatic_submit_post').setAttribute('disabled','disabled');
                    document.getElementById("blogspotomatic_span").innerHTML = 'Posting status: Submitting... (please do not close or refresh this page) ';
                    var data = {
                         action: 'blogspotomatic_post_now',
                         id: postId
                    };
                    jQuery.post(ajaxurl, data, function(response) {
                        document.getElementById('blogspotomatic_submit_post').removeAttribute('disabled');
                        document.getElementById("blogspotomatic_span").innerHTML = 'Posting status: Done! ';
                    });
                } else {
                    return;
                }
            }
			return el( PluginSidebar,
				{
					name: 'blogspotomatic-sidebar',
					icon: 'welcome-write-blog',
					title: 'Blogspotomatic Post Publisher',
				},
				el(
                    'div', 
                    { className: 'coderevolution_gutenberg_div' },
                    el(
                        'h4',
                        { className: 'coderevolution_gutenberg_title' },
                        'Publish Post to Blogspot '
                    ),
                    el(
                        'input',
                        { type:'button', id:'blogspotomatic_submit_post', value:'Post To Blogspot Now!', onClick: updateMessage, className: 'coderevolution_gutenberg_button button button-primary' }
                    ),
                    el(
                    'br'
                    ),
                    el(
                    'br'
                    ),
                    el(
                        'div', 
                        {id:'blogspotomatic_span'},
                        'Posting status: idle'
                    )
				)
			);
		},
	} );
} )( window.wp );