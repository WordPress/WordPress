<?php
defined('ABSPATH') or die();
function aiomatic_compare_fill(&$measure,&$fill) {
	if (count($measure) != count($fill)) {
        while (count($fill) < count($measure) ) {
		    $fill = array_merge( $fill, array_values($fill) );
		}
		$fill = array_slice($fill, 0, count($measure));
	}
}

function aiomatic_test_post_reponse() {

	$post_response = wp_safe_remote_post(
		'https://www.paypal.com/cgi-bin/webscr',
		array(
			'timeout'     => 10,
			'httpversion' => '1.1',
			'body'        => array(
				'cmd' => '_notify-validate',
			),
		)
	);


	if ( ! is_wp_error( $post_response ) && $post_response['response']['code'] >= 200 && $post_response['response']['code'] < 300 ) {
		return true;
	}

	return false;
}

function aiomatic_test_get_reponse() {

	$get_response = wp_safe_remote_get( 'https://woocommerce.com/wc-api/product-key-api?request=ping&network=' . ( is_multisite() ? '1' : '0' ) );

	if ( ! is_wp_error( $get_response ) && $get_response['response']['code'] >= 200 && $get_response['response']['code'] < 300 ) {
		return true;
	}

	return false;
}
function aiomatic_check_cron_status() {
	global $wp_version;

	if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
		/* translators: 1: The name of the PHP constant that is set. */
		return new WP_Error( 'crontrol_info', sprintf( __( 'The %s constant is set to true. WP-Cron spawning is disabled.', 'wp-content-pilot' ), 'DISABLE_WP_CRON' ) );
	}

	if ( defined( 'ALTERNATE_WP_CRON' ) && ALTERNATE_WP_CRON ) {
		/* translators: 1: The name of the PHP constant that is set. */
		return new WP_Error( 'crontrol_info', sprintf( __( 'The %s constant is set to true.', 'wp-content-pilot' ), 'ALTERNATE_WP_CRON' ) );
	}

	$cached_status = get_transient( 'wpcp-cron-test-ok' );

	if ( $cached_status ) {
		return true;
	}

	$sslverify     = version_compare( $wp_version, 4.0, '<' );
	$doing_wp_cron = sprintf( '%.22F', microtime( true ) );

	$cron_request = apply_filters( 'cron_request', array(
		'url'  => site_url( 'wp-cron.php?doing_wp_cron=' . $doing_wp_cron ),
		'key'  => $doing_wp_cron,
		'args' => array(
			'timeout'   => 3,
			'blocking'  => true,
			'sslverify' => apply_filters( 'https_local_ssl_verify', $sslverify ),
		),
	) );

	$cron_request['args']['blocking'] = true;

	$result = wp_remote_post( $cron_request['url'], $cron_request['args'] );

	if ( is_wp_error( $result ) ) {
		return $result;
	} elseif ( wp_remote_retrieve_response_code( $result ) >= 300 ) {
		return new WP_Error( 'unexpected_http_response_code', sprintf(
		/* translators: 1: The HTTP response code. */
			__( 'Unexpected HTTP response code: %s', 'wp-content-pilot' ),
			intval( wp_remote_retrieve_response_code( $result ) )
		) );
	} else {
		set_transient( 'wpcp-cron-test-ok', 1, 3600 );

		return true;
	}

}
function aiomatic_let_to_num( $size ) {
    $l   = substr( $size, - 1 );
    $ret = substr( $size, 0, - 1 );
    switch ( strtoupper( $l ) ) {
        case 'P':
            $ret *= 1024;
        case 'T':
            $ret *= 1024;
        case 'G':
            $ret *= 1024;
        case 'M':
            $ret *= 1024;
        case 'K':
            $ret *= 1024;
    }

    return $ret;
}
function aiomatic_substr($prompt, $start, $len)
{
    if(function_exists('mb_substr'))
    {
        $prompt = mb_substr($prompt, $start, $len, 'UTF-8');
    }
    else
    {
        $prompt = substr($prompt, $start, $len);
    }
    return $prompt;
}
function aiomatic_seo_plugins_active()
{
    if (!function_exists('is_plugin_active')) {
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    }
    $seo_plugin_activated = false;
    if(is_plugin_active('wordpress-seo/wp-seo.php')){
        $seo_plugin_activated = '_yoast_wpseo_metadesc';
    }
    elseif(is_plugin_active('all-in-one-seo-pack/all_in_one_seo_pack.php')){
        $seo_plugin_activated = '_aioseo_description';
    }
    elseif(is_plugin_active('seo-by-rank-math/rank-math.php')){
        $seo_plugin_activated = 'rank_math_description';
    }
    return $seo_plugin_activated;
}
function aiomatic_save_seo_description($post_id, $description)
{
    global $wpdb;
    if(empty($description))
    {
        return;
    }
    $seo_plugin_activated = aiomatic_seo_plugins_active();
    $seo_option = get_option('_yoast_wpseo_metadesc',false);
    if($seo_plugin_activated == '_yoast_wpseo_metadesc' && $seo_option){
        update_post_meta($post_id, $seo_plugin_activated, $description);
    }
    $seo_option = get_option('_aioseo_description',false);
    if($seo_plugin_activated == '_aioseo_description' && $seo_option){
        update_post_meta($post_id, $seo_plugin_activated, $description);
        $check = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".$wpdb->prefix."aioseo_posts WHERE post_id=%d",$post_id));
        if($check)
        {
            $wpdb->update($wpdb->prefix.'aioseo_posts',array(
                'description' => $description
            ), array(
                'post_id' => $post_id
            ));
        }
        else{
            $wpdb->insert($wpdb->prefix.'aioseo_posts',array(
                'post_id' => $post_id,
                'description' => $description,
                'created' => date('Y-m-d H:i:s'),
                'updated' => date('Y-m-d H:i:s')
            ));
        }
    }
    $seo_option = get_option('rank_math_description',false);
    if($seo_plugin_activated == 'rank_math_description' && $seo_option){
        update_post_meta($post_id, $seo_plugin_activated, $description);
    }
    if($seo_plugin_activated == false)
    {
        $seo_plugin_activated = 'aiomatic_html_meta';
        update_post_meta($post_id, $seo_plugin_activated, $description);
    }
}
function aiomatic_get_random_word($min = 4, $max = 10) 
{
    $word = array_merge(range('a', 'z'), range('A', 'Z'));
    shuffle($word);
    $len = rand($min, $max);
    return substr(implode($word), 0, $len);
}
function aiomatic_get_api_service($token)
{
    if(aiomatic_is_aiomaticapi_key($token))
    {
        $api_service = 'AiomaticAPI';
    }
    else
    {
        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
        if (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure')
        {
            $api_service = 'Microsoft Azure OpenAI';
        }
        else
        {
            $api_service = 'OpenAI';
        }
    }
    return $api_service;
}
function aiomatic_check_is_elementor($postid)
{
    if (!function_exists('is_plugin_active')) {
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    }
    if (!is_plugin_active( 'elementor/elementor.php' )) 
    {
		return false;
	}
    if(!isset(\Elementor\Plugin::$instance))
    {
        return false;
    }
    return \Elementor\Plugin::$instance->db->is_built_with_elementor($postid);
}
function aiomatic_upload_base64_image($base64_img, $title, $post_id)
{
    $upload_dir = wp_upload_dir();
    $upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;
    $image_parts = explode(";base64,", $base64_img);
    $decoded = base64_decode($image_parts[1]);
    $filename = sanitize_title($title) . '.png';
    $hashed_filename = md5( $filename . microtime() ) . '_' . $filename;
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
        wp_filesystem($creds);
    }
    $ret = $wp_filesystem->put_contents( $upload_path . $hashed_filename, $decoded ); 
    if ($ret === FALSE) 
    {
        aiomatic_log_to_file('Failed to copy image locally ' . $upload_path . $hashed_filename);
        return false;
    }
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    $file             = array();
    $file['error']    = '';
    $file['tmp_name'] = $upload_path . $hashed_filename;
    $file['name']     = $hashed_filename;
    $file['type']     = 'image/png';
    $file['size']     = $wp_filesystem->size( $upload_path . $hashed_filename );
    $file_return = wp_handle_sideload($file, array( 'test_form' => false ));
    if(!isset($file_return['file']))
    {
        aiomatic_log_to_file('Failed to copy image file locally ' . $upload_path . $hashed_filename . ': ' . print_r($file_return, true));
        return false;
    }
    $filename = $file_return['file'];
    $attachment = array(
        'post_mime_type' => $file_return['type'],
        'post_title' => preg_replace('/\.[^.]+$/', '', basename($filename)),
        'post_content' => '',
        'post_status' => 'inherit',
        'guid' => $upload_dir['url'] . '/' . basename($filename)
    );
    $attach_id = wp_insert_attachment( $attachment, $filename, $post_id );
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $filename);
    wp_update_attachment_metadata($attach_id, $attach_data);
    return $attach_id;
}
function aiomatic_my_get_current_user_roles() {
    
    if( is_user_logged_in() ) {
  
      $user = wp_get_current_user();
  
      $roles = ( array ) $user->roles;
  
      return $roles;
  
    } else {
  
      return array();
  
    }
  
}
function aiomatic_my_get_current_user_subscriptions() {
    $levels = array();
    if(class_exists('Ihc_Db'))
    {
        if( is_user_logged_in() ) 
        {
            $current_user = wp_get_current_user();
            if(isset($current_user->ID))
            {
                $user_sub_data = Ihc_Db::get_user_levels($current_user->ID, true);
                if(is_array($user_sub_data))
                {
                    foreach($user_sub_data as $udata)
                    {
                        if(isset($udata['level_id']))
                        {
                            $levels[] = $udata['level_id'];
                        }
                    }
                }
            }  
        }
    }
    return $levels;
}
function aiomatic_get_assistant()
{
    $aiomatic_assistant_defaults = array("Write a paragraph on this" => array(
"0" => 'Write a paragraph on this topic:

%%selected_text%%
    
----
Written paragraph:
',
        "1" => 'text'
),

"Continue this text" => Array
    (
        "0" => 'Continue this text:

%%selected_text%%

----
Continued text:
',
"1" => 'text'
    ),

"Generate ideas on this" => Array
    (
        "0"=> 'Write a few ideas on that as bullet points:

%%selected_text%%

----
Generated ideas in bullet points:
',
"1" => 'text'
    ),

"Write an article about this" => Array
    (
        "0" => 'Write a complete article about this:

%%selected_text%%

----
Written article:
',
"1" => 'text'
    ),

"Turn this into an Ad" => Array
    (
"0" => 'Turn the following text into a creative advertisement:

%%selected_text%%

----
Advertisement:
',
"1" => 'text'
    ),

"Explain this to a 5 year old" => Array
    (
"0" => 'Explain this to a 5 years old kid:

%%selected_text%%

----
Explanation:
',
"1" => 'text'
    ),

"Find a matching quote for this" => Array
    (
"0" => 'Find a matching quote for the following text:

%%selected_text%%

----
Matching quote:
',
"1" => 'text'
    ),

"Generate a subtitle for this" => Array
    (
        "0" => 'Generate a title for this text:

%%selected_text%%

----
Title:
',
"1" => 'text'
    ),

"Generate a TL;DR of this" => Array
    (
        "0" => 'Write a TL;DR for this text:

%%selected_text%%

----
TL;DR:
',
"1" => 'text'
    ),

"Generate a Call to Action fo this" => Array
    (
        "0" => 'Generate a call to action about this:

%%selected_text%%

----
Call to action:
',
"1" => 'text'
    ),

"Summarize this" => Array
    (
        "0" => 'Summarize this text:

%%selected_text%%

----
Summary:
',
"1" => 'text'
    ),

"Expand this" => Array
    (
        "0" => 'Expand this text:

%%selected_text%%

----
Expanded text:
',
"1" => 'text'
    ),

"Make a bulleted list for this" => Array
    (
        "0" => 'Make a C for this:

%%selected_text%%

----
Bulleted list:
',
"1" => 'text'
    ),

"Rewrite this" => Array
    (
        "0" => 'Rewrite this text:

%%selected_text%%

----
Rewritten text:
',
"1" => 'text'
    ),

"Paraphrase this" => Array
    (
        "0" => 'Paraphrase this text:

%%selected_text%%

----
Paraphrased text:
',
"1" => 'text'
    ),

"Fix grammar of this" => Array
    (
        "0" => 'Fix grammar of this text:

%%selected_text%%

----
Text with fixed grammar:
',
"1" => 'text'
    ),

"Generate a question of this" => Array
    (
        "0" => 'Generate a question about this text:

%%selected_text%%

----
Question:
',
"1" => 'text'
    ),

"Convert this to passive voice" => Array
    (
        "0" => 'Convert this text to passive voice:

%%selected_text%%

----
Converted text to passive voice:
',
"1" => 'text'
    ),

"Convert this to active voice" => Array
    (
        "0" => 'Convert this text to active voice:

%%selected_text%%

----
Converted text to active voice:
',
"1" => 'text'
    ),

"Write a conclusion for this" => Array
    (
        "0" => 'Write a conclusion for this text:

%%selected_text%%

----
Conclusion:
',
"1" => 'text'
    ),

"Write a counterargument for this" => Array
    (
        "0" => 'Wite a counterargument for this text:

%%selected_text%%

----
Counterargument:
',
"1" => 'text'
    ),

"Translate this to Spanish" => Array
    (
"0" => 'Translate this text to Spanish:

%%selected_text%%

----
Spanish translation:
',
"1" => 'text'
    ),

"Generate an image idea for this" => Array
    (
"0" => 'Describe an image that would match this text:

%%selected_text%%

----
Image description:
',
"1" => 'text'
    ),

"Generate an image of this" => Array
    (
        "0" => 'A image of: %%selected_text%%',
"1" => 'image'
    )

);
    $rules  = get_option('aiomatic_assistant_list', array());
    if(!is_array($rules))
    {
        $rules = array();
    }
    if(empty($rules))
    {
        $rules = $aiomatic_assistant_defaults;
    }
    return $rules;
}
function aiomatic_hex2rgb($hex) {
    $hex = str_replace("#", "", $hex);
    if(strlen($hex) == 3) {
        $r = hexdec(substr($hex,0,1).substr($hex,0,1));
	    $g = hexdec(substr($hex,1,1).substr($hex,1,1));
	    $b = hexdec(substr($hex,2,1).substr($hex,2,1));
	} else {
	    $r = hexdec(substr($hex,0,2));
	    $g = hexdec(substr($hex,2,2));
	    $b = hexdec(substr($hex,4,2));
	}
	$rgb = array($r, $g, $b);
	return implode(",", $rgb);
}
function aiomatic_array_unique($array, $keep_key_assoc = false){
    $duplicate_keys = array();
    $tmp = array();       
 
    foreach ($array as $key => $val){
        if (is_object($val))
            $val = (array)$val;
 
        if (!in_array($val, $tmp))
            $tmp[] = $val;
        else
            $duplicate_keys[] = $key;
    }
 
    foreach ($duplicate_keys as $key)
        unset($array[$key]);
 
    return $keep_key_assoc ? $array : array_values($array);
 }
function aiomatic_clean_language_model_texts($content)
{
    $content = preg_replace('#As an? (?:AI )?languau?ge model(?: AI)?,?\s?#i' , '', $content);
    return $content;
}

function aiomatic_trailing_comma($incrementor, $count, &$subject) {
    $stopper = $count - 1;
	if ($incrementor !== $stopper) {
		return $subject .= ',';
	}
}
function aiomatic_auto_clear_log()
{
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
       wp_filesystem($creds);
    }
    if ($wp_filesystem->exists(WP_CONTENT_DIR . '/aiomatic_info.log')) {
        $wp_filesystem->delete(WP_CONTENT_DIR . '/aiomatic_info.log');
    }
}
function aiomatic_isSecure() {
    return
      (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
      || $_SERVER['SERVER_PORT'] == 443;
}

function aiomatic_get_mime ($filename) {
    $mime_types = array(
        'txt' => 'text/plain',
        'htm' => 'text/html',
        'html' => 'text/html',
        'php' => 'text/html',
        'css' => 'text/css',
        'js' => 'application/javascript',
        'json' => 'application/json',
        'xml' => 'application/xml',
        'swf' => 'application/x-shockwave-flash',
        'flv' => 'video/x-flv',
        'png' => 'image/png',
        'jpe' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'jpg' => 'image/jpeg',
        'gif' => 'image/gif',
        'bmp' => 'image/bmp',
        'ico' => 'image/vnd.microsoft.icon',
        'tiff' => 'image/tiff',
        'mts' => 'video/mp2t',
        'tif' => 'image/tiff',
        'svg' => 'image/svg+xml',
        'svgz' => 'image/svg+xml',
        'zip' => 'application/zip',
        'rar' => 'application/x-rar-compressed',
        'exe' => 'application/x-msdownload',
        'msi' => 'application/x-msdownload',
        'cab' => 'application/vnd.ms-cab-compressed',
        'mp3' => 'audio/mpeg',
        'qt' => 'video/quicktime',
        'mov' => 'video/quicktime',
        'wmv' => 'video/x-ms-wmv',
        'mp4' => 'video/mp4',
        'm4p' => 'video/m4p',
        'm4v' => 'video/m4v',
        'mpg' => 'video/mpg',
        'mp2' => 'video/mp2',
        'mpe' => 'video/mpe',
        'mpv' => 'video/mpv',
        'm2v' => 'video/m2v',
        'm4v' => 'video/m4v',
        '3g2' => 'video/3g2',
        '3gpp' => 'video/3gpp',
        'f4v' => 'video/f4v',
        'f4p' => 'video/f4p',
        'f4a' => 'video/f4a',
        'f4b' => 'video/f4b',
        '3gp' => 'video/3gp',
        'avi' => 'video/x-msvideo',
        'mpeg' => 'video/mpeg',
        'mpegps' => 'video/mpeg',
        'webm' => 'video/webm',
        'mpeg4' => 'video/mp4',
        'mkv' => 'video/mkv',
        'pdf' => 'application/pdf',
        'psd' => 'image/vnd.adobe.photoshop',
        'ai' => 'application/postscript',
        'eps' => 'application/postscript',
        'ps' => 'application/postscript',
        'doc' => 'application/msword',
        'rtf' => 'application/rtf',
        'xls' => 'application/vnd.ms-excel',
        'ppt' => 'application/vnd.ms-powerpoint',
        'docx' => 'application/msword',
        'xlsx' => 'application/vnd.ms-excel',
        'pptx' => 'application/vnd.ms-powerpoint',
        'odt' => 'application/vnd.oasis.opendocument.text',
        'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
    );
    $ext = array_values(array_slice(explode('.', $filename), -1));$ext = $ext[0];

    if(stristr($filename, 'dailymotion.com'))
    {
        return 'application/octet-stream';
    }
    if (function_exists('mime_content_type')) {
        error_reporting(0);
        $mimetype = mime_content_type($filename);
        error_reporting(E_ALL);
        if($mimetype == '')
        {
            if (array_key_exists($ext, $mime_types)) {
                return $mime_types[$ext];
            } else {
                return 'application/octet-stream';
            }
        }
        return $mimetype;
    }
    elseif (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME);
        $mimetype = finfo_file($finfo, $filename);
        finfo_close($finfo);
        if($mimetype === false)
        {
            if (array_key_exists($ext, $mime_types)) {
                return $mime_types[$ext];
            } else {
                return 'application/octet-stream';
            }
        }
        return $mimetype;

    } elseif (array_key_exists($ext, $mime_types)) {
        return $mime_types[$ext];
    } else {
        return 'application/octet-stream';
    }
}
function aiomatict_get_items($query=array()){
     global $wpdb;
     $defaults = array(
       'post_hash'=>''
     );
 
    $query = wp_parse_args($query, $defaults);
    
    extract($query);
    $allowed_fields = aiomatict_get_item_table_columns();
    $select_sql = "SELECT post_result FROM {$wpdb->aiomatict_shortcode_rez}";
    $join_sql='';
    $where_sql = $wpdb->prepare("WHERE post_hash = %s", $post_hash);

    $sql = "$select_sql $where_sql";
    $logs = $wpdb->get_results($sql);
    $logs = apply_filters('aiomatict_get_items', $logs, $query);
    return $logs;
}
function replaceAIPostShortcodes($content, $post_link, $post_title, $blog_title, $post_excerpt, $post_content, $user_name, $featured_image, $post_cats, $post_tagz, $post_id, $img_attr = '', $old_title = '', $post_title_keywords = '', $custom_shortcodes = '')
{
    $matches = array();
    $i = 0;
    preg_match_all('~%regex\(\s*\"([^"]+?)\s*"\s*[,;]\s*\"([^"]*)\"\s*(?:[,;]\s*\"([^"]*?)\s*\")?(?:[,;]\s*\"([^"]*?)\s*\")?(?:[,;]\s*\"([^"]*?)\s*\")?\)%~si', $content, $matches);
    if (is_array($matches) && count($matches) && is_array($matches[0])) {
        for($i = 0; $i < count($matches[0]); $i++)
        {
            if (isset($matches[0][$i])) $fullmatch = $matches[0][$i];
            if (isset($matches[1][$i])) $search_in = replaceAIPostShortcodes($matches[1][$i], $post_link, $post_title, $blog_title, $post_excerpt, $post_content, $user_name, $featured_image, $post_cats, $post_tagz, $post_id, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
            if (isset($matches[2][$i])) $matchpattern = $matches[2][$i];
            if (isset($matches[3][$i])) $element = $matches[3][$i];
            if (isset($matches[4][$i])) $delimeter = $matches[4][$i];if (isset($matches[5][$i])) $counter = $matches[5][$i];
            if (isset($matchpattern)) {
               if (preg_match('<^[\/#%+~[\]{}][\s\S]*[\/#%+~[\]{}]$>', $matchpattern, $z)) {
                  $ret = preg_match_all($matchpattern, $search_in, $submatches, PREG_PATTERN_ORDER);
               }
               else {
                  $ret = preg_match_all('~'.$matchpattern.'~si', $search_in, $submatches, PREG_PATTERN_ORDER);
               }
            }
            if (isset($submatches)) {
               if (is_array($submatches)) {
                  $empty_elements = array_keys($submatches[0], "");
                  foreach ($empty_elements as $e) {
                     unset($submatches[0][$e]);
                  }
                  $submatches[0] = array_unique($submatches[0]);
                  if (!is_numeric($element)) {
                     $element = 0;
                  }if (!is_numeric($counter)) {
                     $counter = 0;
                  }
                  if(isset($submatches[(int)($element)]))
                  {
                      $matched = $submatches[(int)($element)];
                  }
                  else
                  {
                      $matched = '';
                  }
                  $matched = array_unique((array)$matched);
                  if (empty($delimeter) || $delimeter == 'null') {
                     if (isset($matched[$counter])) $matched = $matched[$counter];
                  }
                  else {
                     $matched = implode($delimeter, $matched);
                  }
                  if (empty($matched)) {
                     $content = str_replace($fullmatch, '', $content);
                  } else {
                     $content = str_replace($fullmatch, $matched, $content);
                  }
               }
            }
        }
    }
    $spintax = new AIomatic_Spintax();
    $content = $spintax->process($content);
    $pcxxx = explode('<!- template ->', $content);
    $content = $pcxxx[array_rand($pcxxx)];
    $content = str_replace('%%random_sentence%%', aiomatic_random_sentence_generator(), $content);
    $content = str_replace('%%random_sentence2%%', aiomatic_random_sentence_generator(false), $content);
    $content = aiomatic_replaceSynergyShortcodes($content);
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['custom_html'])) {
        $content = str_replace('%%custom_html%%', $aiomatic_Main_Settings['custom_html'], $content);
    }
    if (isset($aiomatic_Main_Settings['custom_html2'])) {
        $content = str_replace('%%custom_html2%%', $aiomatic_Main_Settings['custom_html2'], $content);
    }
    $content = str_replace('%%post_link%%', $post_link, $content);
    $content = str_replace('%%post_title%%', $post_title, $content);
    $content = str_replace('%%post_title_keywords%%', $post_title_keywords, $content);
    $content = str_replace('%%post_original_title%%', $old_title, $content);
    $content = str_replace('%%blog_title%%', $blog_title, $content);
    $content = str_replace('%%post_excerpt%%', $post_excerpt, $content);
    $post_content = strip_shortcodes($post_content);
    $content = str_replace('%%post_content%%', $post_content, $content);
    $content = str_replace('%%post_content_plain_text%%', strip_tags($post_content), $content);
    $content = str_replace('%%author_name%%', $user_name, $content);
    $content = str_replace('%%current_date_time%%', date('Y/m/d H:i:s'), $content);
    $content = str_replace('%%featured_image%%', $featured_image, $content);
    $content = str_replace('%%post_cats%%', $post_cats, $content);
    $content = str_replace('%%post_tags%%', $post_tagz, $content);
    $img_attr = str_replace('%%image_source_name%%', '', $img_attr);
    $img_attr = str_replace('%%image_source_url%%', '', $img_attr);
    $img_attr = str_replace('%%image_source_website%%', '', $img_attr);
    $content = str_replace('%%royalty_free_image_attribution%%', $img_attr, $content);
    if($post_id != '')
    {
        preg_match_all('#%%!([^!]*?)!%%#', $content, $matched_content);
        if(isset($matched_content[1][0]))
        {
            foreach($matched_content[1] as $mc)
            {
                $post_custom_data = get_post_meta($post_id, $mc, true);
                if($post_custom_data != '')
                {
                    $content = str_replace('%%!' . $mc . '!%%', $post_custom_data, $content);
                }
                else
                {
                    $content = str_replace('%%!' . $mc . '!%%', '', $content);
                }
            }
        }
        preg_match_all('#%%!!([^!]*?)!!%%#', $content, $matched_content);
        if(isset($matched_content[1][0]))
        {
            foreach($matched_content[1] as $mc)
            {
                $ctaxs = '';
                $terms = get_the_terms( $post_id, $mc );
                if ( ! empty( $terms ) && ! is_wp_error( $terms ) )
                {
                    $ctaxs_arr = array();
                    foreach ( $terms as $term ) {
                        $ctaxs_arr[] = $term->slug;
                    }
                    $ctaxs = implode(',', $ctaxs_arr);
                }
                if($post_custom_data != '')
                {
                    $content = str_replace('%%!!' . $mc . '!!%%', $ctaxs, $content);
                }
                else
                {
                    $content = str_replace('%%!!' . $mc . '!!%%', '', $content);
                }
            }
        }
    }
    $content = preg_replace_callback('#%%random_image_url\[([^\]]*?)\]%%#', function ($matches) {
        $my_img = aiomatic_get_random_image_google($matches[1], 0, 0, '');
        return $my_img;
    }, $content);
    $content = preg_replace_callback('#%%random_image\[([^\]]*?)\](\[\d+\])?%%#', function ($matches) {
        if(isset($matches[2]))
        {
            $chance = trim($matches[2], '[]');
        }
        else
        {
            $chance = '';
        }
        $my_img = aiomatic_get_random_image_google($matches[1], 0, 0, $chance);
        return '<img src="' . $my_img . '">';
    }, $content);
    $content = preg_replace_callback('#%%random_video\[([^\]]*?)\](\[\d+\])?%%#', function ($matches) {
        if(isset($matches[2]))
        {
            $chance = trim($matches[2], '[]');
        }
        else
        {
            $chance = '';
        }
        $my_vid = aiomatic_get_youtube_video($matches[1], $chance);
        return $my_vid;
    }, $content);

    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        aiomatic_log_to_file('You need to insert a valid OpenAI/AiomaticAPI API Key for the custom shortcode creator to work!');
    }
    else
    {
        $allmodels = aiomatic_get_all_models();
        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
        $appids = array_filter($appids);
        $token = $appids[array_rand($appids)];
        $custom_shortcodes = preg_split('/\r\n|\r|\n/', $custom_shortcodes);
        foreach($custom_shortcodes as $my_short)
        {
            $name_part = explode('=>', $my_short);
            if(isset($name_part[1]) && !empty(trim($name_part[1])))
            {
                $shortname = trim($name_part[0]);
                if(strstr($content, '%%' . $shortname . '%%'))
                {
                    $shortval = '';
                    $ai_part = explode('@@', $name_part[1]);
                    if(isset($ai_part[1]) && !empty(trim($ai_part[1])))
                    {
                        if(!in_array(trim($ai_part[0]), $allmodels))
                        {
                            $aimodel = 'text-davinci-003';
                        }
                        else
                        {
                            $aimodel = trim($ai_part[0]);
                        }
                        $ai_command = trim($ai_part[1]);
                        $max_tokens = aiomatic_get_max_tokens($aimodel);
                        $query_token_count = count(aiomatic_encode($ai_command));
                        $available_tokens = $max_tokens - $query_token_count;
                        if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                        {
                            $string_len = strlen($ai_command);
                            $string_len = $string_len / 2;
                            $string_len = intval(0 - $string_len);
                            $ai_command = aiomatic_substr($ai_command, 0, $string_len);
                            $ai_command = trim($ai_command);
                            $query_token_count = count(aiomatic_encode($ai_command));
                            $available_tokens = $max_tokens - $query_token_count;
                        }
                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                        {
                            $api_service = aiomatic_get_api_service($token);
                            aiomatic_log_to_file('Calling ' . $api_service . ' (' . $aimodel . ') for custom shortcode text: ' . $ai_command);
                        }
                        $aierror = '';
                        $finish_reason = '';
                        $temperature = 1;
                        $top_p = 1;
                        $presence_penalty = 0;
                        $frequency_penalty = 0;
                        $generated_text = aiomatic_generate_text($token, $aimodel, $ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'customShortcode', 0, $finish_reason, $aierror);
                        if($generated_text === false)
                        {
                            aiomatic_log_to_file('Custom shortcode generator error: ' . $aierror);
                        }
                        else
                        {
                            $shortval = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                        }
                    }
                    $content = str_replace('%%' . $shortname . '%%', $shortval, $content);
                }
            }
        }
    }
    $content = apply_filters('aiomatic_replace_aicontent_shortcode', $content);
    return $content;
}
function aiomatic_preg_grep_keys( $pattern, $input, $flags = 0 )
{
    if(!is_array($input))
    {
        return array();
    }
    $keys = preg_grep( $pattern, array_keys( $input ), $flags );
    $vals = array();
    foreach ( $keys as $key )
    {
        $vals[$key] = $input[$key];
    }
    return $vals;
}

function aiomatic_get_youtube_video($keyword, $chance = '')
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['player_width']) && $aiomatic_Main_Settings['player_width'] !== '') {
        $width = esc_attr($aiomatic_Main_Settings['player_width']);
    }
    else
    {
        $width = 580;
    }
    if (isset($aiomatic_Main_Settings['player_height']) && $aiomatic_Main_Settings['player_height'] !== '') {
        $height = esc_attr($aiomatic_Main_Settings['player_height']);
    }
    else
    {
        $height = 380;
    }
    if($chance != '' && is_numeric($chance))
    {
        $chance = intval($chance);
        if(mt_rand(0, 99) >= $chance)
        {
            return '';
        }
    }
    $res = aiomatic_file_get_contents_advanced('https://www.youtube.com/results?search_query=' . urlencode($keyword), '', 'self', 'Mozilla/5.0 (Windows NT 10.0;WOW64;rv:97.0) Gecko/20100101 Firefox/97.0/3871tuT2p1u-81');
    preg_match_all('/"\/watch\?v=([^"&?\/\s]{11})"/', $res, $matches);
    if(isset($matches[1]))
    {
        $items = $matches[1];
        if (count($items) > 0) 
        {
            return '<br/><br/><div class="automaticx-video-container"><iframe allow="autoplay" width="' . $width . '" height="' . $height . '" src="https://www.youtube.com/embed/' . $items[rand(0, count($items) - 1)] . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>';
        }
    }
    return '';
}
function aiomatic_generate_thumbmail( $post_id )
{    
    $post = get_post($post_id);
    $post_parent_id = $post->post_parent === 0 ? $post->ID : $post->post_parent;
    if ( has_post_thumbnail($post_parent_id) )
    {
        if ($id_attachment = get_post_thumbnail_id($post_parent_id)) {
            $the_image  = wp_get_attachment_url($id_attachment, false);
            return $the_image;
        }
    }
    $attachments = array_values(get_children(array(
        'post_parent' => $post_parent_id, 
        'post_status' => 'inherit', 
        'post_type' => 'attachment', 
        'post_mime_type' => 'image', 
        'order' => 'ASC', 
        'orderby' => 'menu_order ID') 
    ));
    if( sizeof($attachments) > 0 ) {
        $the_image  = wp_get_attachment_url($attachments[0]->ID, false);
        return $the_image;
    }
    $image_url = aiomatic_extractThumbnail($post->post_content);
    return $image_url;
}
function aiomatic_extractThumbnail($content) {
    $att = aiomatic_getUrls($content);
    if(count($att) > 0)
    {
        foreach($att as $link)
        {
            $mime = aiomatic_get_mime($link);
            if(stristr($mime, "image/") !== FALSE){
                return $link;
            }
        }
    }
    else
    {
        return '';
    }
    return '';
}
function aiomatic_getUrls($string) {
    $regex = '/https?\:\/\/[^\"\' \n\s]+/i';
    preg_match_all($regex, $string, $matches);
    return ($matches[0]);
}

function aiomatic_strip_html_tags($str)
{
    $str = html_entity_decode($str);
    $str1 = preg_replace('/(<|>)\1{2}/is', '', $str);
    if($str1 !== null)
    {
        $str = $str1;
    }
    $str1 = preg_replace(array(
        '@<head[^>]*?>.*?</head>@siu',
        '@<style[^>]*?>.*?</style>@siu',
        '@<script[^>]*?.*?</script>@siu',
        '@<noscript[^>]*?.*?</noscript>@siu'
    ), "", $str);
    if($str1 !== null)
    {
        $str = $str1;
    }
    $str = strip_tags($str);
    return $str;
}
function aiomatic_base64_to_jpeg($base64_string, $output_file, $ret_path) 
{
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
       wp_filesystem($creds);
    }
    if ($wp_filesystem->exists($output_file)) 
    {
        return array($output_file, $ret_path); 
    }
    $ifp = fopen($output_file, 'wb'); 
    if($ifp !== false)
    {
        $decoded = base64_decode($base64_string);
        if($ifp !== false)
        {
            $rez = fwrite($ifp, $decoded);
            if($rez === false)
            {
                aiomatic_log_to_file('Failed to write file: ' . $output_file);
                return false;
            }
        }
        else
        {
            aiomatic_log_to_file('Failed to decode response file: ' . $base64_string);
            return false;
        }
        fclose($ifp);
    }
    else
    {
        aiomatic_log_to_file('Failed to open file: ' . $output_file);
        return false;
    }
    return array($output_file, $ret_path); 
}
function aiomatic_random_sentence_generator($first = true)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if ($first == false) {
        $r_sentences = $aiomatic_Main_Settings['sentence_list2'];
    } else {
        $r_sentences = $aiomatic_Main_Settings['sentence_list'];
    }
    $r_variables = $aiomatic_Main_Settings['variable_list'];
    $r_sentences = trim($r_sentences);
    $r_variables = trim($r_variables, ';');
    $r_variables = trim($r_variables);
    $r_sentences = str_replace("\r\n", "\n", $r_sentences);
    $r_sentences = str_replace("\r", "\n", $r_sentences);
    $r_sentences = explode("\n", $r_sentences);
    $r_variables = str_replace("\r\n", "\n", $r_variables);
    $r_variables = str_replace("\r", "\n", $r_variables);
    $r_variables = explode("\n", $r_variables);
    $r_vars      = array();
    for ($x = 0; $x < count($r_variables); $x++) {
        $var = explode("=>", trim($r_variables[$x]));
        if (isset($var[1])) {
            $key          = strtolower(trim($var[0]));
            $words        = explode(";", trim($var[1]));
            $r_vars[$key] = $words;
        }
    }
    $max_s    = count($r_sentences) - 1;
    $rand_s   = rand(0, $max_s);
    $sentence = $r_sentences[$rand_s];
    $sentence = str_replace(' ,', ',', ucfirst(aiomatic_replace_words($sentence, $r_vars)));
    $sentence = str_replace(' .', '.', $sentence);
    $sentence = str_replace(' !', '!', $sentence);
    $sentence = str_replace(' ?', '?', $sentence);
    $sentence = trim($sentence);
    return $sentence;
}
function aiomatic_get_random_user_agent() {
	$agents = array(
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36",
		"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8",
		"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36",
		"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0",
		"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:55.0) Gecko/20100101 Firefox/55.0",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
		"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
		"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0",
		"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36 Edge/15.15063",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:55.0) Gecko/20100101 Firefox/55.0",
		"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
		"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36"
	);
	$rand   = rand( 0, count( $agents ) - 1 );
	return trim( $agents[ $rand ] );
}
function aiomatic_admin_footer()
{
?>
    <div class="aiomatic-overlay" style="display: none">
        <div class="aiomatic_modal">
            <div class="aiomatic_modal_head">
                <span class="aiomatic_modal_title"><?php echo esc_html__('GPT3 Modal', 'aiomatic-automatic-ai-content-writer');?></span>
                <span class="aiomatic_modal_close">&times;</span>
            </div>
            <div class="aiomatic_modal_content"></div>
        </div>
    </div>
    <div class="wpcgai_lds-ellipsis" style="display: none">
        <div class="aiomatic-generating-title"><?php echo esc_html__('Generating content...', 'aiomatic-automatic-ai-content-writer');?></div>
        <div class="aiomatic-generating-process"></div>
        <div class="aiomatic-timer"></div>
    </div>
<?php
}
function aiomatic_assign_var(&$target, $var, $root = false) {
	static $cnt = 0;
    $key = key($var);
    if(is_array($var[$key])) 
        aiomatic_assign_var($target[$key], $var[$key], false);
    else {
        if($key==0)
		{
			if($cnt == 0 && $root == true)
			{
				$target['_aiomaticr_nonce'] = $var[$key];
				$cnt++;
			}
			elseif($cnt == 1 && $root == true)
			{
				$target['_wp_http_referer'] = $var[$key];
				$cnt++;
			}
			else
			{
				$target[] = $var[$key];
			}
		}
        else
		{
            $target[$key] = $var[$key];
		}
    }   
}
function aiomatic_utf8ize($arr){
    if (is_array($arr)) {
        foreach ($arr as $k => $v) {
            $arr[$k] = aiomatic_utf8ize($v);
        }
    } else if (is_string ($arr)) {
        return aiomatic_utf8_encode($arr);
    }
    return $arr;
}
function aiomatic_safe_json_encode($value){
    $encoded = json_encode($value);
    switch (json_last_error()) {
        case JSON_ERROR_NONE:
            return $encoded;
        case JSON_ERROR_DEPTH:
            throw new Exception('Maximum stack depth exceeded');
        case JSON_ERROR_STATE_MISMATCH:
            throw new Exception('Underflow or the modes mismatch');
        case JSON_ERROR_CTRL_CHAR:
            throw new Exception('Unexpected control character found');
        case JSON_ERROR_SYNTAX:
            throw new Exception('Syntax error, malformed JSON');
        case JSON_ERROR_UTF8:
            $clean = aiomatic_utf8ize($value);
            return aiomatic_safe_json_encode($clean);
        default:
            throw new Exception('Unknown error in json encoding');
    }
}
function aiomatic_split_to_token_len($tokens, $max_len)
{
    $ret_me = array();
    if(count($tokens) > $max_len)
    {
        $chunks = array_chunk($tokens, $max_len, true);
        foreach($chunks as $thisch)
        {
            $ret_me[] = aiomatic_decode($thisch);
        }
    }
    else
    {
        $ret_me[] = aiomatic_decode($tokens);
    }
    return $ret_me;
}
use Gioni06\Gpt3Tokenizer\Gpt3TokenizerConfig;
use Gioni06\Gpt3Tokenizer\Gpt3Tokenizer;
function aiomatic_decode($tokens) 
{
    if (version_compare(PHP_VERSION, '8.0.2', '>=') && extension_loaded('mbstring')) 
    {
        require_once (dirname(__FILE__) . "/res/tokenizer/Gpt3TokenizerConfig.php"); 
        require_once (dirname(__FILE__) . "/res/tokenizer/Merges.php"); 
        require_once (dirname(__FILE__) . "/res/tokenizer/Vocab.php"); 
        require_once (dirname(__FILE__) . "/res/tokenizer/Gpt3Tokenizer.php"); 
        $config = new Gpt3TokenizerConfig();
        $tokenizer = new Gpt3Tokenizer($config);
        $text = $tokenizer->decode($tokens);
        return $text;
    }
    else
    {
        return aiomatic_decode_old($tokens);
    }
}
function aiomatic_decode_old($tokens) 
{
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') )
    {
        include_once(ABSPATH . 'wp-admin/includes/file.php');
        $creds = request_filesystem_credentials( site_url() );
        wp_filesystem($creds);
    }
    $rencoder = $wp_filesystem->get_contents(dirname(__FILE__) . "/res/encoder.json");
    $encoder = json_decode($rencoder, true);
    if(empty($encoder))
    {
        aiomatic_log_to_file('Failed to load encoder.json: ' . $rencoder);
        return false;
    }
    $decoder = array();
    foreach($encoder as $index => $val)
    {
        $decoder[$val] = $index;
    }
    $raw_chars = $wp_filesystem->get_contents(dirname(__FILE__) . "/res/characters.json");
    $byte_encoder = json_decode($raw_chars, true);
    if(empty($byte_encoder))
    {
        aiomatic_log_to_file('Failed to load characters.json: ' . $raw_chars);
        return false;
    }
    $byte_decoder = array();
    foreach($byte_encoder as $index => $val)
    {
        $byte_decoder[$val] = $index;
    }
    $text = '';
    $mych_arr = [];
    foreach($tokens as $myt)
    {
        if(isset($decoder[$myt]))
        {
            $mych_arr[] = $decoder[$myt];
        }
        else
        {
            aiomatic_log_to_file('Character not found in decoder: ' . $myt);
        }
    }
    $text = implode('', $mych_arr);
    $text_arr = preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY);
    $final_arr = array();
    foreach($text_arr as $txa)
    {
        if(isset($byte_decoder[$txa]))
        {
            $final_arr[] = $byte_decoder[$txa];
        }
        else
        {
            aiomatic_log_to_file('Character not found in byte_decoder: ' . $txa);
        }
    }
    $output = '';
    for ($i = 0, $j = count($final_arr); $i < $j; ++$i) {
        $output .= chr($final_arr[$i]);
    }
    return $output;
}
function aiomatic_encode($text) 
{
    if (version_compare(PHP_VERSION, '8.0.2', '>=') && extension_loaded('mbstring')) 
    {
        require_once (dirname(__FILE__) . "/res/tokenizer/Gpt3TokenizerConfig.php"); 
        require_once (dirname(__FILE__) . "/res/tokenizer/Merges.php"); 
        require_once (dirname(__FILE__) . "/res/tokenizer/Vocab.php"); 
        require_once (dirname(__FILE__) . "/res/tokenizer/Gpt3Tokenizer.php"); 
        $config = new Gpt3TokenizerConfig();
        $tokenizer = new Gpt3Tokenizer($config);
        $tokens = $tokenizer->encode($text);
        return $tokens;
    }
    else
    {
        return aiomatic_encode_old($text);
    }
}
function aiomatic_encode_old($text) 
{
    $bpe_tokens = array();
    if(empty($text))
    {
        return $bpe_tokens;
    }
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') )
    {
        include_once(ABSPATH . 'wp-admin/includes/file.php');
        $creds = request_filesystem_credentials( site_url() );
        wp_filesystem($creds);
    }
    $raw_chars = $wp_filesystem->get_contents(dirname(__FILE__) . "/res/characters.json");
    $byte_encoder = json_decode($raw_chars, true);
    if(empty($byte_encoder))
    {
        aiomatic_log_to_file('Failed to load characters.json: ' . $raw_chars);
        return $bpe_tokens;
    }
    $rencoder = $wp_filesystem->get_contents(dirname(__FILE__) . "/res/encoder.json");
    $encoder = json_decode($rencoder, true);
    if(empty($encoder))
    {
        aiomatic_log_to_file('Failed to load encoder.json: ' . $rencoder);
        return $bpe_tokens;
    }

    $bpe_file = $wp_filesystem->get_contents(dirname(__FILE__) . "/res/vocab.bpe");
    if(empty($bpe_file))
    {
        aiomatic_log_to_file('Failed to load vocab.bpe');
        return $bpe_tokens;
    }
    $text = str_replace ("\r\n", "\n", $text);
    preg_match_all("#'s|'t|'re|'ve|'m|'ll|'d| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+#u", $text, $matches);
    if(!isset($matches[0]) || count($matches[0]) == 0)
    {
        aiomatic_log_to_file('Failed to match string: ' . $text);
        return $bpe_tokens;
    }
    $lines = preg_split('/\r\n|\r|\n/', $bpe_file);
    $bpe_merges = array();
    $bpe_merges_temp = array_slice($lines, 1, count($lines), true);
    foreach($bpe_merges_temp as $bmt)
    {
        $split_bmt = preg_split('#(\s+)#', $bmt);
        $split_bmt = array_filter($split_bmt, 'aiomatic_myFilter');
        if(count($split_bmt) > 0)
        {
            $bpe_merges[] = $split_bmt;
        }
    }
    $bpe_ranks = aiomatic_dictZip($bpe_merges, range(0, count($bpe_merges) - 1));
    
    $cache = array();
    foreach($matches[0] as $token)
    {
        $new_tokens = array();
        $chars = array();
        $token = aiomatic_utf8_encode($token);
        if(function_exists('mb_strlen'))
        {
            $len = mb_strlen($token, 'UTF-8');
            for ($i = 0; $i < $len; $i++) {
                $chars[] = mb_substr($token, $i, 1, 'UTF-8');
            }
        }
        else
        {
            $chars = str_split($token);
        }
        $result_word = '';
        foreach($chars as $char)
        {
            if(isset($byte_encoder[aiomatic_unichr($char)]))
            {
                $result_word .= $byte_encoder[aiomatic_unichr($char)];
            }
        }
        $new_tokens_bpe = aiomatic_bpe($result_word, $bpe_ranks, $cache);
        $new_tokens_bpe = explode(' ', $new_tokens_bpe);
        foreach($new_tokens_bpe as $x)
        {
            if(isset($encoder[$x]))
            {
                if(isset($new_tokens[$x]))
                {
                    $new_tokens[rand() . '---' . $x] = $encoder[$x];
                }
                else
                {
                    $new_tokens[$x] = $encoder[$x];
                }
            }
            else
            {
                if(isset($new_tokens[$x]))
                {
                    $new_tokens[rand() . '---' . $x] = $x;
                }
                else
                {
                    $new_tokens[$x] = $x;
                }
            }
        }
        foreach($new_tokens as $ninx => $nval)
        {
            if(isset($bpe_tokens[$ninx]))
            {
                $bpe_tokens[rand() . '---' . $ninx] = $nval;
            }
            else
            {
                $bpe_tokens[$ninx] = $nval;
            }
        }
    }
    return $bpe_tokens;
}
function aiomatic_myFilter($var)
{
    return ($var !== NULL && $var !== FALSE && $var !== '');
}

function aiomatic_unichr($c) 
{
    if (ord($c[0]) >=0 && ord($c[0]) <= 127)
    {
        return ord($c[0]);
    }
    if (ord($c[0]) >= 192 && ord($c[0]) <= 223)
    {
        return (ord($c[0])-192)*64 + (ord($c[1])-128);
    }
    if (ord($c[0]) >= 224 && ord($c[0]) <= 239)
    {
        return (ord($c[0])-224)*4096 + (ord($c[1])-128)*64 + (ord($c[2])-128);
    }
    if (ord($c[0]) >= 240 && ord($c[0]) <= 247)
    {
        return (ord($c[0])-240)*262144 + (ord($c[1])-128)*4096 + (ord($c[2])-128)*64 + (ord($c[3])-128);
    }
    if (ord($c[0]) >= 248 && ord($c[0]) <= 251)
    {
        return (ord($c[0])-248)*16777216 + (ord($c[1])-128)*262144 + (ord($c[2])-128)*4096 + (ord($c[3])-128)*64 + (ord($c[4])-128);
    }
    if (ord($c[0]) >= 252 && ord($c[0]) <= 253)
    {
        return (ord($c[0])-252)*1073741824 + (ord($c[1])-128)*16777216 + (ord($c[2])-128)*262144 + (ord($c[3])-128)*4096 + (ord($c[4])-128)*64 + (ord($c[5])-128);
    }
    if (ord($c[0]) >= 254 && ord($c[0]) <= 255)
    {
        return 0;
    }
    return 0;
}
function aiomatic_dictZip($x, $y)
{
    $result = array();
    $cnt = 0;
    foreach($x as $i)
    {
        if(isset($i[1]) && isset($i[0]))
        {
            $result[$i[0] . ',' . $i[1]] = $cnt;
            $cnt++;
        }
    }
    return $result;
}
function aiomatic_get_pairs($word) 
{
    $pairs = array();
    $prev_char = $word[0];
    for ($i = 1; $i < count($word); $i++) 
    {
        $char = $word[$i];
        $pairs[] = array($prev_char, $char);
        $prev_char = $char;
    }
    return $pairs;
}
function aiomatic_split($str, $len = 1) 
{
    $arr		= [];
    if(function_exists('mb_strlen'))
    {
        $length 	= mb_strlen($str, 'UTF-8');
    }
    else
    {
        $length 	= strlen($str);
    }

    for ($i = 0; $i < $length; $i += $len) 
    {
        if(function_exists('mb_substr'))
        {
            $arr[] = mb_substr($str, $i, $len, 'UTF-8');
        }
        else
        {
            $arr[] = substr($str, $i, $len);
        }
    }
    return $arr;

}
function aiomatic_bpe($token, $bpe_ranks, &$cache)
{
    if(array_key_exists($token, $cache))
    {
        return $cache[$token];
    }
    $word = aiomatic_split($token);
    $init_len = count($word);
    $pairs = aiomatic_get_pairs($word);
    if(!$pairs)
    {
        return $token;
    }
    while (true) 
    {
        $minPairs = array();
        
        foreach($pairs as $pair)
        {
            if(array_key_exists($pair[0] . ','. $pair[1], $bpe_ranks))
            {
                $rank = $bpe_ranks[$pair[0] . ','. $pair[1]];
                $minPairs[$rank] = $pair;
            }
            else
            { 
                $minPairs[10e10] = $pair;
            }
        }
        ksort($minPairs);
        if(!function_exists('array_key_first'))
        {
            function array_key_first(array $array) { foreach ($array as $key => $value) { return $key; } }
        }
        $min_key = array_key_first($minPairs);
        foreach($minPairs as $mpi => $mp)
        {
            if($mpi < $min_key)
            {
                $min_key = $mpi;
            }
        }
        $bigram = $minPairs[$min_key];
        if(!array_key_exists($bigram[0] . ',' . $bigram[1], $bpe_ranks))
        {
            break;
        }
        $first = $bigram[0];
        $second = $bigram[1];
        $new_word = array();
        $i = 0;
        while ($i < count($word)) 
        {
            $j = aiomatic_indexOf($word, $first, $i);
            if ($j === -1) 
            {
                $new_word = array_merge($new_word, array_slice($word, $i, null, true));
                break;
            }
            if($i > $j)
            {
                $slicer = array();
            }
            elseif($j == 0)
            {
                $slicer = array();
            }
            else
            {
                $slicer = array_slice($word, $i, $j - $i, true);
            }
            $new_word = array_merge($new_word, $slicer);
            if(count($new_word) > $init_len)
            {
                break;
            }
            $i = $j;
            if ($word[$i] === $first && $i < count($word) - 1 && $word[$i + 1] === $second) 
            {
                array_push($new_word, $first . $second);
                $i = $i + 2;
            }
            else
            {
                array_push($new_word, $word[$i]);
                $i = $i + 1;
            }
        }
        if($word == $new_word)
        {
            break;
        }
        $word = $new_word;
        if (count($word) === 1) 
        {
            break;
        }
        else
        {
            $pairs = aiomatic_get_pairs($word);
        }
    }
    $word = implode(' ', $word);
    $cache[$token] = $word;
    return $word;
}
function aiomatic_get_web_page($url)
{
    if(empty($url))
    {
        return false;
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $content = false;
    if (!isset($aiomatic_Main_Settings['proxy_url']) || $aiomatic_Main_Settings['proxy_url'] == '') 
    {
        $args = array(
        'timeout'     => 10,
        'redirection' => 10,
        'user-agent'  => 'Mozilla/5.0 (Windows NT x.y; Win64; x64; rv:10.0) Gecko/20100101 Firefox/10.0',
        'blocking'    => true,
        'headers'     => array(),
        'cookies'     => array(),
        'body'        => null,
        'compress'    => false,
        'decompress'  => true,
        'sslverify'   => false,
        'stream'      => false,
        'filename'    => null
        );
        $ret_data            = wp_remote_get(html_entity_decode($url), $args);  
        $response_code       = wp_remote_retrieve_response_code( $ret_data );      
        if ( 200 != $response_code ) {
        } else {
            $content = wp_remote_retrieve_body( $ret_data );
        }
    }
    if($content === false)
    {
        if(function_exists('curl_version') && filter_var($url, FILTER_VALIDATE_URL))
        {
            $user_agent = 'Mozilla/5.0 (Windows NT x.y; Win64; x64; rv:10.0) Gecko/20100101 Firefox/10.0';
            $options    = array(
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_POST => false,
                CURLOPT_USERAGENT => $user_agent,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => false,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_ENCODING => "",
                CURLOPT_AUTOREFERER => true,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0
            );
            $ch         = curl_init($url);
            if ($ch === FALSE) {
                return FALSE;
            }
            if (isset($aiomatic_Main_Settings['proxy_url']) && $aiomatic_Main_Settings['proxy_url'] != '') {
                $prx = explode(',', $aiomatic_Main_Settings['proxy_url']);
                $randomness = array_rand($prx);
                $options[CURLOPT_PROXY] = trim($prx[$randomness]);
                if (isset($aiomatic_Main_Settings['proxy_auth']) && $aiomatic_Main_Settings['proxy_auth'] != '') 
                {
                    $prx_auth = explode(',', $aiomatic_Main_Settings['proxy_auth']);
                    if(isset($prx_auth[$randomness]) && trim($prx_auth[$randomness]) != '')
                    {
                        $options[CURLOPT_PROXYUSERPWD] = trim($prx_auth[$randomness]);
                    }
                }
            }
            curl_setopt_array($ch, $options);
            $content = curl_exec($ch);
            curl_close($ch);
        }
        else
        {
            $allowUrlFopen = preg_match('/1|yes|on|true/i', ini_get('allow_url_fopen'));
            if ($allowUrlFopen) {
                global $wp_filesystem;
                if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
                    include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
                    wp_filesystem($creds);
                }
                return $wp_filesystem->get_contents($url);
            }
        }
    }
    return $content;
}

function aiomatic_get_web_page_api($url, $post_args = array())
{
    if(count($post_args) == 0)
    {
        $post_args = null;
    }
    $content = false;
    $args = array(
    'method'      => 'POST',
    'timeout'     => 999,
    'redirection' => 10,
    'user-agent'  => 'Mozilla/5.0 (Windows NT x.y; Win64; x64; rv:10.0) Gecko/20100101 Firefox/10.0',
    'blocking'    => true,
    'headers'     => array(),
    'cookies'     => array(),
    'body'        => $post_args,
    'compress'    => false,
    'decompress'  => true,
    'sslverify'   => false,
    'stream'      => false,
    'filename'    => null
    );
    $ret_data            = wp_remote_post($url, $args);  
    $response_code       = wp_remote_retrieve_response_code( $ret_data );     
    if ( 200 != $response_code ) {
    } else {
        $content = wp_remote_retrieve_body( $ret_data );
    }
    if($content === false)
    {
        aiomatic_log_to_file('API response code is: ' . $response_code . ' - ' . $url . ' - ' . print_r($post_args, true));
    }
    return $content;
}

function aiomatic_get_web_page_post($url, $post_args = array(), $headers = array())
{
    if(is_array($post_args) && count($post_args) == 0)
    {
        $post_args = null;
    }
    $content = false;
    $args = array(
        'method'      => 'POST',
        'timeout'     => 999,
        'redirection' => 10,
        'user-agent'  => 'Mozilla/5.0 (Windows NT x.y; Win64; x64; rv:10.0) Gecko/20100101 Firefox/10.0',
        'blocking'    => true,
        'headers'     => $headers,
        'cookies'     => array(),
        'body'        => $post_args,
        'compress'    => false,
        'decompress'  => true,
        'sslverify'   => false,
        'stream'      => false,
        'filename'    => null
    );
    $ret_data            = wp_remote_post($url, $args);  
    $response_code       = wp_remote_retrieve_response_code( $ret_data );     
    if ( 200 != $response_code ) {
    } else {
        $content = wp_remote_retrieve_body( $ret_data );
    }
    if($content === false)
    {
        aiomatic_log_to_file('POST response code is: ' . $response_code . ' - ' . $url . ' - ' . print_r($post_args, true));
    }
    return $content;
}
function aiomatic_utf8_encode($str)
{
    $str .= $str;
    $len = \strlen($str);
    for ($i = $len >> 1, $j = 0; $i < $len; ++$i, ++$j) {
        switch (true) {
            case $str[$i] < "\x80": $str[$j] = $str[$i]; break;
            case $str[$i] < "\xC0": $str[$j] = "\xC2"; $str[++$j] = $str[$i]; break;
            default: $str[$j] = "\xC3"; $str[++$j] = \chr(\ord($str[$i]) - 64); break;
        }
    }
    return substr($str, 0, $j);
}

function aiomatic_indexOf($arrax, $searchElement, $fromIndex)
{
    $index = 0;
    foreach($arrax as $index => $value)
    {
        if($index < $fromIndex)
        {
            $index++;
            continue;
        }
        if($value == $searchElement)
        {
            return $index;
        }
        $index++;
    }
    return -1;
}
function aiomatic_add_to_url($attr, $value, $origURL = '')
{
    if(empty($origURL))
    {
        $origURL = $_SERVER['REQUEST_URI'];
    }
    $url = parse_url($origURL);
    parse_str($url['query'], $q);
    $params = [$attr => $value];
    foreach ( $params as $k => $v ) $q[$k] = $v;
    $new_url = $url['path'] . '?' . http_build_query($q);
    return $new_url;
}
function aiomatic_assign_featured_image($attach_id, $post_id)
{
    if ($attach_id === 0 || !is_numeric($attach_id)) {
        return false;
    }
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    $res2 = set_post_thumbnail($post_id, $attach_id);
    if ($res2 === FALSE) {
        return false;
    }
    return get_the_post_thumbnail_url($attach_id);
}
function aiomatic_is_chatgpt_model($model)
{
    if ( preg_match('/^((?:gpt)-(?:[\d.]+)(?:-[a-zA-Z0-9]+)?(?:-[\d]+)?)/', $model, $matches ) )
    {
        return true;
    }
    return false;
}
function aiomatic_get_all_models($reverse = false)
{
    $all_models = get_option('aiomatic_custom_models', array());
    if($reverse == true)
    {
        $all_models = array_merge(AIOMATIC_MODELS_CHAT, $all_models);
        $all_models = array_merge(AIOMATIC_MODELS, $all_models);
    }
    else
    {
        $all_models = array_merge(AIOMATIC_MODELS, $all_models);
        $all_models = array_merge(AIOMATIC_MODELS_CHAT, $all_models);
    }
    return $all_models;
}

function aiomatic_starts_with($newx_url, $query)
{
    if(substr( $newx_url, 0, strlen($query) ) === $query)
    {
        return true;
    }
    return false;
}
function aiomatic_get_word($key, $r_vars)
{
    if (isset($r_vars[$key])) {
        
        $words  = $r_vars[$key];
        $w_max  = count($words) - 1;
        $w_rand = rand(0, $w_max);
        return aiomatic_replace_words(trim($words[$w_rand]), $r_vars);
    } else {
        return "";
    }
    
}

function aiomatic_replace_words($sentence, $r_vars)
{
    
    if (str_replace('%', '', $sentence) == $sentence)
        return $sentence;
    
    $words = explode(" ", $sentence);
    
    $new_sentence = array();
    for ($w = 0; $w < count($words); $w++) {
        
        $word = trim($words[$w]);
        
        if ($word != '') {
            if (preg_match('/^%([^%\n]*)$/', $word, $m)) {
                $varkey         = trim($m[1]);
                $new_sentence[] = aiomatic_get_word($varkey, $r_vars);
            } else {
                $new_sentence[] = $word;
            }
        }
    }
    return implode(" ", $new_sentence);
}
function aiomatic_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function aiomatic_get_file_url($url)
{
    return esc_url(aiomatic_get_plugin_url() . '/' . $url);
}
function aiomatic_redirect($url, $statusCode = 301)
{
  if(!function_exists('wp_redirect'))
  {
     include_once( ABSPATH . 'wp-includes/pluggable.php' );
  }
  wp_redirect($url, $statusCode);
  die();
}
function aiomatic_sanitize_date_time( $date_time, $type = 'date', $accepts_string = false ) {
	if ( empty( $date_time ) || ! in_array( $type, array( 'date', 'time' ) ) ) {
		return array();
	}
	$segments = array();
	if (
		true === $accepts_string
		&& ( false !== strpos( $date_time, ' ' ) || false === strpos( $date_time, '-' ) )
	) {
		if ( false !== $timestamp = strtotime( $date_time ) ) {
			return $date_time;
		}
	}
	$parts = array_map( 'absint', explode( 'date' == $type ? '-' : ':', $date_time ) );
	if ( 'date' == $type ) {
		$year = $month = $day = 1;
		if ( count( $parts ) >= 3 ) {
			list( $year, $month, $day ) = $parts;
			$year  = ( $year  >= 1 && $year  <= 9999 ) ? $year  : 1;
			$month = ( $month >= 1 && $month <= 12   ) ? $month : 1;
			$day   = ( $day   >= 1 && $day   <= 31   ) ? $day   : 1;
		}
		$segments = array(
			'year'  => $year,
			'month' => $month,
			'day'   => $day
		);
	} elseif ( 'time' == $type ) {
		$hour = $minute = $second = 0;
		switch( count( $parts ) ) {
			case 3 :
				list( $hour, $minute, $second ) = $parts;
				$hour   = ( $hour   >= 0 && $hour   <= 23 ) ? $hour   : 0;
				$minute = ( $minute >= 0 && $minute <= 60 ) ? $minute : 0;
				$second = ( $second >= 0 && $second <= 60 ) ? $second : 0;
				break;
			case 2 :
				list( $hour, $minute ) = $parts;
				$hour   = ( $hour   >= 0 && $hour   <= 23 ) ? $hour   : 0;
				$minute = ( $minute >= 0 && $minute <= 60 ) ? $minute : 0;
				break;
			default : break;
		}
		$segments = array(
			'hour'   => $hour,
			'minute' => $minute,
			'second' => $second
		);
	}

	return apply_filters( 'display_posts_shortcode_sanitized_segments', $segments, $date_time, $type );
}
?>