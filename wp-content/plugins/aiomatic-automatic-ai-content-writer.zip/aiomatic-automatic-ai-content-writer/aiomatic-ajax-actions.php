<?php
defined('ABSPATH') or die();
use \Eventviva\ImageResize;
use Orhanerday\OpenAi\OpenAi;

add_action('wp_ajax_aiomatic_get_elevenlabs_voice_chat', 'aiomatic_get_elevenlabs_voice_chat');
add_action('wp_ajax_nopriv_aiomatic_get_elevenlabs_voice_chat', 'aiomatic_get_elevenlabs_voice_chat');
function aiomatic_get_elevenlabs_voice_chat()
{
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if(!isset($_REQUEST['x_input_text']) || empty($_REQUEST['x_input_text']))
    {
        $aiomatic_result['msg'] = 'No text to send to text-to-speech!';
        wp_send_json($aiomatic_result);
    }
    if ((!isset($aiomatic_Main_Settings['elevenlabs_app_id']) || trim($aiomatic_Main_Settings['elevenlabs_app_id']) == ''))
    {
        $aiomatic_result['msg'] = 'You need to enter an ElevenLabs API key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
    if(isset($aiomatic_Chatbot_Settings['eleven_voice']) && $aiomatic_Chatbot_Settings['eleven_voice'] != '')
    {
        $voice = $aiomatic_Chatbot_Settings['eleven_voice'];
    }
    else
    {
        $voice = '21m00Tcm4TlvDq8ikWAM';
    }
    $message = sanitize_text_field($_REQUEST['x_input_text']);
    $result = aiomatic_elevenlabs_stream($voice, $message);
    if(is_array($result)){
        wp_send_json($result);
    }
    else
    {
        echo $result;
        die();
    }
    wp_send_json($aiomatic_result);
}

add_action('wp_ajax_aiomatic_get_google_voice_chat', 'aiomatic_get_google_voice_chat');
add_action('wp_ajax_nopriv_aiomatic_getgoogle_voice_chat', 'aiomatic_get_google_voice_chat');
function aiomatic_get_google_voice_chat()
{
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if(!isset($_REQUEST['x_input_text']) || empty($_REQUEST['x_input_text']))
    {
        $aiomatic_result['msg'] = 'No text to send to text-to-speech!';
        wp_send_json($aiomatic_result);
    }
    if ((!isset($aiomatic_Main_Settings['google_app_id']) || trim($aiomatic_Main_Settings['google_app_id']) == ''))
    {
        $aiomatic_result['msg'] = 'You need to enter an Google Text-to-Speech API key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
    if(isset($aiomatic_Chatbot_Settings['google_voice']) && $aiomatic_Chatbot_Settings['google_voice'] != '')
    {
        $voice = $aiomatic_Chatbot_Settings['google_voice'];
    }
    else
    {
        $aiomatic_result['msg'] = 'You need to select a Google Text-to-Speech Voice Name for this feature to work.';
        wp_send_json($aiomatic_result);
    }
    if(isset($aiomatic_Chatbot_Settings['audio_profile']) && $aiomatic_Chatbot_Settings['audio_profile'] != '')
    {
        $audio_profile = $aiomatic_Chatbot_Settings['audio_profile'];
    }
    else
    {
        $audio_profile = '';
    }
    if(isset($aiomatic_Chatbot_Settings['voice_language']) && $aiomatic_Chatbot_Settings['voice_language'] != '')
    {
        $voice_language = $aiomatic_Chatbot_Settings['voice_language'];
    }
    else
    {
        $aiomatic_result['msg'] = 'You need to select a Google Text-to-Speech Voice Language for this feature to work.';
        wp_send_json($aiomatic_result);
    }
    if(isset($aiomatic_Chatbot_Settings['voice_speed']) && $aiomatic_Chatbot_Settings['voice_speed'] != '')
    {
        $voice_speed = $aiomatic_Chatbot_Settings['voice_speed'];
    }
    else
    {
        $voice_speed = '';
    }
    if(isset($aiomatic_Chatbot_Settings['voice_pitch']) && $aiomatic_Chatbot_Settings['voice_pitch'] != '')
    {
        $voice_pitch = $aiomatic_Chatbot_Settings['voice_pitch'];
    }
    else
    {
        $voice_pitch = '';
    }
    $message = sanitize_text_field($_REQUEST['x_input_text']);
    $result = aiomatic_google_stream($voice, $voice_language, $audio_profile, $voice_speed, $voice_pitch, $message);
    if(is_array($result)){
        wp_send_json($result);
    }
    else
    {
        echo $result;
        die();
    }
    wp_send_json($aiomatic_result);
}

add_action('wp_ajax_aiomatic_get_elevenlabs_voices', 'aiomatic_update_elevenlabs_voices_func');
add_action('wp_ajax_nopriv_aiomatic_get_elevenlabs_voices', 'aiomatic_update_elevenlabs_voices_func');
function aiomatic_update_elevenlabs_voices_func()
{
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['elevenlabs_app_id']) || trim($aiomatic_Main_Settings['elevenlabs_app_id']) == '')
    {
        $aiomatic_result['msg'] = 'You need to enter an ElevenLabs API key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $my_voices = aiomatic_update_elevenlabs_voices();
    if(is_array($my_voices))
    {
        $aiomatic_result['status'] = 'success';
    }
    else
    {
        $aiomatic_result['msg'] = 'Failed to list ElevenLabs Voices!';
    }
    wp_send_json($aiomatic_result);
}

add_action('wp_ajax_aiomatic_get_google_voices', 'aiomatic_update_google_voices_func');
add_action('wp_ajax_nopriv_aiomatic_get_google_voices', 'aiomatic_update_google_voices_func');
function aiomatic_update_google_voices_func()
{
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
    if (!isset($aiomatic_Main_Settings['elevenlabs_app_id']) || trim($aiomatic_Main_Settings['elevenlabs_app_id']) == '')
    {
        $aiomatic_result['msg'] = 'You need to enter an Google Text-to-Speech API key for this to work!';
        wp_send_json($aiomatic_result);
    }
    if (isset($aiomatic_Chatbot_Settings['voice_language']) && trim($aiomatic_Chatbot_Settings['voice_language']) != '')
    {
        $voice_language = trim($aiomatic_Chatbot_Settings['voice_language']);
    }
    else
    {
        $voice_language = 'en-US';
    }
    $my_voices = aiomatic_update_google_voices($voice_language);
    if(is_array($my_voices))
    {
        $aiomatic_result['status'] = 'success';
    }
    else
    {
        $aiomatic_result['msg'] = 'Failed to list Google Text-to-Speech Voices!';
    }
    wp_send_json($aiomatic_result);
}
add_action('wp_ajax_aiomatic_form_upload', 'aiomatic_form_upload');
function aiomatic_form_upload()
{
	check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(isset($_FILES['file']) && empty($_FILES['file']['error']))
    {
        $file_name = sanitize_file_name(basename($_FILES['file']['name']));
        $filetype = wp_check_filetype($file_name);
        if($filetype['ext'] !== 'json' && !aiomatic_endsWith($file_name, '.json')){
            $aiomatic_result['msg'] = 'Only files with the json extension are supported, you sent: ' . $file_name;
            wp_send_json($aiomatic_result);
        }
        global $wp_filesystem;
        if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
            include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
            wp_filesystem($creds);
        }
        $fc = $wp_filesystem->get_contents($_FILES['file']['tmp_name']);
        if(empty($fc))
        {
            $aiomatic_result['msg'] = 'Failed to read file: ' . $_FILES['file']['tmp_name'];
            wp_send_json($aiomatic_result);
        }
        $fc_dec = json_decode($fc, true);
        if($fc_dec === false)
        {
            $aiomatic_result['msg'] = 'Failed to decode json file: ' . $_FILES['file']['tmp_name'];
            wp_send_json($aiomatic_result);
        }
        if(isset($_POST['overwrite']))
        {
            $overwrite = $_POST['overwrite'];
        }
        else
        {
            $overwrite = '0';
        }
        foreach($fc_dec as $jsonf)
        {
            $address_post_id = 0;
            $query = new WP_Query(
                array(
                    'post_type'              => 'aiomatic_forms',
                    'title'                  => $jsonf['title'],
                    'post_status'            => 'all',
                    'posts_per_page'         => 1,
                    'no_found_rows'          => true,
                    'ignore_sticky_posts'    => true,
                    'update_post_term_cache' => false,
                    'update_post_meta_cache' => false,
                    'orderby'                => 'post_date ID',
                    'order'                  => 'ASC',
                )
            );
            
            if ( ! empty( $query->post ) ) {
                if($overwrite != '1')
                {
                    //form already exists, skipping it
                    continue;
                }
                else
                {
                    while ( $query->have_posts() ) {
                        $query->the_post();
                        $address_post_id = get_the_ID();
                        break;
                    }
                }
            }
            $forms_data = array(
                'post_type' => 'aiomatic_forms',
                'post_title' => $jsonf['title'],
                'post_content' => $jsonf['description'],
                'post_status' => 'publish'
            );
            $forms_data['ID'] = $address_post_id;
            $forms_data = sanitize_post($forms_data, 'db');
            remove_filter('content_save_pre', 'wp_filter_post_kses');
            remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
            if($overwrite != '1')
            {
                $forms_id = wp_insert_post($forms_data);
            }
            else
            {
                if(isset($forms_data['ID']) && $forms_data['ID'] != '0')
                {
                    $forms_id = wp_update_post($forms_data);
                }
                else
                {
                    $forms_id = wp_insert_post($forms_data);
                }
            }
            add_filter('content_save_pre', 'wp_filter_post_kses');
            add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
            if(is_wp_error($forms_id))
            {
                aiomatic_log_to_file('Failed to import form: ' . $forms_id->get_error_message());
            }
            elseif($forms_id === 0)
            {
                aiomatic_log_to_file('Failed to insert form to database: ' . print_r($forms_data, true));
            }
            else 
            {
                update_post_meta($forms_id, 'prompt', $jsonf['prompt']);
                update_post_meta($forms_id, 'model', $jsonf['model']);
                update_post_meta($forms_id, 'header', $jsonf['header']);
                update_post_meta($forms_id, 'submit', $jsonf['submit']);
                update_post_meta($forms_id, 'max', $jsonf['max']);
                update_post_meta($forms_id, 'temperature', $jsonf['temperature']);
                update_post_meta($forms_id, 'topp', $jsonf['topp']);
                update_post_meta($forms_id, 'presence', $jsonf['presence']);
                update_post_meta($forms_id, 'frequency', $jsonf['frequency']);
                update_post_meta($forms_id, 'response', $jsonf['response']);
                update_post_meta($forms_id, 'type', $jsonf['type']);
                update_post_meta($forms_id, '_aiomaticfields', $jsonf['aiomaticfields']);
            }
        }
        $aiomatic_result['status'] = 'success';
    }
    wp_send_json($aiomatic_result);
}

add_action('wp_ajax_aiomatic_default_form', 'aiomatic_default_form');
function aiomatic_default_form()
{
	check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
        wp_filesystem($creds);
    }
    $default_file = dirname(__FILE__) . "/defaults/form-defaults.json";
    if(!$wp_filesystem->exists($default_file))
    {
        $aiomatic_result['msg'] = 'Default form json file not found: ' . $default_file;
        wp_send_json($aiomatic_result);
    }
    $fc = $wp_filesystem->get_contents($default_file);
    if(empty($fc))
    {
        $aiomatic_result['msg'] = 'Failed to read file: ' . $default_file;
        wp_send_json($aiomatic_result);
    }
    $fc_dec = json_decode($fc, true);
    if($fc_dec === false)
    {
        $aiomatic_result['msg'] = 'Failed to decode json file: ' . $default_file;
        wp_send_json($aiomatic_result);
    }
    $overwrite = '0';
    foreach($fc_dec as $jsonf)
    {
        $address_post_id = 0;
        $query = new WP_Query(
            array(
                'post_type'              => 'aiomatic_forms',
                'title'                  => $jsonf['title'],
                'post_status'            => 'all',
                'posts_per_page'         => 1,
                'no_found_rows'          => true,
                'ignore_sticky_posts'    => true,
                'update_post_term_cache' => false,
                'update_post_meta_cache' => false,
                'orderby'                => 'post_date ID',
                'order'                  => 'ASC',
            )
        );
        
        if ( ! empty( $query->post ) ) {
            if($overwrite != '1')
            {
                //form already exists, skipping it
                continue;
            }
            else
            {
                while ( $query->have_posts() ) {
                    $query->the_post();
                    $address_post_id = get_the_ID();
                    break;
                }
            }
        }
        $forms_data = array(
            'post_type' => 'aiomatic_forms',
            'post_title' => $jsonf['title'],
            'post_content' => $jsonf['description'],
            'post_status' => 'publish'
        );
        $forms_data['ID'] = $address_post_id;
        $forms_data = sanitize_post($forms_data, 'db');
        remove_filter('content_save_pre', 'wp_filter_post_kses');
        remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
        if($overwrite != '1')
        {
            $forms_id = wp_insert_post($forms_data);
        }
        else
        {
            if(isset($forms_data['ID']) && $forms_data['ID'] != '0')
            {
                $forms_id = wp_update_post($forms_data);
            }
            else
            {
                $forms_id = wp_insert_post($forms_data);
            }
        }
        add_filter('content_save_pre', 'wp_filter_post_kses');
        add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
        if(is_wp_error($forms_id))
        {
            aiomatic_log_to_file('Failed to import form: ' . $forms_id->get_error_message());
        }
        elseif($forms_id === 0)
        {
            aiomatic_log_to_file('Failed to insert form to database: ' . print_r($forms_data, true));
        }
        else 
        {
            update_post_meta($forms_id, 'prompt', $jsonf['prompt']);
            update_post_meta($forms_id, 'model', $jsonf['model']);
            update_post_meta($forms_id, 'header', $jsonf['header']);
            update_post_meta($forms_id, 'submit', $jsonf['submit']);
            update_post_meta($forms_id, 'max', $jsonf['max']);
            update_post_meta($forms_id, 'temperature', $jsonf['temperature']);
            update_post_meta($forms_id, 'topp', $jsonf['topp']);
            update_post_meta($forms_id, 'presence', $jsonf['presence']);
            update_post_meta($forms_id, 'frequency', $jsonf['frequency']);
            update_post_meta($forms_id, 'response', $jsonf['response']);
            update_post_meta($forms_id, 'type', $jsonf['type']);
            update_post_meta($forms_id, '_aiomaticfields', $jsonf['aiomaticfields']);
        }
    }
    $aiomatic_result['status'] = 'success';
    wp_send_json($aiomatic_result);
}
add_action('wp_ajax_aiomatic_dismiss_admin_notice', 'aiomatic_dismiss_admin_notice');
function aiomatic_dismiss_admin_notice() {
    check_ajax_referer('openai-single-nonce', 'nonce');
    $user_id = get_current_user_id();
    if($user_id != 0)
    {
        update_user_meta($user_id, 'aiomatic_admin_notice_dismissed', true);
    }
    else
    {
        wp_send_json_success('Failed to dismiss message');
    }
    wp_send_json_success('Message dismissed');
}
add_action('wp_ajax_aiomatic_save_image', 'aiomatic_save_image');
function aiomatic_save_image() {
	check_ajax_referer('openai-ajax-nonce', 'nonce');
	$imagesrc = $_POST['imagesrc'];
    if(empty($imagesrc))
    {
        wp_send_json_error(array('error' => 'No image argument data found'));
    }
	$post_id = $_POST['post_id'];
	$orig_prompt = $_POST['orig_prompt'];
    if(empty($post_id))
    {
        $post_id = null;
    }
    $size = 'full';
    $localpath = false;
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if(substr( $imagesrc, 0, 21 ) === "data:image/png;base64")
    {
        $attachment_id = aiomatic_upload_base64_image($imagesrc, $orig_prompt, $post_id);
        if ( is_wp_error( $attachment_id ) ) {
            wp_send_json_error( $attachment_id );
        }
        if (  $attachment_id === false ) {
            wp_send_json_error(array('error' => 'Failed to upload image'));
        }
        $alt = wp_strip_all_tags( $orig_prompt, true );
        update_post_meta( $attachment_id, '_wp_attachment_image_alt', wp_slash( $alt ) );
        list( $url, $width, $height ) = wp_get_attachment_image_src( $attachment_id, $size );
        wp_send_json_success( compact( 'attachment_id', 'url', 'width', 'height', 'size' ) );
    }
    else
    {
        if ((isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '') || (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== ''))
        {
            try
            {
                $localpath = aiomatic_copy_image_locally($imagesrc);
                if($localpath !== false)
                {
                    if(!class_exists('\Eventviva\ImageResize')){require_once (dirname(__FILE__) . "/res/ImageResize/ImageResize.php");}
                    $imageRes = new ImageResize($localpath[1]);
                    $imageRes->quality_jpg = 100;
                    if ((isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '') && (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== ''))
                    {
                        $imageRes->resizeToBestFit($aiomatic_Main_Settings['ai_resize_width'], $aiomatic_Main_Settings['ai_resize_height'], true);
                    }
                    elseif (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== '')
                    {
                        $imageRes->resizeToWidth($aiomatic_Main_Settings['ai_resize_width'], true);
                    }
                    elseif (isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '')
                    {
                        $imageRes->resizeToHeight($aiomatic_Main_Settings['ai_resize_height'], true);
                    }
                    $imageRes->save($localpath[1]);
                }
            }
            catch(Exception $e)
            {
                aiomatic_log_to_file('Failed to resize AI generated image: ' . $localpath[0] . ' to sizes ' . $aiomatic_Main_Settings['ai_resize_width'] . ' - ' . $aiomatic_Main_Settings['ai_resize_height'] . '. Exception thrown ' . esc_html($e->getMessage()) . '!');
            }
        }
        if(isset($localpath[0]))
        {
            $imagesrc = $localpath[0];
        }
        $attachment_id = media_sideload_image( $imagesrc, $post_id, $orig_prompt, 'id' );
        if ( is_wp_error( $attachment_id ) ) {
            wp_send_json_error( $attachment_id );
        }
        $alt = wp_strip_all_tags( $orig_prompt, true );
        update_post_meta( $attachment_id, '_wp_attachment_image_alt', wp_slash( $alt ) );
        list( $url, $width, $height ) = wp_get_attachment_image_src( $attachment_id, $size );
        wp_send_json_success( compact( 'attachment_id', 'url', 'width', 'height', 'size' ) );
    }
}

add_action('wp_ajax_aiomatic_generate_image_ajax', 'aiomatic_generate_image_ajax');
function aiomatic_generate_image_ajax() {
	check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(!isset($_POST['image_size']) || !isset($_POST['instruction']))
    {
        $aiomatic_result['msg'] = 'Incomplete POST request for DALLE2 images';
        wp_send_json($aiomatic_result);
    }
    $ai_model = $_POST['ai_model'];
    if($ai_model == 'stable')
    {
        if(!isset($_POST['image_size']) || !isset($_POST['instruction']))
        {
            $aiomatic_result['msg'] = 'Incomplete POST request for stable images';
            wp_send_json($aiomatic_result);
        }
        $user_token_cap_per_day = sanitize_text_field($_POST['user_token_cap_per_day']);
        if(!empty($user_token_cap_per_day))
        {
            $user_token_cap_per_day = intval($user_token_cap_per_day);
        }
        $user_id = sanitize_text_field($_POST['user_id']);
        $image_size = $_POST['image_size'];
        $instruction = stripslashes($_POST['instruction']);
        $sizes = array('1024x1024', '512x512');
        if(!in_array($image_size, $sizes))
        {
            $aiomatic_result['msg'] = 'Invalid image size provided: ' . $image_size;
            wp_send_json($aiomatic_result);
        }
        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
        if (!isset($aiomatic_Main_Settings['stability_app_id']) || trim($aiomatic_Main_Settings['stability_app_id']) == '') 
        {
            $aiomatic_result['msg'] = 'You need to insert a valid Stability.AI API Key for this to work!';
            wp_send_json($aiomatic_result);
        }
        $used_token_count = 0;
        if(is_numeric($user_token_cap_per_day))
        {
            if(empty($user_id) || $user_id == 0)
            {
                $aiomatic_result['msg'] = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
                wp_send_json($aiomatic_result);
            }
            $used_token_count = get_user_meta($user_id, 'aiomatic_used_stable_image_tokens', true);
            if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
            {
                $used_token_count = intval($used_token_count);
                if($used_token_count > $user_token_cap_per_day)
                {
                    $aiomatic_result['msg'] = 'Daily token count for your user account was exceeded! Please try again tomorrow.';
                    wp_send_json($aiomatic_result);
                }
            }
            else
            {
                $used_token_count = 0;
            }
        }
        if($image_size == '512x512')
        {
            $width = '512';
            $height = '512';
        }
        elseif($image_size == '1024x1024')
        {
            $width = '1024';
            $height = '1024';
        }
        else
        {
            $width = '512';
            $height = '512';
        }
        $temp_get_imgs = aiomatic_generate_stability_image($instruction, $height, $width, 'mediaLibraryStableImage', 0, true);
        if($temp_get_imgs !== false)
        {
            if(is_numeric($user_token_cap_per_day))
            {
                $used_token_count = intval($used_token_count) + 1000;
                update_user_meta($user_id, 'aiomatic_used_stable_image_tokens', $used_token_count);
            }
            $aiomatic_result['data'] = $temp_get_imgs;
            $aiomatic_result['status'] = 'success';
            wp_send_json($aiomatic_result);
        }
        $aiomatic_result['msg'] = 'Error occurred when calling image API!';
        wp_send_json($aiomatic_result);
    }
    else
    {
        $user_token_cap_per_day = sanitize_text_field($_POST['user_token_cap_per_day']);
        if(!empty($user_token_cap_per_day))
        {
            $user_token_cap_per_day = intval($user_token_cap_per_day);
        }
        $user_id = sanitize_text_field($_POST['user_id']);
        $image_size = $_POST['image_size'];
        $instruction = stripslashes($_POST['instruction']);
        $sizes = array('1024x1024', '512x512', '256x256');
        if(!in_array($image_size, $sizes))
        {
            $aiomatic_result['msg'] = 'Invalid image size provided: ' . $image_size;
            wp_send_json($aiomatic_result);
        }
        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
        if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
        {
            $aiomatic_result['msg'] = 'You need to insert a valid OpenAI/AiomaticAPI API Key for this to work!';
            wp_send_json($aiomatic_result);
        }
        $used_token_count = 0;
        if(is_numeric($user_token_cap_per_day))
        {
            if(empty($user_id) || $user_id == 0)
            {
                $aiomatic_result['msg'] = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
                wp_send_json($aiomatic_result);
            }
            $used_token_count = get_user_meta($user_id, 'aiomatic_used_image_tokens', true);
            if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
            {
                $used_token_count = intval($used_token_count);
                if($used_token_count > $user_token_cap_per_day)
                {
                    $aiomatic_result['msg'] = 'Daily token count for your user account was exceeded! Please try again tomorrow.';
                    wp_send_json($aiomatic_result);
                }
            }
            else
            {
                $used_token_count = 0;
            }
        }
        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
        $appids = array_filter($appids);
        $token = $appids[array_rand($appids)];
        $aierror = '';
        $response_text = aiomatic_generate_ai_image($token, 1, $instruction, $image_size, 'mediaLibraryDallEImage', false, 0, $aierror);
        if($response_text !== false && is_array($response_text))
        {
            foreach($response_text as $tmpimg)
            {
                $aiomatic_result['data'] = $tmpimg;
                $aiomatic_result['status'] = 'success';
                wp_send_json($aiomatic_result);
            }
            if(is_numeric($user_token_cap_per_day))
            {
                $used_token_count = intval($used_token_count) + 1000;
                update_user_meta($user_id, 'aiomatic_used_image_tokens', $used_token_count);
            }
        }
        $aiomatic_result['msg'] = 'Error occurred when calling image API: ' . $aierror . ' -- ' . print_r($response_text, true);
        wp_send_json($aiomatic_result);
    }
}

add_action('wp_ajax_aiomatic_image_ajax_submit', 'aiomatic_image_submit');
add_action('wp_ajax_nopriv_aiomatic_image_ajax_submit', 'aiomatic_image_submit');
function aiomatic_image_submit() 
{
	check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(!isset($_POST['image_size']) || !isset($_POST['instruction']))
    {
        $aiomatic_result['msg'] = 'Incomplete POST request for DALLE2 images';
        wp_send_json($aiomatic_result);
    }
    $user_token_cap_per_day = sanitize_text_field($_POST['user_token_cap_per_day']);
    if(!empty($user_token_cap_per_day))
    {
        $user_token_cap_per_day = intval($user_token_cap_per_day);
    }
	$user_id = sanitize_text_field($_POST['user_id']);
	$image_size = $_POST['image_size'];
	$instruction = stripslashes($_POST['instruction']);
    $sizes = array('1024x1024', '512x512', '256x256');
    if(!in_array($image_size, $sizes))
    {
        $aiomatic_result['msg'] = 'Invalid image size provided: ' . $image_size;
        wp_send_json($aiomatic_result);
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        $aiomatic_result['msg'] = 'You need to insert a valid OpenAI/AiomaticAPI API Key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $used_token_count = 0;
    if(is_numeric($user_token_cap_per_day))
    {
        if(empty($user_id) || $user_id == 0)
        {
            $aiomatic_result['msg'] = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
            wp_send_json($aiomatic_result);
        }
        $used_token_count = get_user_meta($user_id, 'aiomatic_used_image_tokens', true);
        if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
        {
            $used_token_count = intval($used_token_count);
            if($used_token_count > $user_token_cap_per_day)
            {
                $aiomatic_result['msg'] = 'Daily token count for your user account was exceeded! Please try again tomorrow.';
                wp_send_json($aiomatic_result);
            }
        }
        else
        {
            $used_token_count = 0;
        }
    }
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
	$aierror = '';
    $response_text = aiomatic_generate_ai_image($token, 1, $instruction, $image_size, 'shortcodeImageForm', false, 0, $aierror);
    if($response_text !== false && is_array($response_text))
    {
        foreach($response_text as $tmpimg)
        {
            $aiomatic_result['data'] = $tmpimg;
            $aiomatic_result['status'] = 'success';
            wp_send_json($aiomatic_result);
        }
        if(is_numeric($user_token_cap_per_day))
        {
            $used_token_count = intval($used_token_count) + 1000;
            update_user_meta($user_id, 'aiomatic_used_image_tokens', $used_token_count);
        }
    }
    $aiomatic_result['msg'] = 'Error occurred when calling image API: ' . $aierror . ' -- ' . print_r($response_text, true);
    wp_send_json($aiomatic_result);
}

add_action('wp_ajax_aiomatic_run_my_bulk_action', 'aiomatic_run_my_bulk_action');
function aiomatic_run_my_bulk_action()
{
    check_ajax_referer('openai-bulk-nonce', 'nonce');
    echo aiomatic_do_bulk_post();
    die();
}
add_action('wp_ajax_aiomatic_preview_form', 'aiomatic_preview_form');
function aiomatic_preview_form()
{
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    if(!isset($_POST['id']) || !isset($_POST['id']))
    {
        die();
    }
    echo do_shortcode('[aiomatic-form id="' . esc_html(trim($_POST['id'])) . '"]');
    die();
}
add_action('wp_ajax_aiomatic_stable_image_ajax_submit', 'aiomatic_stable_image_submit');
add_action('wp_ajax_nopriv_aiomatic_stable_image_ajax_submit', 'aiomatic_stable_image_submit');
function aiomatic_stable_image_submit() 
{
	check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(!isset($_POST['image_size']) || !isset($_POST['instruction']))
    {
        $aiomatic_result['msg'] = 'Incomplete POST request for stable images';
        wp_send_json($aiomatic_result);
    }
    $user_token_cap_per_day = sanitize_text_field($_POST['user_token_cap_per_day']);
    if(!empty($user_token_cap_per_day))
    {
        $user_token_cap_per_day = intval($user_token_cap_per_day);
    }
	$user_id = sanitize_text_field($_POST['user_id']);
	$image_size = $_POST['image_size'];
	$instruction = stripslashes($_POST['instruction']);
    $sizes = array('1024x1024', '512x512');
    if(!in_array($image_size, $sizes))
    {
        $aiomatic_result['msg'] = 'Invalid image size provided: ' . $image_size;
        wp_send_json($aiomatic_result);
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['stability_app_id']) || trim($aiomatic_Main_Settings['stability_app_id']) == '') 
    {
        $aiomatic_result['msg'] = 'You need to insert a valid Stability.AI API Key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $used_token_count = 0;
    if(is_numeric($user_token_cap_per_day))
    {
        if(empty($user_id) || $user_id == 0)
        {
            $aiomatic_result['msg'] = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
            wp_send_json($aiomatic_result);
        }
        $used_token_count = get_user_meta($user_id, 'aiomatic_used_stable_image_tokens', true);
        if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
        {
            $used_token_count = intval($used_token_count);
            if($used_token_count > $user_token_cap_per_day)
            {
                $aiomatic_result['msg'] = 'Daily token count for your user account was exceeded! Please try again tomorrow.';
                wp_send_json($aiomatic_result);
            }
        }
        else
        {
            $used_token_count = 0;
        }
    }
    if($image_size == '512x512')
    {
        $width = '512';
        $height = '512';
    }
    elseif($image_size == '1024x1024')
    {
        $width = '1024';
        $height = '1024';
    }
    else
    {
        $width = '512';
        $height = '512';
    }
    $temp_get_imgs = aiomatic_generate_stability_image($instruction, $height, $width, 'shortcodeChatStableImage', 0, true);
    if($temp_get_imgs !== false)
    {
        if(is_numeric($user_token_cap_per_day))
        {
            $used_token_count = intval($used_token_count) + 1000;
            update_user_meta($user_id, 'aiomatic_used_stable_image_tokens', $used_token_count);
        }
        $aiomatic_result['data'] = $temp_get_imgs;
        $aiomatic_result['status'] = 'success';
        wp_send_json($aiomatic_result);
    }
    $aiomatic_result['msg'] = 'Error occurred when calling image API!';
    wp_send_json($aiomatic_result);
}

add_action( 'wp_ajax_aiomatic_get_image', 'aiomatic_get_image' );
add_action( 'wp_ajax_nopriv_aiomatic_get_image', 'aiomatic_get_image' );
function aiomatic_get_image() {
    if(isset($_GET['id']) ){
        $image = wp_get_attachment_image( filter_input( INPUT_GET, 'id', FILTER_VALIDATE_INT ), 'thumbnail', false, array( 'id' => 'aiomatic-preview-image' ) );
        $data = array(
            'image'    => $image,
        );
        wp_send_json_success( $data );
    } else {
        wp_send_json_error();
    }
}
add_action( 'wp_ajax_create_post', 'aiomatic_create_post' );
function aiomatic_create_post() {
	check_ajax_referer( 'create_post', 'nonce' );
	$post_title = sanitize_text_field( stripslashes($_POST['title']) );
	$post_content = wp_kses_post( stripslashes($_POST['content']) );
	$post_excerpt = sanitize_text_field( stripslashes($_POST['excerpt']) );
	$submit_status = sanitize_text_field( $_POST['submit_status'] );
	$submit_type = isset($_POST['submit_type']) ? sanitize_text_field( $_POST['submit_type'] ) : 'post';
	$post_sticky = sanitize_text_field( $_POST['post_sticky'] );
	$post_author = sanitize_text_field( $_POST['post_author'] );
	$aiomatic_image_id = sanitize_text_field( $_POST['aiomatic_image_id'] );
	$post_date = sanitize_text_field( stripslashes($_POST['post_date']) );
	$post_tags = sanitize_text_field( $_POST['post_tags'] );
	$post_category = stripslashes(sanitize_text_field( stripslashes($_POST['post_category']) ));
	$post_category = json_decode($post_category, true);
	if ( empty( $post_title ) || empty( $post_content ) ) {
	  wp_send_json_error( array( 'message' => 'Title and Content are required fields' ) );
	}
    if(empty($submit_type))
    {
        $submit_type = 'post';
    }
    if(!in_array($submit_type, get_post_types( '', 'names' )))
    {
        $submit_type = 'post';
    }
	$statuses = get_post_statuses();
	$statuses['trash'] = 'Trash';
	if(!array_key_exists($submit_status, $statuses))
	{
		wp_send_json_error( array( 'message' => 'Invalid post status submitted: ' . $submit_status . ' - ' .print_r($statuses, true) ) );
	}
	$author_obj = get_user_by('id', $post_author);
	if($author_obj === false)
	{
		wp_send_json_error( array( 'message' => 'Invalid post author submitted' ) );
	}
	$post_args = array(
		'post_title' => $post_title,
		'post_content' => $post_content,
		'post_excerpt' => $post_excerpt,
		'post_status' => $submit_status,
		'post_type' => $submit_type,
		'post_author' => $post_author,
		'post_date' => $post_date
	);
    if(!empty($post_tags))
	{
		$post_args['tags_input'] = $post_tags;
	}
    remove_filter('content_save_pre', 'wp_filter_post_kses');
    remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
	$post_id = wp_insert_post( $post_args );
    add_filter('content_save_pre', 'wp_filter_post_kses');
    add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
	if ( is_wp_error( $post_id ) ) {
	  wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
	}
    elseif ( $post_id === 0 ) {
        wp_send_json_error( array( 'message' => 'Failed to insert post: ' . $post_title ) );
    }
	if ($post_sticky == 'on') 
	{
		stick_post($post_id);
	}
	if(is_array($post_category))
	{
		$default_category = get_option('default_category');
		wp_set_post_categories($post_id, $post_category, true);
		if(is_numeric($default_category))
		{
			if(!in_array($default_category, $post_category))
			{
				$deftrerm = get_term_by('id', $default_category, 'category');
				if($deftrerm !== false)
				{
					wp_remove_object_terms( $post_id, $deftrerm->slug, 'category' );
				}
			}
		}
	}
	if($aiomatic_image_id != '' && is_numeric($aiomatic_image_id))
	{
		$aiomatic_image_id = intval($aiomatic_image_id);
		require_once(ABSPATH . 'wp-admin/includes/image.php');
		require_once(ABSPATH . 'wp-admin/includes/media.php');
		set_post_thumbnail($post_id, $aiomatic_image_id);
	}
	wp_send_json_success( array( 'post_id' => $post_id ) );
}
add_action( 'wp_ajax_aiomatic_write_text', 'aiomatic_write_text' );
add_action( 'wp_ajax_nopriv_aiomatic_write_text', 'aiomatic_write_text' );
function aiomatic_write_text() {
	check_ajax_referer( 'openai-single-nonce', 'nonce' );
	if(!isset($_POST['prompt']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (prompt)' ) );
	}
	$prompt = stripslashes(sanitize_text_field( $_POST['prompt'] ));
	if(!isset($_POST['model']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (model)' ) );
	}
	$model = stripslashes(sanitize_text_field( $_POST['model'] ));
	if(!isset($_POST['max_tokens']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (max_tokens)' ) );
	}
	$max_tokens = stripslashes(sanitize_text_field( $_POST['max_tokens'] ));
	if(!isset($_POST['temperature']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (temperature)' ) );
	}
	$temperature = stripslashes(sanitize_text_field( $_POST['temperature'] ));
	if(!isset($_POST['title']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (title)' ) );
	}
	$title = stripslashes(sanitize_text_field( $_POST['title'] ));
	if(!isset($_POST['language']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (language)' ) );
	}
	$language = stripslashes(sanitize_text_field( $_POST['language'] ));
	if(!isset($_POST['writing_style']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (writing_style)' ) );
	}
	$writing_style = stripslashes(sanitize_text_field( $_POST['writing_style'] ));
	if(!isset($_POST['writing_tone']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (writing_tone)' ) );
	}
	$writing_tone = stripslashes(sanitize_text_field( $_POST['writing_tone'] ));
	if(!isset($_POST['topics']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (topics)' ) );
	}
	$topics = stripslashes(sanitize_text_field( $_POST['topics'] ));
	if(!isset($_POST['sections']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (sections)' ) );
	}
	$sections = stripslashes(sanitize_text_field( $_POST['sections'] ));
	if(!isset($_POST['sections_count']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (sections_count)' ) );
	}
	$sections_count = stripslashes(sanitize_text_field( $_POST['sections_count'] ));
	if(!isset($_POST['paragraph_count']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (paragraph_count)' ) );
	}
	$paragraph_count = stripslashes(sanitize_text_field( $_POST['paragraph_count'] ));
	$temperature = floatval($temperature);
	$max_tokens = intval($max_tokens);
	if($max_tokens > 2048)
	{
		$big_model = false;
		if(strstr($model, 'davinci') !== false && strstr($model, ':ft-') === false)
		{
			$big_model = true;
		}
		elseif(strstr($model, 'turbo') !== false && strstr($model, ':ft-') === false)
		{
			$big_model = true;
		}
		elseif(strstr($model, 'gpt-4') !== false && strstr($model, ':ft-') === false)
		{
			$big_model = true;
		}
		if($big_model == false)
		{
			$max_tokens = 2048;
		}
	}
	$all_models = aiomatic_get_all_models(true);
	if(!in_array($model, $all_models))
    {
        $model = 'text-davinci-003';
    }
	$aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
	if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') {
		wp_send_json_error( array( 'message' => 'You need to enter an OpenAI API key in plugin settings!' ) );
	}
	$new_post_content = '';
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
	$appids = array_filter($appids);
	$token = $appids[array_rand($appids)];

    $prompt = str_replace('%%title%%', $title, $prompt);
	$prompt = str_replace('%%language%%', $language, $prompt);
	$prompt = str_replace('%%writing_style%%', $writing_style, $prompt);
	$prompt = str_replace('%%writing_tone%%', $writing_tone, $prompt);
	$prompt = str_replace('%%topic%%', $topics, $prompt);
	$prompt = str_replace('%%sections%%', $sections, $prompt);
	$prompt = str_replace('%%sections_count%%', $sections_count, $prompt);
	$prompt = str_replace('%%paragraphs_per_section%%', $paragraph_count, $prompt);
	
	$query_token_count = count(aiomatic_encode($prompt));
	$available_tokens = $max_tokens - $query_token_count;
	if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
	{
		$string_len = strlen($prompt);
		$string_len = $string_len / 2;
		$string_len = intval(0 - $string_len);
        $aicontent = aiomatic_substr($prompt, 0, $string_len);
		$aicontent = trim($aicontent);
		if(empty($aicontent))
		{
			wp_send_json_error( array( 'message' => 'Incorrect prompt provided!' ) );
		}
		$query_token_count = count(aiomatic_encode($aicontent));
		$available_tokens = $max_tokens - $query_token_count;
	}
	$aierror = '';
	$finish_reason = '';
	$generated_text = aiomatic_generate_text($token, $model, $prompt, $available_tokens, $temperature, 1, 0, 0, false, 'singlePostWriter', 0, $finish_reason, $aierror);
	if($generated_text === false)
	{
		wp_send_json_error( array( 'message' => 'Failed to generate AI content: ' . $aierror) );
	}
	else
	{
		$new_post_content = trim(trim(trim($generated_text), '"\''));
	}
	wp_send_json_success( array( 'content' => $new_post_content ) );
}

add_action( 'wp_ajax_aiomatic_delete_template', 'aiomatic_delete_template' );
function aiomatic_delete_template() {
	check_ajax_referer( 'openai-single-nonce', 'nonce' );
	if(!isset($_POST['template_name']))
	{
		wp_send_json_error( array( 'message' => 'Template name is required!' ) );
	}
	$template_name = sanitize_text_field( stripslashes($_POST['template_name']) );
    if(empty($template_name))
    {
        wp_send_json_error( array( 'message' => 'You need to enter a valid template name!' ) );
    }
	$user_id = get_current_user_id(); 
    if($user_id == 0)
    {
        wp_send_json_error( array( 'message' => 'No user logged in, cannot find templates!' ) );
    }
    else
    {
        $key = 'aiomatic_templates'; 
        $single = true; 
        $aiomatic_templates = get_user_meta( $user_id, $key, $single );
        if(!is_array($aiomatic_templates))
        {
            $aiomatic_templates = array();
        }
        if(!isset($aiomatic_templates[$template_name]))
        {
            wp_send_json_error( array( 'message' => 'Template name not found in database, please refresh this page to update template listing' ) );
        }
        else
        {
            unset($aiomatic_templates[$template_name]);
            update_user_meta( $user_id, $key, $aiomatic_templates );
        }
    }
    wp_send_json_success( array( 'content' => 'saved' ) );
}

add_action( 'wp_ajax_aiomatic_save_template', 'aiomatic_save_template' );
function aiomatic_save_template() {
	check_ajax_referer( 'openai-single-nonce', 'nonce' );
	if(!isset($_POST['template_name']))
	{
		wp_send_json_error( array( 'message' => 'Template name is required!' ) );
	}
	$template_name = sanitize_text_field( stripslashes($_POST['template_name']) );
    if(empty($template_name))
    {
        wp_send_json_error( array( 'message' => 'You need to enter a valid template name!' ) );
    }
	if(!isset($_POST['template_options']))
	{
		wp_send_json_error( array( 'message' => 'Template settings are required!' ) );
	}
	$template_options = $_POST['template_options'];
	
	$user_id = get_current_user_id(); 
    if($user_id == 0)
    {
        wp_send_json_error( array( 'message' => 'No user logged in, cannot find templates!' ) );
    }
    else
    {
        $key = 'aiomatic_templates'; 
        $single = true; 
        $aiomatic_templates = get_user_meta( $user_id, $key, $single );
        if(!is_array($aiomatic_templates))
        {
            $aiomatic_templates = array();
        }
        $aiomatic_templates[$template_name] = $template_options;
        update_user_meta( $user_id, $key, $aiomatic_templates );
    }
    wp_send_json_success( array( 'content' => 'saved' ) );
}

add_action( 'wp_ajax_aiomatic_load_template', 'aiomatic_load_template' );
function aiomatic_load_template() {
	check_ajax_referer( 'openai-single-nonce', 'nonce' );
	if(!isset($_POST['template_name']))
	{
		wp_send_json_error( array( 'message' => 'Template name is required!' ) );
	}
	$template_name = sanitize_text_field( stripslashes($_POST['template_name']) );
    if(empty($template_name))
    {
        wp_send_json_error( array( 'message' => 'You need to enter a valid template name!' ) );
    }
    $aiomatic_templates = array();
	$user_id = get_current_user_id(); 
    if($user_id == 0)
    {
        wp_send_json_error( array( 'message' => 'No user logged in, cannot find templates!' ) );
    }
    else
    {
        if($template_name == 'Default Template')
        {
            $author_obj = get_user_by('id', $user_id);
            if($author_obj !== false)
            {
                $user_login = $author_obj->user_login;
            }
            else
            {
                aiomatic_log_to_file('Failed to detect current user name: ' . $user_id);
            }
            $dt = new DateTime();
            $datef = $dt->format('Y-m-d\TH:i:s');
            $default_category = get_option('default_category');
            $aiomatic_templates = array
            (
                'title' => '',
                'topics' => '',
                'submit_status' => 'Draft',
                'submit_type' => 'post',
                'post_sticky' => 'No',
                'post_author' => $user_login,
                'post_date' => $datef,
                'post_category' => array($default_category),
                'post_tags' => '',
                'language' => 'English',
                'writing_style' => 'Creative',
                'writing_tone' => 'Neutral',
                'sections_count' => 2,
                'paragraph_count' => 3,
                'model' => 'text-davinci-3',
                'max_tokens' => 4000,
                'temperature' => 1,
                'prompt_title' => 'Write a title for an article about "%%topic%%" in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Must be between 40 and 60 characters.',
                'prompt_sections' => 'Write %%sections_count%% consecutive headings for an article about "%%title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%.',
                'prompt_content' => 'Write an article about "%%title%%" in %%language%%. The article is organized by the following headings:

%%sections%%

Write %%paragraphs_per_section%% paragraphs per heading.

Use HTML for formatting, include h2 tags, h3 tags, lists and bold.

Add an introduction and a conclusion.

Style: %%writing_style%%. Tone: %%writing_tone%%.',
                'prompt_excerpt' => 'Write an excerpt for an article about "%%title%%" in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Must be between 150 and 250 characters.'
                    );
        }
        else
        {
            $key = 'aiomatic_templates'; 
            $single = true; 
            $aiomatic_templates = get_user_meta( $user_id, $key, $single );
            if(!is_array($aiomatic_templates))
            {
                $aiomatic_templates = array();
            }
            if(!isset($aiomatic_templates[$template_name]))
            {
                wp_send_json_error( array( 'message' => 'Template name not found in the database' ) );
            }
            $aiomatic_templates = $aiomatic_templates[$template_name];
        }
    }
    wp_send_json_success( array( 'content' => $aiomatic_templates ) );
}

add_action('wp_ajax_aiomatic_chat_submit', 'aiomatic_chat_submit');
add_action('wp_ajax_nopriv_aiomatic_chat_submit', 'aiomatic_chat_submit');
function aiomatic_chat_submit() {
	check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(!isset($_POST['input_text']) || !isset($_POST['model']) || !isset($_POST['temp']) || !isset($_POST['presence']) || !isset($_POST['frequency']) || !isset($_POST['remember_string']))
    {
        $aiomatic_result['msg'] = 'Incomplete POST request for chat';
        wp_send_json($aiomatic_result);
    }
    $user_token_cap_per_day = sanitize_text_field($_POST['user_token_cap_per_day']);
    if(!empty($user_token_cap_per_day))
    {
        $user_token_cap_per_day = intval($user_token_cap_per_day);
    }
	$user_id = sanitize_text_field($_POST['user_id']);
	$input_text = stripslashes($_POST['input_text']);
	$remember_string = stripslashes($_POST['remember_string']);
    if(!empty(trim($remember_string)))
    {
        $input_text = trim($remember_string) . PHP_EOL . $input_text;
    }
	$model = sanitize_text_field(stripslashes($_POST['model']));
	$temperature = sanitize_text_field($_POST['temp']);
	$top_p = sanitize_text_field($_POST['top_p']);
	$presence_penalty = sanitize_text_field($_POST['presence']);
	$frequency_penalty = sanitize_text_field($_POST['frequency']);
    $all_models = aiomatic_get_all_models();
    $models = $all_models;
    if(!in_array($model, $models))
    {
        $aiomatic_result['msg'] = 'Invalid model provided: ' . $model;
        wp_send_json($aiomatic_result);
    }
    $temperature = floatval($temperature);
    $top_p = floatval($top_p);
    $presence_penalty = floatval($presence_penalty);
    $frequency_penalty = floatval($frequency_penalty);
    if($temperature < 0 || $temperature > 1)
    {
        $aiomatic_result['msg'] = 'Invalid temperature provided: ' . $temperature;
        wp_send_json($aiomatic_result);
    }
    if($top_p < 0 || $top_p > 1)
    {
        $aiomatic_result['msg'] = 'Invalid top_p provided: ' . $top_p;
        wp_send_json($aiomatic_result);
    }
    if($presence_penalty < -2 || $presence_penalty > 2)
    {
        $aiomatic_result['msg'] = 'Invalid presence_penalty provided: ' . $presence_penalty;
        wp_send_json($aiomatic_result);
    }
    if($frequency_penalty < -2 || $frequency_penalty > 2)
    {
        $aiomatic_result['msg'] = 'Invalid frequency_penalty provided: ' . $frequency_penalty;
        wp_send_json($aiomatic_result);
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        $aiomatic_result['msg'] = 'You need to insert a valid OpenAI/AiomaticAPI API Key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $used_token_count = 0;
    if(is_numeric($user_token_cap_per_day))
    {
        if(empty($user_id) || $user_id == 0)
        {
            $aiomatic_result['msg'] = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
            wp_send_json($aiomatic_result);
        }
        $used_token_count = get_user_meta($user_id, 'aiomatic_used_chat_tokens', true);
        if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
        {
            $used_token_count = intval($used_token_count);
            if($used_token_count > $user_token_cap_per_day)
            {
                $aiomatic_result['msg'] = 'Daily token count for your user account was exceeded! Please try again tomorrow.';
                wp_send_json($aiomatic_result);
            }
        }
        else
        {
            $used_token_count = 0;
        }
    }
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
    $max_tokens = aiomatic_get_max_tokens($model);
    $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
    if (isset($aiomatic_Chatbot_Settings['max_input_length']) && $aiomatic_Chatbot_Settings['max_input_length'] != '' && is_numeric($aiomatic_Chatbot_Settings['max_input_length'])) 
    {
        if(strlen($input_text) > intval($aiomatic_Chatbot_Settings['max_input_length']))
        {
            $input_text = substr($input_text, 0, intval($aiomatic_Chatbot_Settings['max_input_length']));
        }
    }
    $query_token_count = count(aiomatic_encode($input_text));
    $available_tokens = $max_tokens - $query_token_count;
    if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
    {
        $string_len = strlen($input_text);
        $string_len = $string_len / 2;
        $string_len = intval(0 - $string_len);
        $input_text = aiomatic_substr($input_text, 0, $string_len);
        $input_text = trim($input_text);
        if(empty($input_text))
        {
            aiomatic_log_to_file('Empty API seed expression provided (after processing)');
            wp_die();
        }
        $query_token_count = count(aiomatic_encode($input_text));
        $available_tokens = $max_tokens - $query_token_count;
    }
	$error = '';
    $finish_reason = '';
    $response_text = aiomatic_generate_text($token, $model, $input_text, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, true, 'shortcodeChat', 0, $finish_reason, $error);    
    if($response_text === false)
    {
        $aiomatic_result['msg'] = $error;
        wp_send_json($aiomatic_result);
    }
    else
    {
        $inp_count = count(aiomatic_encode($input_text));
        $resp_count = count(aiomatic_encode($response_text));
        if(is_numeric($user_token_cap_per_day))
        {
            $used_token_count = intval($used_token_count) + $inp_count + $resp_count;
            update_user_meta($user_id, 'aiomatic_used_chat_tokens', $used_token_count);
        }
    }
    
    $aiomatic_result['status'] = 'success';
    $aiomatic_result['data'] = trim(esc_html(stripslashes($response_text)));
    wp_send_json($aiomatic_result);
}

add_action('wp_ajax_aiomatic_post_now', 'aiomatic_aiomatic_submit_post_callback');
function aiomatic_aiomatic_submit_post_callback()
{
    $run_id = $_POST['id'];
    $wp_post = get_post($run_id);
    if($wp_post != null)
    {
        aiomatic_do_post($wp_post, true);
    }
    die();
}
add_action('wp_ajax_aiomatic_delete_embedding', 'aiomatic_aiomatic_delete_embedding');
function aiomatic_aiomatic_delete_embedding()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    if(!isset($_POST['embeddingid']))
    {
        $aiomatic_result['msg'] = 'Field missing: embeddingid';
    }
    else
    {
        $embeddingid = $_POST['embeddingid'];
        if($embeddingid != '' && is_numeric($embeddingid))
        {
            $wp_post = get_post($embeddingid);
            if($wp_post != null)
            {
                require_once(dirname(__FILE__) . "/res/Embeddings.php");
                $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
                if (isset($aiomatic_Main_Settings['app_id']) && trim($aiomatic_Main_Settings['app_id']) != '') 
                {
                    $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
                    $appids = array_filter($appids);
                    $token = $appids[array_rand($appids)];
                    require_once(dirname(__FILE__) . "/res/Embeddings.php");
                    $embdedding = new Aiomatic_Embeddings($token);
                    $status = $embdedding->aiomatic_delete_embedding($embeddingid);
                    $aiomatic_result = $status;
                }
                else
                {
                    $aiomatic_result['msg'] = 'No app ID in plugin settings.';
                }
            }
            else
            {
                $aiomatic_result['msg'] = 'No post found with this ID: ' . $embeddingid;
            }
        }
        else
        {
            $aiomatic_result['msg'] = 'Blank embedding ID added';
        }
    }
    wp_send_json($aiomatic_result);
    die();
}
add_action('wp_ajax_aiomatic_delete_logs', 'aiomatic_delete_logs');
function aiomatic_delete_logs()
{
    $aiomatic_result = array('status' => 'success', 'msg' => 'Data deleted successfully');
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    $GLOBALS['aiomatic_stats']->clear_db();
    wp_send_json($aiomatic_result);
    die();
}

add_action('wp_ajax_aiomatic_forms', 'aiomatic_forms');
function aiomatic_forms()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    check_ajax_referer('aiomatic_forms', 'nonce');
    $formid = '';
    if(isset($_POST['formid']) && !empty($_POST['formid']))
    {
        $formid = $_POST['formid'];
    }
    if(!isset($_POST['aiomatic-form-title']) || empty($_POST['aiomatic-form-title']))
    {
        $aiomatic_result['msg'] = 'Empty form title added!';
        wp_send_json($aiomatic_result);
    }
    $title = $_POST['aiomatic-form-title'];
    if(!isset($_POST['aiomatic-form-prompt']) || empty($_POST['aiomatic-form-prompt']))
    {
        $aiomatic_result['msg'] = 'Empty form prompt added!';
        wp_send_json($aiomatic_result);
    }
    $prompt = $_POST['aiomatic-form-prompt'];
    if(!isset($_POST['aiomatic-form-model']) || empty($_POST['aiomatic-form-model']))
    {
        $aiomatic_result['msg'] = 'Empty form model added!';
        wp_send_json($aiomatic_result);
    }
    $model = $_POST['aiomatic-form-model'];
    if(!isset($_POST['aiomatic-header']) || empty($_POST['aiomatic-header']))
    {
        $aiomatic_result['msg'] = 'Empty form header state added!';
        wp_send_json($aiomatic_result);
    }
    $header = $_POST['aiomatic-header'];
    if(!isset($_POST['aiomatic-submit']) || empty($_POST['aiomatic-submit']))
    {
        $aiomatic_result['msg'] = 'Empty form submit text added!';
        wp_send_json($aiomatic_result);
    }
    $submit = $_POST['aiomatic-submit'];
    $description = '';
    if(isset($_POST['aiomatic-form-description']) && !empty($_POST['aiomatic-form-description']))
    {
        $description = $_POST['aiomatic-form-description'];
    }
    $response = '';
    if(isset($_POST['aiomatic-form-response']) && !empty($_POST['aiomatic-form-response']))
    {
        $response = $_POST['aiomatic-form-response'];
    }
    $max = '';
    if(isset($_POST['aiomatic-max']) && !empty($_POST['aiomatic-max']))
    {
        $max = $_POST['aiomatic-max'];
    }
    $temperature = '';
    if(isset($_POST['aiomatic-temperature']) && !empty($_POST['aiomatic-temperature']))
    {
        $temperature = $_POST['aiomatic-temperature'];
    }
    $topp = '';
    if(isset($_POST['aiomatic-topp']) && !empty($_POST['aiomatic-topp']))
    {
        $topp = $_POST['aiomatic-topp'];
    }
    $presence = '';
    if(isset($_POST['aiomatic-presence']) && !empty($_POST['aiomatic-presence']))
    {
        $presence = $_POST['aiomatic-presence'];
    }
    $frequency = '';
    if(isset($_POST['aiomatic-frequency']) && !empty($_POST['aiomatic-frequency']))
    {
        $frequency = $_POST['aiomatic-frequency'];
    }
    $type = '';
    if(isset($_POST['aiomatic-type']) && !empty($_POST['aiomatic-type']))
    {
        $type = $_POST['aiomatic-type'];
    }
    $aiomaticfields = array();
    if(isset($_POST['aiomaticfields']) && !empty($_POST['aiomaticfields']))
    {
        $aiomaticfields = $_POST['aiomaticfields'];
    }
    $aiomatic_result = aiomatic_save_forms($formid, $title, $prompt, $model, $header, $submit, $description, $response, $max, $temperature, $topp, $presence, $frequency, $type, $aiomaticfields);
    wp_send_json($aiomatic_result);
}

add_action('wp_ajax_aiomatic_deleteall_forms', 'aiomatic_deleteall_forms');
function aiomatic_deleteall_forms()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    $allposts = get_posts( array('post_type'=>'aiomatic_forms','numberposts'=>-1) );
    foreach ($allposts as $eachpost) {
        wp_delete_post( $eachpost->ID, true );
    }
    $aiomatic_result['msg'] = 'Successfully deleted all forms!';
    $aiomatic_result['status'] = 'success';
    wp_send_json($aiomatic_result);
    die();
}
add_action('wp_ajax_aiomatic_delete_selected_form', 'aiomatic_delete_selected_form');
function aiomatic_delete_selected_form()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    if(!isset($_POST['ids']))
    {
        $aiomatic_result['msg'] = 'Incorrect AJAX call';
    }
    else
    {
        $deleted = false;
        if(count($_POST['ids'])) 
        {
            foreach ($_POST['ids'] as $id)
            {
                wp_delete_post($id);
                $deleted = true;
            }
        }
        if($deleted === true)
        {
            $aiomatic_result['status'] = 'success';
            $aiomatic_result['msg'] = 'Forms deleted successfully';
        }
    }
    wp_send_json($aiomatic_result);
    die();
}
add_action('wp_ajax_aiomatic_delete_form', 'aiomatic_delete_form');
function aiomatic_delete_form()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(!isset($_POST['formid']))
    {
        $aiomatic_result['msg'] = 'Incorrect AJAX call';
    }
    else
    {
        check_ajax_referer('openai-ajax-nonce', 'nonce');
        $aiomatic_result['status'] = 'success';
        $aiomatic_result['id'] = $_POST['formid'];
        $aiomatic_result['msg'] = 'Success';
        wp_delete_post($_POST['formid']);
    }
    wp_send_json($aiomatic_result);
    die();
}
add_action('wp_ajax_aiomatic_download_embeddings', 'aiomatic_download_embeddings');
function aiomatic_download_embeddings()
{
    global $wpdb;
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    $ids = $wpdb->get_results("SELECT ID FROM ".$wpdb->posts." WHERE post_type='aiomatic_embeddings'");
    $ids = wp_list_pluck($ids,'ID');
    $ret_arr = array();
    if(count($ids)) 
    {
        foreach($ids as $my_postid)
        {
            $content_post = get_post($my_postid);
            if(isset($content_post->post_content))
            {
                $ret_arr[] = array($content_post->post_content);
            }
        }
        if(count($ret_arr) > 0)
        {
            $aiomatic_result['status'] = 'success';
            $aiomatic_result['rows'] = $ret_arr;
        }
        else
        {
            $aiomatic_result['msg'] = 'No embeddings can be downloaded.';
        }
    }
    else
    {
        $aiomatic_result['msg'] = 'No embeddings found to download.';
    }
    wp_send_json($aiomatic_result);
    die();
}
add_action('wp_ajax_aiomatic_get_form', 'aiomatic_get_form');
function aiomatic_get_form()
{
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(isset($_POST['id']) && !empty($_POST['id'])){
        $aiomatic_form = get_post(sanitize_text_field($_POST['id']));
        if($aiomatic_form)
        {
            $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
            $prompt = get_post_meta($aiomatic_form->ID, 'prompt', true);
            $model = get_post_meta($aiomatic_form->ID, 'model', true);
            $header = get_post_meta($aiomatic_form->ID, 'header', true);
            $submit = get_post_meta($aiomatic_form->ID, 'submit', true);
            $max = get_post_meta($aiomatic_form->ID, 'max', true);
            $temperature = get_post_meta($aiomatic_form->ID, 'temperature', true);
            $topp = get_post_meta($aiomatic_form->ID, 'topp', true);
            $presence = get_post_meta($aiomatic_form->ID, 'presence', true);
            $frequency = get_post_meta($aiomatic_form->ID, 'frequency', true);
            $response = get_post_meta($aiomatic_form->ID, 'response', true);
            $type = get_post_meta($aiomatic_form->ID, 'type', true);
            $aiomaticfields = get_post_meta($aiomatic_form->ID, '_aiomaticfields', true);
            if(!is_array($aiomaticfields))
            {
                $aiomaticfields = array();
            }
            $aiomaticfields = array_values($aiomaticfields);
            $result = '<form action="#" method="post" id="aiomatic_forms_form_edit">
            <input type="hidden" name="action" value="aiomatic_forms">
            <input type="hidden" name="formid" value="' . esc_attr($aiomatic_form->ID) . '">
            <input type="hidden" name="nonce" value="' . wp_create_nonce('aiomatic_forms') . '">
              <h2>Input Fields:</h2>
              <button class="aiomatic-create-form-field button">' . esc_html__("Add A New Form Input Field", 'aiomatic-automatic-ai-content-writer') . '</button>
           <br/><br/>
              <div class="aiomatic-template-fields">';
              foreach($aiomaticfields as $inx => $aifield)
              {
                    $result .= '<div class="aiomatic-template-form-field-default">
                    <div class="aiomatic-template-form-field">
                    <div>
                       <div>
                             <strong class="aiomatic-label-top marginbottom-5">Label*</strong>
                             <input type="text" name="aiomaticfields[' . $inx . '][label]" required placeholder="The label which will be shown next to the input field" value="' . esc_attr($aifield['label']) . '" class="aiomatic-create-template-field-label aiomatic-full-size">
                       </div>
                       <div>
                             <strong class="aiomatic-label-top marginbottom-5">' . esc_html__("ID*", 'aiomatic-automatic-ai-content-writer') . '</strong>
                             <input placeholder="my_unique_input_id" type="text" name="aiomaticfields[' . $inx . '][id]" required value="' . esc_attr($aifield['id']) . '" class="aiomatic-create-template-field-id aiomatic-full-size">
                             <small class="aiomatic-full-center">' . esc_html__("You can add the value of this field to the form prompt from below, using this shortcode", 'aiomatic-automatic-ai-content-writer') . ': <b>%%my_unique_input_id%%</b></small>
                       </div>
                       <div>
                             <strong class="aiomatic-label-top marginbottom-5">' . esc_html__("Required*", 'aiomatic-automatic-ai-content-writer') . '</strong>
                             <select name="aiomaticfields[' . $inx . '][required]" class="aiomatic-create-template-field-required aiomatic-full-size">
                                <option value="no"';
                                if($aifield['required'] == 'no')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>No</option>
                                <option value="yes"';
                                if($aifield['required'] == 'yes')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>Yes</option>
                             </select>
                       </div>
                       <div>
                             <strong class="aiomatic-label-top marginbottom-5">' . esc_html__("Field Type*", 'aiomatic-automatic-ai-content-writer') . '</strong>
                             <select name="aiomaticfields[' . $inx . '][type]" class="aiomatic-create-template-field-type aiomatic-full-size">
                                <option value="text"';
                                if($aifield['type'] == 'text')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>Text</option>
                                <option value="select"';
                                if($aifield['type'] == 'select')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>Drop-Down</option>
                                <option value="number"';
                                if($aifield['type'] == 'number')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>Number</option>
                                <option value="email"';
                                if($aifield['type'] == 'email')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>Email</option>
                                <option value="url"';
                                if($aifield['type'] == 'url')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>URL</option>
                                <option value="textarea"';
                                if($aifield['type'] == 'textarea')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>Textarea</option>
                                <option value="checkbox"';
                                if($aifield['type'] == 'checkbox')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>Checkbox</option>
                                <option value="radio"';
                                if($aifield['type'] == 'radio')
                                {
                                    $result .= ' selected';
                                }
                                $result .= '>Radio</option>
                             </select>
                       </div>
                       <div class="aiomatic-create-template-field-min-main';
                       if($aifield['type'] != 'number')
                       {
                           $result .= ' aiomatic-hidden-form';
                       }
                       $result .= '">
                             <strong class="aiomatic-label-top marginbottom-5">' . esc_html__("Min", 'aiomatic-automatic-ai-content-writer') . '</strong>
                             <input placeholder="Minimum value (optional)" type="number" name="aiomaticfields[' . $inx . '][min]" value="' . esc_attr($aifield['min']) . '" class="aiomatic-create-template-field-min aiomatic-full-size">
                       </div>
                       <div class="aiomatic-create-template-field-max-main';
                       if($aifield['type'] != 'number')
                       {
                           $result .= ' aiomatic-hidden-form';
                       }
                       $result .= '">
                             <strong class="aiomatic-label-top marginbottom-5">' . esc_html__("Max", 'aiomatic-automatic-ai-content-writer') . '</strong>
                             <input placeholder="Maximum value (optional)" type="number" name="aiomaticfields[' . $inx . '][max]" value="' . esc_attr($aifield['max']) . '" class="aiomatic-create-template-field-max aiomatic-full-size">
                       </div>
                       <div class="aiomatic-create-template-field-rows-main';
                       if($aifield['type'] != 'textarea')
                       {
                           $result .= ' aiomatic-hidden-form';
                       }
                       $result .= '">
                             <strong class="aiomatic-label-top marginbottom-5">' . esc_html__("Rows", 'aiomatic-automatic-ai-content-writer') . '</strong>
                             <input placeholder="Textarea rows count (optional)" type="number" name="aiomaticfields[' . $inx . '][rows]" value="' . esc_attr($aifield['rows']) . '" class="aiomatic-create-template-field-rows aiomatic-full-size">
                       </div>
                       <div class="aiomatic-create-template-field-cols-main';
                       if($aifield['type'] != 'textarea')
                       {
                           $result .= ' aiomatic-hidden-form';
                       }
                       $result .= '">
                             <strong class="aiomatic-label-top marginbottom-5">' . esc_html__("Cols", 'aiomatic-automatic-ai-content-writer') . '</strong>
                             <input placeholder="Textarea columns count (optional)" type="number" name="aiomaticfields[' . $inx . '][cols]" value="' . esc_attr($aifield['cols']) . '" class="aiomatic-create-template-field-cols aiomatic-full-size">
                       </div>
                    </div>
                    <div class="aiomatic-create-template-field-options-main';
                    if($aifield['type'] != 'radio' && $aifield['type'] != 'checkbox' && $aifield['type'] != 'select')
                    {
                        $result .= ' aiomatic-hidden-form';
                    }
                    $result .= '">
                       <strong class="aiomatic-label-top marginbottom-5">Options</strong>
                       <textarea name="aiomaticfields[' . $inx . '][options]" class="aiomatic-create-template-field-options aiomatic-full-size" placeholder="Possible values, separated by a new line">' . esc_textarea($aifield['options']) . '</textarea>
                    </div>
                    <span class="aiomatic-field-delete">' . esc_html__("Delete this field?", 'aiomatic-automatic-ai-content-writer') . '</span>
                    </div>
                    </div>';
              }
              $result .= '</div>
              <hr/>
              <h2>' . esc_html__("Form Options", 'aiomatic-automatic-ai-content-writer') . ':</h2>
              <h4>' . esc_html__("Type*", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <select name="aiomatic-type" id="aiomatic-edit-type" class="aiomatic-create-template-field-type aiomatic-full-size">
                 <option value="text"';
                 if($type == 'text')
                 {
                    $result .= ' selected';
                 }
                 $result .= '>' . esc_html__("Text", 'aiomatic-automatic-ai-content-writer') . '</option>
                 <option value="image"';
                 if($type == 'image')
                 {
                    $result .= ' selected';
                 }
                 $result .= '>' . esc_html__("Dall-E 2 Image", 'aiomatic-automatic-ai-content-writer') . '</option>';
                 if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '') 
                 {
                    $result .= '<option value="image2"';
                    if($type == 'image2')
                    {
                       $result .= ' selected';
                    }
                    $result .= '>' . esc_html__("Stable Diffusion Image", 'aiomatic-automatic-ai-content-writer') . '</option>';
                 }
                 $result .= '</select>
              <br/>
              <h4>' . esc_html__("Title*", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <input id="aiomatic-form-title_edit" name="aiomatic-form-title" class="aiomatic-full-size" placeholder="Your form name" value="' . esc_attr($aiomatic_form->post_title) . '" required>
              <br/>
              <h4>' . esc_html__("Description", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <textarea id="aiomatic-form-description" name="aiomatic-form-description" class="aiomatic-full-size" placeholder="Your form description">' . esc_textarea($aiomatic_form->post_content) . '</textarea>
              <br/>
              <h4>' . esc_html__("Prompt*", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <textarea id="aiomatic-form-prompt_edit" name="aiomatic-form-prompt" class="aiomatic-full-size" placeholder="The prompt which will be sent to the AI content writer" required>' . esc_textarea($prompt) . '</textarea>
              <br/>
              <h4>' . esc_html__("Sample Response", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <textarea name="aiomatic-form-response" id="aiomatic-form-response" class="aiomatic-full-size" placeholder="A sample response to show for this form">' . esc_textarea($response) . '</textarea>
              <hr/>
              <div class="aiomatic-hide-not-text';
              if($type != 'text')
              {
                $result .= ' aiomatic-hidden-form';
              }
              $result .= '">
              <h2>' . esc_html__("AI Model Options", 'aiomatic-automatic-ai-content-writer') . ':</h2>
              <h4>' . esc_html__("AI Model*", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <select name="aiomatic-form-model" class="aiomatic-create-template-field-type aiomatic-full-size">';
$all_models = aiomatic_get_all_models();
foreach($all_models as $modl)
{
    $result .= '<option value="' . $modl . '"';
    if($modl == $model)
    {
        $result .= ' selected';
    }
    $result .= '>' . $modl . '</option>';
}
$result .= '</select>
              <br/>
              <br/>
              <button class="aiomatic-show-hide-field button">' . esc_html__("Show/Hide Advanced Model Settings", 'aiomatic-automatic-ai-content-writer') . '</button>
              <br/>
              <div class="aiomatic-hidden-form" id="hideAdv_edit">
              <h4>' . esc_html__("Max Token Count", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <input type="number" min="1" max="32768" step="1" name="aiomatic-max" value="' . esc_attr($max) . '" placeholder="Maximum token count to be used" class="cr_width_full">
              <br/>
              <h4>' . esc_html__("Temperature", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <input type="number" min="0" step="0.1" name="aiomatic-temperature" value="' . esc_attr($temperature) . '" placeholder="AI Temperature" class="cr_width_full">
              <br/>
              <h4>' . esc_html__("Top_p", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <input type="number" min="0" max="1" step="0.1" name="aiomatic-topp" value="' . esc_attr($topp) . '" placeholder="AI Top_p" class="cr_width_full">
              <br/>
              <h4>' . esc_html__("Presence Penalty", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <input type="number" min="-2" step="0.1" max="2" name="aiomatic-presence" value="' . esc_attr($presence) . '" placeholder="AI Presence Penalty" class="cr_width_full">
              <br/>
              <h4>' . esc_html__("Frequency Penalty", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <input type="number" min="0" max="1" step="0.1" name="aiomatic-frequency" value="' . esc_attr($frequency) . '" placeholder="AI Frequency penalty" class="cr_width_full">
              </div>
              <hr/>
              </div>
              <h2>' . esc_html__("Front End Options", 'aiomatic-automatic-ai-content-writer') . ':</h2>
              <h4>' . esc_html__("Show Header On Front End*", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <select name="aiomatic-header" class="aiomatic-create-template-field-type aiomatic-full-size">
                 <option value="show"';
                 if($header == 'show')
                 {
                    $result .= ' selected';
                 }
                 $result .= '>Show</option>
                 <option value="hide"';
                 if($header == 'hide')
                 {
                    $result .= ' selected';
                 }
                 $result .= '>Hide</option>
              </select>
              <br/>
              <h4>' . esc_html__("Submit Button Text*", 'aiomatic-automatic-ai-content-writer') . ':</h4>
              <input id="aiomatic-submit_edit" name="aiomatic-submit" value="' . esc_attr($submit) . '" class="aiomatic-full-size" placeholder="Submit" required>
            <br/><br/>
            <button type="submit" id="aiomatic-form-save-button_edit" class="button button-primary">' . esc_html__("Save", 'aiomatic-automatic-ai-content-writer') . '</button>
           <div class="aiomatic-forms-success"></div>
        </form>';
            $aiomatic_result['status'] = 'success';
            $aiomatic_result['data'] = $result;
        }
        else{
            $aiomatic_result['msg'] = 'Form not found';
        }
    }
    wp_send_json($aiomatic_result);
}
add_action('wp_ajax_aiomatic_embeddings_upload', 'aiomatic_embeddings_upload');
function aiomatic_embeddings_upload()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    if(!isset($_POST['xfile']))
    {
        $aiomatic_result['msg'] = 'Incorrect AJAX call';
    }
    else
    {
        require_once(dirname(__FILE__) . "/res/Embeddings.php");
        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
        if (isset($aiomatic_Main_Settings['app_id']) && trim($aiomatic_Main_Settings['app_id']) != '') 
        {
            $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
            $appids = array_filter($appids);
            $token = $appids[array_rand($appids)];
            require_once(dirname(__FILE__) . "/res/Embeddings.php");
            $embdedding = new Aiomatic_Embeddings($token);
            $aiomatic_result = $embdedding->aiomatic_create_embeddings(stripslashes($_POST['xfile']));
        }
        else
        {
            $aiomatic_result['msg'] = 'Please set up API key';
        }
    }
    wp_send_json($aiomatic_result);
    die();
}
add_action('wp_ajax_aiomatic_deleteall_embedding', 'aiomatic_deleteall_embedding');
function aiomatic_deleteall_embedding()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    require_once(dirname(__FILE__) . "/res/Embeddings.php");
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['app_id']) && trim($aiomatic_Main_Settings['app_id']) != '') 
    {
        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
        $appids = array_filter($appids);
        $token = $appids[array_rand($appids)];
        require_once(dirname(__FILE__) . "/res/Embeddings.php");
        $embdedding = new Aiomatic_Embeddings($token);
        $aiomatic_result = $embdedding->aiomatic_deleteall_embeddings();
    }
    else
    {
        $aiomatic_result['msg'] = 'Please set up API key for embeddings';
    }
    wp_send_json($aiomatic_result);
    die();
}
add_action('wp_ajax_aiomatic_delete_selected_embedding', 'aiomatic_delete_selected_embedding');
function aiomatic_delete_selected_embedding()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    check_ajax_referer('openai-ajax-nonce', 'nonce');
    if(!isset($_POST['ids']))
    {
        $aiomatic_result['msg'] = 'Incorrect AJAX call';
    }
    else
    {
        if(count($_POST['ids'])) {
            require_once(dirname(__FILE__) . "/res/Embeddings.php");
            $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
            if (isset($aiomatic_Main_Settings['app_id']) && trim($aiomatic_Main_Settings['app_id']) != '') 
            {
                $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
                $appids = array_filter($appids);
                $token = $appids[array_rand($appids)];
                require_once(dirname(__FILE__) . "/res/Embeddings.php");
                $embdedding = new Aiomatic_Embeddings($token);
                $aiomatic_result = $embdedding->aiomatic_delete_embeddings_ids($_POST['ids']);
            }
            else
            {
                $aiomatic_result['msg'] = 'Please set up API key for embeddings deletion';
            }
        }
    }
    wp_send_json($aiomatic_result);
    die();
}
add_action('wp_ajax_aiomatic_my_action', 'aiomatic_my_action_callback');
function aiomatic_my_action_callback()
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $failed                 = false;
    $del_id                 = $_POST['id'];
    $how                    = $_POST['how'];
    if($how == 'duplicate')
    {
        $GLOBALS['wp_object_cache']->delete('aiomatic_rules_list', 'options');
        if (!get_option('aiomatic_rules_list')) {
            $rules = array();
        } else {
            $rules = get_option('aiomatic_rules_list');
        }
        if (!empty($rules)) {
            $found            = 0;
            $cont = 0;
            foreach ($rules as $request => $bundle[]) {
                if ($cont == $del_id) {
                    $copy_bundle = $rules[$request];
                    $rules[] = $copy_bundle;
                    $found   = 1;
                    break;
                }
                $cont = $cont + 1;
            }
            if($found == 0)
            {
                aiomatic_log_to_file('aiomatic_rules_list index not found: ' . $del_id);
                echo 'nochange';
                die();
            }
            else
            {
                update_option('aiomatic_rules_list', $rules, false);
                echo 'ok';
                die();
            }
        } else {
            aiomatic_log_to_file('aiomatic_rules_list empty!');
            echo 'nochange';
            die();
        }
        
    }
    $force_delete           = true;
    $number                 = 0;
    if ($how == 'trash') {
        $force_delete = false;
    }
    $post_list = array();
    $postsPerPage = 50000;
    $paged = 0;
    do
    {
        $postOffset = $paged * $postsPerPage;
        $query = array(
            'post_status' => array(
                'publish',
                'draft',
                'pending',
                'trash',
                'private',
                'future'
            ),
            'post_type' => array(
                'any'
            ),
            'numberposts' => $postsPerPage,
            'meta_key' => 'aiomatic_parent_rule',
            'fields' => 'ids',
            'offset'  => $postOffset
        );
        $got_me = get_posts($query);
        $post_list = array_merge($post_list, $got_me);
        $paged++;
    }while(!empty($got_me));
    wp_suspend_cache_addition(true);
    foreach ($post_list as $post) {
        $index = get_post_meta($post, 'aiomatic_parent_rule', true);
        if ($index == $del_id) {
            $args             = array(
                'post_parent' => $post
            );
            $post_attachments = get_children($args);
            if (isset($post_attachments) && !empty($post_attachments)) {
                foreach ($post_attachments as $attachment) {
                    wp_delete_attachment($attachment->ID, true);
                }
            }
            $res = wp_delete_post($post, $force_delete);
            if ($res === false) {
                $failed = true;
            } else {
                $number++;
            }
        }
    }
    wp_suspend_cache_addition(false);
    if ($failed === true) {
        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
            aiomatic_log_to_file('[PostDelete] Failed to delete all posts for rule id: ' . esc_html($del_id) . '!');
        }
        echo 'failed';
    } else {
        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
            aiomatic_log_to_file('[PostDelete] Successfuly deleted ' . esc_html($number) . ' posts for rule id: ' . esc_html($del_id) . '!');
        }
        if ($number == 0) {
            echo 'nochange';
        } else {
            echo 'ok';
        }
    }
    die();
}
add_action('wp_ajax_aiomatic_run_my_action', 'aiomatic_run_my_action_callback');
function aiomatic_run_my_action_callback()
{
    $run_id = $_POST['id'];
    echo aiomatic_run_rule($run_id, 0);
    die();
}
add_action('wp_ajax_aiomatic_editor', 'aiomatic_editor');
function aiomatic_editor() {
	check_ajax_referer('wp_rest', 'nonce');

    if(!isset($_POST['prompt']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (prompt)' ) );
	}
	$prompt = stripslashes(sanitize_text_field( $_POST['prompt'] ));
	$aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['assistant_disable']) && $aiomatic_Main_Settings['assistant_disable'] == 'on')
    {
        wp_send_json_error( array( 'message' => 'Assistant disabled in plugin settings' ) );
    }
    if (!isset($aiomatic_Main_Settings['aiomatic_enabled']) || $aiomatic_Main_Settings['aiomatic_enabled'] != 'on')
    {
        wp_send_json_error( array( 'message' => 'Aiomatic plugin disabled' ) );
    }
    if(isset($aiomatic_Main_Settings['assistant_model']) && $aiomatic_Main_Settings['assistant_model'] != '')
    {
        $model = $aiomatic_Main_Settings['assistant_model'];
    }
    else
    {
        $model = 'text-davinci-003';
    }
	$temperature = 1;
    if(isset($aiomatic_Main_Settings['assistant_temperature']) && $aiomatic_Main_Settings['assistant_temperature'] != '')
    {
        $temperature = intval($aiomatic_Main_Settings['assistant_temperature']);
    }
	$top_p = 1;
    if(isset($aiomatic_Main_Settings['assistant_top_p']) && $aiomatic_Main_Settings['assistant_top_p'] != '')
    {
        $top_p = intval($aiomatic_Main_Settings['assistant_top_p']);
    }
	$fpenalty = 0;
    if(isset($aiomatic_Main_Settings['assistant_fpenalty']) && $aiomatic_Main_Settings['assistant_fpenalty'] != '')
    {
        $fpenalty = intval($aiomatic_Main_Settings['assistant_fpenalty']);
    }
	$ppenalty = 0;
    if(isset($aiomatic_Main_Settings['assistant_ppenalty']) && $aiomatic_Main_Settings['assistant_ppenalty'] != '')
    {
        $ppenalty = intval($aiomatic_Main_Settings['assistant_ppenalty']);
    }
	$max_tokens = aiomatic_get_max_tokens($model);
	$all_models = aiomatic_get_all_models(true);
	if(!in_array($model, $all_models))
    {
        $model = 'text-davinci-003';
    }
	if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') {
		wp_send_json_error( array( 'message' => 'You need to enter an OpenAI API key in plugin settings!' ) );
	}
	$new_post_content = '';
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
	$appids = array_filter($appids);
	$token = $appids[array_rand($appids)];
	$query_token_count = count(aiomatic_encode($prompt));
	$available_tokens = $max_tokens - $query_token_count;
	if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
	{
		$string_len = strlen($prompt);
		$string_len = $string_len / 2;
		$string_len = intval(0 - $string_len);
        $aicontent = aiomatic_substr($prompt, 0, $string_len);
		$aicontent = trim($aicontent);
		if(empty($aicontent))
		{
			wp_send_json_error( array( 'message' => 'Incorrect prompt provided!' ) );
		}
		$query_token_count = count(aiomatic_encode($aicontent));
		$available_tokens = $max_tokens - $query_token_count;
	}
	$aierror = '';
	$finish_reason = '';
	$generated_text = aiomatic_generate_text($token, $model, $prompt, $available_tokens, $temperature, $top_p, $ppenalty, $fpenalty, false, 'aiAssistantWriter', 0, $finish_reason, $aierror);
	if($generated_text === false)
	{
		wp_send_json_error( array( 'message' => 'Failed to generate AI content: ' . $aierror) );
	}
	else
	{
		$new_post_content = trim(trim(trim($generated_text), '"\''));
	}
	wp_send_json_success( array( 'content' => $new_post_content ) );

}
add_action('wp_ajax_aiomatic_imager', 'aiomatic_imager');
function aiomatic_imager() {
	check_ajax_referer('wp_rest', 'nonce');

    if(!isset($_POST['prompt']))
	{
		wp_send_json_error( array( 'message' => 'Incorrect query sent (prompt)' ) );
	}
	$prompt = stripslashes(sanitize_text_field( $_POST['prompt'] ));

	$aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['assistant_disable']) && $aiomatic_Main_Settings['assistant_disable'] == 'on')
    {
        wp_send_json_error( array( 'message' => 'Assistant disabled in plugin settings' ) );
    }
    if (!isset($aiomatic_Main_Settings['aiomatic_enabled']) || $aiomatic_Main_Settings['aiomatic_enabled'] != 'on')
    {
        wp_send_json_error( array( 'message' => 'Aiomatic plugin disabled' ) );
    }
	if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') {
		wp_send_json_error( array( 'message' => 'You need to enter an OpenAI API key in plugin settings!' ) );
	}
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
	$appids = array_filter($appids);
	$token = $appids[array_rand($appids)];
    $image_size = '512x512';
	if (isset($aiomatic_Main_Settings['assistant_image_size']) && trim($aiomatic_Main_Settings['assistant_image_size']) != '') 
    {
        $image_size = $aiomatic_Main_Settings['assistant_image_size'];
    }
    $error = '';
    $image = '';
    $echo_ok = false;
    $response_text = aiomatic_generate_ai_image($token, 1, $prompt, $image_size, 'aiAssistantImage', true, 0, $error);
    if($response_text === false)
    {
        wp_send_json_error( array( 'message' => 'Error occurred when calling API in image chat: ' . $error) );
    }
    else
    {
        foreach($response_text as $tmpimg)
        {
            $localpath = aiomatic_copy_image_locally($tmpimg);
            if($localpath !== false)
            {
                $image = '<img src="' . $localpath[0] . '">';
                $echo_ok = true;
                break;
            }
            else
            {
                wp_send_json_error( array( 'message' => 'Failed to copy image file locally: ' . $tmpimg) );
            }
        }
    }
    if($echo_ok === false)
    {
        wp_send_json_error( array( 'message' => 'No image returned from API call: ' . $prompt) );
    }
	if($image === false)
	{
		wp_send_json_error( array( 'message' => 'Failed to generate AI image: ' . $error) );
	}
	wp_send_json_success( array( 'content' => $image ) );
}

add_action('wp_ajax_aiomatic_form_submit', 'aiomatic_form_submit');
add_action('wp_ajax_nopriv_aiomatic_form_submit', 'aiomatic_form_submit');
function aiomatic_form_submit() {
	check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    $response_text = '';
    if(!isset($_POST['presence']) || !isset($_POST['input_text']) || !isset($_POST['model']) || !isset($_POST['temp']) || !isset($_POST['top_p']) || !isset($_POST['frequency']))
    {
        $aiomatic_result['msg'] = 'Incomplete POST request for text editing';
        wp_send_json($aiomatic_result);
    }
    $user_token_cap_per_day = sanitize_text_field($_POST['user_token_cap_per_day']);
    if(!empty($user_token_cap_per_day))
    {
        $user_token_cap_per_day = intval($user_token_cap_per_day);
    }
	$user_id = sanitize_text_field($_POST['user_id']);
    if(isset($_POST['aiomaticType']))
    {
	    $aiomaticType = sanitize_text_field($_POST['aiomaticType']);
    }
    else
    {
        $aiomaticType = 'none';
    }
	$input_text = stripslashes($_POST['input_text']);
	$model = sanitize_text_field(stripslashes($_POST['model']));
	$temperature = sanitize_text_field($_POST['temp']);
	$top_p = sanitize_text_field($_POST['top_p']);
	$presence_penalty = sanitize_text_field($_POST['presence']);
	$frequency_penalty = sanitize_text_field($_POST['frequency']);
    $all_models = aiomatic_get_all_models(true);
    $models = $all_models;
    if(!in_array($model, $models))
    {
        $aiomatic_result['msg'] = 'Invalid model provided: ' . $model;
        wp_send_json($aiomatic_result);
    }
    $temperature = floatval($temperature);
    $top_p = floatval($top_p);
    $presence_penalty = floatval($presence_penalty);
    $frequency_penalty = floatval($frequency_penalty);
    if($temperature < 0 || $temperature > 1)
    {
        $aiomatic_result['msg'] = 'Invalid temperature provided: ' . $temperature;
        wp_send_json($aiomatic_result);
    }
    if($top_p < 0 || $top_p > 1)
    {
        $aiomatic_result['msg'] = 'Invalid top_p provided: ' . $top_p;
        wp_send_json($aiomatic_result);
    }
    if($presence_penalty < -2 || $presence_penalty > 2)
    {
        $aiomatic_result['msg'] = 'Invalid presence_penalty provided: ' . $presence_penalty;
        wp_send_json($aiomatic_result);
    }
    if($frequency_penalty < -2 || $frequency_penalty > 2)
    {
        $aiomatic_result['msg'] = 'Invalid frequency_penalty provided: ' . $frequency_penalty;
        wp_send_json($aiomatic_result);
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        $aiomatic_result['msg'] = 'You need to insert a valid OpenAI/AiomaticAPI API Key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $used_token_count = 0;
    if(is_numeric($user_token_cap_per_day))
    {
        if(empty($user_id) || $user_id == 0)
        {
            $aiomatic_result['msg'] = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
            wp_send_json($aiomatic_result);
        }
        $used_token_count = get_user_meta($user_id, 'aiomatic_used_tokens', true);
        if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
        {
            $used_token_count = intval($used_token_count);
            if($used_token_count > $user_token_cap_per_day)
            {
                $aiomatic_result['msg'] = 'Daily token count for your user account was exceeded! Please try again tomorrow.';
                wp_send_json($aiomatic_result);
            }
        }
        else
        {
            $used_token_count = 0;
        }
    }
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
    if($aiomaticType == 'text' || $aiomaticType == 'none')
    {
        $max_tokens = aiomatic_get_max_tokens($model);
        $input_text = preg_replace('#<br\s*/?>#i', "\n", $input_text);
        $input_text = htmlspecialchars_decode($input_text, ENT_QUOTES);
        $input_text = stripslashes($input_text);
        $input_text = preg_replace('#<div><span class="highlight-none">([\s\S]*?)<\/span><\/div>#i', PHP_EOL . '$1', $input_text);
        $input_text = preg_replace('#<span class="highlight-none">([\s\S]*?)<\/span>#i', '$1', $input_text);
        $query_token_count = count(aiomatic_encode($input_text));
        $available_tokens = $max_tokens - $query_token_count;
        if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
        {
            $string_len = strlen($input_text);
            $string_len = $string_len / 2;
            $string_len = intval(0 - $string_len);
            $input_text = aiomatic_substr($input_text, 0, $string_len);
            $input_text = trim($input_text);
            if(empty($input_text))
            {
                aiomatic_log_to_file('Empty API seed expression provided (after processing)');
                wp_die();
            }
            $query_token_count = count(aiomatic_encode($input_text));
            $available_tokens = $max_tokens - $query_token_count;
        }
        $error = '';
        $finish_reason = '';
        if($aiomaticType == 'text')
        {
            $response_text = aiomatic_generate_text($token, $model, $input_text, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'formsText', 0, $finish_reason, $error);
        }
        else
        {
            $response_text = aiomatic_generate_text($token, $model, $input_text, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'shortcodeCompletion', 0, $finish_reason, $error);
        }
        if($response_text === false)
        {
            $aiomatic_result['msg'] = $error;
            wp_send_json($aiomatic_result);
        }
        else
        {
            $inp_count = count(aiomatic_encode($input_text));
            $resp_count = count(aiomatic_encode($response_text));
            if(is_numeric($user_token_cap_per_day))
            {
                $used_token_count = intval($used_token_count) + $inp_count + $resp_count;
                update_user_meta($user_id, 'aiomatic_used_tokens', $used_token_count);
            }
        }
    }
    elseif($aiomaticType == 'image')
    {
        $echo_ok = false;
        $error = '';
        $image_size = '512x512';
        if (isset($aiomatic_Main_Settings['ai_image_size']) && trim($aiomatic_Main_Settings['ai_image_size']) != '') 
        {
            $image_size = trim($aiomatic_Main_Settings['ai_image_size']);
        }
        $arr_response_text = aiomatic_generate_ai_image($token, 1, $input_text, $image_size, 'formsImage', false, 0, $error);
        if($arr_response_text === false)
        {
            $aiomatic_result['msg'] = $error;
            wp_send_json($aiomatic_result);
        }
        else
        {
            foreach($arr_response_text as $tmpimg)
            {
                $response_text = $tmpimg;
                $echo_ok = true;
            }
            if(is_numeric($user_token_cap_per_day))
            {
                $used_token_count = intval($used_token_count) + 1000;
                update_user_meta($user_id, 'aiomatic_used_image_chat_tokens', $used_token_count);
            }
        }
        if($echo_ok === false)
        {
            $aiomatic_result['msg'] = 'No image returned from API call: ' . $input_text;
            wp_send_json($aiomatic_result);
        }
    }
    elseif($aiomaticType == 'image2')
    {
        $echo_ok = false;
        $error = '';
        $height = '512';
        $width = '512';
        if (isset($aiomatic_Main_Settings['ai_image_size']) && trim($aiomatic_Main_Settings['ai_image_size']) != '') 
        {
            if(trim($aiomatic_Main_Settings['ai_image_size']) == '1024x1024')
            {
                $height = '1024';
                $width = '1024';
            }
        }
        $arr_response_text = aiomatic_generate_stability_image($input_text, $height, $width, 'formsStableImage', 0, true);
        if($arr_response_text === false)
        {
            $aiomatic_result['msg'] = $error;
            wp_send_json($aiomatic_result);
        }
        else
        {
            $response_text = $arr_response_text;
            $echo_ok = true;
            if(is_numeric($user_token_cap_per_day))
            {
                $used_token_count = intval($used_token_count) + 1000;
                update_user_meta($user_id, 'aiomatic_used_image_chat_tokens', $used_token_count);
            }
        }
        if($echo_ok === false)
        {
            $aiomatic_result['msg'] = 'No image returned from API call: ' . $input_text;
            wp_send_json($aiomatic_result);
        }
    }
    else
    {
        $aiomatic_result['msg'] = 'Unknown request type submitted: ' . esc_html($aiomaticType);
        wp_send_json($aiomatic_result);
    }
    $aiomatic_result['status'] = 'success';
    $aiomatic_result['data'] = esc_html($response_text);
    wp_send_json($aiomatic_result);
	wp_die();
}

add_action('wp_ajax_aiomatic_edit_submit', 'aiomatic_edit_submit');
add_action('wp_ajax_nopriv_aiomatic_edit_submit', 'aiomatic_edit_submit');

function aiomatic_edit_submit() {
	check_ajax_referer('openai-ajax-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(!isset($_POST['instruction']) || !isset($_POST['input_text']) || !isset($_POST['model']) || !isset($_POST['temp']) || !isset($_POST['top_p']))
    {
        $aiomatic_result['msg'] = 'Incomplete POST request for text editing';
        wp_send_json($aiomatic_result);
    }
	$instruction = stripslashes($_POST['instruction']);
	$input_text = stripslashes($_POST['input_text']);
	$model = sanitize_text_field($_POST['model']);
	$temperature = sanitize_text_field($_POST['temp']);
	$top_p = sanitize_text_field($_POST['top_p']);
    $user_token_cap_per_day = sanitize_text_field($_POST['user_token_cap_per_day']);
    if(!empty($user_token_cap_per_day))
    {
        $user_token_cap_per_day = intval($user_token_cap_per_day);
    }
	$user_id = sanitize_text_field($_POST['user_id']);
    $temperature = floatval($temperature);
    $top_p = floatval($top_p);
    $all_models = aiomatic_get_all_models(true);
    $models = array_merge($all_models, array('text-davinci-edit-001', 'code-davinci-edit-001'));
    if(!in_array($model, $models))
    {
        $aiomatic_result['msg'] = 'Invalid editing model provided: ' . $model;
        wp_send_json($aiomatic_result);
    }
    if($temperature < 0 || $temperature > 1)
    {
        $aiomatic_result['msg'] = 'Invalid temperature provided: ' . $temperature;
        wp_send_json($aiomatic_result);
    }
    if($top_p < 0 || $top_p > 1)
    {
        $aiomatic_result['msg'] = 'Invalid top_p provided: ' . $top_p;
        wp_send_json($aiomatic_result);
    }
    if(empty($instruction))
    {
        $aiomatic_result['msg'] = 'You need to add an instruction for the text editing!';
        wp_send_json($aiomatic_result);
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        $aiomatic_result['msg'] = 'You need to insert a valid OpenAI/AiomaticAPI API Key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $used_token_count = 0;
    if(is_numeric($user_token_cap_per_day))
    {
        if(empty($user_id) || $user_id == 0)
        {
            $aiomatic_result['msg'] = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
            wp_send_json($aiomatic_result);
        }
        $used_token_count = get_user_meta($user_id, 'aiomatic_used_edit_tokens', true);
        if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
        {
            $used_token_count = intval($used_token_count);
            if($used_token_count > $user_token_cap_per_day)
            {
                $aiomatic_result['msg'] = 'Daily token count for your user account was exceeded! Please try again tomorrow.';
                wp_send_json($aiomatic_result);
            }
        }
        else
        {
            $used_token_count = 0;
        }
    }
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
    $completionmodels = $all_models;
    if(in_array($model, $completionmodels))
    {
        if(!aiomatic_endsWith(trim($instruction), ':'))
        {
            $prompt = $instruction . ': ' . $input_text;
        }
        else
        {
            $prompt = $instruction . $input_text;
        }
        $error = '';
        $finish_reason = '';
        $max_tokens = aiomatic_get_max_tokens($model);
        $prompt = stripslashes($prompt);
        $query_token_count = count(aiomatic_encode($prompt));
        $available_tokens = $max_tokens - $query_token_count;
        if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
        {
            $string_len = strlen($prompt);
            $string_len = $string_len / 2;
            $string_len = intval(0 - $string_len);
            $prompt = aiomatic_substr($prompt, 0, $string_len);
            $prompt = trim($prompt);
            if(empty($prompt))
            {
                $aiomatic_result['msg'] = 'Empty API seed expression provided (after processing)';
                wp_send_json($aiomatic_result);
            }
            else
            {
                $query_token_count = count(aiomatic_encode($prompt));
                $available_tokens = $max_tokens - $query_token_count;
            }
        }
        $response_text = aiomatic_generate_text($token, $model, $prompt, $available_tokens, $temperature, $top_p, 0, 0, false, 'shortcodeCEditor', 0, $finish_reason, $error);
        if($response_text === false)
        {
            $aiomatic_result['msg'] = $error;
            wp_send_json($aiomatic_result);
        }
        else
        {
            $inp_count = count(aiomatic_encode($prompt));
            $resp_count = count(aiomatic_encode($response_text));
            if(is_numeric($user_token_cap_per_day))
            {
                $used_token_count = intval($used_token_count) + $inp_count + $resp_count;
                update_user_meta($user_id, 'aiomatic_used_tokens', $used_token_count);
            }
        }
        $response_text = trim($response_text);
        $aiomatic_result['status'] = 'success';
        $aiomatic_result['data'] = $response_text;
        wp_send_json($aiomatic_result);
    }
    else
    {
        $aierror = '';
        $input_text = stripslashes($input_text);
        $instruction = stripslashes($instruction);
        $response_text = aiomatic_edit_text($token, $model, $instruction, $input_text, $temperature, $top_p, 'shortcodeEditor', 0, $aierror);
        if($response_text === false)
        {
            $aiomatic_result['msg'] = $aierror;
            wp_send_json($aiomatic_result);
        }
        else
        {
            $instr_count = count(aiomatic_encode($instruction));
            $inp_count = count(aiomatic_encode($input_text));
            $resp_count = count(aiomatic_encode($response_text));
            if(is_numeric($user_token_cap_per_day))
            {
                $used_token_count = intval($used_token_count) + $instr_count + $inp_count + $resp_count;
                update_user_meta($user_id, 'aiomatic_used_edit_tokens', $used_token_count);
            }
        }
        $aiomatic_result['status'] = 'success';
        $aiomatic_result['data'] = $response_text;
        wp_send_json($aiomatic_result);
    }
}

add_action('wp_ajax_aiomatic_image_chat_submit', 'aiomatic_image_chat_submit');
add_action('wp_ajax_nopriv_aiomatic_image_chat_submit', 'aiomatic_image_chat_submit');

function aiomatic_image_chat_submit() 
{
    $echo_ok = false;
	check_ajax_referer('openai-ajax-images-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if(!isset($_POST['input_text']))
    {
        $aiomatic_result['msg'] = 'Incomplete POST request for image chat';
        wp_send_json($aiomatic_result);
    }
    $user_token_cap_per_day = sanitize_text_field($_POST['user_token_cap_per_day']);
    if(!empty($user_token_cap_per_day))
    {
        $user_token_cap_per_day = intval($user_token_cap_per_day);
    }
	$user_id = sanitize_text_field($_POST['user_id']);
	$input_text = stripslashes($_POST['input_text']);
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        $aiomatic_result['msg'] = 'You need to insert a valid OpenAI/AiomaticAPI API Key for this to work!';
        wp_send_json($aiomatic_result);
    }
    $used_token_count = 0;
    if(is_numeric($user_token_cap_per_day))
    {
        if(empty($user_id) || $user_id == 0)
        {
            $aiomatic_result['msg'] = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
            wp_send_json($aiomatic_result);
        }
        $used_token_count = get_user_meta($user_id, 'aiomatic_used_image_chat_tokens', true);
        if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
        {
            $used_token_count = intval($used_token_count);
            if($used_token_count > $user_token_cap_per_day)
            {
                $aiomatic_result['msg'] = 'Daily token count for your user account was exceeded! Please try again tomorrow.';
                wp_send_json($aiomatic_result);
            }
        }
        else
        {
            $used_token_count = 0;
        }
    }
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
	$error = '';
    $image_size = '512x512';
	if (isset($aiomatic_Main_Settings['image_chat_size']) && trim($aiomatic_Main_Settings['image_chat_size']) != '') 
    {
        $image_size = $aiomatic_Main_Settings['image_chat_size'];
    }
    $response_text = aiomatic_generate_ai_image($token, 1, $input_text, $image_size, 'shortcodeImageChat', false, 0, $error);
    if($response_text === false)
    {
        $aiomatic_result['msg'] = $error;
        wp_send_json($aiomatic_result);
    }
    else
    {
        foreach($response_text as $tmpimg)
        {
            $aiomatic_result['status'] = 'success';
            if(isset($aiomatic_result['data']))
            {
                $aiomatic_result['data'] .= '<a href="' . $tmpimg . '" target="_blank"><img src="' . $tmpimg . '"></a>';
            }
            else
            {
                $aiomatic_result['data'] = '<a href="' . $tmpimg . '" target="_blank"><img src="' . $tmpimg . '"></a>';
            }
            $echo_ok = true;
        }
        if(is_numeric($user_token_cap_per_day))
        {
            $used_token_count = intval($used_token_count) + 1000;
            update_user_meta($user_id, 'aiomatic_used_image_chat_tokens', $used_token_count);
        }
    }
    if($echo_ok === false)
    {
        $aiomatic_result['msg'] = 'No image returned from API call: ' . $input_text;
        wp_send_json($aiomatic_result);
    }
    wp_send_json($aiomatic_result);
}

add_action('wp_ajax_aiomatic_user_meta_save', 'aiomatic_user_meta_save');
add_action('wp_ajax_nopriv_aiomatic_user_meta_save', 'aiomatic_user_meta_save');

function aiomatic_user_meta_save() 
{
	check_ajax_referer('openai-persistent-nonce', 'nonce');
    if(!isset($_POST['x_input_text']))
    {
        aiomatic_log_to_file('Failed to save persistent conversation, no x_input_text: ' . print_r($_POST, true));
	    wp_die();
    }
    if(!isset($_POST['user_id']))
    {
        aiomatic_log_to_file('Failed to save persistent conversation, no user_id: ' . print_r($_POST, true));
	    wp_die();
    }
	$user_id = sanitize_text_field($_POST['user_id']);
    if(!isset($_POST['persistent']))
    {
        aiomatic_log_to_file('Failed to save persistent conversation, no persistentid: ' . print_r($_POST, true));
	    wp_die();
    }
	$persistent = sanitize_text_field($_POST['persistent']);
    if(empty($user_id) || $user_id == 0)
    {
        aiomatic_log_to_file('Failed to save persistent conversation, user_id is not valid: ' . print_r($_POST, true));
	    wp_die();
    }
	$x_input_text = stripslashes($_POST['x_input_text']);
    if(!empty($x_input_text))
    {
        update_user_meta($user_id, 'aiomatic_chat_history_' . $persistent, $x_input_text);
    }
	wp_die();
}
add_action( 'wp_ajax_aiomatic_audio_converter', 'aiomatic_audio_converter' );
add_action( 'wp_ajax_nopriv_aiomatic_audio_converter', 'aiomatic_audio_converter' );
function aiomatic_audio_converter()
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if ( ! wp_verify_nonce( $_POST['nonce'], 'openai-audio-nonce' ) ) {
        $aiomatic_result['msg'] = 'You are not allowed to do this action!';
        wp_send_json($aiomatic_result);
    }
    $purpose = isset($_REQUEST['audio_purpose']) && !empty($_REQUEST['audio_purpose']) ? sanitize_text_field($_REQUEST['audio_purpose']) : 'transcriptions';
    $prompt = isset($_REQUEST['prompt']) && !empty($_REQUEST['prompt']) ? sanitize_text_field($_REQUEST['prompt']) : '';
    $type = isset($_REQUEST['type']) && !empty($_REQUEST['type']) ? sanitize_text_field($_REQUEST['type']) : 'upload';
    $url = isset($_REQUEST['url']) && !empty($_REQUEST['url']) ? sanitize_text_field($_REQUEST['url']) : '';
    $model = isset($_REQUEST['model']) && !empty($_REQUEST['model']) ? sanitize_text_field($_REQUEST['model']) : 'whisper-1';
    $temperature = isset($_REQUEST['temperature']) && !empty($_REQUEST['temperature']) ? sanitize_text_field($_REQUEST['temperature']) : 0;
    $language = isset($_REQUEST['language']) && !empty($_REQUEST['language']) ? sanitize_text_field($_REQUEST['language']) : 'en';
    $mime_types = ['mp3' => 'audio/mpeg','mp4' => 'video/mp4','mpeg' => 'video/mpeg','m4a' => 'audio/m4a','wav' => 'audio/wav','webm' => 'video/webm'];
    if($purpose != 'transcriptions' && $purpose != 'translations')
    {
        $aiomatic_result['msg'] = 'Unknown purpose submitted.';
        wp_send_json($aiomatic_result);
    }
    if($type == 'upload' && !isset($_FILES['file'])){
        $aiomatic_result['msg'] = 'An audio file is mandatory.';
        wp_send_json($aiomatic_result);
    }
    if($type == 'record' && !isset($_FILES['recorded_audio'])){
        $aiomatic_result['msg'] = 'An audio recording is mandatory.';
        wp_send_json($aiomatic_result);
    }
    if($type == 'upload'){
        $file = $_FILES['file'];
        $file_name = sanitize_file_name(basename($file['name']));
        $filetype = wp_check_filetype($file_name);
        if(!in_array($filetype['type'], $mime_types)){
            $aiomatic_result['msg'] = 'We only accept mp3, mp4, mpeg, mpga, m4a, wav, or webm.';
            wp_send_json($aiomatic_result);
        }
        if($file['size'] > 26214400){
            $aiomatic_result['msg'] = 'Audio file maximum 25MB';
            wp_send_json($aiomatic_result);
        }
    }
    if($type == 'record'){
        $file = $_FILES['recorded_audio'];
        $file_name = sanitize_file_name(basename($file['name']));
        $filetype = wp_check_filetype($file_name);
        if(!in_array($filetype['type'], $mime_types)){
            $aiomatic_result['msg'] = 'We only accept mp3, mp4, mpeg, mpga, m4a, wav, or webm.';
            wp_send_json($aiomatic_result);
        }
        if($file['size'] > 26214400){
            $aiomatic_result['msg'] = 'Audio file maximum 25MB';
            wp_send_json($aiomatic_result);
        }
        $tmp_file = $file['tmp_name'];
    }
    if($type == 'url'){
        if(empty($url)){
            $aiomatic_result['msg'] = 'The audio URL is required';
            wp_send_json($aiomatic_result);
        }
        $remoteFile = get_headers($url, 1);
        $file_name = basename($url);
        $is_in_mime_types = false;
        $file_ext = '';
        foreach($mime_types as $key=>$mime_type){
            if((is_array($remoteFile['Content-Type']) && in_array($mime_type,$remoteFile['Content-Type'])) || strpos($remoteFile['Content-Type'], $mime_type) !== false){
                $is_in_mime_types = true;
                $file_ext = '.'.$key;
                break;
            }
        }
        if(!$is_in_mime_types){
            $aiomatic_result['msg'] = 'We only accept mp3, mp4, mpeg, mpga, m4a, wav, or webm.';
            wp_send_json($aiomatic_result);
        }

        if(strpos($file_name, $file_ext) === false){
            $file_name = md5(uniqid() . time()) . $file_ext;
        }
        if($remoteFile['Content-Length'] > 26214400){
            $aiomatic_result['msg'] = 'Audio file maximum 25MB';
            wp_send_json($aiomatic_result);
        }
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') {
        $aiomatic_result['msg'] = 'You need to add an API key in plugin settings for this shortcode to work.';
        wp_send_json($aiomatic_result);
    }
    else
    {
        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
        $appids = array_filter($appids);
        $token = $appids[array_rand($appids)];
        if(empty($token))
        {
            $aiomatic_result['msg'] = 'Invalid API key submitted';
            wp_send_json($aiomatic_result);
        }
        if(aiomatic_is_aiomaticapi_key($token))
        {
            $aiomatic_result['msg'] = 'Currently only OpenAI API is supported for audio processing.';
            wp_send_json($aiomatic_result);
        }
    }
    if (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        $aiomatic_result['msg'] = 'Azure API is not currently supported for audio conversion.';
        wp_send_json($aiomatic_result);
    }
    require_once (dirname(__FILE__) . "/res/openai/Url.php"); 
    require_once (dirname(__FILE__) . "/res/openai/OpenAi.php"); 
    $open_ai = new OpenAi($token);
    if(!$open_ai){
        $aiomatic_result['msg'] = 'Missing API Setting';
        wp_send_json($aiomatic_result);
    }
    if($type == 'url'){
        if(!function_exists('download_url')){
            include_once( ABSPATH . 'wp-admin/includes/file.php' );
        }
        $tmp_file = download_url($url);
        if ( is_wp_error( $tmp_file ) ){
            $aiomatic_result['msg'] = $tmp_file->get_error_message();
            wp_send_json($aiomatic_result);
        }
    }
    if($type == 'upload'){
        $tmp_file = $file['tmp_name'];
    }
    $response_format = 'text';
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
        wp_filesystem($creds);
    }
    $data_request = array(
        'audio' => array(
            'filename' => $file_name,
            'data' => $wp_filesystem->get_contents($tmp_file)
        ),
        'model' => $model,
        'temperature' => $temperature,
        'response_format' => $response_format,
        'prompt' => $prompt
    );
    if($purpose == 'transcriptions' && !empty($language)){
        $data_request['language'] = $language;
    }
    $delay = '';
    if (isset($aiomatic_Main_Settings['request_delay']) && $aiomatic_Main_Settings['request_delay'] != '') 
    {
        if(stristr($aiomatic_Main_Settings['request_delay'], ',') !== false)
        {
            $tempo = explode(',', $aiomatic_Main_Settings['request_delay']);
            if(isset($tempo[1]) && is_numeric(trim($tempo[1])) && is_numeric(trim($tempo[0])))
            {
                $delay = rand(trim($tempo[0]), trim($tempo[1]));
            }
        }
        else
        {
            if(is_numeric(trim($aiomatic_Main_Settings['request_delay'])))
            {
                $delay = intval(trim($aiomatic_Main_Settings['request_delay']));
            }
        }
    }
    if($delay != '' && is_numeric($delay))
    {
        usleep($delay);
    }
    if($purpose == 'transcriptions')
    {
        $completion = $open_ai->transcribe($data_request);
    }
    elseif($purpose == 'translations')
    {
        $completion = $open_ai->translate($data_request);
    }
    $result = json_decode($completion);
    if($result && isset($result->error)){
        $aiomatic_result['msg'] = $result->error->message;
        wp_send_json($aiomatic_result);
    }
    $aiomatic_result['status'] = 'success';
    $text_generated = $completion;
    $aiomatic_result['data'] = $text_generated;
    if(empty($text_generated)){
        $aiomatic_result['msg'] = 'OpenAI returned empty content';
        wp_send_json($aiomatic_result);
    }
    wp_send_json($aiomatic_result);
}
add_action( 'wp_ajax_aiomatic_moderate_text', 'aiomatic_moderate_text' );
add_action( 'wp_ajax_nopriv_aiomatic_moderate_text', 'aiomatic_moderate_text' );
function aiomatic_moderate_text()
{
    check_ajax_referer('openai-moderation-nonce', 'nonce');
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    $text = isset($_REQUEST['text']) && !empty($_REQUEST['text']) ? sanitize_text_field($_REQUEST['text']) : '';
    if(empty($text))
    {
        $aiomatic_result['msg'] = 'You need to enter a text to moderate!';
        wp_send_json($aiomatic_result);
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') {
        $aiomatic_result['msg'] = 'You need to add an API key in plugin settings for this shortcode to work.';
        wp_send_json($aiomatic_result);
    }
    else
    {
        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
        $appids = array_filter($appids);
        $token = $appids[array_rand($appids)];
        if(empty($token))
        {
            $aiomatic_result['msg'] = 'Invalid API key submitted';
            wp_send_json($aiomatic_result);
        }
        if(aiomatic_is_aiomaticapi_key($token))
        {
            $aiomatic_result['msg'] = 'Currently only OpenAI API is supported for audio processing.';
            wp_send_json($aiomatic_result);
        }
    }
    if (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        $aiomatic_result['msg'] = 'Azure API is not currently supported for moderation.';
        wp_send_json($aiomatic_result);
    }
    require_once (dirname(__FILE__) . "/res/openai/Url.php"); 
    require_once (dirname(__FILE__) . "/res/openai/OpenAi.php"); 
    $open_ai = new OpenAi($token);
    if(!$open_ai){
        $aiomatic_result['msg'] = 'Missing API Setting';
        wp_send_json($aiomatic_result);
    }
    $data_request = array(
        'input' => $text
    );
    if(isset($_REQUEST['model']) && !empty(trim($_REQUEST['model'])))
    {
        $data_request['model'] = trim($_REQUEST['model']);
    }
    $delay = '';
    if (isset($aiomatic_Main_Settings['request_delay']) && $aiomatic_Main_Settings['request_delay'] != '') 
    {
        if(stristr($aiomatic_Main_Settings['request_delay'], ',') !== false)
        {
            $tempo = explode(',', $aiomatic_Main_Settings['request_delay']);
            if(isset($tempo[1]) && is_numeric(trim($tempo[1])) && is_numeric(trim($tempo[0])))
            {
                $delay = rand(trim($tempo[0]), trim($tempo[1]));
            }
        }
        else
        {
            if(is_numeric(trim($aiomatic_Main_Settings['request_delay'])))
            {
                $delay = intval(trim($aiomatic_Main_Settings['request_delay']));
            }
        }
    }
    if($delay != '' && is_numeric($delay))
    {
        usleep($delay);
    }
    $moderation = $open_ai->moderation($data_request);
    $result = json_decode($moderation);
    if($result && isset($result->error)){
        $aiomatic_result['msg'] = $result->error->message;
        wp_send_json($aiomatic_result);
    }
    $aiomatic_result['status'] = 'success';
    $aiomatic_result['data'] = $moderation;
    wp_send_json($aiomatic_result);
}
?>