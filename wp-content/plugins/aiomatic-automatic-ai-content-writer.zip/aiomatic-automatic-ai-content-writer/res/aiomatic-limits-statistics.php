<?php
function aiomatic_get_editable_roles() {
   global $wp_roles;

   $all_roles = $wp_roles->roles;
   $editable_roles = apply_filters('editable_roles', $all_roles);
   return $editable_roles;
}
function aiomatic_save_restrictions($data) {
   check_admin_referer( 'aiomatic_save_restrictions', '_aiomaticr_nonce' );
   $data = $_POST['aiomatic_Limit_Rules'];
   $restrictions = array();
   for($i = 0; $i < sizeof($data['user_credits']); ++$i) {
         $bundle = array();
         $user_credits = trim( sanitize_text_field( $data['user_credits'][$i] ) );
         $bundle[] = $user_credits;
         $bundle[] = trim($data['user_credit_type'][$i]);
         $bundle[] = trim( sanitize_text_field( $data['user_time_frame'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['absolute'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['role'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['active'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['ums_sub'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['message'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['rule_description'][$i] ) );
      if ($user_credits == '') { continue; }
      else { $restrictions[$i] = $bundle; }
   }
   update_option('aiomatic_Limit_Rules', $restrictions);
}
if (isset($_POST['aiomatic_Limit_Rules'])) {
	add_action('admin_init', 'aiomatic_save_restrictions');
}
function aiomatic_expand_limitations() {
   $roles = aiomatic_get_editable_roles();
   $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
   $limitations = get_option('aiomatic_Limit_Rules');
   $output = '';
   if (!empty($limitations)) {
      wp_register_script('aiomatic-stats-extra-script', '');
      wp_enqueue_script('aiomatic-stats-extra-script');
      foreach ($limitations as $cont => $bundle[]) {
              $bundle_values = array_values($bundle); 
              $myValues = $bundle_values[$cont];
              
              $array_my_values = array_values($myValues);
              for($iji=0;$iji<count($array_my_values);++$iji){if(is_string($array_my_values[$iji])){$array_my_values[$iji]=stripslashes($array_my_values[$iji]);}} 
              $user_credits = $array_my_values[0];
              $user_credit_type = $array_my_values[1];
              $user_time_frame = $array_my_values[2];
              $absolute = $array_my_values[3];
              $role = $array_my_values[4];
              $active = $array_my_values[5];
              $ums_sub = $array_my_values[6];
              $message = $array_my_values[7];
              $rule_description = $array_my_values[8];
              if($rule_description == '')
              {
                 $rule_description = $cont;
              }
              wp_add_inline_script('aiomatic-stats-extra-script', 'aiomaticCreateAdmin(' . esc_html($cont) . ');', 'after');
         $output .= '
         <tr>
            <td class="cr_td_xo"><input type="text" name="aiomatic_Limit_Rules[rule_description][]" id="rule_description' . esc_html($cont) . '" class="cr_center" placeholder="Rule ID" value="' . esc_html($rule_description) . '" class="cr_width_full"/></td>
            <td class="cr_min_100"><input type="number" min="0" required step="0.01" name="aiomatic_Limit_Rules[user_credits][]" value="'.esc_attr($user_credits).'" class="cr_width_full" placeholder="Maximum Credits For Users"/></td>
            <td class="cr_min_100">
            <select name="aiomatic_Limit_Rules[user_credit_type][]" class="cr_width_full">
                <option value="queries" ';
                if($user_credit_type === 'queries')
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Queries', 'aiomatic-automatic-ai-content-writer') . '</option>';
$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
$appids = array_filter($appids);
$token = $appids[array_rand($appids)];   
if(!aiomatic_is_aiomaticapi_key($token))
{
   $output .= '<option value="units" ';
                if($user_credit_type === 'units')
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Tokens', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="price" ';
                if($user_credit_type === 'price')
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Price', 'aiomatic-automatic-ai-content-writer') . '</option>';
}
                $output .= '</select></td>
            <td class="cr_6cust"><select class="cr_max_width_80" name="aiomatic_Limit_Rules[user_time_frame][]">
            <option value="day" ';
            if($user_time_frame === 'day')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Day', 'aiomatic-automatic-ai-content-writer') . '</option>
            <option value="week" ';
            if($user_time_frame === 'week')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Week', 'aiomatic-automatic-ai-content-writer') . '</option>
            <option value="month" ';
            if($user_time_frame === 'month')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Month', 'aiomatic-automatic-ai-content-writer') . '</option>
            <option value="year" ';
            if($user_time_frame === 'year')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Year', 'aiomatic-automatic-ai-content-writer') . '</option>
            </select></td>
            <td class="cr_td_q">
            <select class="cr_max_width_80" name="aiomatic_Limit_Rules[absolute][]">
            <option value="0" ';
            if($absolute === '0')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('No', 'aiomatic-automatic-ai-content-writer') . '</option>
            <option value="1" ';
            if($absolute === '1')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Yes', 'aiomatic-automatic-ai-content-writer') . '</option>
            </select></td>
            <td class="cr_width_70">
         <center><input type="button" id="mybtnfzr' . esc_html($cont) . '" value="Settings"></center>
         <div id="mymodalfzr' . esc_html($cont) . '" class="codemodalfzr">
<div class="codemodalfzr-content">
<div class="codemodalfzr-header">
<span id="aiomatic_close' . esc_html($cont) . '" class="codeclosefzr">&times;</span>
<h2>' . esc_html__('Rule', 'aiomatic-automatic-ai-content-writer') . ' <span class="cr_color_white">ID ' . esc_html($cont) . '</span> ' . esc_html__('Advanced Settings', 'aiomatic-automatic-ai-content-writer') . '</h2>
</div>
<div class="codemodalfzr-body">
<div class="table-responsive">
<table class="responsive table cr_main_table_nowr">
<tr><td colspan="2"><h2>' . esc_html__('What to Restrict', 'aiomatic-automatic-ai-content-writer') . ':</h2></td></tr>
<tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text" >' . esc_html__('Select the user role to be restricted.', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b>' . esc_html__("User Role:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <select name="aiomatic_Limit_Rules[role][]" class="cr_width_full">
      <option value="none" ';
         if($role === 'none')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Don\'t check', 'aiomatic-automatic-ai-content-writer') . '</option>
      <option value="any" ';
         if($role === 'any')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Apply For Any Role', 'aiomatic-automatic-ai-content-writer') . '</option>';
      foreach($roles as $urole => $caps)
      {
         $output .= '<option value="' . $urole . '"';
         if($urole === $role)
         {
            $output .= ' selected="selected"';
         }
         $output .= '>' . $urole . '</option>';
      }
      $output .= '</select>
  </div>
  </td></tr>
<tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text" >' . esc_html__('Integration with \'Ultimate Membership Pro\'', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b><a href="https://1.envato.market/UltimateMember" target="_blank">' . esc_html__("Ultimate Membership Pro", 'aiomatic-automatic-ai-content-writer')  . '</a>&nbsp;' . esc_html__("Subscription Plan:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <select name="aiomatic_Limit_Rules[ums_sub][]" class="cr_width_full">
      <option value="none" ';
         if($ums_sub === 'none')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Don\'t check', 'aiomatic-automatic-ai-content-writer') . '</option>';
$levels = array();
if(class_exists('\Indeed\Ihc\Db\Memberships') && function_exists('ihc_reorder_arr'))
{
   $levels = \Indeed\Ihc\Db\Memberships::getAll();
   $levels = ihc_reorder_arr($levels);
}
if(count($levels) > 0)
{
   $output .= '<option value="any" ';
   if($ums_sub === 'any')
   {
         $output .= 'selected="selected"';
   }
   $output .= '>' . esc_html__('Apply For Any Subscription', 'aiomatic-automatic-ai-content-writer') . '</option>';
   $output .= '<option value="nosub" ';
   if($ums_sub === 'nosub')
   {
         $output .= 'selected="selected"';
   }
   $output .= '>' . esc_html__('Not Subscribed Users', 'aiomatic-automatic-ai-content-writer') . '</option>';
}
      foreach($levels as $levelid => $larr)
      {
         $output .= '<option value="' . $levelid . '"';
         if((string)$levelid === $ums_sub)
         {
            $output .= ' selected="selected"';
         }
         $output .= '>' . $larr['label']. '</option>';
      }
      $output .= '</select>
  </div>
  </td></tr>
  <tr><td colspan="2"><h2>' . esc_html__('More Settings', 'aiomatic-automatic-ai-content-writer') . ':</h2></td></tr>
  <tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text">' . esc_html__('Set the message to show to restricted users.', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b>' . esc_html__("User Restricted Message:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <input type="text" name="aiomatic_Limit_Rules[message][]" value="'.esc_attr($message).'" class="cr_width_full" placeholder="You are restricted"/>
  </div>
  </td></tr>
</table></div> 
</div>
<div class="codemodalfzr-footer">
<br/>
<h3 class="cr_inline">Aiomatic Restrictions</h3><span id="aiomatic_ok' . esc_html($cont) . '" class="codeokfzr cr_inline">OK&nbsp;</span>
<br/><br/>
</div>
</div>

</div>     
              </td>
              <td class="cr_30 cr_center" ><span class="wpaiomatic-delete">X</span></td>
                  <td class="cr_short_td">
                  <select name="aiomatic_Limit_Rules[active][]" class="cr_width_full">
      <option value="1" ';
         if($active === '1')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Yes', 'aiomatic-automatic-ai-content-writer') . '</option>
         <option value="0" ';
         if($active === '0')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('No', 'aiomatic-automatic-ai-content-writer') . '</option></select></td>
         </tr>	
         ';
              $cont = $cont + 1;
      }
   } // end if
   return $output;
}
function aiomatic_getIncidents() 
{
   $url = 'https://status.openai.com/history.rss';
   $response = wp_remote_get( $url );
   if ( is_wp_error( $response ) ) {
     throw new Exception( $response->get_error_message() );
   }
   $response = wp_remote_retrieve_body( $response );
   $xml = simplexml_load_string( $response );
   $incidents = array();
   $oneWeekAgo = time() - 7 * 24 * 60 * 60;
   foreach ( $xml->channel->item as $item ) {
     $date = strtotime( $item->pubDate );
     if ( $date > $oneWeekAgo ) {
       $incidents[] = array(
         'title' => (string) $item->title,
         'description' => (string) $item->description,
         'date' => $date
       );
     }
   }
   return $incidents;
}
function aiomatic_display_arrows($curpage)
{
   if(isset($_GET['pagesort']) && $_GET['pagesort'] == $curpage)
   {
      if (isset($_GET['pageord']) && $_GET['pageord'] == 'asc')
      {
         echo '&nbsp;↑';
      }
      else
      {
         echo '&nbsp;↓';
      }
   }
   else
   {
      if(!isset($_GET['pagesort']) && $curpage == 'time')
      {
         echo '&nbsp;↓';
      }
   }
}
function aiomatic_openai_status()
{
   $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
   $aiomatic_Limit_Settings = get_option('aiomatic_Limit_Settings', false);
   if (isset($aiomatic_Limit_Settings['user_credits'])) {
      $user_credits = $aiomatic_Limit_Settings['user_credits'];
  } else {
      $user_credits = '';
  }
  if (isset($aiomatic_Limit_Settings['user_credit_type'])) {
      $user_credit_type = $aiomatic_Limit_Settings['user_credit_type'];
  } else {
      $user_credit_type = '';
  }
  if (isset($aiomatic_Limit_Settings['user_time_frame'])) {
      $user_time_frame = $aiomatic_Limit_Settings['user_time_frame'];
  } else {
      $user_time_frame = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_time_frame'])) {
      $guest_time_frame = $aiomatic_Limit_Settings['guest_time_frame'];
  } else {
      $guest_time_frame = '';
  }
  if (isset($aiomatic_Limit_Settings['is_absolute_user'])) {
      $is_absolute_user = $aiomatic_Limit_Settings['is_absolute_user'];
  } else {
      $is_absolute_user = '';
  }
  if (isset($aiomatic_Limit_Settings['is_absolute_guest'])) {
      $is_absolute_guest = $aiomatic_Limit_Settings['is_absolute_guest'];
  } else {
      $is_absolute_guest = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_credit_type'])) {
      $guest_credit_type = $aiomatic_Limit_Settings['guest_credit_type'];
  } else {
      $guest_credit_type = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_credits'])) {
      $guest_credits = $aiomatic_Limit_Settings['guest_credits'];
  } else {
      $guest_credits = '';
  }
  if (isset($aiomatic_Limit_Settings['limit_message_logged'])) {
      $limit_message_logged = $aiomatic_Limit_Settings['limit_message_logged'];
  } else {
      $limit_message_logged = '';
  }
  if (isset($aiomatic_Limit_Settings['limit_message_not_logged'])) {
      $limit_message_not_logged = $aiomatic_Limit_Settings['limit_message_not_logged'];
  } else {
      $limit_message_not_logged = '';
  }
  if (isset($aiomatic_Limit_Settings['limit_message_rule'])) {
      $limit_message_rule = $aiomatic_Limit_Settings['limit_message_rule'];
  } else {
      $limit_message_rule = '';
  }
  if (isset($aiomatic_Limit_Settings['ignored_users'])) {
      $ignored_users = $aiomatic_Limit_Settings['ignored_users'];
  } else {
      $ignored_users = '';
  }
  if (isset($aiomatic_Limit_Settings['enable_limits'])) {
      $enable_limits = $aiomatic_Limit_Settings['enable_limits'];
  } else {
      $enable_limits = '';
  }
  $max_per_page = 100;
?>
<div class="wp-header-end"></div>
<div class="wrap gs_popuptype_holder seo_pops">
<h2 class="cr_center"><?php echo esc_html__("Limits & Statistics", 'aiomatic-automatic-ai-content-writer');?></h2>
<div class="wrap">
        <nav class="nav-tab-wrapper">
            <a href="#tab-0" class="nav-tab nav-tab-active"><?php echo esc_html__("Tutorial", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-1" class="nav-tab"><?php echo esc_html__("Usage Logs", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-5" class="nav-tab"><?php echo esc_html__("Usage Graphs", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-2" class="nav-tab"><?php echo esc_html__("Usage Limits", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-3" class="nav-tab"><?php echo esc_html__("OpenAI Status", 'aiomatic-automatic-ai-content-writer');?></a>
        </nav>
        <div id="tab-0" class="tab-content">
         <br/>
<?php echo esc_html__("The Aiomatic plugin provides a robust set of features for managing and monitoring the usage of AI services. This tutorial will guide you through the 'Limits and Statistics' feature of the Aiomatic plugin.", 'aiomatic-automatic-ai-content-writer');?>

<h2><?php echo esc_html__("Usage Logs", 'aiomatic-automatic-ai-content-writer');?></h2>
<ol><li>
<?php echo esc_html__("Navigate to the 'Limits and Statistics' section of the Aiomatic plugin.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Click on the 'Usage Logs' tab. Here, you will see a table with the following columns:", 'aiomatic-automatic-ai-content-writer');?>
<ul>
<li>
<?php echo esc_html__("User: The user who made the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("IP: The IP address from which the request was made.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Source: The source of the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Model: The AI model used for the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Mode: The mode in which the request was made.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Units: The number of units used for the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Type: The type of units listed.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Price: The cost of the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Time: The time when the request was made.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Session ID: The ID of the session in which the request was made.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("You can use this table to monitor the usage of the plugin and track any unusual activity.", 'aiomatic-automatic-ai-content-writer');?>
</li>
</ul>
</li>
</ol>
<h2><?php echo esc_html__("Usage Graphs", 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__("Click on the 'Usage Graphs' tab in the 'Limits and Statistics' section. Here, you can view graphs that represent the call count, used token count, usage cost, and generated AI image count. These graphs provide a visual representation of the plugin's usage over time, helping you understand usage trends and patterns.", 'aiomatic-automatic-ai-content-writer');?>
<h2><?php echo esc_html__("Usage Limits", 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__("Click on the 'Usage Limits' tab in the 'Limits and Statistics' section. Here, you can set usage limits for both logged in and not logged in users. You can set limits based on token usage, price usage, or call count usage. You can also create usage limiting rules. For example, you might limit the number of requests a user can make in a given time period. The Aiomatic plugin can be integrated with the 'Ultimate Membership Pro' plugin. This allows you to set different usage amounts for members who have joined different membership plans. You can also limit usage based on user role. For example, you might allow administrators to make more requests than regular users.", 'aiomatic-automatic-ai-content-writer');?>
<h2><?php echo esc_html__("OpenAI Status", 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__("Click on the 'OpenAI Status' tab in the 'Limits and Statistics' section. Here, you can see reported incidents from OpenAI's part and their API service status. This can help you troubleshoot any issues with the AI services provided by the plugin. Remember, the 'Limits and Statistics' feature is a powerful tool for managing and monitoring the usage of the Aiomatic plugin. By understanding how to use this feature, you can ensure that your AI services are being used effectively and responsibly.", 'aiomatic-automatic-ai-content-writer');?>
<h2><?php echo esc_html__("Limits and Statistics Tutorial Video", 'aiomatic-automatic-ai-content-writer');?></h2>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/skwJz6yeqIg" frameborder="0" allowfullscreen></iframe></div></p>
       </div>
        <div id="tab-1" class="tab-content">
         <br/>
         <?php
         if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
            echo '<div id="aiomatic_statistics_holder">';
            if (isset($_GET['pagenum']) && $_GET['pagenum'] != '' && is_numeric($_GET['pagenum'])) 
            {
               $shiftp = intval($_GET['pagenum']);
            }
            else
            {
               $shiftp = 1;
            }
            $shiftn = ($shiftp - 1) * $max_per_page;
            $sor_arr = array();
            if (isset($_GET['pagesort']))
            {
               if ($_GET['pagesort'] == 'id')
               {
                  $sor_arr["accessor"] = "id";
               }
               elseif ($_GET['pagesort'] == 'user')
               {
                  $sor_arr["accessor"] = "userId";
               }
               elseif ($_GET['pagesort'] == 'ip')
               {
                  $sor_arr["accessor"] = "ip";
               }
               elseif ($_GET['pagesort'] == 'source')
               {
                  $sor_arr["accessor"] = "env";
               }
               elseif ($_GET['pagesort'] == 'model')
               {
                  $sor_arr["accessor"] = "model";
               }
               elseif ($_GET['pagesort'] == 'mode')
               {
                  $sor_arr["accessor"] = "mode";
               }
               elseif ($_GET['pagesort'] == 'units')
               {
                  $sor_arr["accessor"] = "units";
               }
               elseif ($_GET['pagesort'] == 'type')
               {
                  $sor_arr["accessor"] = "type";
               }
               elseif ($_GET['pagesort'] == 'price')
               {
                  $sor_arr["accessor"] = "price";
               }
               elseif ($_GET['pagesort'] == 'time')
               {
                  $sor_arr["accessor"] = "time";
               }
               elseif ($_GET['pagesort'] == 'session')
               {
                  $sor_arr["accessor"] = "session";
               }
               if (isset($_GET['pageord']) && $_GET['pageord'] == 'asc')
               {
                  $sor_arr["by"] = "asc";
               }
               else
               {
                  $sor_arr["by"] = "desc";
               }
            }
            $statistics_res = $GLOBALS['aiomatic_stats']->logs_query( [], $shiftn, $max_per_page, null, $sor_arr );
            if($statistics_res['total'] == 0)
            {
               echo esc_html__("Empty results.", 'aiomatic-automatic-ai-content-writer');
            }
            else
            {
               echo '<div id="aiomatic-main-stat-holder" class="table-responsive">';
               echo '<button href="#" id="aiomatic_delete_logs" class="page-title-action aiomatic_delete_logs">Delete All Logs</button>';
               echo '<div class="aiomatic-paging-controller">';
               if($statistics_res['total'] > $max_per_page)
               {
                  $pages = ceil($statistics_res['total'] / $max_per_page);
                  $nextp = $shiftp + 1;
                  $prevp = $shiftp - 1;
                  if($nextp > $pages)
                  {
                     $nextp = $pages;
                  }
                  if($prevp < 1)
                  {
                     $prevp = 1;
                  }
                  $first_url = aiomatic_add_to_url('pagenum', 1);
                  $next_url = aiomatic_add_to_url('pagenum', $nextp);
                  $prev_url = aiomatic_add_to_url('pagenum', $prevp);
                  $last_url = aiomatic_add_to_url('pagenum', $pages);
                  echo '&nbsp;<span class="aiomatic-results-count">' . $statistics_res['total'] . '&nbsp;' . esc_html__("results", 'aiomatic-automatic-ai-content-writer') . '</span>&nbsp;&nbsp;';
                  echo '&nbsp;<a href="' . $first_url . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M18.41 7.41L17 6l-6 6l6 6l1.41-1.41L13.83 12l4.58-4.59m-6 0L11 6l-6 6l6 6l1.41-1.41L7.83 12l4.58-4.59Z"></path></svg></a>';
                  echo '&nbsp;<a href="' . $prev_url . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M15.41 16.58L10.83 12l4.58-4.59L14 6l-6 6l6 6l1.41-1.42Z"></path></svg></a>';
                  echo '&nbsp;<span class="aiomatic-paging">' . esc_html__("Page", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . $shiftp . '&nbsp;' . esc_html__("of", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . $pages . '</span>';
                  echo '&nbsp;<a href="' . $next_url . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M8.59 16.58L13.17 12L8.59 7.41L10 6l6 6l-6 6l-1.41-1.42Z"></path></svg></a>';
                  echo '&nbsp;<a href="' . $last_url . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M5.59 7.41L7 6l6 6l-6 6l-1.41-1.41L10.17 12L5.59 7.41m6 0L13 6l6 6l-6 6l-1.41-1.41L16.17 12l-4.58-4.59Z"></path></svg></a>';
               }
               else
               {
                  echo '&nbsp;<span class="aiomatic-results-count">' . $statistics_res['total'] . '&nbsp;' . esc_html__("results", 'aiomatic-automatic-ai-content-writer') . '</span>&nbsp;&nbsp;';
                  echo '&nbsp;<svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M18.41 7.41L17 6l-6 6l6 6l1.41-1.41L13.83 12l4.58-4.59m-6 0L11 6l-6 6l6 6l1.41-1.41L7.83 12l4.58-4.59Z"></path></svg>';
                  echo '&nbsp;<svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M15.41 16.58L10.83 12l4.58-4.59L14 6l-6 6l6 6l1.41-1.42Z"></path></svg>';
                  echo '&nbsp;<span class="aiomatic-paging">' . esc_html__("Page", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . '1' . '&nbsp;' . esc_html__("of", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . '1' . '</span>';
                  echo '&nbsp;<svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M8.59 16.58L13.17 12L8.59 7.41L10 6l6 6l-6 6l-1.41-1.42Z"></path></svg>';
                  echo '&nbsp;<svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M5.59 7.41L7 6l6 6l-6 6l-1.41-1.41L10.17 12L5.59 7.41m6 0L13 6l6 6l-6 6l-1.41-1.41L16.17 12l-4.58-4.59Z"></path></svg>';
               }
               echo '</div>';
               echo '<table id="stat_table" class="widefat responsive table cr_main_table">';
               $id_sort = aiomatic_add_to_url('pagesort', 'id');
               $user_sort = aiomatic_add_to_url('pagesort', 'user');
               $ip_sort = aiomatic_add_to_url('pagesort', 'ip');
               $source_sort = aiomatic_add_to_url('pagesort', 'source');
               $model_sort = aiomatic_add_to_url('pagesort', 'model');
               $mode_sort = aiomatic_add_to_url('pagesort', 'mode');
               $units_sort = aiomatic_add_to_url('pagesort', 'units');
               $type_sort = aiomatic_add_to_url('pagesort', 'type');
               $price_sort = aiomatic_add_to_url('pagesort', 'price');
               $time_sort = aiomatic_add_to_url('pagesort', 'time');
               $session_sort = aiomatic_add_to_url('pagesort', 'session');
               if (isset($_GET['pageord']) && $_GET['pageord'] != '')
               {
                  if($_GET['pageord'] == 'asc')
                  {
                     $id_sort = aiomatic_add_to_url('pageord', 'desc', $id_sort);
                     $user_sort = aiomatic_add_to_url('pageord', 'desc', $user_sort);
                     $ip_sort = aiomatic_add_to_url('pageord', 'desc', $ip_sort);
                     $source_sort = aiomatic_add_to_url('pageord', 'desc', $source_sort);
                     $model_sort = aiomatic_add_to_url('pageord', 'desc', $model_sort);
                     $mode_sort = aiomatic_add_to_url('pageord', 'desc', $mode_sort);
                     $units_sort = aiomatic_add_to_url('pageord', 'desc', $units_sort);
                     $type_sort = aiomatic_add_to_url('pageord', 'desc', $type_sort);
                     $price_sort = aiomatic_add_to_url('pageord', 'desc', $price_sort);
                     $time_sort = aiomatic_add_to_url('pageord', 'desc', $time_sort);
                     $session_sort = aiomatic_add_to_url('pageord', 'desc', $session_sort);
                  }
                  elseif($_GET['pageord'] == 'desc')
                  {
                     $id_sort = aiomatic_add_to_url('pageord', 'asc', $id_sort);
                     $user_sort = aiomatic_add_to_url('pageord', 'asc', $user_sort);
                     $ip_sort = aiomatic_add_to_url('pageord', 'asc', $ip_sort);
                     $source_sort = aiomatic_add_to_url('pageord', 'asc', $source_sort);
                     $model_sort = aiomatic_add_to_url('pageord', 'asc', $model_sort);
                     $mode_sort = aiomatic_add_to_url('pageord', 'asc', $mode_sort);
                     $units_sort = aiomatic_add_to_url('pageord', 'asc', $units_sort);
                     $type_sort = aiomatic_add_to_url('pageord', 'asc', $type_sort);
                     $price_sort = aiomatic_add_to_url('pageord', 'asc', $price_sort);
                     $time_sort = aiomatic_add_to_url('pageord', 'asc', $time_sort);
                     $session_sort = aiomatic_add_to_url('pageord', 'asc', $session_sort);
                  }
               }
               else
               {
                  $id_sort = aiomatic_add_to_url('pageord', 'asc', $id_sort);
                  $user_sort = aiomatic_add_to_url('pageord', 'asc', $user_sort);
                  $ip_sort = aiomatic_add_to_url('pageord', 'asc', $ip_sort);
                  $source_sort = aiomatic_add_to_url('pageord', 'asc', $source_sort);
                  $model_sort = aiomatic_add_to_url('pageord', 'asc', $model_sort);
                  $mode_sort = aiomatic_add_to_url('pageord', 'asc', $mode_sort);
                  $units_sort = aiomatic_add_to_url('pageord', 'asc', $units_sort);
                  $type_sort = aiomatic_add_to_url('pageord', 'asc', $type_sort);
                  $price_sort = aiomatic_add_to_url('pageord', 'asc', $price_sort);
                  $time_sort = aiomatic_add_to_url('pageord', 'asc', $time_sort);
                  $session_sort = aiomatic_add_to_url('pageord', 'asc', $session_sort);
               }
               echo '<tr><th><a class="aiomatic_normal" href="' . $id_sort . '">' . esc_html__("ID", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('id');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $user_sort . '">' . esc_html__("User", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('user');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $ip_sort . '">' . esc_html__("IP", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('ip');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $source_sort . '">' . esc_html__("Source", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('source');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $model_sort . '">' . esc_html__("Model", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('model');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $mode_sort . '">' . esc_html__("Mode", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('mode');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $units_sort . '">' . esc_html__("Units", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('units');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $type_sort . '">' . esc_html__("Type", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('type');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $price_sort . '">' . esc_html__("Price", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('price');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $time_sort . '">' . esc_html__("Time", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('time');
               echo '</a></th><th><a class="aiomatic_normal" href="' . $session_sort . '">' . esc_html__("Session ID", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('session');
               echo '</a></th></tr>';
               $myusers = array();
               foreach($statistics_res['rows'] as $stat_row)
               {
                  if(!isset($myusers[$stat_row['userId']]))
                  {
                     $thisuser = get_user_by( 'id', $stat_row['userId'] );
                     if($thisuser !== false)
                     {
                        $myusers[$stat_row['userId']] = $thisuser->user_login;
                     }
                  }
                  echo '<tr>';
                  echo '<td>' . $stat_row['id'] . '</td>';
                  if(isset($myusers[$stat_row['userId']]))
                  {
                     echo '<td>' . $myusers[$stat_row['userId']] . '</td>';
                  }
                  else
                  {
                     echo '<td>ID: ' . $stat_row['userId'] . '</td>';
                  }
                  echo '<td>' . $stat_row['ip'] . '</td>';
                  echo '<td>' . $stat_row['env'] . '</td>';
                  echo '<td>' . $stat_row['model'] . '</td>';
                  echo '<td>' . $stat_row['mode'] . '</td>';
                  echo '<td>' . $stat_row['units'] . '</td>';
                  echo '<td>' . $stat_row['type'] . '</td>';
                  if(aiomatic_is_aiomaticapi_key($stat_row['apiRef']))
                  {
                     echo '<td>N/A</td>';
                  }
                  else
                  {
                     echo '<td>' . $stat_row['price'] . '$</td>';
                  }
                  echo '<td>' . $stat_row['time'] . '</td>';
                  echo '<td>' . $stat_row['session'] . '</td>';
                  echo '</tr>';
               }
               echo '</table>';
               echo '</div>';
            }
            echo '</div>';
         }
         else
         {
             echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Main Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
         }
         ?>
        </div>
        <div id="tab-2" class="tab-content">
        <br/>
        <?php
         if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
         ?>
        <form id="myForm" method="post" action="<?php if(is_multisite() && is_network_admin()){echo '../options.php';}else{echo 'options.php';}?>">
        <?php
        settings_fields('aiomatic_option_group3');
        do_settings_sections('aiomatic_option_group3');
        ?>
   <div class="cr_autocomplete">
      <input type="password" id="PreventChromeAutocomplete" 
         name="PreventChromeAutocomplete" autocomplete="address-level4" />
   </div>
        <table class="widefat">
        <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to enable global usage limits?", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Enable Global Usage Limits:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="enable_limits" onclick="limitsChanged();" name="aiomatic_Limit_Settings[enable_limits]" <?php
                        if ($enable_limits == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
        <tr class="hideLimits"><td colspan="2"><h3><?php echo esc_html__("Restrictions For Logged In Users:", 'aiomatic-automatic-ai-content-writer');?></h3></td></tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the maximum number of credits for logged in users. Also, you can select the type of credits: queries, tokens or price. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Max User Credits:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="number" id="user_credits" step="0.01" min="0" placeholder="<?php echo esc_html__("Maximum Credits For Users", 'aiomatic-automatic-ai-content-writer');?>" name="aiomatic_Limit_Settings[user_credits]" value="<?php
                     echo esc_html($user_credits);
                     ?>"/>
                     <select id="user_credit_type" name="aiomatic_Limit_Settings[user_credit_type]" >
                     <option value="queries"<?php
                        if ($user_credit_type == "queries") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Queries", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
                     $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
                     $appids = array_filter($appids);
                     $token = $appids[array_rand($appids)];   
                     if(!aiomatic_is_aiomaticapi_key($token))
                     {
?>
                     <option value="units"<?php
                        if ($user_credit_type == "units") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Tokens", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="price"<?php
                        if ($user_credit_type == "price") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Price", 'aiomatic-automatic-ai-content-writer');?></option>
                        <?php
                     }
                     ?>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the time frame for which to apply the above limitation.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Time Frame:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <select id="user_time_frame" name="aiomatic_Limit_Settings[user_time_frame]" >
                     <option value="day"<?php
                        if ($user_time_frame == "day") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Day", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="week"<?php
                        if ($user_time_frame == "week") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Week", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="month"<?php
                        if ($user_time_frame == "month") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Month", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="year"<?php
                           if ($user_time_frame == "year") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Year", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("With absolute, a day represents today. Otherwise, it represent the past 24 hours from now. The same logic applies to the other time frames.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Absolute Timeframe:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="checkbox" id="is_absolute_user" name="aiomatic_Limit_Settings[is_absolute_user]"<?php
                  if ($is_absolute_user == 'on')
                        echo ' checked ';
                  ?>>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the users who will have full access when interacting with the features of the plugin.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Full Access Users:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <select id="ignored_users" name="aiomatic_Limit_Settings[ignored_users]" >
                     <option value="admin"<?php
                        if ($ignored_users == "admin") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Admins Only", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="editor"<?php
                        if ($ignored_users == "editor") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Editors & Admins", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="none"<?php
                        if ($ignored_users == "none") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("None", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Set the message to be displayed to logged in users when usage limit is reached.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Message When Limit Reached (Logged In Users):", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <textarea rows="1" cols="70" name="aiomatic_Limit_Settings[limit_message_logged]" placeholder="<?php echo esc_html__("Usage limit message", 'aiomatic-automatic-ai-content-writer');?>"><?php
               echo esc_textarea($limit_message_logged);
               ?></textarea>
               </div>
            </td>
         </tr>
         <tr class="hideLimits"><td colspan="2"><h3><?php echo esc_html__("Restrictions For Not Logged In Users:", 'aiomatic-automatic-ai-content-writer');?></h3></td></tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the maximum number of credits for guests who are not logged in. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Max Guest Credits:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="number" id="guest_credits" step="0.01" min="0" placeholder="<?php echo esc_html__("Maximum Credits For Guests", 'aiomatic-automatic-ai-content-writer');?>" name="aiomatic_Limit_Settings[guest_credits]" value="<?php
                     echo esc_html($guest_credits);
                     ?>"/>
                     <select id="guest_credit_type" name="aiomatic_Limit_Settings[guest_credit_type]" >
                     <option value="queries"<?php
                        if ($guest_credit_type == "queries") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Queries", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
                        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
                     $appids = array_filter($appids);
                     $token = $appids[array_rand($appids)];   
                     if(!aiomatic_is_aiomaticapi_key($token))
                     {
?>
                     <option value="units"<?php
                        if ($guest_credit_type == "units") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Tokens", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="price"<?php
                        if ($guest_credit_type == "price") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Price", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
}
?>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the time frame for which to apply the above limitation.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Time Frame:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <select id="guest_time_frame" name="aiomatic_Limit_Settings[guest_time_frame]" >
                     <option value="day"<?php
                        if ($guest_time_frame == "day") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Day", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="week"<?php
                        if ($guest_time_frame == "week") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Week", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="month"<?php
                        if ($guest_time_frame == "month") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Month", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="year"<?php
                           if ($guest_time_frame == "year") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Year", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("With absolute, a day represents today. Otherwise, it represent the past 24 hours from now. The same logic applies to the other time frames.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Absolute Timeframe:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="checkbox" id="is_absolute_guest" name="aiomatic_Limit_Settings[is_absolute_guest]"<?php
                  if ($is_absolute_guest == 'on')
                        echo ' checked ';
                  ?>>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Set the message to be displayed to not logged in users when usage limit is reached.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Message When Limit Reached (Not Logged In Users):", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <textarea rows="1" cols="70" name="aiomatic_Limit_Settings[limit_message_not_logged]" placeholder="<?php echo esc_html__("Usage limit message", 'aiomatic-automatic-ai-content-writer');?>"><?php
               echo esc_textarea($limit_message_not_logged);
               ?></textarea>
               </div>
            </td>
         </tr>
         <tr>
            <td colspan="2"><hr/></td>
         </tr>
         <tr>
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Set the message to be displayed to logged in users when usage limit is reached for the 'Rule Based Restrictions'.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Message When Limit Reached (Rule Based Restrictions - Global):", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <textarea rows="1" cols="70" name="aiomatic_Limit_Settings[limit_message_rule]" placeholder="<?php echo esc_html__("Usage limit message", 'aiomatic-automatic-ai-content-writer');?>"><?php
               echo esc_textarea($limit_message_rule);
               ?></textarea>
               </div>
            </td>
         </tr>
         <tr><td colspan="2"><hr/></td></tr>
         </table>
         <h3><?php echo esc_html__("Rule Based Restrictions:", 'aiomatic-automatic-ai-content-writer');?></h3>
         <?php
         wp_nonce_field( 'aiomatic_save_restrictions', '_aiomaticr_nonce' );
         ?>
         <table class="responsive table cr_main_table">
            <thead>
               <tr>
                  <th>
                     <?php echo esc_html__("ID", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("This is the ID of the rule. ", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th>
                     <?php echo esc_html__("Max User Credits", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select the maximum number of credits for logged in users. Also, you can select the type of credits: queries, tokens or price. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th>
                     <?php echo esc_html__("Credit Type", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select the type of credits.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th>
                     <?php echo esc_html__("Time Frame", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select the time frame for which to apply the above limitation.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_30">
                     Absolute
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select if you want to apply an absolute timeframe. With absolute, a day represents today. Otherwise, it represent the past 24 hours from now. The same logic applies to the other time frames.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_80">
                     <?php echo esc_html__("Options", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Shows advanced settings for this rule.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_30">
                     <?php echo esc_html__("Del", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Do you want to delete this rule?", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_32" >
                     <?php echo esc_html__("Active", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Do you want to enable this plugin? You can deactivate any rule (you don't have to delete them to deactivate them).", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
               </tr>
            </thead>
            <tbody>
               <?php echo aiomatic_expand_limitations(); ?>
               <tr>
                  <td class="cr_td_xo"><input type="text" name="aiomatic_Limit_Rules[rule_description][]" id="rule_description" class="cr_center" placeholder="Rule ID" value="" class="cr_width_full"/></td>
                  <td class="cr_custx"><input type="number" min="0" step="0.01" placeholder="Max user credits" name="aiomatic_Limit_Rules[user_credits][]" value="" class="cr_width_full" /></td>
                  <td class="cr_custx">
                     <select id="user_credit_type" name="aiomatic_Limit_Rules[user_credit_type][]" >
                     <option value="queries"<?php
                        if ($user_credit_type == "queries") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Queries", 'aiomatic-automatic-ai-content-writer');?></option>
                        <?php
                     $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
                     $appids = array_filter($appids);
                     $token = $appids[array_rand($appids)];   
                     if(!aiomatic_is_aiomaticapi_key($token))
                     {
                     ?>
                     <option value="units"<?php
                        if ($user_credit_type == "units") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Tokens", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="price"<?php
                        if ($user_credit_type == "price") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Price", 'aiomatic-automatic-ai-content-writer');?></option>
                        <?php
                     }
                     ?>
                  </select></td>
                  <td class="cr_6cust">
                     <select class="cr_max_width_80" name="aiomatic_Limit_Rules[user_time_frame][]">
                        <option value="day" selected><?php echo esc_html__("Day", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="week"><?php echo esc_html__("Week", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="month"><?php echo esc_html__("Month", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="year"><?php echo esc_html__("Year", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select>
                  </td>
                  <td class="cr_td_q">
                     <select class="cr_max_width_80" name="aiomatic_Limit_Rules[absolute][]">
                        <option value="0" selected><?php echo esc_html__("No", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="1"><?php echo esc_html__("Yes", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select></td>
                  <td class="cr_width_70">
                     <center><input type="button" id="mybtnfzr" value="Settings"></center>
                     <div id="mymodalfzr" class="codemodalfzr">
                        <div class="codemodalfzr-content">
                           <div class="codemodalfzr-header">
                              <span id="aiomatic_close" class="codeclosefzr">&times;</span>
                              <h2><span class="cr_color_white"><?php echo esc_html__("New Rule", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
                           </div>
                           <div class="codemodalfzr-body">
                              <div class="table-responsive">
                                 <table class="responsive table cr_main_table_nowr">
                                    <tr>
                                    <td colspan="2">
                                    <h2><?php echo esc_html__("What to Restrict:", 'aiomatic-automatic-ai-content-writer');?></h2>
                                    </td>
                                    </tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                          <div>
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Select the user role to be restricted.", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><?php echo esc_html__("User Role:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td>
                                       <select name="aiomatic_Limit_Rules[role][]" class="cr_width_full">
                                       <option value="none" selected><?php echo esc_html__("Don't check", 'aiomatic-automatic-ai-content-writer');?></option>
                                       <option value="any"><?php echo esc_html__("Apply For Any Role", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
$roles = aiomatic_get_editable_roles();
foreach($roles as $urole => $caps)
{
?>
   <option value="<?php echo $urole;?>"><?php echo $urole;?></option>
<?php
}
?>
                                       </select>
                                       </div>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                          <div>
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Integration with 'Ultimate Membership Pro'", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><a href="https://1.envato.market/UltimateMember" target="_blank"><?php echo esc_html__("Ultimate Membership Pro", 'aiomatic-automatic-ai-content-writer');?></a>&nbsp;<?php echo esc_html__("Subscription Plan:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td>
                                       <select name="aiomatic_Limit_Rules[ums_sub][]" class="cr_width_full">
                                       <option value="none" selected><?php echo esc_html__("Don't check", 'aiomatic-automatic-ai-content-writer');?></option>
                                       
<?php
$levels = array();
if(class_exists('\Indeed\Ihc\Db\Memberships') && function_exists('ihc_reorder_arr'))
{
   $levels = \Indeed\Ihc\Db\Memberships::getAll();
   $levels = ihc_reorder_arr($levels);
}
if(count($levels) > 0)
{
?>
<option value="nosub"><?php echo esc_html__("Not Subscribed Users", 'aiomatic-automatic-ai-content-writer');?></option>
<option value="any"><?php echo esc_html__("Apply For Any Subscription", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
}
foreach($levels as $levelid => $larr)
{
?>
   <option value="<?php echo $levelid;?>"><?php echo esc_html($larr['label']);?></option>
<?php
}
?>
                                       </select>
                                       </div>
                                       </td>
                                    </tr>
                                    <tr><td colspan="2">
                                    <h2><?php echo esc_html__("More Settings:", 'aiomatic-automatic-ai-content-writer');?></h2>
                                    </td></tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                          <div>
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Set the message to show to restricted users.", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><?php echo esc_html__("User Restricted Message:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td><input type="text" placeholder="You are restricted" name="aiomatic_Limit_Rules[message][]" value="" class="cr_width_full" />
                                       </div>
                                       </td>
                                    </tr>
                                 </table>
                              </div>
                           </div>
                           <div class="codemodalfzr-footer">
                              <br/>
                              <h3 class="cr_inline">Aiomatic Restriction Rules</h3>
                              <span id="aiomatic_ok" class="codeokfzr cr_inline">OK&nbsp;</span>
                              <br/><br/>
                           </div>
                        </div>
                     </div>
                  </td>
                  <td class="cr_30 cr_center" ><span class="cr_30">X</span></td>
                  <td class="cr_short_td">
                  <select name="aiomatic_Limit_Rules[active][]" class="cr_width_full">
                     <option value="1" selected><?php echo esc_html__("Yes", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="0"><?php echo esc_html__("No", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select></td>
               </tr>
            </tbody>
         </table>
         <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="<?php echo esc_html__("Save Settings", 'aiomatic-automatic-ai-content-writer');?>"/></p></div>
         </form>
         <?php
            echo esc_html__("API usage for this user account: ", 'aiomatic-automatic-ai-content-writer') . do_shortcode('[aiomatic-user-remaining-credits-bar]');
         }
         else
         {
             echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Main Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
         }
            ?>
        </div>
        <div id="tab-3" class="tab-content">
        <br/>
        <p class="cr_center"><?php echo esc_html__("Only the incidents which occured less than a week ago are displayed here.", 'aiomatic-automatic-ai-content-writer');?></p><hr/>
<?php 
try {
   $incidents = get_transient( 'aiomatic_openai_incidents' );
   if ( $incidents === false ) {
      $incidents = aiomatic_getIncidents();
      set_transient( 'aiomatic_openai_incidents', $incidents, 60 * 10 );
   }
   $echo_me = '';
   foreach($incidents as $incident)
   {
      $echo_me .= '<div><h3><img draggable="false" role="img" class="emoji" alt="⚠️" src="https://s.w.org/images/core/emoji/14.0.0/svg/26a0.svg">';
      $echo_me .= ' ' . $incident['date'] . ': ' . $incident['title'] . '</h3><div class="description">' . $incident['description'] . '</div></div><hr class="cr-dashed"/>';
   }
   echo $echo_me;
   if($echo_me != '')
   {
       echo '<hr/>';
   }
}
catch ( Exception $e ) {
   echo 'Error while processing OpenAI status: ' . $e->getMessage();
}
?>
        </div>
        <div id="tab-5" class="tab-content">
         <br/>
         <?php
         if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
?>
         <div id="aiomatic_chart_holder">
<?php
echo '<span class="pagination-links">';
$current_page = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$older = 0;
if(isset($_GET['older']) && $_GET['older'] != '')
{
   $older = intval($_GET['older']);
   if($older < 0)
   {
      $older = 0;
   }
}
echo '&nbsp;<a href="' . add_query_arg( array( 'older' => $older + 12 ), $current_page ) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M18.41 7.41L17 6l-6 6l6 6l1.41-1.41L13.83 12l4.58-4.59m-6 0L11 6l-6 6l6 6l1.41-1.41L7.83 12l4.58-4.59Z"></path></svg></a>';
echo '&nbsp;<a href="' . add_query_arg( array( 'older' => $older + 1 ), $current_page ) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M15.41 16.58L10.83 12l4.58-4.59L14 6l-6 6l6 6l1.41-1.42Z"></path></svg></a>';
echo '&nbsp;<span class="aiomatic-paging">' . esc_html__("Page", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . ($older + 1) . '&nbsp;</span>';
if($older > 0)
{
   echo '&nbsp;<a href="' . add_query_arg( array( 'older' => $older - 1 ), $current_page ) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M8.59 16.58L13.17 12L8.59 7.41L10 6l6 6l-6 6l-1.41-1.42Z"></path></svg></a>';
   echo '&nbsp;<a href="' . add_query_arg( array( 'older' => 0 ), $current_page ) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M5.59 7.41L7 6l6 6l-6 6l-1.41-1.41L10.17 12L5.59 7.41m6 0L13 6l6 6l-6 6l-1.41-1.41L16.17 12l-4.58-4.59Z"></path></svg></a>';
}
echo '</span>';
   if(isset($_GET['older']) && $_GET['older'] != '' && $_GET['older'] != '0')
   {
      $older = intval($_GET['older']);
      if($older < 0)
      {
         $older = 0;
      }
      $day0time = strtotime(($older * 30) . ' days ago', time());
   }
   else
   {
      $day0time = time();
   }
   $how_many_more_days = 30;
   $results = array();
   $priceresults = array();
   $tokenresults = array();
   $imageresults = array();
   for($j = 0; $j < $how_many_more_days; $j++)
   {
      $total_usd = 0;
      $total_tokens = 0;
      $total_images = 0;
      $strx = "-" . $j . " day";
      if($j > 1)
      {
         $strx .= 's';
      }
      $my_day = date('M d Y', strtotime($strx, $day0time));
      $my_daystart = date('Y-m-d H:i:s', strtotime($my_day . ' 00:00'));
      $my_dayend = date('Y-m-d H:i:s', strtotime($my_day . ' 23:59'));
      $filters['from'] = $my_daystart;
      $filters['to'] = $my_dayend;
      $myday_res = $GLOBALS['aiomatic_stats']->logs_query( [], 0, 100, $filters, null );
      foreach($myday_res['rows'] as $resz)
      {
         $total_usd += $resz['price'];
         if($resz['type'] == 'token' || $resz['type'] == 'tokens')
         {
            $total_tokens += $resz['units'];
         }
         elseif($resz['type'] == 'image' || $resz['type'] == 'images')
         {
            $total_images += $resz['units'];
         }
      }
      $results[$my_day] = $myday_res['total'];
      $priceresults[$my_day] = $total_usd;
      $tokenresults[$my_day] = $total_tokens;
      $imageresults[$my_day] = $total_images;
   }
   $results = array_reverse($results);
   $priceresults = array_reverse($priceresults);
   $tokenresults = array_reverse($tokenresults);
   $imageresults = array_reverse($imageresults);
   $results_html = implode(',' , $results);
   $price_html = implode(',' , $priceresults);
   $token_html = implode(',' , $tokenresults);
   $image_html = implode(',' , $imageresults);
   $days_html = implode(', ',array_keys($results));
   $days_html = str_replace(', ', ',', $days_html);
   $results_html = str_replace(', ', ',', $results_html);
   $our_short = '[aiomatic_charts title="Chart' . uniqid() . '" datalabels="' . esc_html__('API Call Count', 'aiomatic-automatic-ai-content-writer') . ',' . esc_html__('API Call Cost (USD)', 'aiomatic-automatic-ai-content-writer') . ',' . esc_html__('API Token Count', 'aiomatic-automatic-ai-content-writer') . ',' . esc_html__('AI Image Count', 'aiomatic-automatic-ai-content-writer') . '" labels="' . $days_html . '" type="Line" align="aligncenter" margin="5px 20px" datasets="' . $results_html . 'next' . $price_html . 'next' . $token_html . 'next' . $image_html . '" canvasheight="200" width="100%" height="400" relativewidth="1" classn="" colors="#D040D2,#A0A48C,#69D2E1,#40D240" fillopacity="0.7" animation="true" scalefontsize="12" scalefontcolor="#666" scaleoverride="false" scalesteps="null" scalestepwidth="null" scalestartvalue="null"]';
   $returnhtml = do_shortcode($our_short);
   echo $returnhtml;
?>
         </div>
<?php
}
else
{
    echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Main Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
}
?>
      </div>
</div>
<?php
}
?>