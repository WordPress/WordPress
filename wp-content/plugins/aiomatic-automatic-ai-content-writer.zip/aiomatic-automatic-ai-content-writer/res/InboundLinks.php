<?php
use DonatelloZa\RakePlus\RakePlus;
class AiomaticAutoInboundLinks 
{
    public function __construct() 
    {
        require_once (dirname(__FILE__) . "/rake-php-plus/src/AbstractStopwordProvider.php"); 
        require_once (dirname(__FILE__) . "/rake-php-plus/src/ILangParseOptions.php"); 
        require_once (dirname(__FILE__) . "/rake-php-plus/src/LangParseOptions.php"); 
        require_once (dirname(__FILE__) . "/rake-php-plus/src/StopwordArray.php"); 
        require_once (dirname(__FILE__) . "/rake-php-plus/src/StopwordsPatternFile.php"); 
        require_once (dirname(__FILE__) . "/rake-php-plus/src/StopwordsPHP.php"); 
        require_once (dirname(__FILE__) . "/rake-php-plus/src/RakePlus.php");
    }
    public function add_inbound_links($content, $max, $link_post_types, $lang, $rel_search, $current_post_id = null) 
    {
        $keywords = $this->find_keywords($content, $lang);
        $content = $this->insert_links($content, $keywords, $max, $link_post_types, $rel_search, $current_post_id);
        return $content;
    }

    private function find_keywords($content, $lang = 'en_US') 
    {
        $plain_text_content = strip_tags($content);
        if(empty($plain_text_content))
        {
            return array();
        }
        $rake = RakePlus::create($plain_text_content, $lang);
        $keywords = $rake->sortByScore('desc')->scores();
        return $keywords;
    }


    private function insert_links($content, $keywords, $max, $link_post_types, $rel_search, $post_id = null) 
    {
        $added = 0;
        $doneids = array();
        if($post_id != null)
        {
            $doneids[] = $post_id;
        }
        foreach ($keywords as $keyword => $score) 
        {
            if($added >= $max)
            {
                break;
            }
            if(strstr($content, $keyword) !== false && strlen($keyword) > 2)
            {
                $linked_posts = $this->get_linked_posts($keyword, $link_post_types, $rel_search, $doneids);
                if (!empty($linked_posts)) 
                {
                    $replacement = sprintf(
                        '<a href="%s" title="%s">%s</a>',
                        esc_url($linked_posts[0]->guid),
                        esc_attr($linked_posts[0]->post_title),
                        $keyword
                    );
                    $content = preg_replace('/\b' . preg_quote($keyword, '/') . '\b/', $replacement, $content, 1);
                    $doneids[] = $linked_posts[0]->ID;
                    $added++;
                }
            }
        }

        return $content;
    }

    private function get_linked_posts($keyword, $link_post_types, $rel_search, $post_id) 
    {
        global $wpdb;
        $idquery = "AND ID != %d";
        if($post_id === null)
        {
            $post_id = 0;
        }
        else if(is_array($post_id) && empty($post_id))
        {
            $post_id = 0;
        }
        else if(is_array($post_id))
        {
            $post_id = implode(',', $post_id);
            $idquery = "AND ID NOT IN (%1s)";
        }
        if(empty($link_post_types))
        {
            $link_post_types = 'post';
        }
        $posttypevar = '';
        if($link_post_types !== 'post')
        {
            $pts = explode(',', $link_post_types);
            foreach($pts as $pt)
            {
                if($posttypevar != '')
                {
                    $posttypevar .= " AND ";
                }
                $posttypevar .= "WHERE post_type = '" . trim($pt) . "'";
            }
            $posttypevar = '(' . $posttypevar . ')';
        }
        else
        {
            $posttypevar = "WHERE post_type = 'post'";
        }
        $argsvar = array($post_id);
        if(is_array($rel_search) && !empty($rel_search))
        {
            if(count($rel_search) == 1)
            {
                $refvar = array_reverse($rel_search);
                $what = array_pop($refvar);
                $like_expr = $what . ' LIKE %s';
                $argsvar[] = '%' . $wpdb->esc_like($keyword) . '%';
            }
            else
            {
                $like_expr = '(';
                $indx = 0;
                foreach($rel_search as $rsx)
                {
                    if($indx === 0)
                    {
                        $like_expr .= $rsx . ' LIKE %s';
                    }
                    else
                    {
                        $like_expr .= ' OR ' . $rsx . ' LIKE %s';
                    }
                    $indx++;
                    $argsvar[] = '%' . $wpdb->esc_like($keyword) . '%';
                }
                $like_expr .= ')';
            }
        }
        else
        {
            $like_expr = '(post_title LIKE %s OR post_content LIKE %s)';
            $argsvar[] = '%' . $wpdb->esc_like($keyword) . '%';
            $argsvar[] = '%' . $wpdb->esc_like($keyword) . '%';
        }
        $mysqls = "SELECT * FROM {$wpdb->posts}
        " . $posttypevar . "
        AND post_status = 'publish'
        " . $idquery . "
        AND " . $like_expr . "
        LIMIT 1";
        $sql = $wpdb->prepare(
            $mysqls,
            $argsvar
        );
        $linked_posts = $wpdb->get_results($sql);
        if(is_array($linked_posts))
        {
            foreach($linked_posts as $mindex => $mpost)
            {
                $myperma = get_permalink($mpost->ID);
                if($myperma !== false)
                {
                    $linked_posts[$mindex]->guid = $myperma;
                }
            }
        }
        return $linked_posts;
    }
}