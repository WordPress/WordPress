<?php
function aiomatic_chatbot_panel()
{
   $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
   if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
   {
      ?>
<h1><?php echo esc_html__("You must add an OpenAI/AiomaticAPI API Key into the plugin's 'Main Settings' menu before you can use this feature!", 'aiomatic-automatic-ai-content-writer');?></h1>
<?php
return;
   }
   $all_models = aiomatic_get_all_models(true);
?>
<div class="wp-header-end"></div>
<div class="wrap gs_popuptype_holder seo_pops">
    <div class="wrap">
    <nav class="nav-tab-wrapper">
        <a href="#tab-t" class="nav-tab nav-tab-active"><?php echo esc_html__("Tutorial", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-0" class="nav-tab"><?php echo esc_html__("Chatbot Context", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-1" class="nav-tab"><?php echo esc_html__("Chatbot Default Styling", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-2" class="nav-tab"><?php echo esc_html__("Chatbot Moderation", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-5" class="nav-tab"><?php echo esc_html__("Chatbot Website Injection", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-3" class="nav-tab"><?php echo esc_html__("Chatbot Settings", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-4" class="nav-tab"><?php echo esc_html__("Default API Parameters", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-8" class="nav-tab"><?php echo esc_html__("Chatbot Text-to-Speech", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-7" class="nav-tab"><?php echo esc_html__("Custom Chatbot Builder", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-6" class="nav-tab"><?php echo esc_html__("Persistent Chat Logs", 'aiomatic-automatic-ai-content-writer');?></a>
    </nav>
        <form id="myForm" method="post" action="<?php if(is_multisite() && is_network_admin()){echo '../options.php';}else{echo 'options.php';}?>">
        <div class="cr_autocomplete">
 <input type="password" id="PreventChromeAutocomplete" 
  name="PreventChromeAutocomplete" autocomplete="address-level4" />
</div>
<?php
    settings_fields('aiomatic_option_group4');
    do_settings_sections('aiomatic_option_group4');
    $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
    if (isset($aiomatic_Chatbot_Settings['font_size'])) {
        $font_size = $aiomatic_Chatbot_Settings['font_size'];
    } else {
        $font_size = '';
    }
    if (isset($aiomatic_Chatbot_Settings['voice_language'])) {
        $voice_language = $aiomatic_Chatbot_Settings['voice_language'];
    } else {
        $voice_language = 'en-US';
    }
    if (isset($aiomatic_Chatbot_Settings['google_voice'])) {
        $google_voice = $aiomatic_Chatbot_Settings['google_voice'];
    } else {
        $google_voice = 'en-US';
    }
    if (isset($aiomatic_Chatbot_Settings['voice_pitch'])) {
        $voice_pitch = $aiomatic_Chatbot_Settings['voice_pitch'];
    } else {
        $voice_pitch = '0';
    }
    if (isset($aiomatic_Chatbot_Settings['voice_speed'])) {
        $voice_speed = $aiomatic_Chatbot_Settings['voice_speed'];
    } else {
        $voice_speed = '1';
    }
    if (isset($aiomatic_Chatbot_Settings['audio_profile'])) {
        $audio_profile = $aiomatic_Chatbot_Settings['audio_profile'];
    } else {
        $audio_profile = 'en-US';
    }
    if (isset($aiomatic_Chatbot_Settings['chatbot_text_speech'])) {
        $chatbot_text_speech = $aiomatic_Chatbot_Settings['chatbot_text_speech'];
    } else {
        $chatbot_text_speech = '';
    }
    if (isset($aiomatic_Chatbot_Settings['eleven_voice'])) {
        $eleven_voice = $aiomatic_Chatbot_Settings['eleven_voice'];
    } else {
        $eleven_voice = '';
    }
    if (isset($aiomatic_Chatbot_Settings['width'])) {
        $width = $aiomatic_Chatbot_Settings['width'];
    } else {
        $width = '';
    }
    if (isset($aiomatic_Chatbot_Settings['height'])) {
        $height = $aiomatic_Chatbot_Settings['height'];
    } else {
        $height = '';
    }
    if (isset($aiomatic_Chatbot_Settings['minheight'])) {
        $minheight = $aiomatic_Chatbot_Settings['minheight'];
    } else {
        $minheight = '';
    }
    if (isset($aiomatic_Chatbot_Settings['placeholder'])) {
        $placeholder = $aiomatic_Chatbot_Settings['placeholder'];
    } else {
        $placeholder = '';
    }
    if (isset($aiomatic_Chatbot_Settings['submit'])) {
        $submit = $aiomatic_Chatbot_Settings['submit'];
    } else {
        $submit = '';
    }
    if (isset($aiomatic_Chatbot_Settings['background'])) {
        $background = $aiomatic_Chatbot_Settings['background'];
    } else {
        $background = '#f7f7f9';
    }
    if (isset($aiomatic_Chatbot_Settings['user_font_color'])) {
        $user_font_color = $aiomatic_Chatbot_Settings['user_font_color'];
    } else {
        $user_font_color = 'white';
    }
    if (isset($aiomatic_Chatbot_Settings['user_background_color'])) {
        $user_background_color = $aiomatic_Chatbot_Settings['user_background_color'];
    } else {
        $user_background_color = '#0084ff';
    }
    if (isset($aiomatic_Chatbot_Settings['ai_font_color'])) {
        $ai_font_color = $aiomatic_Chatbot_Settings['ai_font_color'];
    } else {
        $ai_font_color = 'black';
    }
    if (isset($aiomatic_Chatbot_Settings['ai_background_color'])) {
        $ai_background_color = $aiomatic_Chatbot_Settings['ai_background_color'];
    } else {
        $ai_background_color = '#f0f0f0';
    }
    if (isset($aiomatic_Chatbot_Settings['input_border_color'])) {
        $input_border_color = $aiomatic_Chatbot_Settings['input_border_color'];
    } else {
        $input_border_color = '#e1e3e6';
    }
    if (isset($aiomatic_Chatbot_Settings['submit_color'])) {
        $submit_color = $aiomatic_Chatbot_Settings['submit_color'];
    } else {
        $submit_color = '#55a7e2';
    }
    if (isset($aiomatic_Chatbot_Settings['submit_text_color'])) {
        $submit_text_color = $aiomatic_Chatbot_Settings['submit_text_color'];
    } else {
        $submit_text_color = '#ffffff';
    }
    if (isset($aiomatic_Chatbot_Settings['enable_moderation'])) {
        $enable_moderation = $aiomatic_Chatbot_Settings['enable_moderation'];
    } else {
        $enable_moderation = '';
    }
    if (isset($aiomatic_Chatbot_Settings['moderation_model'])) {
        $moderation_model = $aiomatic_Chatbot_Settings['moderation_model'];
    } else {
        $moderation_model = '';
    }
    if (isset($aiomatic_Chatbot_Settings['flagged_message'])) {
        $flagged_message = $aiomatic_Chatbot_Settings['flagged_message'];
    } else {
        $flagged_message = '';
    }
    if (isset($aiomatic_Chatbot_Settings['enable_copy'])) {
        $enable_copy = $aiomatic_Chatbot_Settings['enable_copy'];
    } else {
        $enable_copy = '';
    }
    if (isset($aiomatic_Chatbot_Settings['scroll_bot'])) {
        $scroll_bot = $aiomatic_Chatbot_Settings['scroll_bot'];
    } else {
        $scroll_bot = '';
    }
    if (isset($aiomatic_Chatbot_Settings['instant_response'])) {
        $instant_response = $aiomatic_Chatbot_Settings['instant_response'];
    } else {
        $instant_response = '';
    }
    if (isset($aiomatic_Chatbot_Settings['voice_input'])) {
        $voice_input = $aiomatic_Chatbot_Settings['voice_input'];
    } else {
        $voice_input = '';
    }
    if (isset($aiomatic_Chatbot_Settings['chat_preppend_text'])) {
        $chat_preppend_text = $aiomatic_Chatbot_Settings['chat_preppend_text'];
    } else {
        $chat_preppend_text = '';
    }
    if (isset($aiomatic_Chatbot_Settings['user_message_preppend'])) {
        $user_message_preppend = $aiomatic_Chatbot_Settings['user_message_preppend'];
    } else {
        $user_message_preppend = '';
    }
    if (isset($aiomatic_Chatbot_Settings['ai_message_preppend'])) {
        $ai_message_preppend = $aiomatic_Chatbot_Settings['ai_message_preppend'];
    } else {
        $ai_message_preppend = '';
    }
    if (isset($aiomatic_Chatbot_Settings['ai_first_message'])) {
        $ai_first_message = $aiomatic_Chatbot_Settings['ai_first_message'];
    } else {
        $ai_first_message = '';
    }
    if (isset($aiomatic_Chatbot_Settings['chat_mode'])) {
        $chat_mode = $aiomatic_Chatbot_Settings['chat_mode'];
    } else {
        $chat_mode = '';
    }
    if (isset($aiomatic_Chatbot_Settings['chat_model'])) {
        $chat_model = $aiomatic_Chatbot_Settings['chat_model'];
    } else {
        $chat_model = '';
    }
    if (isset($aiomatic_Chatbot_Settings['persistent'])) {
        $persistent = $aiomatic_Chatbot_Settings['persistent'];
    } else {
        $persistent = '';
    }
    if (isset($aiomatic_Chatbot_Settings['prompt_templates'])) {
        $prompt_templates = $aiomatic_Chatbot_Settings['prompt_templates'];
    } else {
        $prompt_templates = '';
    }
    if (isset($aiomatic_Chatbot_Settings['prompt_editable'])) {
        $prompt_editable = $aiomatic_Chatbot_Settings['prompt_editable'];
    } else {
        $prompt_editable = '';
    }
    if (isset($aiomatic_Chatbot_Settings['user_token_cap_per_day'])) {
        $user_token_cap_per_day = $aiomatic_Chatbot_Settings['user_token_cap_per_day'];
    } else {
        $user_token_cap_per_day = '';
    }
    if (isset($aiomatic_Chatbot_Settings['max_input_length'])) {
        $max_input_length = $aiomatic_Chatbot_Settings['max_input_length'];
    } else {
        $max_input_length = '';
    }
    if (isset($aiomatic_Chatbot_Settings['temperature'])) {
        $temperature = $aiomatic_Chatbot_Settings['temperature'];
    } else {
        $temperature = '';
    }
    if (isset($aiomatic_Chatbot_Settings['top_p'])) {
        $top_p = $aiomatic_Chatbot_Settings['top_p'];
    } else {
        $top_p = '';
    }
    if (isset($aiomatic_Chatbot_Settings['presence_penalty'])) {
        $presence_penalty = $aiomatic_Chatbot_Settings['presence_penalty'];
    } else {
        $presence_penalty = '';
    }
    if (isset($aiomatic_Chatbot_Settings['frequency_penalty'])) {
        $frequency_penalty = $aiomatic_Chatbot_Settings['frequency_penalty'];
    } else {
        $frequency_penalty = '';
    }
    if (isset($aiomatic_Chatbot_Settings['enable_front_end'])) {
        $enable_front_end = $aiomatic_Chatbot_Settings['enable_front_end'];
    } else {
        $enable_front_end = '';
    }
    if (isset($aiomatic_Chatbot_Settings['window_location'])) {
        $window_location = $aiomatic_Chatbot_Settings['window_location'];
    } else {
        $window_location = '';
    }
    if (isset($aiomatic_Chatbot_Settings['window_width'])) {
        $window_width = $aiomatic_Chatbot_Settings['window_width'];
    } else {
        $window_width = '';
    }
    if (isset($aiomatic_Chatbot_Settings['not_show_urls'])) {
        $not_show_urls = $aiomatic_Chatbot_Settings['not_show_urls'];
    } else {
        $not_show_urls = '';
    }
    if (isset($aiomatic_Chatbot_Settings['chatbot_icon_html'])) {
        $chatbot_icon_html = $aiomatic_Chatbot_Settings['chatbot_icon_html'];
    } else {
        $chatbot_icon_html = '';
    }
    if (isset($aiomatic_Chatbot_Settings['chatbot_icon'])) {
        $chatbot_icon = $aiomatic_Chatbot_Settings['chatbot_icon'];
    } else {
        $chatbot_icon = '';
    }
    if (isset($_GET['settings-updated'])) {
?>
<div id="message" class="updated">
<p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Settings saved.', 'aiomatic-automatic-ai-content-writer');?></strong></p>
</div>
<?php
}
?>
<div class="aiomatic_class">
<div id="tab-t" class="tab-content">
<br/>
<h3><?php echo esc_html__("AI Chatbot Configuration Details", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__('In this tutorial, I\'ll walk through the process of setting up an AI-powered chatbot on your WordPress website using the Aiomatic WordPress plugin. This plugin allows you to integrate AI language models to create a highly customizable chatbot that can interact with your website visitors.', 'aiomatic-automatic-ai-content-writer');?></p>
<h4><?php echo esc_html__("Step 1: Customize the Chatbot Behavior", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("In the Aiomatic settings page, navigate to the \"AI Chatbot\" menu of the plugin. You will be able to customize the chatbot in the 'Chatbot Customization', 'Chatbot Default Styling', 'Chatbot Settings' and 'Default API Parameters' tabs. Here, you can define how the chatbot will respond to specific user inputs. You can also change the visual style and appearance of the chatbot. Don't forget to always save your changes.", 'aiomatic-automatic-ai-content-writer');?></p>
<h4><?php echo esc_html__("Step 2: Add the Chatbot to Your Website", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("You can add the chatbot globally to your site or locally to posts or pages. To add the chatbot locally, you can use the [aiomatic-chat-form] shortcode. If you want to add it globally, you need to go to the settings page of the plugin, go to the \"AI Chatbot\" menu of the plugin and navigate to the 'Chatbot Website Injection' tab. Choose where you want the chatbot to appear on your website (e.g., on all front end, back end, except pages where you don't want the chatbot to appear).", 'aiomatic-automatic-ai-content-writer');?></p>
<h4><?php echo esc_html__("Step 3: Test the Chatbot", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("Visit your website and look for the chatbot. Interact with the chatbot by typing questions or phrases into the chat window. Verify that the chatbot responds appropriately based on the rules you defined.", 'aiomatic-automatic-ai-content-writer');?></p>
<p><?php echo esc_html__("That's it! You've successfully set up an AI-powered chatbot on your WordPress website using the Aiomatic plugin. This chatbot can be a valuable tool for engaging with your website visitors, answering frequently asked questions, and providing personalized assistance.", 'aiomatic-automatic-ai-content-writer');?></p>
<h3><?php echo esc_html__("AI Chatbot Tutorial Video", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/QCkNkCrFi-o" frameborder="0" allowfullscreen></iframe></div></p>
</div>
<div id="tab-0" class="tab-content">
<table class="widefat">
    <tr><td colspan="2">
    <h2><?php echo esc_html__("Chatbot Context Settings:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Add a context to the AI chatbot, so it knows how to act and how to respond to customers. You can define here the language, tone of voice and role of the AI assistant. Any other settings will also be able to be defined here. This text will be preppended to each conversation, to teach the AI some additional info about you or its behavior. This text will not be displayed to users, it will be only sent to the chatbot. You can also use shortcodes in this field. List of supported shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%, %%user_name%%, %%user_email%%, %%user_display_name%%, %%user_id%%, %%user_firstname%%, %%user_lastname%%, %%user_url%%, %%user_description%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the seed command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). Example of prompt to pretain the AI --- Article: \"%%post_content%%\" \n\n Discussion: \n\n", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Context:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="2" name="aiomatic_Chatbot_Settings[chat_preppend_text]" placeholder="Example: Converse as if you were a Marketing Agency Assistant. Be friendly, creative. Respond only in English."><?php
    echo esc_textarea($chat_preppend_text);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the name of the user. This will be prepended to each user message. This is useful to teach the AI chatbot about its role and name.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("User Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="2" name="aiomatic_Chatbot_Settings[user_message_preppend]" placeholder="User:"><?php
    echo esc_textarea($user_message_preppend);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the name of the AI. This will be prepended to each AI message. This is useful to teach the AI chatbot about its role and name.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="2" name="aiomatic_Chatbot_Settings[ai_message_preppend]" placeholder="AI:"><?php
    echo esc_textarea($ai_message_preppend);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the name of the AI. This will be prepended to each AI message. This is useful to teach the AI chatbot about its role and name.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI First Message:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="2" name="aiomatic_Chatbot_Settings[ai_first_message]" placeholder="Hi! How can I help you?"><?php
    echo esc_textarea($ai_first_message);
?></textarea>
        </div>
        </td></tr>
</table>
</div>
<div id="tab-7" class="tab-content">
    <table class="widefat">
    <tr><td><h2><?php echo esc_html__("Use the following shortcode to add the customized chatbot to your site:", 'aiomatic-automatic-ai-content-writer');?></h2></td></tr>
    <tr><td colspan="2" class="cr_width_full"><span class="cr_red cr_center cr_width_full cr_margin_block crf_bord" id="customized_chatbot">[aiomatic-chat-form temperature="default" top_p="default" model="default" presence_penalty="default" frequency_penalty="default" instant_response="false" chat_preppend_text="Act as a customer assistant, respond to every question in a helpful way." user_message_preppend="User:" ai_message_preppend="AI:" ai_first_message="Hello, how can I help you today?" chat_mode="text" persistent="off" prompt_templates="" prompt_editable="on" placeholder="Enter your chat message here" submit="Submit" show_in_window="off" window_location="top-right" font_size="1em" height="100%" background="auto" minheight="250px" user_font_color="#ffffff" user_background_color="#0084ff" ai_font_color="#000000" ai_background_color="#f0f0f0" input_border_color="#e1e3e6" submit_color="#55a7e2" submit_text_color="#ffffff" width="100%"]</span></td></tr>
    <tr><td colspan="2">
    <h2><?php echo esc_html__("Chatbot Model Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
</td></tr>
    <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font size of the chatbot form. Default is 1em", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Model:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="model_b" onchange="modelChanged_b();" >
<?php
echo '<option selected value="default">default</option>';
foreach($all_models as $modelx)
{
echo '<option value="' . $modelx .'"';
if ($chat_model == $modelx) 
{
echo " selected";
}
echo '>' . esc_html($modelx) . '</option>';
}
?>
?>
                    </select>
        </div>
        </td></tr>
        <tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="0.1" id="temperature_b" max="1" class="cr_width_full" onchange="temperatureChanged_b();" value="<?php echo esc_html($temperature);?>" placeholder="1">
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="0.1" max="1" id="top_p_b" class="cr_width_full" onchange="toppChanged_b();" value="<?php echo esc_html($top_p);?>" placeholder="1">
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="-2" step="0.1" max="2" id="presence_penalty_b" class="cr_width_full" onchange="presenceChanged_b();" value="<?php echo esc_html($presence_penalty);?>" placeholder="0">
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="-2" step="0.1" max="2" id="frequency_penalty_b" class="cr_width_full" onchange="frequencyChanged_b();" value="<?php echo esc_html($frequency_penalty);?>" placeholder="0">
        </td></tr>
        <tr><td>
        <h2><?php echo esc_html__("Chatbot Context Settings:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Add a context to the AI chatbot, so it knows how to act and how to respond to customers. You can define here the language, tone of voice and role of the AI assistant. Any other settings will also be able to be defined here. This text will be preppended to each conversation, to teach the AI some additional info about you or its behavior. This text will not be displayed to users, it will be only sent to the chatbot. You can also use shortcodes in this field. List of supported shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%, %%user_name%%, %%user_email%%, %%user_display_name%%, %%user_id%%, %%user_firstname%%, %%user_lastname%%, %%user_url%%, %%user_description%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the seed command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). Example of prompt to pretain the AI --- Article: \"%%post_content%%\" \n\n Discussion: \n\n", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Context:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea id="context_b" onchange="contextChanged_b();" rows="2" placeholder="Example: Converse as if you were a Marketing Agency Assistant. Be friendly, creative. Respond only in English."><?php
    echo esc_textarea($chat_preppend_text);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the name of the user. This will be prepended to each user message. This is useful to teach the AI chatbot about its role and name.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("User Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea id="user_name_b" rows="2" onchange="userChanged_b();" placeholder="User:"><?php
    echo esc_textarea($user_message_preppend);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the name of the AI. This will be prepended to each AI message. This is useful to teach the AI chatbot about its role and name.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea id="ai_name_b" rows="2" onchange="aiChanged_b();" placeholder="AI:"><?php
    echo esc_textarea($ai_message_preppend);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the name of the AI. This will be prepended to each AI message. This is useful to teach the AI chatbot about its role and name.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI First Message:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea id="ai_message_b" onchange="messageChanged_b();" rows="2" placeholder="Hi! How can I help you?"><?php
    echo esc_textarea($ai_first_message);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
    <h2><?php echo esc_html__("Chatbot General Settings:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to make the chatbot respond with full text or do you want to enable a typing effect, so text will appear gradually.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Enable Chatbot Instant Responses:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                <input type="checkbox" id="instant_response_b" onchange="instantChanged_b();">
        </div>
        </td></tr>
        <tr>
    <td>
        <div>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the default chat mode (image or text).", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("Default Chat Mode:", 'aiomatic-automatic-ai-content-writer');?></b>   
    </td>
    <td class="cr_min_width_200">
    <select id="chat_mode_b" onchange="modeChanged_b();" class="cr_width_full">
    <?php
echo '<option value="text">Text</option>';
echo '<option value="images">Image</option>';
?>
    </select>  
    </td>
    </tr>
        <tr>
    <td>
        <div>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select if you want to enable the persistent chat mode. Chats will be saved in the database and can be viewed from the 'Limits and Statistics' menu of the plugin.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("Persistent Chat:", 'aiomatic-automatic-ai-content-writer');?></b>   
    </td>
    <td class="cr_min_width_200">
    <select id="persistent_b" onchange="persistentChanged_b();" class="cr_width_full">
    <?php
echo '<option value="off">Off</option>';
echo '<option value="on">On</option>';
?>
    </select>  
    </td>
    </tr>
    <tr><td>
    <div>
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
<?php
echo esc_html__("Select if you want to enable the prompts to be user editable. You should use this feature only together with the prompt templates feature.", 'aiomatic-automatic-ai-content-writer');
?>
                    </div>
                </div>
                <b><?php echo esc_html__("Prompt Templates:", 'aiomatic-automatic-ai-content-writer');?></b>
                </div>
                </td><td>
                <div>
                <textarea rows="2" onchange="templateChanged_b();" id="template_b" placeholder="Add a semicolon (;) separated list of prompt templates from which the users will be able to select and submit one."><?php
echo esc_textarea($prompt_templates);
?></textarea>
    </div>
    </td></tr>
    <td>
        <div>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select if you want to enable the prompts to be user editable. You should use this feature only together with the prompt templates feature.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("Prompts Editable By Users:", 'aiomatic-automatic-ai-content-writer');?></b>   
    </td>
    <td class="cr_min_width_200">
    <select id="prompt_editable_b" onchange="editableChanged_b();" class="cr_width_full">
    <?php
echo '<option value="on">On</option>';
echo '<option value="off">Off</option>';
?>
    </select>  
    </td>
    </tr>
    <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to inject the chatbot globally, to the entire front end and/or back end of your site.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Inject Chatbot Globally Your Site:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="enable_front_end_b" onchange="frontChanged_b();" class="cr_width_full">
<?php
echo '<option value="off">Off</option>';
echo '<option value="front">Front End</option>';
echo '<option value="back">Back End</option>';
echo '<option value="both">Front End & Back End</option>';
?>
</select>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select where you want to show the embedded chatbot.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Location:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="window_location_b" onchange="locationChanged_b();" class="cr_width_full">
<?php
echo '<option value="bottom-right">Bottom Right</option>';
echo '<option value="bottom-left">Bottom Left</option>';
echo '<option value="top-right">Top Right</option>';
echo '<option value="top-left">Top Left</option>';
?>
</select>
        </div>
        </td></tr>
        <tr><td>
    <h2><?php echo esc_html__("Chatbot Styling Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font size of the chatbot form. Default is 1em", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Font Size:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="font_size_b" onchange="fontSizeChanged_b();" >
<?php
echo '<option selected value="1em">1em</option>';
for($i = 10; $i <= 30; $i++){
    echo '<option value="'.esc_html($i).'px">'.esc_html($i).'px</option>';
}
?>
                    </select>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the width of the chatbot form. For full width, you can set 100% (default value). You can also set values in pixels, like: 400px", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Form Width:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="text" id="width_b" value="100%" placeholder="100%" onchange="widthChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the height of the chatbot form. Default is auto. You can set values in pixels, like: 400px", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Form Height:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="text" id="height_b" value="auto" placeholder="auto" onchange="heightChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the min-height of the chatbot form (when the form is resized, this is the minimum height it will be allowed to get. Default is 250px. You can set values in pixels, like: 400px", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Form Min-Height:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="text" id="minheight_b" value="250px" placeholder="250px" onchange="minheightChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the placeholder text of the chat input. The default is: Enter your chat message here.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Input Placeholder:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" id="placeholder_b" placeholder="Enter your chat message here" onchange="placeholderChanged_b()">Enter your chat message here</textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the text of the submit button. The default is: Submit", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Input Submit Button Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" id="submit_b" placeholder="Submit" onchange="submitChanged_b()">Submit</textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the background color of the chatbot form. Default is #f7f7f9", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Background Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="background_b" value="#ffffff" onchange="backgroundChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font color of the user chatbot form. Default is white", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("User Font Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="user_font_color_b" value="#ffffff" onchange="userfontcolorChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font color of the user baloon chatbot form. Default is #0084ff", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("User Baloon Background Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="user_background_color_b" value="#0084ff" onchange="userbackgroundcolorChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font color of the AI chatbot form. Default is black", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Font Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="ai_font_color_b" value="#000000" onchange="aifontcolorChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font color of the AI baloon chatbot form. Default is #f0f0f0", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Baloon Background Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="ai_background_color_b" value="#f0f0f0" onchange="aibackgroundcolorChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the border color for the input field. Default is #e1e3e6", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Input Border Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="input_border_color_b" value="#e1e3e6" onchange="bordercolorChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the color of the submit button. Default is #55a7e2", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Submit Button Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="submit_color_b" value="#55a7e2" onchange="submitcolorChanged_b()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the text color of the submit button. Default is #55a7e2", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Submit Button Text Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="submit_text_color_b" value="#ffffff" onchange="submittextcolorChanged_b()">
        </div>
        </td></tr>
    </table>
</div>
<div id="tab-8" class="tab-content">
    <table class="widefat">
    <tr><td colspan="2">
    <h2><?php echo esc_html__("Chatbot Text-to-Speech Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
<?php
if ((!isset($aiomatic_Main_Settings['elevenlabs_app_id']) || trim($aiomatic_Main_Settings['elevenlabs_app_id']) == '') && (!isset($aiomatic_Main_Settings['google_app_id']) || trim($aiomatic_Main_Settings['google_app_id']) == ''))
{
    echo '<tr><td colspan="2"><h2>' . esc_html__("You need to enter a ElevenLabs.io API key or a Google Text-to-Speech API key in the 'API Keys' tab and save settings, to use this feature.", 'aiomatic-automatic-ai-content-writer') . '</h2></td></tr>';
}
elseif (!isset($aiomatic_Chatbot_Settings['instant_response']) || trim($aiomatic_Chatbot_Settings['instant_response']) != 'on')
{
    echo '<tr><td colspan="2"><h2>' . esc_html__("Text-to-Speech is not supported if chatbot 'Instant Responses' are not enabled. Please go to the 'Chatbot Settings' tab and enable the 'Enable Chatbot Instant Responses' settings field.", 'aiomatic-automatic-ai-content-writer') . '</h2></td></tr>';
}
else
{
    if (isset($aiomatic_Main_Settings['elevenlabs_app_id']) && trim($aiomatic_Main_Settings['elevenlabs_app_id']) != '')
    {
        echo '<tr><td><b>' . esc_html__("Sync ElevenLabs.io Voices:", 'aiomatic-automatic-ai-content-writer') . '</b></td><td><input type="button" onclick="aiomatic_sync_voices_elevenlabs()" id="elevenlabs_sync" value="Sync"></td></tr>';
    }
    if (isset($aiomatic_Main_Settings['google_app_id']) && trim($aiomatic_Main_Settings['google_app_id']) != '')
    {
        echo '<tr><td><b>' . esc_html__("Sync Google Text-to-Speech Voices:", 'aiomatic-automatic-ai-content-writer') . '</b></td><td><input type="button" onclick="aiomatic_sync_voices_google()" id="google_sync" value="Sync"></td></tr>';
    }
?>
<tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to enable chatbot text to speech.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Enable Chatbot Text-to-Speech:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="chatbot_text_speech" onchange="aiomatic_text_changed()" name="aiomatic_Chatbot_Settings[chatbot_text_speech]" >
<?php
echo '<option' . ($chatbot_text_speech == 'off' ? ' selected': '') . ' value="off">Off</option>';
if (isset($aiomatic_Main_Settings['elevenlabs_app_id']) && trim($aiomatic_Main_Settings['elevenlabs_app_id']) != '')
{
    echo '<option' . ($chatbot_text_speech == 'elevenlabs' ? ' selected': '') . ' value="elevenlabs">ElevenLabs.io</option>';
}
if (isset($aiomatic_Main_Settings['google_app_id']) && trim($aiomatic_Main_Settings['google_app_id']) != '')
{
    echo '<option' . ($chatbot_text_speech == 'google' ? ' selected': '') . ' value="google">Google Text-to-Speech</option>';
}
?>
</select>
        </div>
        </td></tr>
<tr class="hideeleven"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select a voice you want to use for your chatbot.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Select a Voice:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="eleven_voice" name="aiomatic_Chatbot_Settings[eleven_voice]" >
<?php
$eleven_voices = aiomatic_get_eleven_voices();
if($eleven_voices === false)
{
    echo '<option value="" disabled>'.esc_html__("Failed to list voices!", 'aiomatic-automatic-ai-content-writer').'</option>';
}
else
{
    foreach($eleven_voices as $key => $voice)
    {
        echo '<option' . ($eleven_voice == esc_attr($key) ? ' selected': '') . ' value="'.esc_attr($key).'">'.esc_html($voice).'</option>';
    }
}
?>
</select>
        </div>
        </td></tr>
<tr class="hidegoogle"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select a the language of the chosen voice.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Voice Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="voice_language" name="aiomatic_Chatbot_Settings[voice_language]" >
<?php
$gvlanguages = array(
    'af-ZA' => 'Afrikaans (Suid-Afrika)',
    'ar-XA' => 'Arabic, multi-region',
    'id-ID' => 'Bahasa Indonesia (Indonesia)',
    'ms-MY' => 'Bahasa Melayu (Malaysia)',
    'ca-ES' => 'Català (Espanya)',
    'da-DK' => 'Dansk (Danmark)',
    'de-DE' => 'Deutsch (Deutschland)',
    'en-AU' => 'English (Australia)',
    'en-GB' => 'English (Great Britain)',
    'en-IN' => 'English (India)',
    'en-US' => 'English (United States)',
    'es-ES' => 'Español (España)',
    'es-US' => 'Español (Estados Unidos)',
    'eu-ES' => 'Euskara (Espainia)',
    'fil-PH' => 'Filipino (Pilipinas)',
    'fr-CA' => 'Français (Canada)',
    'fr-FR' => 'Français (France)',
    'gl-ES' => 'Galego (España)',
    'it-IT' => 'Italiano (Italia)',
    'lv-LV' => 'Latviešu (latviešu)',
    'lt-LT' => 'Lietuvių (Lietuva)',
    'hu-HU' => 'Magyar (Magyarország)',
    'nl-NL' => 'Nederlands (Nederland)',
    'nb-NO' => 'Norsk bokmål (Norge)',
    'pl-PL' => 'Polski (Polska)',
    'pt-BR' => 'Português (Brasil)',
    'pt-PT' => 'Português (Portugal)',
    'ro-RO' => 'Română (România)',
    'sk-SK' => 'Slovenčina (Slovensko)',
    'fi-FI' => 'Suomi (Suomi)',
    'sv-SE' => 'Svenska (Sverige)',
    'vi-VN' => 'Tiếng Việt (Việt Nam)',
    'tr-TR' => 'Türkçe (Türkiye)',
    'is-IS' => 'Íslenska (Ísland)',
    'cs-CZ' => 'Čeština (Česká republika)',
    'el-GR' => 'Ελληνικά (Ελλάδα)',
    'bg-BG' => 'Български (България)',
    'ru-RU' => 'Русский (Россия)',
    'sr-RS' => 'Српски (Србија)',
    'uk-UA' => 'Українська (Україна)',
    'he-IL' => 'עברית (ישראל)',
    'mr-IN' => 'मराठी (भारत)',
    'hi-IN' => 'हिन्दी (भारत)',
    'bn-IN' => 'বাংলা (ভারত)',
    'gu-IN' => 'ગુજરાતી (ભારત)',
    'ta-IN' => 'தமிழ் (இந்தியா)',
    'te-IN' => 'తెలుగు (భారతదేశం)',
    'kn-IN' => 'ಕನ್ನಡ (ಭಾರತ)',
    'ml-IN' => 'മലയാളം (ഇന്ത്യ)',
    'th-TH' => 'ไทย (ประเทศไทย)',
    'cmn-TW' => '國語 (台灣)',
    'yue-HK' => '廣東話 (香港)',
    'ja-JP' => '日本語（日本)',
    'cmn-CN' => '普通话 (中国大陆)',
    'ko-KR' => '한국어 (대한민국)'
);
foreach($gvlanguages as $key => $lang)
{
    echo '<option' . ($voice_language == esc_attr($key) ? ' selected': '') . ' value="'.esc_attr($key).'">'.esc_html($lang).'</option>';
}
?>
</select>
        </div>
        </td></tr>
        <tr class="hidegoogle"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select a the name of the chosen voice.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Voice Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="google_voice" name="aiomatic_Chatbot_Settings[google_voice]" >
<?php
$google_voices = aiomatic_get_google_voices($voice_language);
if($google_voices === false)
{
    echo '<option value="" disabled>'.esc_html__("Failed to list voices!", 'aiomatic-automatic-ai-content-writer').'</option>';
}
else
{
    foreach($google_voices as $key => $voice)
    {
        echo '<option' . ($google_voice == esc_attr($voice['name']) ? ' selected': '') . ' value="'.esc_attr($voice['name']).'">'.esc_html($voice['name']).'</option>';
    }
}
?>
</select>
        </div>
        </td></tr>
        <tr class="hidegoogle"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select a the Audio Device Profile of the chosen voice.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Audio Device Profile:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="audio_profile" name="aiomatic_Chatbot_Settings[audio_profile]" >
<?php
$gvprofiles = array(
    '' => esc_html__('Default','aiomatic-automatic-ai-content-writer'),
    'wearable-class-device' => esc_html__('Smart watch or wearable','aiomatic-automatic-ai-content-writer'),
    'handset-class-device' => esc_html__('Smartphone','aiomatic-automatic-ai-content-writer'),
    'headphone-class-device' => esc_html__('Headphones or earbuds','aiomatic-automatic-ai-content-writer'),
    'small-bluetooth-speaker-class-device' => esc_html__('Small home speaker','aiomatic-automatic-ai-content-writer'),
    'medium-bluetooth-speaker-class-device' => esc_html__('Smart home speaker','aiomatic-automatic-ai-content-writer'),
    'large-home-entertainment-class-device' => esc_html__('Home entertainment system or smart TV','aiomatic-automatic-ai-content-writer'),
    'large-automotive-class-device' => esc_html__('Car speaker','aiomatic-automatic-ai-content-writer'),
    'telephony-class-application' => esc_html__('Interactive Voice Response (IVR) system','aiomatic-automatic-ai-content-writer')
);
foreach($gvprofiles as $key => $val)
{
    echo '<option' . ($audio_profile == esc_attr($key) ? ' selected': '') . ' value="'.esc_attr($key).'">'.esc_html($val).'</option>';
}
?>
</select>
        </div>
        </td></tr>
        <tr class="hidegoogle"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select a the Voice Speed of the chosen voice. Speaking rate/speed, in the range [0.25, 4.0]. 1.0 is the normal native speed supported by the specific voice. 2.0 is twice as fast, and 0.5 is half as fast. If unset(0.0), defaults to the native 1.0 speed. Any other values < 0.25 or > 4.0 will return an error.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Voice Speed:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" min="0.25" max="4" step="0.01" id="voice_speed" name="aiomatic_Chatbot_Settings[voice_speed]" class="cr_width_full" value="<?php echo esc_html($voice_speed);?>" placeholder="Voice speed">
        </div>
        </td></tr>
        <tr class="hidegoogle"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select a the Voice Pitch of the chosen voice. Speaking pitch, in the range [-20.0, 20.0]. 20 means increase 20 semitones from the original pitch. -20 means decrease 20 semitones from the original pitch.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Voice Pitch:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" min="-20" step="0.1" max="20" id="voice_pitch" name="aiomatic_Chatbot_Settings[voice_pitch]" class="cr_width_full" value="<?php echo esc_html($voice_pitch);?>" placeholder="Voice pitch">
        </div>
        </td></tr>
<?php
}
?>
    </table>
</div>
<div id="tab-1" class="tab-content">
    <table class="widefat">
    <tr><td colspan="2">
    <h2><?php echo esc_html__("AI Chatbot Default Styling Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font size of the chatbot form. Default is 1em", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Font Size:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="font_size" name="aiomatic_Chatbot_Settings[font_size]" onchange="fontSizeChanged();" >
<?php
echo '<option'.($font_size == '1em' ? ' selected': '').' value="1em">1em</option>';
for($i = 10; $i <= 30; $i++){
    echo '<option'.($font_size == $i ? ' selected': '').' value="'.esc_html($i).'px">'.esc_html($i).'px</option>';
}
?>
                    </select>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the width of the chatbot form. For full width, you can set 100% (default value). You can also set values in pixels, like: 400px", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Form Width:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="text" id="width" name="aiomatic_Chatbot_Settings[width]" value="<?php echo esc_html($width);?>" placeholder="100%" onchange="widthChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the height of the chatbot form. Default is auto. You can set values in pixels, like: 400px", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Form Height:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="text" id="height" name="aiomatic_Chatbot_Settings[height]" value="<?php echo esc_html($height);?>" placeholder="auto" onchange="heightChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the min-height of the chatbot form (when the form is resized, this is the minimum height it will be allowed to get. Default is 250px. You can set values in pixels, like: 400px", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Form Min-Height:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="text" id="minheight" name="aiomatic_Chatbot_Settings[minheight]" value="<?php echo esc_html($minheight);?>" placeholder="250px" onchange="minheightChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the placeholder text of the chat input. The default is: Enter your chat message here.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Input Placeholder:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Chatbot_Settings[placeholder]" placeholder="Enter your chat message here"><?php
    echo esc_textarea($placeholder);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the text of the submit button. The default is: Submit", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chat Input Submit Button Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Chatbot_Settings[submit]" placeholder="Submit"><?php
    echo esc_textarea($submit);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the background color of the chatbot form. Default is #f7f7f9", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Background Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="background" name="aiomatic_Chatbot_Settings[background]" value="<?php echo esc_html($background);?>" onchange="backgroundChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font color of the user chatbot form. Default is white", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("User Font Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="user_font_color" name="aiomatic_Chatbot_Settings[user_font_color]" value="<?php echo esc_html($user_font_color);?>" onchange="userfontcolorChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font color of the user baloon chatbot form. Default is #0084ff", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("User Baloon Background Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="user_background_color" name="aiomatic_Chatbot_Settings[user_background_color]" value="<?php echo esc_html($user_background_color);?>" onchange="userbackgroundcolorChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font color of the AI chatbot form. Default is black", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Font Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="ai_font_color" name="aiomatic_Chatbot_Settings[ai_font_color]" value="<?php echo esc_html($ai_font_color);?>" onchange="aifontcolorChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the font color of the AI baloon chatbot form. Default is #f0f0f0", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Baloon Background Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="ai_background_color" name="aiomatic_Chatbot_Settings[ai_background_color]" value="<?php echo esc_html($ai_background_color);?>" onchange="aibackgroundcolorChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the border color for the input field. Default is #e1e3e6", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Input Border Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="input_border_color" name="aiomatic_Chatbot_Settings[input_border_color]" value="<?php echo esc_html($input_border_color);?>" onchange="bordercolorChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the color of the submit button. Default is #55a7e2", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Submit Button Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="submit_color" name="aiomatic_Chatbot_Settings[submit_color]" value="<?php echo esc_html($submit_color);?>" onchange="submitcolorChanged()">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the text color of the submit button. Default is #55a7e2", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Submit Button Text Color:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="color" id="submit_text_color" name="aiomatic_Chatbot_Settings[submit_text_color]" value="<?php echo esc_html($submit_text_color);?>" onchange="submittextcolorChanged()">
        </div>
        </td></tr>
    </table>
</div>
<div id="tab-2" class="tab-content">
<table class="widefat">
    <tr><td colspan="2">
    <h2><?php echo esc_html__("AI Chatbot Moderation Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to enable chatbot moderation", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Enable User Message Moderation:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                <input type="checkbox" id="enable_moderation" name="aiomatic_Chatbot_Settings[enable_moderation]"<?php
    if ($enable_moderation == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the AI model you want to use for moderation.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Moderation Model:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="moderation_model" name="aiomatic_Chatbot_Settings[moderation_model]" >
<?php
echo '<option' . ($moderation_model == 'text-moderation-stable' ? ' selected': '') . ' value="text-moderation-stable">text-moderation-stable</option>';
echo '<option' . ($moderation_model == 'text-moderation-latest' ? ' selected': '') . ' value="text-moderation-latest">text-moderation-latest</option>';
?>
                    </select>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the message which will appear to users when their input is flagged.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Flagged Text Message:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Chatbot_Settings[flagged_message]" placeholder="Your message has been flagged as potentially harmful or inappropriate. Please review your language and content to ensure it aligns with our values of respect and sensitivity towards others. Thank you for your cooperation."><?php
    echo esc_textarea($flagged_message);
?></textarea>
        </div>
        </td></tr>
</table>
</div>
<div id="tab-3" class="tab-content">
<table class="widefat">
    <tr><td colspan="2">
    <h2><?php echo esc_html__("AI Chatbot Settings:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to enable the copying of messages, if users click the message bubbles.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Enable Message Copying By Clicking It:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                <input type="checkbox" id="enable_copy" name="aiomatic_Chatbot_Settings[enable_copy]"<?php
    if ($enable_copy == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to automatically scroll the window to bottom on new messages.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Scroll To Bottom Of The Form On New Messages:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                <input type="checkbox" id="scroll_bot" name="aiomatic_Chatbot_Settings[scroll_bot]"<?php
    if ($scroll_bot == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to make the chatbot respond with full text or do you want to enable a typing effect, so text will appear gradually. This is also required for the text-to-speech feature of the plugin.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Enable Chatbot Instant Responses:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                <input type="checkbox" id="instant_response" name="aiomatic_Chatbot_Settings[instant_response]"<?php
    if ($instant_response == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to enable the voice input feature for the chatbot.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Enable Chatbot Voice Input:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                <input type="checkbox" id="voice_input" name="aiomatic_Chatbot_Settings[voice_input]"<?php
    if ($voice_input == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr>
        <tr>
    <td>
        <div>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the default chat mode (image or text).", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("Default Chat Mode:", 'aiomatic-automatic-ai-content-writer');?></b>   
    </td>
    <td class="cr_min_width_200">
    <select id="chat_mode" name="aiomatic_Chatbot_Settings[chat_mode]" class="cr_width_full">
    <?php
echo '<option' . ($chat_mode == 'text' ? ' selected': '') . ' value="text">Text</option>';
echo '<option' . ($chat_mode == 'images' ? ' selected': '') . ' value="images">Image</option>';
?>
    </select>  
    </td>
    </tr>
        <tr>
    <td>
        <div>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select if you want to enable the persistent chat mode. Chats will be saved in the database and can be viewed from the 'Limits and Statistics' menu of the plugin.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("Persistent Chat:", 'aiomatic-automatic-ai-content-writer');?></b>   
    </td>
    <td class="cr_min_width_200">
    <select id="persistent" name="aiomatic_Chatbot_Settings[persistent]" class="cr_width_full">
    <?php
echo '<option' . ($persistent == 'off' ? ' selected': '') . ' value="off">Off</option>';
echo '<option' . ($persistent == 'on' ? ' selected': '') . ' value="on">On</option>';
?>
    </select>  
    </td>
    </tr>
    <tr><td>
    <div>
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
<?php
echo esc_html__("Select if you want to enable the prompts to be user editable. You should use this feature only together with the prompt templates feature.", 'aiomatic-automatic-ai-content-writer');
?>
                    </div>
                </div>
                <b><?php echo esc_html__("Prompt Templates:", 'aiomatic-automatic-ai-content-writer');?></b>
                </div>
                </td><td>
                <div>
                <textarea rows="2" name="aiomatic_Chatbot_Settings[prompt_templates]" placeholder="Add a semicolon (;) separated list of prompt templates from which the users will be able to select and submit one."><?php
echo esc_textarea($prompt_templates);
?></textarea>
    </div>
    </td></tr>
    <td>
        <div>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select if you want to enable the prompts to be user editable. You should use this feature only together with the prompt templates feature.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("Prompts Editable By Users:", 'aiomatic-automatic-ai-content-writer');?></b>   
    </td>
    <td class="cr_min_width_200">
    <select id="prompt_editable" name="aiomatic_Chatbot_Settings[prompt_editable]" class="cr_width_full">
    <?php
echo '<option' . ($prompt_editable == 'on' ? ' selected': '') . ' value="on">On</option>';
echo '<option' . ($prompt_editable == 'off' ? ' selected': '') . ' value="off">Off</option>';
?>
    </select>  
    </td>
    </tr>
    <tr><td colspan="2">
    <h2><?php echo esc_html__("AI Chatbot Limitations:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
    <tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the daily token count for logged in users. Users who are not logged in will not be allowed to submit the form. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("User Token Cap Per Day:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="1" id="user_token_cap_per_day" name="aiomatic_Chatbot_Settings[user_token_cap_per_day]" class="cr_width_full" value="<?php echo esc_html($user_token_cap_per_day);?>" placeholder="User token cap / day">
        </td></tr>
    <tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the maximum input length for user messages.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Max Input Length (Characters):", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="1" id="max_input_length" name="aiomatic_Chatbot_Settings[max_input_length]" class="cr_width_full" value="<?php echo esc_html($max_input_length);?>" placeholder="Max input length">
        </td></tr>
</table>
</div>
<div id="tab-4" class="tab-content">
<table class="widefat">
    <tr><td colspan="2">
    <h2><?php echo esc_html__("Default API Parameters:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
<tr>
    <td>
        <div>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the model to be used for chatbot.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("Chatbot Model:", 'aiomatic-automatic-ai-content-writer');?></b>   
    </td>
    <td class="cr_min_width_200">
    <select id="chat_model" name="aiomatic_Chatbot_Settings[chat_model]" class="cr_width_full">
    <?php
foreach($all_models as $modelx)
{
echo '<option value="' . $modelx .'"';
if ($chat_model == $modelx) 
{
echo " selected";
}
echo '>' . esc_html($modelx) . '</option>';
}
?>
    </select>  
    </td>
    </tr>
    <tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="0.1" id="temperature" max="1" name="aiomatic_Chatbot_Settings[temperature]" class="cr_width_full" value="<?php echo esc_html($temperature);?>" placeholder="1">
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="0.1" max="1" id="top_p" name="aiomatic_Chatbot_Settings[top_p]" class="cr_width_full" value="<?php echo esc_html($top_p);?>" placeholder="1">
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="-2" step="0.1" max="2" id="presence_penalty" name="aiomatic_Chatbot_Settings[presence_penalty]" class="cr_width_full" value="<?php echo esc_html($presence_penalty);?>" placeholder="0">
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="-2" step="0.1" max="2" id="frequency_penalty" name="aiomatic_Chatbot_Settings[frequency_penalty]" class="cr_width_full" value="<?php echo esc_html($frequency_penalty);?>" placeholder="0">
        </td></tr>
</table>
</div>
<div id="tab-5" class="tab-content">
<table class="widefat">
    <tr><td colspan="2">
    <h2><?php echo esc_html__("Chatbot Global Injection Settings:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to inject the chatbot globally, to the entire front end and/or back end of your site.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Inject Chatbot Globally Your Site:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="enable_front_end" name="aiomatic_Chatbot_Settings[enable_front_end]" >
<?php
echo '<option' . ($enable_front_end == 'off' ? ' selected': '') . ' value="off">Off</option>';
echo '<option' . ($enable_front_end == 'front' ? ' selected': '') . ' value="front">Front End</option>';
echo '<option' . ($enable_front_end == 'back' ? ' selected': '') . ' value="back">Back End</option>';
echo '<option' . ($enable_front_end == 'both' ? ' selected': '') . ' value="both">Front End & Back End</option>';
?>
</select>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select where you want to show the embedded chatbot.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Location:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<select id="window_location" name="aiomatic_Chatbot_Settings[window_location]" >
<?php
echo '<option' . ($window_location == 'bottom-right' ? ' selected': '') . ' value="bottom-right">Bottom Right</option>';
echo '<option' . ($window_location == 'bottom-left' ? ' selected': '') . ' value="bottom-left">Bottom Left</option>';
echo '<option' . ($window_location == 'top-right' ? ' selected': '') . ' value="top-right">Top Right</option>';
echo '<option' . ($window_location == 'top-left' ? ' selected': '') . ' value="top-left">Top Left</option>';
?>
</select>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the width of the chatbot form embedded. Default is 460px", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Width:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
<input type="text" id="window_width" name="aiomatic_Chatbot_Settings[window_width]" class="cr_width_full" value="<?php echo esc_html($window_width);?>" placeholder="400px">
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set a list of URL where to not show the chatbot. You can enter multiple URLs, each on a new line.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("URLs Where To Not Show The Chatbot:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                        <textarea rows="2" name="aiomatic_Chatbot_Settings[not_show_urls]" placeholder="URL list, each on a new line"><?php
    echo esc_textarea($not_show_urls);
?></textarea>
        </div>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set a icon which will open the chatbot.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Chatbot Open Icon:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="0"<?php
    if ($chatbot_icon == '0')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/0.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="1"<?php
    if ($chatbot_icon == '1')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/1.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="2"<?php
    if ($chatbot_icon == '2')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/2.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="3"<?php
    if ($chatbot_icon == '3')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/3.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="4"<?php
    if ($chatbot_icon == '4')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/4.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="5"<?php
    if ($chatbot_icon == '5')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/5.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="6"<?php
    if ($chatbot_icon == '6')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/6.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="7"<?php
    if ($chatbot_icon == '7')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/7.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="8"<?php
    if ($chatbot_icon == '8')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/8.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="9"<?php
    if ($chatbot_icon == '9')
        echo ' checked ';
?>><img src="<?php echo plugins_url('icons/9.png', __FILE__);?>" width="32" height="32"><br>
    <input type="radio" name="aiomatic_Chatbot_Settings[chatbot_icon]" value="x"<?php
    if ($chatbot_icon == 'x')
        echo ' checked ';
?>><?php echo esc_html__("Your Own HTML:", 'aiomatic-automatic-ai-content-writer');?><input type="text" value="<?php echo esc_html($chatbot_icon_html);?>" placeholder="Your HTML content" name="aiomatic_Chatbot_Settings[chatbot_icon_html]" />
        </div>
        </td></tr>
</table>
</div>

<div id="tab-6" class="tab-content">
<br/>
<?php
if ( isset( $_GET['action'] ) && isset( $_GET['user_id'] ) && wp_verify_nonce( $_GET['_wpnonce'], 'user_meta_manager_' . $_GET['action'] . '_' . $_GET['user_id'] ) ) 
{
    $user_id = intval( $_GET['user_id'] );
    $action = sanitize_key( $_GET['action'] );
    $conv_id = sanitize_key( $_GET['conv_id'] );
    if ( $action == 'delete_meta' && is_numeric($user_id) && $user_id > 0 ) 
    {
        delete_user_meta( $user_id, 'aiomatic_chat_history' . $conv_id );
    }
}

$paged = 1;
if ( isset( $_GET['paged'] ) ) {
$paged = intval( $_GET['paged'] );
}
$users_per_page = 20;
if ( isset( $_GET['users_per_page'] ) ) {
$users_per_page = intval( $_GET['users_per_page'] );
}
$users_query = new WP_User_Query(
array(
    'meta_query' => array(
    array(
        'key'     => 'aiomatic_chat_history',
        'compare_key' => 'LIKE'
    )
    ),
    'number' => $users_per_page,
    'paged' => $paged,
)
);
$total_users = $users_query->get_total();
$total_pages = ceil( $total_users / $users_per_page );
$users = $users_query->get_results();
echo '<div class="wrap">';
echo '<h1>' . esc_html__('User Conversation Manager', 'aiomatic-automatic-ai-content-writer') . '</h1>';
echo '<table class="wp-list-table widefat fixed striped users">';
echo '<thead>';
echo '<tr>';
echo '<th scope="col" id="username" class="manage-column column-username column-primary">Username</th>';
echo '<th scope="col" id="username" class="manage-column column-username column-primary">Chat ID</th>';
echo '<th scope="col" id="email" class="manage-column column-email">Email</th>';
echo '<th scope="col" id="actions" class="manage-column column-actions">Actions</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody id="the-list">';
if(count($users) == 0)
{
    echo '</tbody></table><br/><br/>' . esc_html__('No persistent chat messages found. You can enable this feature if you use the following shortcode to add a persistent AI chat to your page: [aiomatic-chat-form persistent="on"]', 'aiomatic-automatic-ai-content-writer') . '</div>';
}
else
{
    $current_page = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $users = aiomatic_array_unique($users);
    foreach ( $users as $user ) {
        $user_id = $user->ID;
        $username = $user->user_login;
        $email = $user->user_email;
        $all_meta = get_user_meta($user_id, '', true);
        $my_meta = array_filter($all_meta, function($key){
            return strpos($key, 'aiomatic_chat_history') === 0;
        }, ARRAY_FILTER_USE_KEY);
        foreach($my_meta as $key => $zmeta)
        {
            echo '<tr>';
            echo '<td class="username column-username has-row-actions column-primary" data-colname="Username">' . esc_html( $username ) . '</td>';
            $pref = explode('aiomatic_chat_history', $key);
            echo '<td class="chatid column-chatid" data-colname="ChatID">' . $pref[1] . '</td>';
            echo '<td class="email column-email" data-colname="Email">' . esc_html( $email ) . '</td>';
            echo '<td class="actions column-actions" data-colname="Actions">';
            echo '<a href="' . add_query_arg( array( 'action' => 'view_meta', 'user_id' => $user_id, 'conv_id' => $pref[1], '_wpnonce' => wp_create_nonce( 'user_meta_manager_view_meta_' . $user_id ) ), $current_page ) . '">View</a> | ';
            echo '<a href="' . add_query_arg( array( 'action' => 'download_meta', 'user_id' => $user_id, 'conv_id' => $pref[1], '_wpnonce' => wp_create_nonce( 'user_meta_manager_download_meta_' . $user_id ) ), $current_page ) . '">Download</a> | ';
            echo '<a href="' . add_query_arg( array( 'action' => 'delete_meta', 'user_id' => $user_id, 'conv_id' => $pref[1], '_wpnonce' => wp_create_nonce( 'user_meta_manager_delete_meta_' . $user_id ) ), $current_page ) . '">Delete</a>';
            echo '</td>';
            echo '</tr>';
        }
    }
    echo '</tbody>';
    echo '</table>';
    echo '<div class="tablenav bottom">';
    echo '<div class="tablenav-pages">';
    echo '<span class="displaying-num">' . $total_users . ' items</span>';
    echo '<span class="pagination-links">';
    if($paged > 1)
    {
    echo '<a href="' . add_query_arg( array( 'paged' => $paged - 1 ), $current_page ) . '">' . esc_html__('Prev', 'aiomatic-automatic-ai-content-writer') . '</a>&nbsp;';
    }
    for ( $i = 1; $i <= $total_pages; $i++ ) 
    {
        $class = ( $i == $paged ) ? ' current' : '';
        echo '<a class="' . $class . '" href="' . add_query_arg( array( 'paged' => $i ), $current_page ) . '">' . $i . '</a>&nbsp;';
    }
    if($paged < $total_pages)
    {
    echo '<a href="' . add_query_arg( array( 'paged' => $paged + 1 ), $current_page ) . '">' . esc_html__('Next', 'aiomatic-automatic-ai-content-writer') . '</a>&nbsp;';
    }
    echo '</span>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    if ( isset( $_GET['action'] ) && isset( $_GET['user_id'] ) && wp_verify_nonce( $_GET['_wpnonce'], 'user_meta_manager_' . $_GET['action'] . '_' . $_GET['user_id'] ) ) 
    {
        $user_id = intval( $_GET['user_id'] );
        $action = sanitize_key( $_GET['action'] );
        $conv_id = sanitize_key( $_GET['conv_id'] );
        if ( $action == 'delete_meta' ) 
        {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>' . esc_html__('User conversation data has been deleted.', 'aiomatic-automatic-ai-content-writer') . '</p>';
            echo '</div>';
        } 
        elseif ( $action == 'view_meta' ) 
        {
            $conv_meta = get_user_meta($user_id, 'aiomatic_chat_history' . $conv_id, true);
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('User Conversation Manager', 'aiomatic-automatic-ai-content-writer') . '</h1>';
            echo '<div id="aiomatic_chat_history" class="ai-chat form-control" title="Click on a bubble to copy its content!">
            <table class="form-table">';
            echo '<tbody>';
            echo '<tr>';
            echo '<td>' . $conv_meta . '</td>';
            echo '</tr>';
            echo '</tbody>';
            echo '</table></div>';
            $zcurrent_page = preg_replace('#&action=view_meta#', '', $current_page);
            $zcurrent_page = preg_replace('#&conv_id=([^&]*?)&#', '&', $zcurrent_page);
            echo '<a href="' . $zcurrent_page . '" class="button">' . esc_html__('Back to List', 'aiomatic-automatic-ai-content-writer') . '</a>';
            echo '</div>';
        }
        elseif ( $action == 'download_meta' ) 
        {
            $conv_meta = get_user_meta($user_id, 'aiomatic_chat_history' . $conv_id, true);
            $conv_meta = str_replace('<div class="ai-bubble ai-mine">', 'User: ', $conv_meta);
            $conv_meta = str_replace('<div class="ai-bubble ai-other">', 'AI: ', $conv_meta);
            $conv_meta = str_replace('</div>', '\r\n', $conv_meta);
            $conv_meta = str_replace('<br>', '\r\n', $conv_meta);
            echo '<script type="text/javascript">function aiomatic_toBinary(string) {
                const codeUnits = Uint16Array.from(
                { length: string.length },
                (element, index) => string.charCodeAt(index)
                );
                const charCodes = new Uint8Array(codeUnits.buffer);
            
                let result = "";
                charCodes.forEach((char) => {
                result += String.fromCharCode(char);
                });
                return result;
            }try{var blists = aiomatic_toBinary("' . str_replace('"', '\"', $conv_meta) . '");var encodedString = btoa(blists);var hiddenElement = document.createElement(\'a\');hiddenElement.href = \'data:text/attachment;base64,\' + encodedString;hiddenElement.target = \'_blank\';hiddenElement.download = \'chat-log-' . $user_id . '.txt\';hiddenElement.click();}catch(e){alert(e);}</script>';
            $zcurrent_page = preg_replace('#&action=download_meta#', '', $current_page);
            $zcurrent_page = preg_replace('#&conv_id=([^&]*?)&#', '&', $zcurrent_page);
            echo '<a href="' . $zcurrent_page . '" class="button">' . esc_html__('Back to List', 'aiomatic-automatic-ai-content-writer') . '</a>';
        }
    }
}
?>
</div>
</div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings", 'aiomatic-automatic-ai-content-writer');?>"/></p></div>
    </form>
</div>
<hr/>
    <div>
    <h2 class="cr_image_center"><?php echo esc_html__("Chatbot Preview", 'aiomatic-automatic-ai-content-writer');?></h2>
<?php
echo aiomatic_chat_shortcode(array( 'temperature' => '', 'top_p' => '', 'presence_penalty' => '', 'frequency_penalty' => '', 'model' => '', 'instant_response' => '', 'show_in_window' => 'off' ));
?>
    </div>
    <br/><br/>
    <hr/>
    <div class="cr_image_center"><?php echo esc_html__("To add the chat bot to your website, please include the shortcode [aiomatic-chat-form] in the desired location on your site.", 'aiomatic-automatic-ai-content-writer');?></div>
</div>
<?php
}
?>