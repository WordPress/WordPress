<?php
defined('ABSPATH') or die();
function aiomatic_write_content($prompt, $model, $temperature, $max_p, $presence_penalty, $frequency_penalty, $max_tokens, $token)
{
    $new_post_content = false;
    $query_token_count = count(aiomatic_encode($prompt));
	$available_tokens = $max_tokens - $query_token_count;
	if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
	{
		$string_len = strlen($prompt);
		$string_len = $string_len / 2;
		$string_len = intval(0 - $string_len);
		$aicontent = aiomatic_substr($prompt, 0, $string_len);
		$aicontent = trim($aicontent);
		if(empty($aicontent))
		{
			wp_send_json_error( array( 'message' => 'Incorrect prompt provided!' ) );
		}
		$query_token_count = count(aiomatic_encode($aicontent));
		$available_tokens = $max_tokens - $query_token_count;
	}
	$aierror = '';
	$finish_reason = '';
	$generated_text = aiomatic_generate_text($token, $model, $prompt, $available_tokens, $temperature, $max_p, $presence_penalty, $frequency_penalty, false, 'topicContentWriter', 0, $finish_reason, $aierror);
	if($generated_text === false)
	{
		aiomatic_log_to_file('Failed to generate content using AI writer: ' . $model . ' - error: ' . $aierror);
	}
	else
	{
		$new_post_content = trim(trim(trim($generated_text), '"\''));
        if(empty($new_post_content))
        {
            aiomatic_log_to_file('No content returned by the AI writer: ' . $model . ' - prompt: ' . $prompt);
            return false;
        }
	}
    return $new_post_content;
}
function aiomatic_replacetopics($prompt, $title, $language, $writing_style, $writing_tone, $topics, $sections, $current_section, $sections_count, $paragraph_count, $post_title_keywords, $custom_shortcodes)
{
    $blog_title = html_entity_decode(get_bloginfo('title'));
    $prompt = str_replace('%%topic%%', $topics, $prompt);
    $prompt = str_replace('%%title%%', $title, $prompt);
    $prompt = str_replace('%%post_title_keywords%%', $post_title_keywords, $prompt);
    $prompt = str_replace('%%post_original_title%%', $title, $prompt);
    $prompt = str_replace('%%blog_title%%', $blog_title, $prompt);
    $prompt = str_replace('%%language%%', $language, $prompt);
    $prompt = str_replace('%%writing_style%%', $writing_style, $prompt);
    $prompt = str_replace('%%writing_tone%%', $writing_tone, $prompt);
    $prompt = str_replace('%%sections%%', $sections, $prompt);
    $prompt = str_replace('%%current_section%%', $current_section, $prompt);
    $prompt = str_replace('%%sections_count%%', $sections_count, $prompt);
    $prompt = str_replace('%%paragraphs_per_section%%', $paragraph_count, $prompt);
    $prompt = str_replace('%%random_sentence%%', aiomatic_random_sentence_generator(), $prompt);
    $prompt = str_replace('%%random_sentence2%%', aiomatic_random_sentence_generator(false), $prompt);  
    $prompt = aiomatic_replaceSynergyShortcodes($prompt);

    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        aiomatic_log_to_file('You need to insert a valid OpenAI/AiomaticAPI API Key for the custom shortcode creator to work!');
    }
    else
    {
        $allmodels = aiomatic_get_all_models();
        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
        $appids = array_filter($appids);
        $token = $appids[array_rand($appids)];
        $custom_shortcodes = preg_split('/\r\n|\r|\n/', $custom_shortcodes);
        foreach($custom_shortcodes as $my_short)
        {
            $name_part = explode('=>', $my_short);
            if(isset($name_part[1]) && !empty(trim($name_part[1])))
            {
                $shortname = trim($name_part[0]);
                if(strstr($prompt, '%%' . $shortname . '%%'))
                {
                    $shortval = '';
                    $ai_part = explode('@@', $name_part[1]);
                    if(isset($ai_part[1]) && !empty(trim($ai_part[1])))
                    {
                        if(!in_array(trim($ai_part[0]), $allmodels))
                        {
                            $aimodel = 'text-davinci-003';
                        }
                        else
                        {
                            $aimodel = trim($ai_part[0]);
                        }
                        $ai_command = trim($ai_part[1]);
                        $max_tokens = aiomatic_get_max_tokens($aimodel);
                        $query_token_count = count(aiomatic_encode($ai_command));
                        $available_tokens = $max_tokens - $query_token_count;
                        if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                        {
                            $string_len = strlen($ai_command);
                            $string_len = $string_len / 2;
                            $string_len = intval(0 - $string_len);
                            $ai_command = aiomatic_substr($ai_command, 0, $string_len);
                            $ai_command = trim($ai_command);
                            $query_token_count = count(aiomatic_encode($ai_command));
                            $available_tokens = $max_tokens - $query_token_count;
                        }
                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                        {
                            $api_service = aiomatic_get_api_service($token);
                            aiomatic_log_to_file('Calling ' . $api_service . ' (' . $aimodel . ') for custom shortcode text: ' . $ai_command);
                        }
                        $aierror = '';
                        $finish_reason = '';
                        $temperature = 1;
                        $top_p = 1;
                        $presence_penalty = 0;
                        $frequency_penalty = 0;
                        $generated_text = aiomatic_generate_text($token, $aimodel, $ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'customShortcode', 0, $finish_reason, $aierror);
                        if($generated_text === false)
                        {
                            aiomatic_log_to_file('Custom shortcode generator error: ' . $aierror);
                        }
                        else
                        {
                            $shortval = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                        }
                    }
                    $prompt = str_replace('%%' . $shortname . '%%', $shortval, $prompt);
                }
            }
        }
    }
    $prompt = apply_filters('aiomatic_replace_aicontent_shortcode', $prompt);
    return $prompt;
}
function aiomatic_get_royalty_free_image($query_words, $enable_ai_images, $image_size, &$images_arr, $token, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $custom_shortcodes)
{
    $ret_image = false;
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if(count($images_arr) > 0)
    {
        $first_el = array_shift($images_arr);
        $ret_image = $first_el;
    }
    elseif($enable_ai_images == '1')
    {
        if(strlen($query_words) > 400)
        {
            $query_words = aiomatic_substr($query_words, 0, 400);
        }
        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
        {
            $api_service = aiomatic_get_api_service($token);
            aiomatic_log_to_file('Calling ' . $api_service . ' for image: ' . $query_words);
        }
        $aierror = '';
        $temp_get_imgs = aiomatic_generate_ai_image($token, 1, $query_words, $image_size, 'contentImageAI', false, 0, $aierror);
        if($temp_get_imgs !== false)
        {
            foreach($temp_get_imgs as $tmpimg)
            {
                $ret_image = $tmpimg;
            }
        }
        else
        {
            aiomatic_log_to_file('Failed to generate AI image: ' . $aierror);
        }
    }
    elseif($enable_ai_images == '2')
    {
        if(strlen($query_words) > 2000)
        {
            $query_words = aiomatic_substr($query_words, 0, 2000);
        }
        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
        {
            $api_service = 'Stability.AI';
            aiomatic_log_to_file('Calling ' . $api_service . ' for image: ' . $query_words);
        }
        if($image_size == '256x256')
        {
            $width = '512';
            $height = '512';
        }
        elseif($image_size == '512x512')
        {
            $width = '512';
            $height = '512';
        }
        elseif($image_size == '1024x1024')
        {
            $width = '1024';
            $height = '1024';
        }
        else
        {
            $width = '512';
            $height = '512';
        }
        $temp_get_imgs = aiomatic_generate_stability_image($query_words, $height, $width, 'contentStableImageAI', 0, false);
        if($temp_get_imgs !== false)
        {
            $ret_image = $temp_get_imgs[1];
        }
        else
        {
            aiomatic_log_to_file('Failed to generate Stability.AI image.');
        }
    }
    else
    {
        $image_query = aiomatic_extract_keyword($query_words, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $token, $custom_shortcodes);
        if(!empty($image_query))
        {
            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
            {
                aiomatic_log_to_file('Keyword "' . $image_query . '" extract from text: ' . $query_words);
            }
            $query_words = $image_query;
        }
        $temp_img_attr = '';
        $temp_get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $temp_img_attr, 10, false);
        if($temp_get_img == '' || $temp_get_img === false)
        {
            aiomatic_log_to_file('Failed to find royalty free image for: ' . $query_words);
        }
        else
        {
            $ret_image = $temp_get_img;
        }
    }
    return $ret_image;
}
function aiomatic_extract_keyword($image_query, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $token, $custom_shortcodes)
{
    $query_words = '';
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'textrazor')
    {
        if(isset($aiomatic_Main_Settings['textrazor_key']) && trim($aiomatic_Main_Settings['textrazor_key']) != '')
        {
            try
            {
                if(!class_exists('TextRazor'))
                {
                    require_once(dirname(__FILE__) . "/res/TextRazor.php");
                }
                TextRazorSettings::setApiKey(trim($aiomatic_Main_Settings['textrazor_key']));
                $textrazor = new TextRazor();
                $textrazor->addExtractor('entities');
                $response = $textrazor->analyze($image_query);
                if (isset($response['response']['entities'])) 
                {
                    foreach ($response['response']['entities'] as $entity) 
                    {
                        if(isset($entity['entityEnglishId']))
                        {
                            $query_words = $entity['entityEnglishId'];
                            if(!empty($query_words))
                            {
                                break;
                            }
                        }
                        else
                        {
                            $query_words = $entity['entityId'];
                            if(!empty($query_words))
                            {
                                break;
                            }
                        }
                    }
                }
            }
            catch(Exception $e)
            {
                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                    aiomatic_log_to_file('Failed to search for keywords using TextRazor (!): ' . $e->getMessage());
                }
            }
        }
    }
    elseif(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'openai')
    {
        if(isset($aiomatic_Main_Settings['keyword_prompts']) && trim($aiomatic_Main_Settings['keyword_prompts']) != '')
        {
            if(isset($aiomatic_Main_Settings['keyword_model']) && $aiomatic_Main_Settings['keyword_model'] != '')
            {
                $kw_model = $aiomatic_Main_Settings['keyword_model'];
            }
            else
            {
                $kw_model = 'text-davinci-003';
            }
            $title_ai_command = trim($aiomatic_Main_Settings['keyword_prompts']);
            $title_ai_command = preg_split('/\r\n|\r|\n/', $title_ai_command);
            $title_ai_command = array_filter($title_ai_command);
            if(count($title_ai_command) > 0)
            {
                $title_ai_command = $title_ai_command[array_rand($title_ai_command)];
            }
            else
            {
                $title_ai_command = '';
            }
            $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
            if(!empty($title_ai_command))
            {
                $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, '', $custom_shortcodes);
            }
            $title_ai_command = trim($title_ai_command);
            if (filter_var($title_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($title_ai_command, '.txt'))
            {
                $txt_content = aiomatic_get_web_page($title_ai_command);
                if ($txt_content !== FALSE) 
                {
                    $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                    $txt_content = array_filter($txt_content);
                    if(count($txt_content) > 0)
                    {
                        $txt_content = $txt_content[array_rand($txt_content)];
                        if(trim($txt_content) != '') 
                        {
                            $title_ai_command = $txt_content;
                            $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                            $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, '', $custom_shortcodes);
                        }
                    }
                }
            }
            if(empty($title_ai_command))
            {
                aiomatic_log_to_file('Empty API keyword extractor seed expression provided!');
                $title_ai_command = 'Type the most relevant keyword, no other text before or after it, for a blog post titled:  ' . trim(strip_tags($image_query));
            }
            $max_seed_tokens = 1000;
            if(strlen($title_ai_command) > $max_seed_tokens * 4)
            {
                $title_ai_command = aiomatic_substr($title_ai_command, 0, (0 - ($max_seed_tokens * 4)));
            }
            $title_ai_command = trim($title_ai_command);
            if(empty($title_ai_command))
            {
                aiomatic_log_to_file('Empty API title seed expression provided(3)! ' . print_r($title_ai_command, true));
            }
            else
            {
                $max_tokens = 2048;
                $query_token_count = count(aiomatic_encode($title_ai_command));
                $available_tokens = $max_tokens - $query_token_count;
                if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                {
                    $string_len = strlen($title_ai_command);
                    $string_len = $string_len / 2;
                    $string_len = intval(0 - $string_len);
                    $title_ai_command = aiomatic_substr($title_ai_command, 0, $string_len);
                    $title_ai_command = trim($title_ai_command);
                    $query_token_count = count(aiomatic_encode($title_ai_command));
                    $available_tokens = $max_tokens - $query_token_count;
                }
                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                {
                    $api_service = aiomatic_get_api_service($token);
                    aiomatic_log_to_file('Calling ' . $api_service . ' (' . $kw_model . ') for title text: ' . $title_ai_command);
                }
                $aierror = '';
                $finish_reason = '';
                $temperature = 0;
                $top_p = 0;
                $presence_penalty = 0;
                $frequency_penalty = 0;
                $generated_text = aiomatic_generate_text($token, $kw_model, $title_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'keywordImg', 0, $finish_reason, $aierror);
                if($generated_text === false)
                {
                    aiomatic_log_to_file('Keyword generator error: ' . $aierror);
                }
                else
                {
                    $query_words = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                }
            }
        }
    }
    if(empty($query_words))
    {
        $keyword_class = new Aiomatic_keywords();
        $query_words = $keyword_class->keywords($image_query, 1);
    }
    return $query_words;
}
function aiomoatic_get_video($new_post_title)
{
    $retme = '';
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['yt_app_id']) && trim($aiomatic_Main_Settings['yt_app_id']) != '') {
        $items = array();
        $za_app = explode(',', $aiomatic_Main_Settings['yt_app_id']);
        $za_app = trim($za_app[array_rand($za_app)]);
        $feed_uri = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&key=' . $za_app;
        $feed_uri .= '&maxResults=10';
        $feed_uri .= '&q='.urlencode(trim(stripslashes(str_replace('&quot;', '"', $new_post_title))));
        $ch  = curl_init();
        if ($ch !== FALSE) {
            if (isset($aiomatic_Main_Settings['proxy_url']) && $aiomatic_Main_Settings['proxy_url'] != '') {
                curl_setopt($ch, CURLOPT_PROXY, $aiomatic_Main_Settings['proxy_url']);
                if (isset($aiomatic_Main_Settings['proxy_auth']) && $aiomatic_Main_Settings['proxy_auth'] != '') {
                    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $aiomatic_Main_Settings['proxy_auth']);
                }
            }
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            curl_setopt($ch, CURLOPT_HTTPGET, 1);
            curl_setopt($ch, CURLOPT_REFERER, get_site_url());
            curl_setopt($ch, CURLOPT_URL, $feed_uri);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            $exec = curl_exec($ch);
            curl_close($ch);
            if ($exec !== FALSE) {
                $json  = json_decode($exec);
                if(isset($json->items))
                {
                    $items = $json->items;
                    if (count($items) == 0) 
                    {
                        $feed_uri = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&key=' . $za_app;
                        $feed_uri .= '&maxResults=10';
                        $keyword_class = new Aiomatic_keywords();
                        $new_post_title = $keyword_class->keywords($new_post_title, 1);
                        $feed_uri .= '&q='.urlencode(trim(stripslashes(str_replace('&quot;', '"', $new_post_title))));
                        $ch  = curl_init();
                        if ($ch !== FALSE) {
                            if (isset($aiomatic_Main_Settings['proxy_url']) && $aiomatic_Main_Settings['proxy_url'] != '') {
                                curl_setopt($ch, CURLOPT_PROXY, $aiomatic_Main_Settings['proxy_url']);
                                if (isset($aiomatic_Main_Settings['proxy_auth']) && $aiomatic_Main_Settings['proxy_auth'] != '') {
                                    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $aiomatic_Main_Settings['proxy_auth']);
                                }
                            }
                            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                            curl_setopt($ch, CURLOPT_HTTPGET, 1);
                            curl_setopt($ch, CURLOPT_REFERER, get_site_url());
                            curl_setopt($ch, CURLOPT_URL, $feed_uri);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                            $exec = curl_exec($ch);
                            curl_close($ch);
                            if ($exec === FALSE) {
                                $json  = json_decode($exec);
                                if(isset($json->items))
                                {
                                    $items = $json->items;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                        aiomatic_log_to_file('YouTube API returned error: ' . $exec);
                    }
                }
            }
        }
        if(isset($items[0]->id->videoId))
        {
            $rand_ind = array_rand($items);
            $video_id = $items[$rand_ind]->id->videoId;
            if (isset($aiomatic_Main_Settings['player_width']) && $aiomatic_Main_Settings['player_width'] !== '') {
                $width = esc_attr($aiomatic_Main_Settings['player_width']);
            }
            else
            {
                $width = 580;
            }
            if (isset($aiomatic_Main_Settings['player_height']) && $aiomatic_Main_Settings['player_height'] !== '') {
                $height = esc_attr($aiomatic_Main_Settings['player_height']);
            }
            else
            {
                $height = 380;
            }
            $retme = '<br/><br/><div class="automaticx-video-container"><iframe allow="autoplay" width="' . $width . '" height="' . $height . '" src="https://www.youtube.com/embed/' . $video_id . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>';
        }
    }
    else
    {
        $retme = aiomatic_get_youtube_video(trim(stripslashes(str_replace('&quot;', '"', $new_post_title))), '');
    }
    return $retme;
}
function aiomatic_run_rule($param, $auto = 1, $ret_content = 0)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        aiomatic_log_to_file('You need to insert a valid OpenAI/AiomaticAPI API Key for this to work!');
        return 'fail';
    }
	$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
    if($ret_content == 0)
    {
        $f = fopen(get_temp_dir() . 'aiomatic_' . $param, 'w');
        if($f !== false)
        {
            $flock_disabled = explode(',', ini_get('disable_functions'));
            if(!in_array('flock', $flock_disabled))
            {
                if (!flock($f, LOCK_EX | LOCK_NB)) {
                    return 'nochange';
                }
            }
        }
        
        $GLOBALS['wp_object_cache']->delete('aiomatic_running_list', 'options');
        if (!get_option('aiomatic_running_list')) {
            $running = array();
        } else {
            $running = get_option('aiomatic_running_list');
        }
        if (!empty($running)) {
            if (in_array($param, $running)) {
                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                    aiomatic_log_to_file('Only one instance of this rule is allowed. Rule is already running!');
                }
                return 'nochange';
            }
        }
        $running[] = $param;
        update_option('aiomatic_running_list', $running, false);
        register_shutdown_function('aiomatic_clear_flag_at_shutdown', $param);
        if (isset($aiomatic_Main_Settings['rule_timeout']) && $aiomatic_Main_Settings['rule_timeout'] != '') {
            $timeout = intval($aiomatic_Main_Settings['rule_timeout']);
        } else {
            $timeout = 3600;
        }
        ini_set('safe_mode', 'Off');
        ini_set('max_execution_time', $timeout);
        ini_set('ignore_user_abort', 1);
        ini_set('user_agent', aiomatic_get_random_user_agent());
        if(function_exists('ignore_user_abort'))
        {
            ignore_user_abort(true);
        }
                if(function_exists('set_time_limit'))
        {
            set_time_limit($timeout);
        }
    }
    if (isset($aiomatic_Main_Settings['player_width']) && $aiomatic_Main_Settings['player_width'] !== '') {
        $width = esc_attr($aiomatic_Main_Settings['player_width']);
    }
    else
    {
        $width = 580;
    }
    if (isset($aiomatic_Main_Settings['player_height']) && $aiomatic_Main_Settings['player_height'] !== '') {
        $height = esc_attr($aiomatic_Main_Settings['player_height']);
    }
    else
    {
        $height = 380;
    }
    $posts_inserted         = 0;
    if (isset($aiomatic_Main_Settings['aiomatic_enabled']) && $aiomatic_Main_Settings['aiomatic_enabled'] == 'on') {
        try 
        {
            $old_title        = '';
            $cont             = 0;
            $found            = 0;
            $enable_comments  = '1';
            $enable_pingback  = '1';
            $ai_command       = '';
            $headings         = '';
            $images           = '';
            $videos           = '';
            $max              = PHP_INT_MAX;
            $post_title       = '';
            $default_category = '';
            $extra_categories = '';
            $min_char         = '1';
            $post_status     = 'publish';
            $remove_default  = '';
            $title_ai_command = '';
            $strip_title     = '';
            $title_source    = '';
            $headings_ai_command = '';
            $title_once      = '';
            $category_model  = 'text-davinci-003';
            $category_ai_command  = '';
            $custom_shortcodes= '';
            $strip_by_regex  = '';
            $strip_by_regex_prompts = '';
            $replace_regex   = '';
            $replace_regex_prompts = '';
            $run_regex_on    = '';
            $max_links       = '';
            $link_post_types = 'post';
            $enable_toc      = '';
            $tag_model       = 'text-davinci-003';
            $tag_ai_command  = '';
            $min_time        = '';
            $max_time        = '';
            $skip_spin       = '';
            $skip_translate  = '';
            $title_model     = 'text-davinci-003';
            $post_type       = 'post';
            $accept_comments = 'closed';
            $post_user_name  = 1;
            $item_create_tag = '';
            $can_create_tag  = 'disabled';
            $item_tags       = '';
            $max             = 50;
            $auto_categories = 'disabled';
            $custom_fields   = '';
            $custom_tax      = '';
            $temperature     = '';
            $post_prepend    = '';
            $post_append     = '';
            $enable_ai_images = '';
            $top_p           = '';
            $presence_penalty = '';
            $frequency_penalty = '';
            $royalty_free    = '';
            $image_size      = '256x256';
            $headings_list   = '';
            $images_list     = '';
            $headings_model  = 'text-davinci-003';
            $wpml_lang       = '';
            $post_format     = 'post-format-standard';
            $post_array      = array();
            $max_tokens      = AIOMATIC_DEFAULT_MAX_TOKENS;
            $max_seed_tokens = 1000;
            $posting_mode    = 'title';
            $post_topic_list = '';
            $post_sections_list = '';
            $content_language = '';
            $writing_style   = '';
            $writing_tone    = '';
            $sections_prompt = '';
            $title_prompt    = '';
            $content_prompt  = '';
            $excerpt_prompt  = '';
            $section_count   = '';
            $paragraph_count = '';
            $topic_title_model = '';
            $topic_sections_model = '';
            $topic_content_model = '';
            $topic_excerpt_model = '';
            $single_content_call = '';
            $intro_prompt    = '';
            $topic_intro_model = 'text-davinci-003';
            $outro_prompt    = '';
            $topic_outro_model = 'text-davinci-003';
            $model           = 'text-davinci-003';
            $topic_qa_model  = 'text-davinci-003';
            $topic_images    = '';
            $qa_prompt       = '';
            $topic_videos    = '';
            $title_toc       = '';
            $title_qa        = '';
            $title_outro     = '';
            $enable_qa       = '';
            $sections_role   = '';
            $rule_description = '';
            $max_continue_tokens = 500;
            $GLOBALS['wp_object_cache']->delete('aiomatic_rules_list', 'options');
            if (!get_option('aiomatic_rules_list')) {
                $rules = array();
            } else {
                $rules = get_option('aiomatic_rules_list');
            }
            if (!empty($rules)) {
                foreach ($rules as $request => $bundle[]) {
                    if ($cont == $param) {
                        $bundle_values    = array_values($bundle);
                        $myValues         = $bundle_values[$cont];
                        $array_my_values  = array_values($myValues);for($iji=0;$iji<count($array_my_values);++$iji){if(is_string($array_my_values[$iji])){$array_my_values[$iji]=stripslashes($array_my_values[$iji]);}}
                        $schedule         = isset($array_my_values[0]) ? $array_my_values[0] : '';
                        $active           = isset($array_my_values[1]) ? $array_my_values[1] : '';
                        $last_run         = isset($array_my_values[2]) ? $array_my_values[2] : '';
                        $max              = isset($array_my_values[3]) ? $array_my_values[3] : '';
                        $post_status      = isset($array_my_values[4]) ? $array_my_values[4] : '';
                        $post_type        = isset($array_my_values[5]) ? $array_my_values[5] : '';
                        $post_user_name   = isset($array_my_values[6]) ? $array_my_values[6] : '';
                        $item_create_tag  = isset($array_my_values[7]) ? $array_my_values[7] : '';
                        $default_category = isset($array_my_values[8]) ? $array_my_values[8] : '';
                        $auto_categories  = isset($array_my_values[9]) ? $array_my_values[9] : '';
                        $can_create_tag   = isset($array_my_values[10]) ? $array_my_values[10] : '';
                        $enable_comments  = isset($array_my_values[11]) ? $array_my_values[11] : '';
                        $image_url        = isset($array_my_values[12]) ? $array_my_values[12] : '';
                        $post_title       = isset($array_my_values[13]) ? htmlspecialchars_decode($array_my_values[13]) : '';
                        $enable_pingback  = isset($array_my_values[14]) ? $array_my_values[14] : '';
                        $post_format      = isset($array_my_values[15]) ? $array_my_values[15] : '';
                        $min_char         = isset($array_my_values[16]) ? $array_my_values[16] : '';
                        $custom_fields    = isset($array_my_values[17]) ? $array_my_values[17] : '';
                        $custom_tax       = isset($array_my_values[18]) ? $array_my_values[18] : '';
                        $temperature      = isset($array_my_values[19]) ? $array_my_values[19] : '';
                        $top_p            = isset($array_my_values[20]) ? $array_my_values[20] : '';
                        $presence_penalty = isset($array_my_values[21]) ? $array_my_values[21] : '';
                        $frequency_penalty = isset($array_my_values[22]) ? $array_my_values[22] : '';
                        $royalty_free     = isset($array_my_values[23]) ? $array_my_values[23] : '';
                        $ai_command       = isset($array_my_values[24]) ? $array_my_values[24] : '';
                        $max_tokens       = isset($array_my_values[25]) ? $array_my_values[25] : AIOMATIC_DEFAULT_MAX_TOKENS;
                        $max_seed_tokens  = isset($array_my_values[26]) ? $array_my_values[26] : 1000;
                        $max_continue_tokens= isset($array_my_values[27]) ? $array_my_values[27] : 500;
                        $model            = isset($array_my_values[28]) ? $array_my_values[28] : 'text-davinci-003';
                        $headings         = isset($array_my_values[29]) ? $array_my_values[29] : '';
                        $images           = isset($array_my_values[30]) ? $array_my_values[30] : '';
                        $videos           = isset($array_my_values[31]) ? $array_my_values[31] : '';
                        $post_prepend     = isset($array_my_values[32]) ? $array_my_values[32] : '';
                        $post_append      = isset($array_my_values[33]) ? $array_my_values[33] : '';
                        $enable_ai_images = isset($array_my_values[34]) ? $array_my_values[34] : '';
                        $ai_command_image = isset($array_my_values[35]) ? $array_my_values[35] : '';
                        $image_size       = isset($array_my_values[36]) ? $array_my_values[36] : '';
                        $headings_list    = isset($array_my_values[37]) ? $array_my_values[37] : '';
                        $images_list      = isset($array_my_values[38]) ? $array_my_values[38] : '';
                        $wpml_lang        = isset($array_my_values[39]) ? $array_my_values[39] : '';
                        $remove_default   = isset($array_my_values[40]) ? $array_my_values[40] : '';
                        $title_model      = isset($array_my_values[41]) ? $array_my_values[41] : 'text-davinci-003';
                        $title_ai_command = isset($array_my_values[42]) ? $array_my_values[42] : '';
                        $strip_title      = isset($array_my_values[43]) ? $array_my_values[43] : '';
                        $title_once       = isset($array_my_values[44]) ? $array_my_values[44] : '';
                        $category_model   = isset($array_my_values[45]) ? $array_my_values[45] : 'text-davinci-003';
                        $category_ai_command= isset($array_my_values[46]) ? $array_my_values[46] : '';
                        $tag_model        = isset($array_my_values[47]) ? $array_my_values[47] : 'text-davinci-003';
                        $tag_ai_command   = isset($array_my_values[48]) ? $array_my_values[48] : '';
                        $min_time         = isset($array_my_values[49]) ? $array_my_values[49] : '';
                        $max_time         = isset($array_my_values[50]) ? $array_my_values[50] : '';
                        $skip_spin        = isset($array_my_values[51]) ? $array_my_values[51] : '';
                        $skip_translate   = isset($array_my_values[52]) ? $array_my_values[52] : '';
                        $title_source     = isset($array_my_values[53]) ? $array_my_values[53] : '';
                        $headings_ai_command= isset($array_my_values[54]) ? $array_my_values[54] : '';
                        $headings_model   = isset($array_my_values[55]) ? $array_my_values[55] : 'text-davinci-003';
                        $posting_mode     = isset($array_my_values[56]) ? $array_my_values[56] : 'title';
                        $post_topic_list  = isset($array_my_values[57]) ? $array_my_values[57] : '';
                        $post_sections_list= isset($array_my_values[58]) ? $array_my_values[58] : '';
                        $content_language = isset($array_my_values[59]) ? $array_my_values[59] : '';
                        $writing_style    = isset($array_my_values[60]) ? $array_my_values[60] : '';
                        $writing_tone     = isset($array_my_values[61]) ? $array_my_values[61] : '';
                        $title_prompt     = isset($array_my_values[62]) ? $array_my_values[62] : '';
                        $sections_prompt  = isset($array_my_values[63]) ? $array_my_values[63] : '';
                        $content_prompt   = isset($array_my_values[64]) ? $array_my_values[64] : '';
                        $excerpt_prompt   = isset($array_my_values[65]) ? $array_my_values[65] : '';
                        $section_count    = isset($array_my_values[66]) ? $array_my_values[66] : '';
                        $paragraph_count  = isset($array_my_values[67]) ? $array_my_values[67] : '';
                        $topic_title_model = isset($array_my_values[68]) ? $array_my_values[68] : 'text-davinci-003';
                        $topic_sections_model  = isset($array_my_values[69]) ? $array_my_values[69] : 'text-davinci-003';
                        $topic_content_model  = isset($array_my_values[70]) ? $array_my_values[70] : 'text-davinci-003';
                        $topic_excerpt_model  = isset($array_my_values[71]) ? $array_my_values[71] : 'text-davinci-003';
                        $single_content_call  = isset($array_my_values[72]) ? $array_my_values[72] : '';
                        $intro_prompt         = isset($array_my_values[73]) ? $array_my_values[73] : '';
                        $topic_intro_model    = isset($array_my_values[74]) ? $array_my_values[74] : 'text-davinci-003';
                        $outro_prompt         = isset($array_my_values[75]) ? $array_my_values[75] : '';
                        $topic_outro_model    = isset($array_my_values[76]) ? $array_my_values[76] : 'text-davinci-003';
                        $topic_images         = isset($array_my_values[77]) ? $array_my_values[77] : '';
                        $sections_role        = isset($array_my_values[78]) ? $array_my_values[78] : '';
                        $topic_videos         = isset($array_my_values[79]) ? $array_my_values[79] : '';
                        $rule_description     = isset($array_my_values[80]) ? $array_my_values[80] : '';
                        $custom_shortcodes    = isset($array_my_values[81]) ? $array_my_values[81] : '';
                        $strip_by_regex       = isset($array_my_values[82]) ? $array_my_values[82] : '';
                        $replace_regex        = isset($array_my_values[83]) ? $array_my_values[83] : '';
                        $strip_by_regex_prompts= isset($array_my_values[84]) ? $array_my_values[84] : '';
                        $replace_regex_prompts= isset($array_my_values[85]) ? $array_my_values[85] : '';
                        $run_regex_on     = isset($array_my_values[86]) ? $array_my_values[86] : '';
                        $max_links        = isset($array_my_values[87]) ? $array_my_values[87] : '';
                        $link_post_types  = isset($array_my_values[88]) ? $array_my_values[88] : '';
                        $enable_toc       = isset($array_my_values[89]) ? $array_my_values[89] : '';
                        $title_toc        = isset($array_my_values[90]) ? $array_my_values[90] : '';
                        $qa_prompt        = isset($array_my_values[91]) ? $array_my_values[91] : '';
                        $topic_qa_model   = isset($array_my_values[92]) ? $array_my_values[92] : 'text-davinci-003';
                        $enable_qa        = isset($array_my_values[93]) ? $array_my_values[93] : '';
                        $title_qa         = isset($array_my_values[94]) ? $array_my_values[94] : '';
                        $title_outro      = isset($array_my_values[95]) ? $array_my_values[95] : '';
                        $found            = 1;
                        break;
                    }
                    $cont = $cont + 1;
                }
            } else {
                aiomatic_log_to_file('No rules found for aiomatic_rules_list!');
                if($auto == 1)
                {
                    aiomatic_clearFromList($param);
                }
                return 'fail';
            }
            $inboundlinker = null;
            if($max_links !== '')
            {
                preg_match_all('#\s*(\d+)\s*-\s*(\d+)\s*#', $max_links, $mxatches);
                if(isset($mxatches[2][0]))
                {
                    $min_l = $mxatches[1][0];
                    $max_l = $mxatches[2][0];
                    $max_links = rand(intval($min_l), intval($max_l));
                }
                else
                {
                    $max_links = intval($max_links);
                }
                require_once(dirname(__FILE__) . "/res/InboundLinks.php");
                $inboundlinker = new AiomaticAutoInboundLinks();
            }
            if(empty($max_tokens) || intval($max_tokens) <= 0)
            {
                $max_tokens = AIOMATIC_DEFAULT_MAX_TOKENS;
            }
            if(intval($max_tokens) > AIOMATIC_DEFAULT_MAX_TOKENS && ((!stristr($model, 'davinci') && !stristr($model, 'gpt')) || strstr($model, ':ft-') === true))
            {
                $max_tokens = AIOMATIC_DEFAULT_MAX_TOKENS;
            }
            if($max_seed_tokens === '')
            {
                $max_seed_tokens = 1000;
            }
            if($max_continue_tokens === '')
            {
                $max_continue_tokens = 500;
            }
            if ($found == 0) {
                aiomatic_log_to_file($param . ' not found in aiomatic_rules_list!');
                if($auto == 1)
                {
                    aiomatic_clearFromList($param);
                }
                return 'fail';
            } else {
                if($ret_content == 0)
                {
                    $GLOBALS['wp_object_cache']->delete('aiomatic_rules_list', 'options');
                    $rules = get_option('aiomatic_rules_list');
                    $rules[$param][2] = aiomatic_get_date_now();
                    update_option('aiomatic_rules_list', $rules, false);
                }
            }
            if ($enable_comments == '1') {
                $accept_comments = 'open';
            }
            $count = 1;
            if($temperature == '')
            {
                $temperature = 1;
            }
            else
            {
                $temperature = floatval($temperature);
            }
            if($top_p == '')
            {
                $top_p = 1;
            }
            else
            {
                $top_p = floatval($top_p);
            }
            if($frequency_penalty == '')
            {
                $frequency_penalty = 0;
            }
            else
            {
                $frequency_penalty = floatval($frequency_penalty);
            }
            if($presence_penalty == '')
            {
                $presence_penalty = 0;
            }
            else
            {
                $presence_penalty = floatval($presence_penalty);
            }
            $max_tokens = intval($max_tokens);
            $max_seed_tokens = intval($max_seed_tokens);
            $max_continue_tokens = intval($max_continue_tokens);
            $blog_title       = html_entity_decode(get_bloginfo('title'));
            $post_title = aiomatic_replaceSynergyShortcodes($post_title);
            if($post_title != '')
            {
                $post_title_lines = preg_split('/\r\n|\r|\n/', $post_title);
            }
            else
            {
                $post_title_lines = array();
            }
            $additional_kws = array();
            $post_link = '';
            $user_name        = '';
            $featured_image   = '';
            $post_cats = '';
            $post_tagz = '';
            $post_excerpt = '';
            $final_content = '';
            $postID = '';
            $heading_val = '';
            $image_query = '';
            $temp_post = '';
            $cntx = count($post_title_lines);
            $rss_feeds = array();
            for($ji = 0; $ji < $cntx; $ji++)
            {
                if (filter_var($post_title_lines[$ji], FILTER_VALIDATE_URL) !== false) 
                {
                    if(aiomatic_endsWith($post_title_lines[$ji], '.txt'))
                    {
                        $txt_content = aiomatic_get_web_page($post_title_lines[$ji]);
                        if ($txt_content === FALSE) 
                        {
                            aiomatic_log_to_file('Failed to read text file: ' . $post_title_lines[$ji]);
                            if($auto == 1)
                            {
                                aiomatic_log_to_file($param);
                            }
                            continue;
                        }
                        unset($post_title_lines[$ji]);
                        $additional_kws = preg_split('/\r\n|\r|\n/', $txt_content);
                    }
                    else
                    {
                        aiomatic_log_to_file('Trying to parse RSS feed items: ' . $post_title_lines[$ji]);
                        try
                        {
                            if(!class_exists('SimplePie_Autoloader', false))
                            {
                                require_once(dirname(__FILE__) . "/res/simplepie/autoloader.php");
                            }
                        }
                        catch(Exception $e) 
                        {
                            aiomatic_log_to_file('Exception thrown in SimplePie autoloader: ' . $e->getMessage());
                            if($auto == 1)
                            {
                                aiomatic_log_to_file($param);
                            }
                            continue;
                        }
                        $feed = new SimplePie();
                        $feed->set_timeout(120);
                        $feed->set_feed_url($post_title_lines[$ji]);
                        $feed->enable_cache(false);
                        $feed->strip_htmltags(false);
                        $feed->init();
                        $feed->handle_content_type();
                        if ($feed->error()) 
                        {
                            aiomatic_log_to_file('Error in parsing RSS feed: ' . $feed->error() . ' for ' . $post_title_lines[$ji]);
                            if($auto == 1)
                            {
                                aiomatic_clearFromList($param);
                            }
                            continue;
                        }
                        $items = $feed->get_items();
                        $zero = true;
                        foreach($items as $itemx)
                        {
                            if($zero == true)
                            {
                                $post_link = trim($itemx->get_permalink());
                                if ($fauthor = $itemx->get_author()) 
                                {
                                    $user_name = $fauthor->get_name();
                                }
                                else
                                {
                                    $user_name = '';
                                }
                                $feed_cats = array();
                                if(isset($itemx->category))
                                {
                                    foreach($itemx->category as $cata)
                                    {
                                        $feed_cats[] = $cata->__toString();
                                    }
                                    if(count($feed_cats) == 0)
                                    {
                                        $feed_cats[] = $itemx->category->__toString();
                                    }
                                    $post_cats = implode(',', $feed_cats);
                                }
                                else
                                {
                                    $post_cats = '';
                                }
                                $post_excerpt = $itemx->get_description();
                                $final_content = $itemx->get_content();
                                $rss_feeds[$itemx->get_title()] = array('url' => $post_link, 'author' => $user_name,  'cats' => $post_cats, 'excerpt' => $post_excerpt, 'content' => $final_content );
                            }
                            else
                            {
                                $post_link_temp = trim($itemx->get_permalink());
                                if ($fauthor = $itemx->get_author()) 
                                {
                                    $user_name_temp = $fauthor->get_name();
                                }
                                else
                                {
                                    $user_name_temp = '';
                                }
                                $feed_cats = array();
                                if(isset($itemx->category))
                                {
                                    foreach($itemx->category as $cata)
                                    {
                                        $feed_cats[] = $cata->__toString();
                                    }
                                    if(count($feed_cats) == 0)
                                    {
                                        $feed_cats[] = $itemx->category->__toString();
                                    }
                                    $post_cats_temp = implode(',', $feed_cats);
                                }
                                else
                                {
                                    $post_cats_temp = '';
                                }
                                $post_excerpt_temp = $itemx->get_description();
                                $final_content_temp = $itemx->get_content();
                                $rss_feeds[$itemx->get_title()] = array('url' => $post_link_temp, 'author' => $user_name_temp,  'cats' => $post_cats_temp, 'excerpt' => $post_excerpt_temp, 'content' => $final_content_temp );
                            }
                            $additional_kws[] = $itemx->get_title();
                            $zero = false;
                        }
                        unset($post_title_lines[$ji]);
                    }
                }
            }
            if(count($additional_kws) > 0)
            {
                $post_title_lines = array_merge($post_title_lines, $additional_kws);
            }
            if($title_once == '1')
            {
                $posted_items = array();
                $postsPerPage = 50000;
                $paged = 0;
                wp_suspend_cache_addition(true);
                $post_stati = get_post_stati();
                foreach ($post_stati as $key => $val) {
                    if ($val == 'auto-draft') {
                        unset($post_stati[$key]);
                    }
                    if ($val == 'inherit') {
                        unset($post_stati[$key]);
                    }
                    if ($val == 'request-pending') {
                        unset($post_stati[$key]);
                    }
                    if ($val == 'request-confirmed') {
                        unset($post_stati[$key]);
                    }
                    if ($val == 'request-failed') {
                        unset($post_stati[$key]);
                    }
                    if ($val == 'request-completed') {
                        unset($post_stati[$key]);
                    }
                    if ($val == 'future') {
                        unset($post_stati[$key]);
                    }
                }
                do
                {
                    $postOffset = $paged * $postsPerPage;
                    $query     = array(
                        'post_status' => $post_stati,
                        'post_type' => array(
                            'any'
                        ),
                        'numberposts' => $postsPerPage,
                        'fields' => 'ids',
                        'meta_key' => 'aiomatic_source_title',
                        'offset'  => $postOffset
                    );
                    $post_list = get_posts($query);
                    foreach ($post_list as $post) {
                        $orig_tit = get_post_meta($post, 'aiomatic_source_title', true);
                        if(!empty($orig_tit))
                        {
                            $posted_items[$orig_tit] = $post;
                        }
                    }
                    $paged++;
                }while(!empty($post_list));
                wp_suspend_cache_addition(false);
                unset($post_list);
                $post_title_lines_processed = array();
                foreach($post_title_lines as $ptl)
                {
                    $ptlprocessed = explode('!###!', $ptl);
                    if(isset($ptlprocessed[1]) && !empty($ptlprocessed[1]) && !empty($ptlprocessed[0]))
                    {
                        $post_title_lines_processed[] = $ptlprocessed[0];
                    }
                    else
                    {
                        $post_title_lines_processed[] = $ptl;
                    }
                }
                foreach($posted_items as $ptit => $pid)
                {
                    if (($key = array_search($ptit, $post_title_lines_processed)) !== false) {
                        aiomatic_log_to_file('Skipping title, already processed: ' . $ptit);
                        unset($post_title_lines[$key]);
                        unset($post_title_lines_processed[$key]);
                    }
                }
            }
            $spintax = new AIomatic_Spintax();
            $orig_ai_command = $ai_command;
            $orig_ai_command_title = $title_ai_command;
            $orig_ai_command_category = $category_ai_command;
            $orig_ai_command_tag = $tag_ai_command;
            $orig_ai_command_image = $ai_command_image;
            $already_spinned = 0;
            if(isset($aiomatic_Main_Settings['attr_text']) && $aiomatic_Main_Settings['attr_text'] != '')
            {
                $img_attr = $aiomatic_Main_Settings['attr_text'];
            }
            else
            {
                $img_attr = '';
            }
            if($headings_list != '')
            {
                $headings_arr_temp = preg_split('/\r\n|\r|\n/', $headings_list);
                $headings_arr_temp = array_map('trim', $headings_arr_temp);
                $headings_arr = array();
                foreach($headings_arr_temp as $hat)
                {
                    $hat = aiomatic_replaceSynergyShortcodes($hat);
                    $hat = replaceAIPostShortcodes($hat, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, '', $custom_shortcodes);
                    $headings_arr[] = array('q' => $hat, 'a' => '');
                }
            }
            else
            {
                $headings_arr = array();
            }
            if($images_list != '')
            {
                $images_arr = preg_split('/\r\n|\r|\n/', $images_list);
                $images_arr = array_map('trim', $images_arr);
            }
            else
            {
                $images_arr = array();
            }
            while(true) 
            {
                $current_section = '';
                $post_sections = '';
                $post_topic = '';
                $post_title_keywords = '';
                if($posting_mode == 'topic')
                {
                    $post_topic_list_arr = preg_split('/\r\n|\r|\n/', $post_topic_list);
                    if($title_once == '1')
                    {
                        $posted_topics = array();
                        $postsPerPage = 50000;
                        $paged = 0;
                        wp_suspend_cache_addition(true);
                        $post_stati = get_post_stati();
                        foreach ($post_stati as $key => $val) {
                            if ($val == 'auto-draft') {
                                unset($post_stati[$key]);
                            }
                            if ($val == 'inherit') {
                                unset($post_stati[$key]);
                            }
                            if ($val == 'request-pending') {
                                unset($post_stati[$key]);
                            }
                            if ($val == 'request-confirmed') {
                                unset($post_stati[$key]);
                            }
                            if ($val == 'request-failed') {
                                unset($post_stati[$key]);
                            }
                            if ($val == 'request-completed') {
                                unset($post_stati[$key]);
                            }
                            if ($val == 'future') {
                                unset($post_stati[$key]);
                            }
                        }
                        do
                        {
                            $postOffset = $paged * $postsPerPage;
                            $query     = array(
                                'post_status' => $post_stati,
                                'post_type' => array(
                                    'any'
                                ),
                                'numberposts' => $postsPerPage,
                                'fields' => 'ids',
                                'meta_key' => 'aiomatic_post_topic',
                                'offset'  => $postOffset
                            );
                            $post_list = get_posts($query);
                            foreach ($post_list as $post) {
                                $aiomatic_post_topic = get_post_meta($post, 'aiomatic_post_topic', true);
                                if(!empty($aiomatic_post_topic))
                                {
                                    $posted_topics[$aiomatic_post_topic] = $post;
                                }
                            }
                            $paged++;
                        }while(!empty($post_list));
                        wp_suspend_cache_addition(false);
                        unset($post_list);
                        foreach($posted_topics as $ptit => $pid)
                        {
                            if(!strstr($ptit, '%%title%%'))
                            {
                                if (($key = array_search($ptit, $post_topic_list_arr)) !== false) 
                                {
                                    aiomatic_log_to_file('Skipping topic, already processed: ' . $ptit);
                                    unset($post_topic_list_arr[$key]);
                                }
                            }
                        }
                    }
                    if(count($post_topic_list_arr) == 0)
                    {
                        aiomatic_log_to_file('All topics already processed, nothing to do.');
                        if($auto == 1)
                        {
                            aiomatic_clearFromList($param);
                        }
                        return 'nochange';
                    }
                    $post_topic = $post_topic_list_arr[array_rand($post_topic_list_arr)];
                    $post_sections = '';
                    $current_section = '';
                    $headings_arr_copy = $headings_arr;
                    $added_img_list = array();
                    $added_vid_list = array();
                    $added_images = 0;
                    $added_videos = 0;
                    $heading_results = array();
                    if ($count > intval($max)) {
                        break;
                    }
                    if($title_prompt != '' & $post_topic_list != '')
                    {
                        $current_index = array_rand($post_title_lines);
                        $post_title = trim($post_title_lines[$current_index]);
                        $ptlprocessed = explode('!###!', $post_title);
                        if(isset($ptlprocessed[1]) && !empty($ptlprocessed[1]) && !empty($ptlprocessed[0]))
                        {
                            $post_title = $ptlprocessed[0];
                            $post_title_keywords = $ptlprocessed[1];
                        }
                        $post_title = apply_filters('aiomatic_replace_aicontent_shortcode', $post_title);
                        $title_prompt_arr = preg_split('/\r\n|\r|\n/', $title_prompt);
                        $my_title_prompt = $title_prompt_arr[array_rand($title_prompt_arr)];
                        $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                        $zatitle_prompt = aiomatic_replacetopics($my_title_prompt, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        if(stristr($run_regex_on, 'title') !== false)
                        {
                            if ($strip_by_regex_prompts !== '')
                            {
                                $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex_prompts);
                                $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex_prompts);
                                $xcnt = 0;
                                foreach($xstrip_by_regex as $sbr)
                                {
                                    if(isset($xreplace_regex[$xcnt]))
                                    {
                                        $repreg = $xreplace_regex[$xcnt];
                                    }
                                    else
                                    {
                                        $repreg = '';
                                    }
                                    $xcnt++;
                                    $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $zatitle_prompt);
                                    if($temp_cont !== NULL)
                                    {
                                        $zatitle_prompt = $temp_cont;
                                    }
                                }
                            }
                        }
                        if($zatitle_prompt != '')
                        {
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $topic_title_model . ') for topic title text: ' . $zatitle_prompt);
                            }
                            $written = aiomatic_write_content($zatitle_prompt, $topic_title_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $token);
                            if($written === false)
                            {
                                aiomatic_log_to_file('Failed to generate title!');
                                if($auto == 1)
                                {
                                    aiomatic_clearFromList($param);
                                }
                                return 'fail';
                            }
                            else
                            {
                                $post_title = $written;
                                if (!isset($aiomatic_Main_Settings['do_not_check_duplicates']) || $aiomatic_Main_Settings['do_not_check_duplicates'] != 'on') 
                                {
                                    $posts = get_posts(
                                        array(
                                            'post_type'              => $post_type,
                                            'title'                  => html_entity_decode($post_title),
                                            'post_status'            => 'all',
                                            'numberposts'            => 1,
                                            'update_post_term_cache' => false,
                                            'update_post_meta_cache' => false,           
                                            'orderby'                => 'post_date ID',
                                            'order'                  => 'ASC',
                                        )
                                    );
                                    if ( ! empty( $posts ) ) {
                                        $zap = $posts[0];
                                    } else {
                                        $zap = null;
                                    }
                                    if($zap !== null)
                                    {
                                        aiomatic_log_to_file('Post with specified AI generated title already published, skipping it: ' . $post_title);
                                        continue;
                                    }
                                }
                            }
                        }
                        else
                        {
                            aiomatic_log_to_file('Empty processed title prompt. Nothing to do.');
                            if($auto == 1)
                            {
                                aiomatic_clearFromList($param);
                            }
                            return 'fail';
                        }
                    }
                    else
                    {
                        if(count($post_title_lines) == 0)
                        {
                            break;
                        }
                        $current_index = array_rand($post_title_lines);
                        $post_title = trim($post_title_lines[$current_index]);
                        $ptlprocessed = explode('!###!', $post_title);
                        if(isset($ptlprocessed[1]) && !empty($ptlprocessed[1]) && !empty($ptlprocessed[0]))
                        {
                            $post_title = $ptlprocessed[0];
                            $post_title_keywords = $ptlprocessed[1];
                        }
                        if(isset($rss_feeds[$post_title]))
                        {
                            $post_link = $rss_feeds[$post_title]['url'];
                            $user_name = $rss_feeds[$post_title]['author'];
                            $post_cats = $rss_feeds[$post_title]['cats'];
                            $post_excerpt = $rss_feeds[$post_title]['excerpt'];
                            $final_content = $rss_feeds[$post_title]['content'];
                        }
                        $tprepp = $spintax->Parse($post_title);
                        if($tprepp != false && $tprepp != '')
                        {
                            $post_title = $tprepp;
                        }
                        $old_title = $post_title;
                        $already_spinned = 0;
                        if (filter_var($post_title, FILTER_VALIDATE_URL) === false && stristr($post_title, '%%ai_generated_title%%') === false)
                        {
                            unset($post_title_lines[$current_index]);
                        }
                        $post_title = apply_filters('aiomatic_replace_aicontent_shortcode', $post_title);
                        if (strpos($post_title, '%%') === false)
                        {
                            if (!isset($aiomatic_Main_Settings['do_not_check_duplicates']) || $aiomatic_Main_Settings['do_not_check_duplicates'] != 'on') 
                            {
                                $posts = get_posts(
                                    array(
                                        'post_type'              => $post_type,
                                        'title'                  => html_entity_decode($post_title),
                                        'post_status'            => 'all',
                                        'numberposts'            => 1,
                                        'update_post_term_cache' => false,
                                        'update_post_meta_cache' => false,           
                                        'orderby'                => 'post_date ID',
                                        'order'                  => 'ASC',
                                    )
                                );
                                if ( ! empty( $posts ) ) {
                                    $zap = $posts[0];
                                } else {
                                    $zap = null;
                                }
                                if($zap !== null)
                                {
                                    aiomatic_log_to_file('Post with specified title already existing, skipping it: ' . $post_title);
                                    unset($post_title_lines[$current_index]);
                                    continue;
                                }
                            }
                            $new_post_title = $post_title;
                        }
                        else
                        {
                            $new_post_title = $post_title;
                            $new_post_title = aiomatic_replaceContentShortcodes($new_post_title, $img_attr, $ai_command);
                            if (!isset($aiomatic_Main_Settings['do_not_check_duplicates']) || $aiomatic_Main_Settings['do_not_check_duplicates'] != 'on') 
                            {
                                $posts = get_posts(
                                    array(
                                        'post_type'              => $post_type,
                                        'title'                  => html_entity_decode($new_post_title),
                                        'post_status'            => 'all',
                                        'numberposts'            => 1,
                                        'update_post_term_cache' => false,
                                        'update_post_meta_cache' => false,           
                                        'orderby'                => 'post_date ID',
                                        'order'                  => 'ASC',
                                    )
                                );
                                if ( ! empty( $posts ) ) {
                                    $zap = $posts[0];
                                } else {
                                    $zap = null;
                                }
                                if($zap !== null)
                                {
                                    aiomatic_log_to_file('Post with specified title already published, skipping it: ' . $new_post_title);
                                    unset($post_title_lines[$current_index]);
                                    continue;
                                }
                            }
                        }
                    }
                    if(empty($post_title))
                    {
                        aiomatic_log_to_file('Empty post title submitted, nothing to do!');
                        continue;
                    }
                    if(stristr($run_regex_on, 'sections') !== false)
                    {
                        if ($strip_by_regex_prompts !== '')
                        {
                            $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex_prompts);
                            $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex_prompts);
                            $xcnt = 0;
                            foreach($xstrip_by_regex as $sbr)
                            {
                                if(isset($xreplace_regex[$xcnt]))
                                {
                                    $repreg = $xreplace_regex[$xcnt];
                                }
                                else
                                {
                                    $repreg = '';
                                }
                                $xcnt++;
                                $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $sections_prompt);
                                if($temp_cont !== NULL)
                                {
                                    $sections_prompt = $temp_cont;
                                }
                            }
                        }
                    }
                    if($sections_prompt != '' && $post_sections_list == '')
                    {
                        $sections_prompt_arr = preg_split('/\r\n|\r|\n/', $sections_prompt);
                        $my_post_section = $sections_prompt_arr[array_rand($sections_prompt_arr)];
                        $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                        $my_post_section = aiomatic_replacetopics($my_post_section, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        if($my_post_section != '')
                        {
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $topic_sections_model . ') for topic section text: ' . $my_post_section);
                            }
                            $written = aiomatic_write_content($my_post_section, $topic_sections_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $token);
                            if($written === false)
                            {
                                aiomatic_log_to_file('Failed to generate sections!');
                                if($auto == 1)
                                {
                                    aiomatic_clearFromList($param);
                                }
                                return 'fail';
                            }
                            else
                            {
                                $post_sections = $written;
                            }
                        }
                        else
                        {
                            aiomatic_log_to_file('Empty processed sections prompt. Nothing to do.');
                            if($auto == 1)
                            {
                                aiomatic_clearFromList($param);
                            }
                            return 'fail';
                        }
                    }
                    else
                    {
                        if($post_sections_list != '')
                        {
                            $post_sections = $spintax->Parse($post_sections_list);
                        }
                    }

                    $new_post_content = '';
                    if(stristr($run_regex_on, 'intro') !== false)
                    {
                        if ($strip_by_regex_prompts !== '')
                        {
                            $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex_prompts);
                            $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex_prompts);
                            $xcnt = 0;
                            foreach($xstrip_by_regex as $sbr)
                            {
                                if(isset($xreplace_regex[$xcnt]))
                                {
                                    $repreg = $xreplace_regex[$xcnt];
                                }
                                else
                                {
                                    $repreg = '';
                                }
                                $xcnt++;
                                $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $intro_prompt);
                                if($temp_cont !== NULL)
                                {
                                    $intro_prompt = $temp_cont;
                                }
                            }
                        }
                    }
                    if($intro_prompt != '')
                    {
                        $my_intro_prompt = $intro_prompt;
                        $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                        $my_intro_prompt = aiomatic_replacetopics($my_intro_prompt, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        if($my_intro_prompt != '')
                        {
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $topic_intro_model . ') for topic intro text: ' . $my_intro_prompt);
                            }
                            $written = aiomatic_write_content($my_intro_prompt, $topic_intro_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $token);
                            if($written === false)
                            {
                                aiomatic_log_to_file('Failed to generate intro for section: ' . $current_section);
                                continue;
                            }
                            else
                            {
                                if($new_post_content != '')
                                {
                                    $new_post_content .= ' ';
                                }
                                $new_post_content .= $written;
                            }
                        }
                        else
                        {
                            aiomatic_log_to_file('Empty processed intro prompt. Nothing to do.');
                        }
                    }
                    if($topic_images != '' && is_numeric($topic_images) && $topic_images > $added_images)
                    {
                        if($new_post_content !== '')
                        {
                            $new_img = aiomatic_get_royalty_free_image($post_title, $enable_ai_images, $image_size, $images_arr, $token, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $custom_shortcodes);
                            if($new_img !== false && !in_array($new_img, $added_img_list))
                            {
                                $new_post_content .= '<br/><img src="' . $new_img . '" alt="' . $post_title . '"><br/>';
                                $added_img_list[] = $new_img;
                                $added_images++;
                            }
                        }
                    }
                    if($content_prompt != '')
                    {
                        if($single_content_call == '1')
                        {
                            $current_section = $post_sections;
                            $my_post_content = $content_prompt;
                            $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                            $my_post_content = aiomatic_replacetopics($my_post_content, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                            
                            if(stristr($run_regex_on, 'content') !== false)
                            {
                                if ($strip_by_regex_prompts !== '')
                                {
                                    $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex_prompts);
                                    $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex_prompts);
                                    $xcnt = 0;
                                    foreach($xstrip_by_regex as $sbr)
                                    {
                                        if(isset($xreplace_regex[$xcnt]))
                                        {
                                            $repreg = $xreplace_regex[$xcnt];
                                        }
                                        else
                                        {
                                            $repreg = '';
                                        }
                                        $xcnt++;
                                        $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $my_post_content);
                                        if($temp_cont !== NULL)
                                        {
                                            $my_post_content = $temp_cont;
                                        }
                                    }
                                }
                            }
                            if($my_post_content != '')
                            {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                {
                                    $api_service = aiomatic_get_api_service($token);
                                    aiomatic_log_to_file('Calling ' . $api_service . ' (' . $topic_content_model . ') for topic content text: ' . $my_post_content);
                                }
                                $written = aiomatic_write_content($my_post_content, $topic_content_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $token);
                                if($written === false)
                                {
                                    aiomatic_log_to_file('Failed to generate topic list for section: ' . $current_section);
                                    continue;
                                }
                                else
                                {
                                    if($new_post_content != '')
                                    {
                                        $new_post_content .= ' ';
                                    }
                                    $new_img_arr = array();
                                    if($topic_images != '' && is_numeric($topic_images) && intval($topic_images) - 2 > $added_images)
                                    {
                                        $howmore = intval($topic_images) - 2;
                                        for($cont = 0; $cont < $howmore; $cont++)
                                        {
                                            $new_img = aiomatic_get_royalty_free_image($current_section, $enable_ai_images, $image_size, $images_arr, $token, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $custom_shortcodes);
                                            if($new_img !== false && !in_array($new_img, $added_img_list))
                                            {
                                                $new_post_content .= '<br/><img src="' . $new_img . '" alt="' . $current_section . '"><br/>';
                                                $added_img_list[] = $new_img;
                                                $new_img_arr[] = $new_img;
                                                $added_images++;
                                            }
                                        } 
                                    }
                                    if(count($new_img_arr) > 0)
                                    {
                                        $written_arr = preg_split("/\r\n|\n|\r/", $written);
                                        if(count($written_arr) > 1)
                                        {
                                            foreach($new_img_arr as $new_img_x)
                                            {
                                                array_splice($written_arr, rand(0, count($written_arr)), 0, '<br/><img src="' . $new_img_x . '">');
                                            }
                                            $written = implode('\r\n', $written_arr);
                                        }
                                    }
                                    $new_vid_arr = array();
                                    $new_post_content .= $written;
                                    if($topic_videos != '' && is_numeric($topic_videos) && intval($topic_videos) > $added_videos)
                                    {
                                        $howmore = intval($topic_videos) - $added_videos;
                                        for($cont = 0; $cont < $howmore; $cont++)
                                        {
                                            $new_vid = aiomoatic_get_video($current_section);
                                            if($new_vid !== false && !in_array($new_vid, $added_vid_list))
                                            {
                                                $new_post_content .= $new_vid;
                                                $added_vid_list[] = $new_img;
                                                $new_vid_arr[] = $new_img;
                                                $added_videos++;
                                            }
                                        } 
                                    }
                                    if(count($new_vid_arr) > 0)
                                    {
                                        $written_arr = preg_split("/\r\n|\n|\r/", $written);
                                        if(count($written_arr) > 1)
                                        {
                                            foreach($new_vid_arr as $new_img_x)
                                            {
                                                array_splice($written_arr, rand(0, count($written_arr)), 0, '<br/><img src="' . $new_img_x . '">');
                                            }
                                            $written = implode('\r\n', $written_arr);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                aiomatic_log_to_file('Empty processed topic prompt. Nothing to do.');
                            }
                        }
                        else
                        {
                            if($post_sections != '')
                            {
                                $post_sections_arr = preg_split('/\r\n|\r|\n/', $post_sections);
                            }
                            else
                            {
                                $post_sections_arr = array();
                            }
                            $toc = '';
                            if($enable_toc == '1')
                            {
                                if(!empty($title_toc))
                                {
                                    $my_title_toc = $title_toc;
                                    $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                                    $my_title_toc = aiomatic_replacetopics($my_title_toc, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    $my_title_toc = $spintax->Parse(trim($my_title_toc));
                                    if($my_title_toc != '')
                                    {
                                        $toc .= '<h2>' . $my_title_toc . '</h2>';
                                    }
                                }
                                $toc .= '<ul class="toc-class">';
                                foreach($post_sections_arr as $current_section)
                                {
                                    $toc .= '<li><a href="#' . sanitize_title($current_section) . '">' . $current_section . '</a></li>';
                                }
                                if($title_qa != '')
                                {
                                    $my_title_qa = $title_qa;
                                    $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                                    $my_title_qa = aiomatic_replacetopics($my_title_qa, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    $my_title_qa = $spintax->Parse(trim($my_title_qa));
                                    if($my_title_qa != '')
                                    {
                                        if($qa_prompt != '')
                                        {
                                            $toc .= '<li><a href="#qa">' . $my_title_qa . '</a></li>';
                                        }
                                    }
                                }
                                if($title_outro != '')
                                {
                                    $my_title_outro = $title_outro;
                                    $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                                    $my_title_outro = aiomatic_replacetopics($my_title_outro, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    $my_title_outro = $spintax->Parse(trim($my_title_outro));
                                    if($my_title_outro != '')
                                    {
                                        if($outro_prompt != '')
                                        {
                                            $toc .= '<li><a href="#outro">' . $my_title_outro . '</a></li>';
                                        }
                                    }
                                }
                                $toc .= '</ul>';
                                $new_post_content .= '<br/>' . $toc . '<br/>';
                            }
                            foreach($post_sections_arr as $current_section)
                            {
                                $current_section = trim($current_section);
                                $current_section = trim($current_section, '.;');
                                if(empty($current_section))
                                {
                                    continue;
                                }
                                $my_post_content = $content_prompt;
                                $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                                $my_post_content = aiomatic_replacetopics($my_post_content, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                if(stristr($run_regex_on, 'content') !== false)
                                {
                                    if ($strip_by_regex_prompts !== '')
                                    {
                                        $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex_prompts);
                                        $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex_prompts);
                                        $xcnt = 0;
                                        foreach($xstrip_by_regex as $sbr)
                                        {
                                            if(isset($xreplace_regex[$xcnt]))
                                            {
                                                $repreg = $xreplace_regex[$xcnt];
                                            }
                                            else
                                            {
                                                $repreg = '';
                                            }
                                            $xcnt++;
                                            $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $my_post_content);
                                            if($temp_cont !== NULL)
                                            {
                                                $my_post_content = $temp_cont;
                                            }
                                        }
                                    }
                                }
                                if($my_post_content != '')
                                {
                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                    {
                                        $api_service = aiomatic_get_api_service($token);
                                        aiomatic_log_to_file('Calling ' . $api_service . ' (' . $topic_content_model . ') for topic multi content text: ' . $my_post_content);
                                    }
                                    $written = aiomatic_write_content($my_post_content, $topic_content_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $token);
                                    if($written === false)
                                    {
                                        aiomatic_log_to_file('Failed to generate content for section: ' . $current_section);
                                        continue;
                                    }
                                    else
                                    {
                                        if($topic_videos != '' && is_numeric($topic_videos) && $topic_videos > $added_videos)
                                        {
                                            $new_vid = aiomoatic_get_video($current_section);
                                            if($new_vid !== false && !in_array($new_vid, $added_vid_list))
                                            {
                                                $new_post_content .= $new_vid;
                                                $added_vid_list[] = $new_vid;
                                                $added_videos++;
                                            }
                                        }
                                        $written = str_ireplace($current_section, '', $written);
                                        preg_match_all('#\d+\.\s*([\s\S]*)#', $current_section, $mxatches);
                                        if(isset($mxatches[1][0]))
                                        {
                                            $written = str_ireplace(trim($mxatches[1][0]), '', $written);
                                            $written = str_ireplace(str_replace(['"', '\''], '', $mxatches[1][0]), '', $written);
                                        }
                                        $written = str_ireplace('<h2></h2>', '', $written);
                                        $written = str_ireplace('<h3></h3>', '', $written);
                                        if($sections_role == 'h2')
                                        {
                                            $new_post_content .= '<h2 id="' . sanitize_title($current_section) . '">' . $current_section . '</h2>';
                                        }
                                        elseif($sections_role == 'h3')
                                        {
                                            $new_post_content .= '<h3 id="' . sanitize_title($current_section) . '">' . $current_section . '</h3>';
                                        }
                                        elseif($sections_role == 'b')
                                        {
                                            $new_post_content .= '<b id="' . sanitize_title($current_section) . '">' . $current_section . '</b>';
                                        }
                                        elseif($sections_role == 'i')
                                        {
                                            $new_post_content .= '<i id="' . sanitize_title($current_section) . '">' . $current_section . '</i>';
                                        }
                                        elseif($sections_role == 'bi')
                                        {
                                            $new_post_content .= '<b><i id="' . sanitize_title($current_section) . '">' . $current_section . '</i></b>';
                                        }
                                        elseif($sections_role == 'p')
                                        {
                                            $new_post_content .= '<p id="' . sanitize_title($current_section) . '">' . $current_section . '</p>';
                                        }
                                        elseif($sections_role == 'x')
                                        {
                                            $new_post_content .= '<br/><span id="' . sanitize_title($current_section) . '">' . $current_section . '</span><br/>';
                                        }
                                        $new_post_content .= $written;
                                    }
                                    if($topic_images != '' && is_numeric($topic_images) && $topic_images > $added_images)
                                    {
                                        if($new_post_content !== '')
                                        {
                                            $new_img = aiomatic_get_royalty_free_image($current_section, $enable_ai_images, $image_size, $images_arr, $token, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $custom_shortcodes);
                                            if($new_img !== false && !in_array($new_img, $added_img_list))
                                            {
                                                $new_post_content .= '<br/><img src="' . $new_img . '" alt="' . $current_section . '"><br/>';
                                                $added_img_list[] = $new_img;
                                                $added_images++;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    aiomatic_log_to_file('Empty processed content prompt. Nothing to do.');
                                }
                            }
                        }
                    }
                    if($enable_qa == '1')
                    {
                        if($qa_prompt != '')
                        {
                            $my_qa_prompt = $qa_prompt;
                            $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                            $my_qa_prompt = aiomatic_replacetopics($my_qa_prompt, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                            if(stristr($run_regex_on, 'qa') !== false)
                            {
                                if ($strip_by_regex_prompts !== '')
                                {
                                    $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex_prompts);
                                    $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex_prompts);
                                    $xcnt = 0;
                                    foreach($xstrip_by_regex as $sbr)
                                    {
                                        if(isset($xreplace_regex[$xcnt]))
                                        {
                                            $repreg = $xreplace_regex[$xcnt];
                                        }
                                        else
                                        {
                                            $repreg = '';
                                        }
                                        $xcnt++;
                                        $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $my_qa_prompt);
                                        if($temp_cont !== NULL)
                                        {
                                            $my_qa_prompt = $temp_cont;
                                        }
                                    }
                                }
                            }
                            if($my_qa_prompt != '')
                            {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                {
                                    $api_service = aiomatic_get_api_service($token);
                                    aiomatic_log_to_file('Calling ' . $api_service . ' (' . $topic_qa_model . ') for topic Q&A text: ' . $my_qa_prompt);
                                }
                                $written = aiomatic_write_content($my_qa_prompt, $topic_qa_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $token);
                                if($written === false)
                                {
                                    aiomatic_log_to_file('Failed to generate Q&A for topic: ' . $current_section);
                                    continue;
                                }
                                else
                                {
                                    if($new_post_content != '')
                                    {
                                        $new_post_content .= ' ';
                                    }
                                    if($title_qa !== '')
                                    {
                                        $new_post_content .= '<h2 id="qa">' . $title_qa . '</h2>';
                                    }
                                    $new_post_content .= $written;
                                }
                            }
                            else
                            {
                                aiomatic_log_to_file('Empty processed Q&A prompt. Nothing to do.');
                            }
                        }
                    }
                    if($outro_prompt != '')
                    {
                        $my_outro_prompt = $outro_prompt;
                        $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                        $my_outro_prompt = aiomatic_replacetopics($my_outro_prompt, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        if(stristr($run_regex_on, 'outro') !== false)
                        {
                            if ($strip_by_regex_prompts !== '')
                            {
                                $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex_prompts);
                                $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex_prompts);
                                $xcnt = 0;
                                foreach($xstrip_by_regex as $sbr)
                                {
                                    if(isset($xreplace_regex[$xcnt]))
                                    {
                                        $repreg = $xreplace_regex[$xcnt];
                                    }
                                    else
                                    {
                                        $repreg = '';
                                    }
                                    $xcnt++;
                                    $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $my_outro_prompt);
                                    if($temp_cont !== NULL)
                                    {
                                        $my_outro_prompt = $temp_cont;
                                    }
                                }
                            }
                        }
                        if($my_outro_prompt != '')
                        {
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $topic_outro_model . ') for topic outro text: ' . $my_outro_prompt);
                            }
                            $written = aiomatic_write_content($my_outro_prompt, $topic_outro_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $token);
                            if($written === false)
                            {
                                aiomatic_log_to_file('Failed to generate outro for section: ' . $current_section);
                                continue;
                            }
                            else
                            {
                                if($new_post_content != '')
                                {
                                    $new_post_content .= ' ';
                                }
                                if($title_outro !== '')
                                {
                                    $new_post_content .= '<h2 id="outro">' . $title_outro . '</h2>';
                                }
                                else
                                {
                                    $new_post_content .= '<br/><br/>';
                                }
                                $new_post_content .= $written;
                            }
                        }
                        else
                        {
                            aiomatic_log_to_file('Empty processed outro prompt. Nothing to do.');
                        }
                    }
                    if($topic_images != '' && is_numeric($topic_images) && $topic_images > $added_images)
                    {
                        if($new_post_content !== '')
                        {
                            $new_img = aiomatic_get_royalty_free_image($post_title, $enable_ai_images, $image_size, $images_arr, $token, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $custom_shortcodes);
                            if($new_img !== false && !in_array($new_img, $added_img_list))
                            {
                                $new_post_content .= '<br/><img src="' . $new_img . '" alt="' . $post_title . '"><br/>';
                                $added_img_list[] = $new_img;
                                $added_images++;
                            }
                        }
                    }
                    if($new_post_content == '')
                    {
                        aiomatic_log_to_file("Warning, empty post content because of empty content prompt!");
                    }

                    $new_post_excerpt = '';
                    $current_section = $post_sections;
                    if($excerpt_prompt != '')
                    {
                        $excerpt_prompt_arr = preg_split('/\r\n|\r|\n/', $excerpt_prompt);
                        $my_post_excerpt = $excerpt_prompt_arr[array_rand($excerpt_prompt_arr)];
                        $za_post_title = aiomatic_replaceContentShortcodes($post_title, $img_attr, $ai_command);
                        $my_post_excerpt = aiomatic_replacetopics($my_post_excerpt, $za_post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        if(stristr($run_regex_on, 'excerpt') !== false)
                        {
                            if ($strip_by_regex_prompts !== '')
                            {
                                $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex_prompts);
                                $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex_prompts);
                                $xcnt = 0;
                                foreach($xstrip_by_regex as $sbr)
                                {
                                    if(isset($xreplace_regex[$xcnt]))
                                    {
                                        $repreg = $xreplace_regex[$xcnt];
                                    }
                                    else
                                    {
                                        $repreg = '';
                                    }
                                    $xcnt++;
                                    $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $my_post_excerpt);
                                    if($temp_cont !== NULL)
                                    {
                                        $my_post_excerpt = $temp_cont;
                                    }
                                }
                            }
                        }
                        if($my_post_excerpt != '')
                        {
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $topic_excerpt_model . ') for topic excerpt text: ' . $my_post_excerpt);
                            }
                            $written = aiomatic_write_content($my_post_excerpt, $topic_excerpt_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $token);
                            if($written === false)
                            {
                                aiomatic_log_to_file('Failed to generate excerpt!');
                            }
                            else
                            {
                                $new_post_excerpt = $written;
                            }
                        }
                        else
                        {
                            aiomatic_log_to_file('Empty processed excerpt prompt. Nothing to do.');
                        }
                    }

                    $get_img = '';
                    if($royalty_free == '1')
                    {
                        if($enable_ai_images == '1')
                        {
                            $query_words = $post_title;
                            if($image_query == '')
                            {
                                $image_query = $temp_post;
                            }
                            if($orig_ai_command_image == '')
                            {
                                $orig_ai_command_image = $image_query;
                            }
                            if($orig_ai_command_image != '')
                            {
                                $ai_command_image = $orig_ai_command_image;
                                $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                $ai_command_image = array_filter($ai_command_image);
                                if(count($ai_command_image) > 0)
                                {
                                    $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                }
                                else
                                {
                                    $ai_command_image = '';
                                }
                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                if(!empty($ai_command_image))
                                {
                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                }
                                else
                                {
                                    $ai_command_image = trim(strip_tags($post_title));
                                }
                                $ai_command_image = trim($ai_command_image);
                                if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                {
                                    $txt_content = aiomatic_get_web_page($ai_command_image);
                                    if ($txt_content !== FALSE) 
                                    {
                                        $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                        $txt_content = array_filter($txt_content);
                                        if(count($txt_content) > 0)
                                        {
                                            $txt_content = $txt_content[array_rand($txt_content)];
                                            if(trim($txt_content) != '') 
                                            {
                                                $ai_command_image = $txt_content;
                                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                            }
                                        }
                                    }
                                }
                                if(empty($ai_command_image))
                                {
                                    aiomatic_log_to_file('Empty API featured image seed expression provided!');
                                }
                                else
                                {
                                    if(strlen($ai_command_image) > 400)
                                    {
                                        $ai_command_image = aiomatic_substr($ai_command_image, 0, 400);
                                    }
                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                    {
                                        $api_service = aiomatic_get_api_service($token);
                                        aiomatic_log_to_file('Calling ' . $api_service . ' for featured image: ' . $ai_command_image);
                                    }
                                    $aierror = '';
                                    $get_img = aiomatic_generate_ai_image($token, 1, $ai_command_image, $image_size, 'featuredImage', true, 0, $aierror);
                                    if($get_img !== false)
                                    {
                                        foreach($get_img as $tmpimg)
                                        {
                                            $get_img = $tmpimg;
                                            break;
                                        }
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            aiomatic_log_to_file('AI generated featured image returned: ' . $get_img);
                                        }
                                    }
                                    else
                                    {
                                        aiomatic_log_to_file('Failed to generate AI featured image: ' . $aierror);
                                        $get_img = '';
                                    }
                                }
                            }
                            else
                            {
                                aiomatic_log_to_file('Empty AI featured image query entered.');
                            }
                        }
                        elseif($enable_ai_images == '2')
                        {
                            $query_words = $post_title;
                            if($image_query == '')
                            {
                                $image_query = $temp_post;
                            }
                            if($orig_ai_command_image == '')
                            {
                                $orig_ai_command_image = $image_query;
                            }
                            if($orig_ai_command_image != '')
                            {
                                $ai_command_image = $orig_ai_command_image;
                                $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                $ai_command_image = array_filter($ai_command_image);
                                if(count($ai_command_image) > 0)
                                {
                                    $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                }
                                else
                                {
                                    $ai_command_image = '';
                                }
                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                if(!empty($ai_command_image))
                                {
                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                }
                                else
                                {
                                    $ai_command_image = trim(strip_tags($post_title));
                                }
                                $ai_command_image = trim($ai_command_image);
                                if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                {
                                    $txt_content = aiomatic_get_web_page($ai_command_image);
                                    if ($txt_content !== FALSE) 
                                    {
                                        $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                        $txt_content = array_filter($txt_content);
                                        if(count($txt_content) > 0)
                                        {
                                            $txt_content = $txt_content[array_rand($txt_content)];
                                            if(trim($txt_content) != '') 
                                            {
                                                $ai_command_image = $txt_content;
                                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                            }
                                        }
                                    }
                                }
                                if(empty($ai_command_image))
                                {
                                    aiomatic_log_to_file('Empty API featured image seed expression provided!');
                                }
                                else
                                {
                                    if(strlen($ai_command_image) > 2000)
                                    {
                                        $ai_command_image = aiomatic_substr($ai_command_image, 0, 2000);
                                    }
                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                    {
                                        $api_service = 'Stability.AI';
                                        aiomatic_log_to_file('Calling ' . $api_service . ' for featured image: ' . $ai_command_image);
                                    }
                                    if($image_size == '256x256')
                                    {
                                        $width = '512';
                                        $height = '512';
                                    }
                                    elseif($image_size == '512x512')
                                    {
                                        $width = '512';
                                        $height = '512';
                                    }
                                    elseif($image_size == '1024x1024')
                                    {
                                        $width = '1024';
                                        $height = '1024';
                                    }
                                    else
                                    {
                                        $width = '512';
                                        $height = '512';
                                    }
                                    $get_img = aiomatic_generate_stability_image($ai_command_image, $height, $width, 'featuredStableImage', 0, false);
                                    if($get_img !== false)
                                    {
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            aiomatic_log_to_file('AI generated featured image returned: ' . $get_img[1]);
                                        }
                                    }
                                    else
                                    {
                                        aiomatic_log_to_file('Failed to generate Stability.AI featured image.');
                                        $get_img = '';
                                    }
                                }
                            }
                            else
                            {
                                aiomatic_log_to_file('Empty AI featured image query entered.');
                            }
                        }
                        else
                        {
                            $image_query_set = false;
                            $query_words = '';
                            $ai_command_image = '';
                            if($orig_ai_command_image == '')
                            {
                                $orig_ai_command_image = $image_query;
                            }
                            if($orig_ai_command_image != '')
                            {
                                $ai_command_image = $orig_ai_command_image;
                                $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                $ai_command_image = array_filter($ai_command_image);
                                if(count($ai_command_image) > 0)
                                {
                                    $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                }
                                else
                                {
                                    $ai_command_image = '';
                                }
                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                if(!empty($ai_command_image))
                                {
                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                }
                                else
                                {
                                    $ai_command_image = trim(strip_tags($post_title));
                                }
                                $ai_command_image = trim($ai_command_image);
                                if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                {
                                    $txt_content = aiomatic_get_web_page($ai_command_image);
                                    if ($txt_content !== FALSE) 
                                    {
                                        $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                        $txt_content = array_filter($txt_content);
                                        if(count($txt_content) > 0)
                                        {
                                            $txt_content = $txt_content[array_rand($txt_content)];
                                            if(trim($txt_content) != '') 
                                            {
                                                $ai_command_image = $txt_content;
                                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                            }
                                        }
                                    }
                                }
                            }
                            if($ai_command_image != '')
                            {
                                $query_words = $ai_command_image;
                                $image_query = $ai_command_image;
                                $image_query_set = true;
                            }
                            if(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'textrazor')
                            {
                                if(isset($aiomatic_Main_Settings['textrazor_key']) && trim($aiomatic_Main_Settings['textrazor_key']) != '')
                                {
                                    try
                                    {
                                        if(!class_exists('TextRazor'))
                                        {
                                            require_once(dirname(__FILE__) . "/res/TextRazor.php");
                                        }
                                        TextRazorSettings::setApiKey(trim($aiomatic_Main_Settings['textrazor_key']));
                                        $textrazor = new TextRazor();
                                        $textrazor->addExtractor('entities');
                                        $response = $textrazor->analyze($image_query);
                                        if (isset($response['response']['entities'])) 
                                        {
                                            foreach ($response['response']['entities'] as $entity) 
                                            {
                                                $query_words = '';
                                                if(isset($entity['entityEnglishId']))
                                                {
                                                    $query_words = $entity['entityEnglishId'];
                                                }
                                                else
                                                {
                                                    $query_words = $entity['entityId'];
                                                }
                                                if($query_words != '')
                                                {
                                                    $z_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $img_attr, 10, true);
                                                    if(!empty($z_img))
                                                    {
                                                        $get_img = $z_img;
                                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                            aiomatic_log_to_file('Royalty Free Image Generated with help of TextRazor (kw: "' . $query_words . '"): ' . $z_img);
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    catch(Exception $e)
                                    {
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                            aiomatic_log_to_file('Failed to search for keywords using TextRazor (2): ' . $e->getMessage());
                                        }
                                    }
                                }
                            }
                            elseif(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'openai')
                            {
                                if(isset($aiomatic_Main_Settings['keyword_prompts']) && trim($aiomatic_Main_Settings['keyword_prompts']) != '')
                                {
                                    if(isset($aiomatic_Main_Settings['keyword_model']) && $aiomatic_Main_Settings['keyword_model'] != '')
                                    {
                                        $kw_model = $aiomatic_Main_Settings['keyword_model'];
                                    }
                                    else
                                    {
                                        $kw_model = 'text-davinci-003';
                                    }
                                    $title_ai_command = trim($aiomatic_Main_Settings['keyword_prompts']);
                                    $title_ai_command = preg_split('/\r\n|\r|\n/', $title_ai_command);
                                    $title_ai_command = array_filter($title_ai_command);
                                    if(count($title_ai_command) > 0)
                                    {
                                        $title_ai_command = $title_ai_command[array_rand($title_ai_command)];
                                    }
                                    else
                                    {
                                        $title_ai_command = '';
                                    }
                                    $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                    if(!empty($title_ai_command))
                                    {
                                        $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    }
                                    $title_ai_command = trim($title_ai_command);
                                    if (filter_var($title_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($title_ai_command, '.txt'))
                                    {
                                        $txt_content = aiomatic_get_web_page($title_ai_command);
                                        if ($txt_content !== FALSE) 
                                        {
                                            $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                            $txt_content = array_filter($txt_content);
                                            if(count($txt_content) > 0)
                                            {
                                                $txt_content = $txt_content[array_rand($txt_content)];
                                                if(trim($txt_content) != '') 
                                                {
                                                    $title_ai_command = $txt_content;
                                                    $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                                    $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                }
                                            }
                                        }
                                    }
                                    if(empty($title_ai_command))
                                    {
                                        aiomatic_log_to_file('Empty API keyword extractor seed expression provided!');
                                        $title_ai_command = 'Type the most relevant keyword, no other text before or after it, for a blog post titled:  ' . trim(strip_tags($post_title));
                                    }
                                    if(strlen($title_ai_command) > $max_seed_tokens * 4)
                                    {
                                        $title_ai_command = aiomatic_substr($title_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                                    }
                                    $title_ai_command = trim($title_ai_command);
                                    if(empty($title_ai_command))
                                    {
                                        aiomatic_log_to_file('Empty API title seed expression provided(3)! ' . print_r($title_ai_command, true));
                                    }
                                    else
                                    {
                                        $query_token_count = count(aiomatic_encode($title_ai_command));
                                        $available_tokens = $max_tokens - $query_token_count;
                                        if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                                        {
                                            $string_len = strlen($title_ai_command);
                                            $string_len = $string_len / 2;
                                            $string_len = intval(0 - $string_len);
                                            $title_ai_command = aiomatic_substr($title_ai_command, 0, $string_len);
                                            $title_ai_command = trim($title_ai_command);
                                            $query_token_count = count(aiomatic_encode($title_ai_command));
                                            $available_tokens = $max_tokens - $query_token_count;
                                        }
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            $api_service = aiomatic_get_api_service($token);
                                            aiomatic_log_to_file('Calling ' . $api_service . ' (' . $kw_model . ') for title text: ' . $title_ai_command);
                                        }
                                        $aierror = '';
                                        $finish_reason = '';
                                        $generated_text = aiomatic_generate_text($token, $kw_model, $title_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'keywordID' . $param, 0, $finish_reason, $aierror);
                                        if($generated_text === false)
                                        {
                                            aiomatic_log_to_file('Keyword generator error: ' . $aierror);
                                            $ai_title = '';
                                        }
                                        else
                                        {
                                            $ai_title = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                                            $ai_titles = explode(',', $ai_title);
                                            foreach($ai_titles as $query_words)
                                            {
                                                $z_img = aiomatic_get_free_image($aiomatic_Main_Settings, trim($query_words), $img_attr, 10, true);
                                                if(!empty($z_img))
                                                {
                                                    $get_img = $z_img;
                                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                        aiomatic_log_to_file('Royalty Free Image Generated with help of AI (kw: "' . $query_words . '"): ' . $z_img);
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            $api_service = aiomatic_get_api_service($token);
                                            aiomatic_log_to_file('Successfully got API keyword result from ' . $api_service . ': ' . $ai_title);
                                        }
                                    }
                                }
                            }
                            if(empty($get_img))
                            {
                                if($image_query_set == true && !empty($image_query))
                                {
                                    $get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $image_query, $img_attr, 10, true);
                                    if($get_img == '' || $get_img === false)
                                    {
                                        if(isset($aiomatic_Main_Settings['bimage']) && $aiomatic_Main_Settings['bimage'] == 'on')
                                        {
                                            $keyword_class = new Aiomatic_keywords();
                                            $image_query = $keyword_class->keywords($image_query, 1);
                                            $get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $image_query, $img_attr, 20, true);
                                        }
                                    }
                                }
                                if(empty($get_img))
                                {
                                    $keyword_class = new Aiomatic_keywords();
                                    $query_words = $keyword_class->keywords($post_title, 2);
                                    $get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $img_attr, 10, true);
                                    if($get_img == '' || $get_img === false)
                                    {
                                        if(isset($aiomatic_Main_Settings['bimage']) && $aiomatic_Main_Settings['bimage'] == 'on')
                                        {
                                            $query_words = $keyword_class->keywords($post_title, 1);
                                            $get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $img_attr, 20, true);
                                            if($get_img == '' || $get_img === false)
                                            {
                                                if(isset($aiomatic_Main_Settings['no_royalty_skip']) && $aiomatic_Main_Settings['no_royalty_skip'] == 'on')
                                                {
                                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                        aiomatic_log_to_file('Skipping importing because no royalty free image found.');
                                                    }
                                                    unset($post_title_lines[$current_index]);
                                                    continue;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if(isset($aiomatic_Main_Settings['no_royalty_skip']) && $aiomatic_Main_Settings['no_royalty_skip'] == 'on')
                                            {
                                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                    aiomatic_log_to_file('Skipping importing because no royalty free image found.');
                                                }
                                                unset($post_title_lines[$current_index]);
                                                continue;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (isset($aiomatic_Main_Settings['spin_text']) && $aiomatic_Main_Settings['spin_text'] !== 'disabled') 
                    {
                        $already_spinned = '1';
                    }
                    $my_post                              = array();
                    $my_post['aiomatic_post_image']       = $get_img;
                    if($enable_ai_images == '2')
                    {
                        $my_post['aiomatic_local_image']      = '1';
                    }
                    else
                    {
                        $my_post['aiomatic_local_image']      = '0';
                    }
                    $my_post['aiomatic_enable_pingbacks'] = $enable_pingback;
                    $my_post['default_category']          = $default_category;
                    $my_post['post_type']                 = $post_type;
                    $my_post['comment_status']            = $accept_comments;
                    $my_post['post_status']               = $post_status;
                    $my_post['post_author']               = $post_user_name;
                    if($strip_title == '1')
                    {
                        $new_post_content = str_replace($post_title, '', $new_post_content);
                        $new_post_content = str_replace('<h2></h2>', '', $new_post_content);
                        $new_post_content = str_replace('<h3></h3>', '', $new_post_content);
                    }
                    if (isset($aiomatic_Main_Settings['swear_filter']) && $aiomatic_Main_Settings['swear_filter'] == 'on') 
                    {
                        require_once(dirname(__FILE__) . "/res/swear.php");
                        $new_post_content = aiomatic_filterwords($new_post_content);
                    }
                    if(isset($aiomatic_Main_Settings['global_ban_words']) && $aiomatic_Main_Settings['global_ban_words'] != '') {
                        $continue    = false;
                        $aiomatic_Main_Settings['global_ban_words'] = trim(trim(trim($aiomatic_Main_Settings['global_ban_words']), ','));
                        $banned_list = explode(',', $aiomatic_Main_Settings['global_ban_words']);
                        foreach ($banned_list as $banned_word) {
                            if (stripos($new_post_content, trim($banned_word)) !== FALSE) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('Skipping post "' . esc_html($post_title) . '", because it\'s content contains global banned word: ' . $banned_word);
                                }
                                $continue = true;
                                break;
                            }
                            if (stripos($post_title, trim($banned_word)) !== FALSE) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('Skipping post "' . esc_html($post_title) . '", because it\'s title contains global banned word: ' . $banned_word);
                                }
                                $continue = true;
                                break;
                            }
                        }
                        if ($continue === true) {
                            continue;
                        }
                    }
                    if(isset($aiomatic_Main_Settings['global_req_words']) && $aiomatic_Main_Settings['global_req_words'] != '')
                    {
                        if(isset($aiomatic_Main_Settings['require_only_one']) && $aiomatic_Main_Settings['require_only_one'] == 'on')
                        {
                            $continue      = true;
                            $aiomatic_Main_Settings['global_req_words'] = trim(trim(trim($aiomatic_Main_Settings['global_req_words']), ','));
                            $required_list = explode(',', $aiomatic_Main_Settings['global_req_words']);
                            foreach ($required_list as $required_word) {
                                if (stripos($new_post_content, trim($required_word)) !== FALSE || stripos($post_title, trim($required_word)) !== FALSE) {
                                    $continue = false;
                                    break;
                                }
                            }
                            if ($continue === true) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('Skipping post "' . esc_html($post_title) . '", because it\'s content doesn\'t contain global required words.');
                                }
                                continue;
                            }
                        }
                        else
                        {
                            $continue      = false;
                            $aiomatic_Main_Settings['global_req_words'] = trim(trim(trim($aiomatic_Main_Settings['global_req_words']), ','));
                            $required_list = explode(',', $aiomatic_Main_Settings['global_req_words']);
                            foreach ($required_list as $required_word) {
                                if (stripos($new_post_content, trim($required_word)) === FALSE && stripos($post_title, trim($required_word)) === FALSE) {
                                    $continue = true;
                                    break;
                                }
                            }
                            if ($continue === true) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('Skipping post "' . esc_html($post_title) . '", because it\'s content doesn\'t contain global required words.');
                                }
                                continue;
                            }
                        }
                    }
                    $new_post_title = $post_title;
                    $arr = aiomatic_spin_and_translate($new_post_title, $new_post_content, '3', $skip_spin, $skip_translate);
                    if($arr[0] != $new_post_title)
                    {
                        $new_post_title = $arr[0];
                        if (!isset($aiomatic_Main_Settings['do_not_check_duplicates']) || $aiomatic_Main_Settings['do_not_check_duplicates'] != 'on') 
                        {
                            $posts = get_posts(
                                array(
                                    'post_type'              => $post_type,
                                    'title'                  => html_entity_decode($new_post_title),
                                    'post_status'            => 'all',
                                    'numberposts'            => 1,
                                    'update_post_term_cache' => false,
                                    'update_post_meta_cache' => false,           
                                    'orderby'                => 'post_date ID',
                                    'order'                  => 'ASC',
                                )
                            );
                            if ( ! empty( $posts ) ) {
                                $zap = $posts[0];
                            } else {
                                $zap = null;
                            }
                            if($zap !== null)
                            {
                                aiomatic_log_to_file('Post with specified title already existing (after spin/translate), skipping it: ' . $new_post_title);
                                unset($post_title_lines[$current_index]);
                                continue;
                            }
                        }
                    }
                    $new_post_content            = $arr[1];
                    if (isset($aiomatic_Main_Settings['spin_text']) && $aiomatic_Main_Settings['spin_text'] !== 'disabled') 
                    {
                        $already_spinned = '1';
                    }
                    if ($auto_categories == 'content') {
                        $extra_categories            = aiomatic_extractKeyWords($new_post_content);
                        $extra_categories            = implode(',', $extra_categories);
                    }
                    elseif ($auto_categories == 'title') {
                        $extra_categories            = aiomatic_extractKeyWords($new_post_title);
                        $extra_categories            = implode(',', $extra_categories);
                    }
                    elseif ($auto_categories == 'both') {
                        $extra_categories            = aiomatic_extractKeyWords($new_post_content);
                        $extra_categories            = implode(',', $extra_categories);
                        $extra_categories2            = aiomatic_extractKeyWords($new_post_title);
                        $extra_categories2            = implode(',', $extra_categories2);
                        if($extra_categories2 != '')
                        {
                            $extra_categories .= ',' . $extra_categories2;
                        }
                    }
                    elseif ($auto_categories == 'ai') 
                    {
                        $category_ai_command = $orig_ai_command_category;
                        $category_ai_command = preg_split('/\r\n|\r|\n/', $category_ai_command);
                        $category_ai_command = array_filter($category_ai_command);
                        if(count($category_ai_command) > 0)
                        {
                            $category_ai_command = $category_ai_command[array_rand($category_ai_command)];
                        }
                        else
                        {
                            $category_ai_command = '';
                        }
                        $category_ai_command = aiomatic_replaceSynergyShortcodes($category_ai_command);
                        if(!empty($category_ai_command))
                        {
                            $category_ai_command = replaceAIPostShortcodes($category_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                            $category_ai_command = aiomatic_replacetopics($category_ai_command, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        }
                        else
                        {
                            $category_ai_command = trim(strip_tags('Write a comma separated list of categories, for the post title: %%post_title%%'));
                        }
                        $category_ai_command = trim($category_ai_command);
                        if (filter_var($category_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($category_ai_command, '.txt'))
                        {
                            $txt_content = aiomatic_get_web_page($category_ai_command);
                            if ($txt_content !== FALSE) 
                            {
                                $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                $txt_content = array_filter($txt_content);
                                if(count($txt_content) > 0)
                                {
                                    $txt_content = $txt_content[array_rand($txt_content)];
                                    if(trim($txt_content) != '') 
                                    {
                                        $category_ai_command = $txt_content;
                                        $category_ai_command = aiomatic_replaceSynergyShortcodes($category_ai_command);
                                        $category_ai_command = replaceAIPostShortcodes($category_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                        $category_ai_command = aiomatic_replacetopics($category_ai_command, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    }
                                }
                            }
                        }
                        if(empty($category_ai_command))
                        {
                            aiomatic_log_to_file('Empty API post category seed expression provided!');
                        }
                        else
                        {
                            if(strlen($category_ai_command) > $max_seed_tokens * 4)
                            {
                                $category_ai_command = aiomatic_substr($category_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                            }
                            $category_ai_command = trim($category_ai_command);
                            if(empty($category_ai_command))
                            {
                                aiomatic_log_to_file('Empty API category seed expression provided! ' . print_r($category_ai_command, true));
                                break;
                            }
                            $query_token_count = count(aiomatic_encode($category_ai_command));
                            $available_tokens = $max_tokens - $query_token_count;
                            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                            {
                                $string_len = strlen($category_ai_command);
                                $string_len = $string_len / 2;
                                $string_len = intval(0 - $string_len);
                                $category_ai_command = aiomatic_substr($category_ai_command, 0, $string_len);
                                $category_ai_command = trim($category_ai_command);
                                if(empty($category_ai_command))
                                {
                                    aiomatic_log_to_file('Empty API seed expression provided (after processing) ' . print_r($category_ai_command, true));
                                    break;
                                }
                                $query_token_count = count(aiomatic_encode($category_ai_command));
                                $available_tokens = $max_tokens - $query_token_count;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $category_model . ') for category generator: ' . $category_ai_command);
                            }
                            $aierror = '';
                            $finish_reason = '';
                            $generated_text = aiomatic_generate_text($token, $category_model, $category_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'categoryID' . $param, 0, $finish_reason, $aierror);
                            if($generated_text === false)
                            {
                                aiomatic_log_to_file('Category generator error: ' . $aierror);
                                break;
                            }
                            else
                            {
                                $extra_categories = $generated_text;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Successfully got API category result from ' . $api_service . ': ' . $generated_text);
                            }
                        }
                    }
                    else
                    {
                        $extra_categories = '';
                    }
                    $my_post['extra_categories'] = $extra_categories;
                    
                    $item_tags                   = aiomatic_extractKeyWords($new_post_content, 3);
                    $item_tags                   = implode(',', $item_tags);
                    $title_tags                   = aiomatic_extractKeyWords($new_post_title, 3);
                    $title_tags                   = implode(',', $title_tags);
                    $item_create_tag_sp = $spintax->Parse($item_create_tag);
                    if ($can_create_tag == 'content') {
                        $post_the_tags = ($item_create_tag_sp != '' ? $item_create_tag_sp . ',' : '') . $item_tags;
                        $my_post['extra_tags']       = $item_tags;
                    } else if ($can_create_tag == 'title') {
                        $post_the_tags = ($item_create_tag_sp != '' ? $item_create_tag_sp . ',' : '') . $title_tags;
                        $my_post['extra_tags']       = $title_tags;
                    } else if ($can_create_tag == 'both') {
                        $post_the_tags = ($item_create_tag_sp != '' ? $item_create_tag_sp . ',' : '') . ($item_tags != '' ? $item_tags . ',' : '') . $title_tags;
                        $my_post['extra_tags']       = ($item_tags != '' ? $item_tags . ',' : '') . $title_tags;
                    } else if ($can_create_tag == 'ai') {
                        $ai_tags = '';
                        $tag_ai_command = $orig_ai_command_tag;
                        $tag_ai_command = preg_split('/\r\n|\r|\n/', $tag_ai_command);
                        $tag_ai_command = array_filter($tag_ai_command);
                        if(count($tag_ai_command) > 0)
                        {
                            $tag_ai_command = $tag_ai_command[array_rand($tag_ai_command)];
                        }
                        else
                        {
                            $tag_ai_command = '';
                        }
                        $tag_ai_command = aiomatic_replaceSynergyShortcodes($tag_ai_command);
                        if(!empty($tag_ai_command))
                        {
                            $tag_ai_command = replaceAIPostShortcodes($tag_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                            $tag_ai_command = aiomatic_replacetopics($tag_ai_command, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        }
                        else
                        {
                            $tag_ai_command = trim(strip_tags('Write a comma separated list of tags, for the post title: %%post_title%%'));
                        }
                        $tag_ai_command = trim($tag_ai_command);
                        if (filter_var($tag_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($tag_ai_command, '.txt'))
                        {
                            $txt_content = aiomatic_get_web_page($tag_ai_command);
                            if ($txt_content !== FALSE) 
                            {
                                $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                $txt_content = array_filter($txt_content);
                                if(count($txt_content) > 0)
                                {
                                    $txt_content = $txt_content[array_rand($txt_content)];
                                    if(trim($txt_content) != '') 
                                    {
                                        $tag_ai_command = $txt_content;
                                        $tag_ai_command = aiomatic_replaceSynergyShortcodes($tag_ai_command);
                                        $tag_ai_command = replaceAIPostShortcodes($tag_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                        $tag_ai_command = aiomatic_replacetopics($tag_ai_command, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    }
                                }
                            }
                        }
                        if(empty($tag_ai_command))
                        {
                            aiomatic_log_to_file('Empty API post tag seed expression provided!');
                        }
                        else
                        {
                            if(strlen($tag_ai_command) > $max_seed_tokens * 4)
                            {
                                $tag_ai_command = aiomatic_substr($tag_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                            }
                            $tag_ai_command = trim($tag_ai_command);
                            if(empty($tag_ai_command))
                            {
                                aiomatic_log_to_file('Empty API tag seed expression provided! ' . print_r($tag_ai_command, true));
                                break;
                            }
                            $query_token_count = count(aiomatic_encode($tag_ai_command));
                            $available_tokens = $max_tokens - $query_token_count;
                            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                            {
                                $string_len = strlen($tag_ai_command);
                                $string_len = $string_len / 2;
                                $string_len = intval(0 - $string_len);
                                $tag_ai_command = aiomatic_substr($tag_ai_command, 0, $string_len);
                                $tag_ai_command = trim($tag_ai_command);
                                if(empty($tag_ai_command))
                                {
                                    aiomatic_log_to_file('Empty API seed expression provided (after processing) ' . print_r($tag_ai_command, true));
                                    break;
                                }
                                $query_token_count = count(aiomatic_encode($tag_ai_command));
                                $available_tokens = $max_tokens - $query_token_count;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $tag_model . ') for tag generator: ' . $tag_ai_command);
                            }
                            $aierror = '';
                            $finish_reason = '';
                            $generated_text = aiomatic_generate_text($token, $tag_model, $tag_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'tagID' . $param, 0, $finish_reason, $aierror);
                            if($generated_text === false)
                            {
                                aiomatic_log_to_file('Tag generator error: ' . $aierror);
                                break;
                            }
                            else
                            {
                                $ai_tags = $generated_text;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Successfully got API tag result from ' . $api_service . ': ' . $generated_text);
                            }
                        }
                        $post_the_tags = ($item_create_tag_sp != '' ? $item_create_tag_sp . ',' : '') . $ai_tags;
                        $my_post['extra_tags']       = $ai_tags;
                    } else {
                        $post_the_tags = $item_create_tag_sp;
                        $my_post['extra_tags']       = '';
                    }
                    $my_post['tags_input'] = $post_the_tags;
                    $new_post_content        = html_entity_decode($new_post_content);
                    $new_post_content = str_replace('</ iframe>', '</iframe>', $new_post_content);
                    if ($strip_by_regex !== '')
                    {
                        $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex);
                        $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex);
                        $xcnt = 0;
                        foreach($xstrip_by_regex as $sbr)
                        {
                            if(isset($xreplace_regex[$xcnt]))
                            {
                                $repreg = $xreplace_regex[$xcnt];
                            }
                            else
                            {
                                $repreg = '';
                            }
                            $xcnt++;
                            $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $new_post_content);
                            if($temp_cont !== NULL)
                            {
                                $new_post_content = $temp_cont;
                            }
                        }
                    }
                    $post_prepender = replaceAIPostShortcodes($post_prepend, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                    $post_prepender = aiomatic_replacetopics($post_prepender, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                    $post_appender = replaceAIPostShortcodes($post_append, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                    $post_appender = aiomatic_replacetopics($post_appender, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                    $post_appender = aiomatic_replaceSynergyShortcodes($post_appender);
                    $post_prepender = aiomatic_replaceSynergyShortcodes($post_prepender);
                    if($ret_content == 1)
                    {
                        return array($post_prepender . ' ' . $new_post_content . ' ' . $post_appender, $new_post_title);
                    }
                    $the_final_cont = $post_prepender . ' ' . $new_post_content . ' ' . $post_appender;
                    $zlang = 'en_US';
                    if (isset($aiomatic_Main_Settings['kw_lang']) && !empty($aiomatic_Main_Settings['kw_lang'])) {
                        $zlang = $aiomatic_Main_Settings['kw_lang'];
                    }
                    $rel_search = array('post_title', 'post_content');
                    if (isset($aiomatic_Main_Settings['rel_search']) && is_array($aiomatic_Main_Settings['rel_search'])) {
                        $rel_search = $aiomatic_Main_Settings['rel_search'];
                    }
                    if($max_links !== '' && $inboundlinker !== null)
                    {
                        try
                        {
                            $the_final_cont = $inboundlinker->add_inbound_links($the_final_cont, $max_links, $link_post_types, $zlang, $rel_search, null);
                        }
                        catch(Exception $ex)
                        {
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                aiomatic_log_to_file('Failed to add new inbound links to content: ' . $ex->getMessage());
                            }
                        }
                    }
                    $my_post['post_content'] = $the_final_cont;
                    $my_post['post_title']           = $new_post_title;
                    $my_post['aiomatic_source_title']   = $post_title;
                    $my_post['aiomatic_timestamp']   = aiomatic_get_date_now();
                    $my_post['aiomatic_post_format'] = $post_format;
                    if (isset($default_category) && $default_category !== 'aiomatic_no_category_12345678' && $default_category[0] !== 'aiomatic_no_category_12345678') 
                    {
                        if(is_array($default_category))
                        {
                            $cextra = '';
                            foreach($default_category as $dc)
                            {
                                $cextra .= ',' . get_cat_name($dc);
                            }
                            $extra_categories_temp = trim( $cextra . ',' . $extra_categories, ',');
                        }
                        else
                        {
                            $extra_categories_temp = trim(get_cat_name($default_category) . ',' .$extra_categories, ',');
                        }
                    }
                    else
                    {
                        $extra_categories_temp = $extra_categories;
                    }
                    $block_arr = array();
                    $custom_arr = array();
                    if($custom_fields != '')
                    {
                        if(stristr($custom_fields, '=>') != false)
                        {
                            $rule_arr = explode(',', trim($custom_fields));
                            foreach($rule_arr as $rule)
                            {
                                $my_args = explode('=>', trim($rule));
                                if(isset($my_args[1]))
                                {
                                    $my_args[1] = do_shortcode($my_args[1]);
                                    $my_args[0] = do_shortcode($my_args[0]);
                                    $custom_field_content = trim($my_args[1]);
                                    $custom_field_content = replaceAIPostShortcodes($custom_field_content, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    $custom_field_content = aiomatic_replacetopics($custom_field_content, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    $custom_field_content = aiomatic_replaceSynergyShortcodes($custom_field_content);
                                    $custom_field_content = $spintax->Parse($custom_field_content, $block_arr);
                                    $custom_field_content = aiomatic_replaceContentShortcodes($custom_field_content, $img_attr, $ai_command);
                                    if(stristr($my_args[1], 'serialize_') !== false)
                                    {
                                        $custom_arr[trim($my_args[0])] = array(str_replace('serialize_', '', $custom_field_content));
                                    }
                                    else
                                    {
                                        if(stristr($my_args[0], '[') !== false && stristr($my_args[0], ']') !== false)
                                        {
                                            preg_match_all('#([^\[\]]*?)\[([^\[\]]*?)\]#', $my_args[0], $cfm);
                                            if(isset($cfm[2][0]))
                                            {
                                                if(isset($custom_arr[trim($cfm[1][0])]) && is_array($custom_arr[trim($cfm[1][0])]))
                                                {
                                                    $custom_arr[trim($cfm[1][0])] = array_merge($custom_arr[trim($cfm[1][0])], array(trim($cfm[2][0]) => $custom_field_content));
                                                }
                                                else
                                                {
                                                    $custom_arr[trim($cfm[1][0])] = array(trim($cfm[2][0]) => $custom_field_content);
                                                }
                                            }
                                            else
                                            {
                                                $custom_arr[trim($my_args[0])] = $custom_field_content;
                                            }
                                        }
                                        else
                                        {
                                            $custom_arr[trim($my_args[0])] = $custom_field_content;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    $custom_arr = array_merge($custom_arr, array('aiomatic_auto_post_spinned' => $already_spinned, 'aiomatic_post_cats' => $extra_categories_temp, 'aiomatic_post_tags' => $post_the_tags));
                    $my_post['meta_input'] = $custom_arr;
                    $custom_tax_arr = array();
                    if($custom_tax != '')
                    {
                        if(stristr($custom_tax, '=>') != false)
                        {
                            $rule_arr = explode(';', trim($custom_tax));
                            foreach($rule_arr as $rule)
                            {
                                $my_args = explode('=>', trim($rule));
                                if(isset($my_args[1]))
                                {
                                    $custom_tax_content = trim($my_args[1]);
                                    $custom_tax_content = replaceAIPostShortcodes($custom_tax_content, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    $custom_tax_content = aiomatic_replacetopics($custom_tax_content, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    $custom_tax_content = aiomatic_replaceSynergyShortcodes($custom_tax_content);
                                    $custom_tax_content = $spintax->Parse($custom_tax_content, $block_arr);
                                    $custom_tax_content = aiomatic_replaceContentShortcodes($custom_tax_content, $img_attr, $ai_command);
                                    if(isset($custom_tax_arr[trim($my_args[0])]))
                                    {
                                        $custom_tax_arr[trim($my_args[0])] .= ',' . $custom_tax_content;
                                    }
                                    else
                                    {
                                        $custom_tax_arr[trim($my_args[0])] = $custom_tax_content;
                                    }
                                }
                            }
                        }
                    }
                    if(count($custom_tax_arr) > 0)
                    {
                        $my_post['taxo_input'] = $custom_tax_arr;
                    }
                    if ($enable_pingback == '1') {
                        $my_post['ping_status'] = 'open';
                    } else {
                        $my_post['ping_status'] = 'closed';
                    }
                    if($min_time != '' && $max_time != '')
                    {
                        $t1 = strtotime($min_time);
                        $t2 = strtotime($max_time);
                        if($t1 != false && $t2 != false)
                        {
                            $int = rand($t1, $t2);
                            $my_post['post_date'] = date('Y-m-d H:i:s', $int);
                        }
                    }
                    elseif($min_time != '')
                    {
                        $t1 = strtotime($min_time);
                        if($t1 != false)
                        {
                            $my_post['post_date'] = date('Y-m-d H:i:s', $t1);
                        }
                    }
                    elseif($max_time != '')
                    {
                        $t1 = strtotime($max_time);
                        if($t1 != false)
                        {
                            $my_post['post_date'] = date('Y-m-d H:i:s', $t1);
                        }
                    }
                    if($new_post_excerpt != '')
                    {
                        $my_post['post_excerpt']          = $new_post_excerpt;
                    }
                    $post_array[] = $my_post;
                    $count++;
                }
                elseif($posting_mode == 'title')
                {
                    $headings_arr_copy = $headings_arr;
                    $added_img_list = array();
                    $added_images = 0;
                    $heading_results = array();
                    if(count($post_title_lines) == 0)
                    {
                        break;
                    }
                    if ($count > intval($max)) {
                        break;
                    }
                    $current_index = array_rand($post_title_lines);
                    $post_title = trim($post_title_lines[$current_index]);
                    $ptlprocessed = explode('!###!', $post_title);
                    if(isset($ptlprocessed[1]) && !empty($ptlprocessed[1]) && !empty($ptlprocessed[0]))
                    {
                        $post_title = $ptlprocessed[0];
                        $post_title_keywords = $ptlprocessed[1];
                    }
                    if(isset($rss_feeds[$post_title]))
                    {
                        $post_link = $rss_feeds[$post_title]['url'];
                        $user_name = $rss_feeds[$post_title]['author'];
                        $post_cats = $rss_feeds[$post_title]['cats'];
                        $post_excerpt = $rss_feeds[$post_title]['excerpt'];
                        $final_content = $rss_feeds[$post_title]['content'];
                    }
                    $tprepp = $spintax->Parse($post_title);
                    if($tprepp != false && $tprepp != '')
                    {
                        $post_title = $tprepp;
                    }
                    $old_title = $post_title;
                    $already_spinned = 0;
                    if (filter_var($post_title, FILTER_VALIDATE_URL) === false && stristr($post_title, '%%ai_generated_title%%') === false)
                    {
                        unset($post_title_lines[$current_index]);
                    }
                    $allmodels = aiomatic_get_all_models();
                    $custom_shortcodes_arr = preg_split('/\r\n|\r|\n/', $custom_shortcodes);
                    foreach($custom_shortcodes_arr as $my_short)
                    {
                        $name_part = explode('=>', $my_short);
                        if(isset($name_part[1]) && !empty(trim($name_part[1])))
                        {
                            $shortname = trim($name_part[0]);
                            if(strstr($post_title, '%%' . $shortname . '%%'))
                            {
                                $shortval = '';
                                $ai_part = explode('@@', $name_part[1]);
                                if(isset($ai_part[1]) && !empty(trim($ai_part[1])))
                                {
                                    if(!in_array(trim($ai_part[0]), $allmodels))
                                    {
                                        $aimodel = 'text-davinci-003';
                                    }
                                    else
                                    {
                                        $aimodel = trim($ai_part[0]);
                                    }
                                    $zai_command = trim($ai_part[1]);
                                    $zmax_tokens = aiomatic_get_max_tokens($aimodel);
                                    $zquery_token_count = count(aiomatic_encode($zai_command));
                                    $zavailable_tokens = $zmax_tokens - $zquery_token_count;
                                    if($zavailable_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                                    {
                                        $string_len = strlen($zai_command);
                                        $string_len = $string_len / 2;
                                        $string_len = intval(0 - $string_len);
                                        $zai_command = aiomatic_substr($zai_command, 0, $string_len);
                                        $zai_command = trim($zai_command);
                                        $zquery_token_count = count(aiomatic_encode($zai_command));
                                        $zavailable_tokens = $zmax_tokens - $zquery_token_count;
                                    }
                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                    {
                                        $api_service = aiomatic_get_api_service($token);
                                        aiomatic_log_to_file('Calling ' . $api_service . ' (' . $aimodel . ') for custom shortcode text: ' . $zai_command);
                                    }
                                    $aierror = '';
                                    $finish_reason = '';
                                    $ztemperature = 1;
                                    $ztop_p = 1;
                                    $zpresence_penalty = 0;
                                    $zfrequency_penalty = 0;
                                    $generated_text = aiomatic_generate_text($token, $aimodel, $zai_command, $zavailable_tokens, $ztemperature, $ztop_p, $zpresence_penalty, $zfrequency_penalty, false, 'customShortcode', 0, $finish_reason, $aierror);
                                    if($generated_text === false)
                                    {
                                        aiomatic_log_to_file('Custom shortcode generator error: ' . $aierror);
                                    }
                                    else
                                    {
                                        $shortval = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                                    }
                                }
                                $post_title = str_replace('%%' . $shortname . '%%', $shortval, $post_title);
                            }
                        }
                    } 
                    if(stristr($post_title, '%%ai_generated_title%%') !== false || $title_source == 'ai')
                    {
                        if($orig_ai_command_title == '')
                        {
                            $orig_ai_command_title = $post_title;
                        }
                        if($orig_ai_command_title != '')
                        {
                            $title_ai_command = $orig_ai_command_title;
                            $title_ai_command = preg_split('/\r\n|\r|\n/', $title_ai_command);
                            $title_ai_command = array_filter($title_ai_command);
                            if(count($title_ai_command) > 0)
                            {
                                $title_ai_command = $title_ai_command[array_rand($title_ai_command)];
                            }
                            else
                            {
                                $title_ai_command = '';
                            }
                            $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                            if(!empty($title_ai_command))
                            {
                                $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                            }
                            else
                            {
                                $title_ai_command = trim(strip_tags($post_title));
                            }
                            $title_ai_command = trim($title_ai_command);
                            if (filter_var($title_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($title_ai_command, '.txt'))
                            {
                                $txt_content = aiomatic_get_web_page($title_ai_command);
                                if ($txt_content !== FALSE) 
                                {
                                    $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                    $txt_content = array_filter($txt_content);
                                    if(count($txt_content) > 0)
                                    {
                                        $txt_content = $txt_content[array_rand($txt_content)];
                                        if(trim($txt_content) != '') 
                                        {
                                            $title_ai_command = $txt_content;
                                            $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                            $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                        }
                                    }
                                }
                            }
                            if(empty($title_ai_command))
                            {
                                aiomatic_log_to_file('Empty API post title seed expression provided!');
                            }
                            else
                            {
                                if(strlen($title_ai_command) > $max_seed_tokens * 4)
                                {
                                    $title_ai_command = aiomatic_substr($title_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                                }
                                $title_ai_command = trim($title_ai_command);
                                if(empty($title_ai_command))
                                {
                                    aiomatic_log_to_file('Empty API title seed expression provided(2)! ' . print_r($title_ai_command, true));
                                    break;
                                }
                                $query_token_count = count(aiomatic_encode($title_ai_command));
                                $available_tokens = $max_tokens - $query_token_count;
                                if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                                {
                                    $string_len = strlen($title_ai_command);
                                    $string_len = $string_len / 2;
                                    $string_len = intval(0 - $string_len);
                                    $title_ai_command = aiomatic_substr($title_ai_command, 0, $string_len);
                                    $title_ai_command = trim($title_ai_command);
                                    if(empty($title_ai_command))
                                    {
                                        aiomatic_log_to_file('Empty API seed expression provided (after processing) ' . print_r($title_ai_command, true));
                                        break;
                                    }
                                    $query_token_count = count(aiomatic_encode($title_ai_command));
                                    $available_tokens = $max_tokens - $query_token_count;
                                }
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                {
                                    $api_service = aiomatic_get_api_service($token);
                                    aiomatic_log_to_file('Calling ' . $api_service . ' (' . $title_model . ') for title text: ' . $title_ai_command);
                                }
                                $aierror = '';
                                $finish_reason = '';
                                $generated_text = aiomatic_generate_text($token, $title_model, $title_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'titleID' . $param, 0, $finish_reason, $aierror);
                                if($generated_text === false)
                                {
                                    aiomatic_log_to_file('Title generator error: ' . $aierror);
                                    break;
                                }
                                else
                                {
                                    $ai_title = ucfirst(trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\'')));
                                    if($title_source == 'ai')
                                    {
                                        $old_title = $post_title;
                                        $post_title = $ai_title;
                                    }
                                    else
                                    {
                                        $post_title = str_ireplace('%%ai_generated_title%%', $ai_title, $post_title);
                                    }
                                }
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                {
                                    $api_service = aiomatic_get_api_service($token);
                                    aiomatic_log_to_file('Successfully got API title result from ' . $api_service . ': ' . $post_title);
                                }
                            }
                        }
                        else
                        {
                            aiomatic_log_to_file('Empty AI title query entered.');
                        }
                    }
                    else
                    {
                        $post_title = aiomatic_replaceSynergyShortcodes($post_title);
                    }
                    $post_title = apply_filters('aiomatic_replace_aicontent_shortcode', $post_title);
                    if(empty($post_title))
                    {
                        continue;
                    }
                    if (strpos($post_title, '%%') === false)
                    {
                        if (!isset($aiomatic_Main_Settings['do_not_check_duplicates']) || $aiomatic_Main_Settings['do_not_check_duplicates'] != 'on') 
                        {
                            $xposts = get_posts(
                                array(
                                    'post_type'              => $post_type,
                                    'title'                  => html_entity_decode($post_title),
                                    'post_status'            => 'all',
                                    'numberposts'            => 1,
                                    'update_post_term_cache' => false,
                                    'update_post_meta_cache' => false,           
                                    'orderby'                => 'post_date ID',
                                    'order'                  => 'ASC',
                                )
                            );
                            if ( ! empty( $xposts ) ) {
                                $zap = $xposts[0];
                            } else {
                                $zap = null;
                            }
                            if($zap !== null)
                            {
                                aiomatic_log_to_file('Post with specified title already existing, skipping it: ' . $post_title);
                                unset($post_title_lines[$current_index]);
                                continue;
                            }
                        }
                        $new_post_title = $post_title;
                    }
                    else
                    {
                        $new_post_title = $post_title;
                        $new_post_title = aiomatic_replaceContentShortcodes($new_post_title, $img_attr, $ai_command);
                        if (!isset($aiomatic_Main_Settings['do_not_check_duplicates']) || $aiomatic_Main_Settings['do_not_check_duplicates'] != 'on') 
                        {
                            $xposts = get_posts(
                                array(
                                    'post_type'              => $post_type,
                                    'title'                  => html_entity_decode($new_post_title),
                                    'post_status'            => 'all',
                                    'numberposts'            => 1,
                                    'update_post_term_cache' => false,
                                    'update_post_meta_cache' => false,           
                                    'orderby'                => 'post_date ID',
                                    'order'                  => 'ASC',
                                )
                            );
                            if ( ! empty( $xposts ) ) {
                                $zap = $xposts[0];
                            } else {
                                $zap = null;
                            }
                            if($zap !== null)
                            {
                                aiomatic_log_to_file('Post with specified title already published, skipping it: ' . $new_post_title);
                                unset($post_title_lines[$current_index]);
                                continue;
                            }
                        }
                    }
                    $get_img = '';
                    if($royalty_free == '1')
                    {
                        if($enable_ai_images == '1')
                        {
                            $query_words = $post_title;
                            if($image_query == '')
                            {
                                $image_query = $temp_post;
                            }
                            if($orig_ai_command_image == '')
                            {
                                $orig_ai_command_image = $image_query;
                            }
                            if($orig_ai_command_image != '')
                            {
                                $ai_command_image = $orig_ai_command_image;
                                $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                $ai_command_image = array_filter($ai_command_image);
                                if(count($ai_command_image) > 0)
                                {
                                    $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                }
                                else
                                {
                                    $ai_command_image = '';
                                }
                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                if(!empty($ai_command_image))
                                {
                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                }
                                else
                                {
                                    $ai_command_image = trim(strip_tags($post_title));
                                }
                                $ai_command_image = trim($ai_command_image);
                                if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                {
                                    $txt_content = aiomatic_get_web_page($ai_command_image);
                                    if ($txt_content !== FALSE) 
                                    {
                                        $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                        $txt_content = array_filter($txt_content);
                                        if(count($txt_content) > 0)
                                        {
                                            $txt_content = $txt_content[array_rand($txt_content)];
                                            if(trim($txt_content) != '') 
                                            {
                                                $ai_command_image = $txt_content;
                                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                            }
                                        }
                                    }
                                }
                                if(empty($ai_command_image))
                                {
                                    aiomatic_log_to_file('Empty API featured image seed expression provided!');
                                }
                                else
                                {
                                    if(strlen($ai_command_image) > 400)
                                    {
                                        $ai_command_image = aiomatic_substr($ai_command_image, 0, 400);
                                    }
                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                    {
                                        $api_service = aiomatic_get_api_service($token);
                                        aiomatic_log_to_file('Calling ' . $api_service . ' for featured image: ' . $ai_command_image);
                                    }
                                    $aierror = '';
                                    $get_img = aiomatic_generate_ai_image($token, 1, $ai_command_image, $image_size, 'featuredImage', true, 0, $aierror);
                                    if($get_img !== false)
                                    {
                                        foreach($get_img as $tmpimg)
                                        {
                                            $get_img = $tmpimg;
                                            break;
                                        }
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            aiomatic_log_to_file('AI generated featured image returned: ' . $get_img);
                                        }
                                    }
                                    else
                                    {
                                        aiomatic_log_to_file('Failed to generate AI featured image: ' . $aierror);
                                        $get_img = '';
                                    }
                                }
                            }
                            else
                            {
                                aiomatic_log_to_file('Empty AI featured image query entered.');
                            }
                        }
                        elseif($enable_ai_images == '2')
                        {
                            $query_words = $post_title;
                            if($image_query == '')
                            {
                                $image_query = $temp_post;
                            }
                            if($orig_ai_command_image == '')
                            {
                                $orig_ai_command_image = $image_query;
                            }
                            if($orig_ai_command_image != '')
                            {
                                $ai_command_image = $orig_ai_command_image;
                                $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                $ai_command_image = array_filter($ai_command_image);
                                if(count($ai_command_image) > 0)
                                {
                                    $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                }
                                else
                                {
                                    $ai_command_image = '';
                                }
                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                if(!empty($ai_command_image))
                                {
                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                }
                                else
                                {
                                    $ai_command_image = trim(strip_tags($post_title));
                                }
                                $ai_command_image = trim($ai_command_image);
                                if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                {
                                    $txt_content = aiomatic_get_web_page($ai_command_image);
                                    if ($txt_content !== FALSE) 
                                    {
                                        $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                        $txt_content = array_filter($txt_content);
                                        if(count($txt_content) > 0)
                                        {
                                            $txt_content = $txt_content[array_rand($txt_content)];
                                            if(trim($txt_content) != '') 
                                            {
                                                $ai_command_image = $txt_content;
                                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                            }
                                        }
                                    }
                                }
                                if(empty($ai_command_image))
                                {
                                    aiomatic_log_to_file('Empty API featured image seed expression provided!');
                                }
                                else
                                {
                                    if(strlen($ai_command_image) > 2000)
                                    {
                                        $ai_command_image = aiomatic_substr($ai_command_image, 0, 2000);
                                    }
                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                    {
                                        $api_service = 'Stability.AI';
                                        aiomatic_log_to_file('Calling ' . $api_service . ' for featured image: ' . $ai_command_image);
                                    }
                                    if($image_size == '256x256')
                                    {
                                        $width = '512';
                                        $height = '512';
                                    }
                                    elseif($image_size == '512x512')
                                    {
                                        $width = '512';
                                        $height = '512';
                                    }
                                    elseif($image_size == '1024x1024')
                                    {
                                        $width = '1024';
                                        $height = '1024';
                                    }
                                    else
                                    {
                                        $width = '512';
                                        $height = '512';
                                    }
                                    $get_img = aiomatic_generate_stability_image($ai_command_image, $height, $width, 'featuredStableImage', 0, false);
                                    if($get_img !== false)
                                    {
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            aiomatic_log_to_file('AI generated featured image returned: ' . $get_img[1]);
                                        }
                                    }
                                    else
                                    {
                                        aiomatic_log_to_file('Failed to generate Stability.AI featured image.');
                                        $get_img = '';
                                    }
                                }
                            }
                            else
                            {
                                aiomatic_log_to_file('Empty AI featured image query entered.');
                            }
                        }
                        else
                        {
                            $image_query_set = false;
                            $query_words = '';
                            $ai_command_image = '';
                            if($orig_ai_command_image == '')
                            {
                                $orig_ai_command_image = $image_query;
                            }
                            if($orig_ai_command_image != '')
                            {
                                $ai_command_image = $orig_ai_command_image;
                                $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                $ai_command_image = array_filter($ai_command_image);
                                if(count($ai_command_image) > 0)
                                {
                                    $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                }
                                else
                                {
                                    $ai_command_image = '';
                                }
                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                if(!empty($ai_command_image))
                                {
                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                }
                                else
                                {
                                    $ai_command_image = trim(strip_tags($post_title));
                                }
                                $ai_command_image = trim($ai_command_image);
                                if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                {
                                    $txt_content = aiomatic_get_web_page($ai_command_image);
                                    if ($txt_content !== FALSE) 
                                    {
                                        $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                        $txt_content = array_filter($txt_content);
                                        if(count($txt_content) > 0)
                                        {
                                            $txt_content = $txt_content[array_rand($txt_content)];
                                            if(trim($txt_content) != '') 
                                            {
                                                $ai_command_image = $txt_content;
                                                $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                            }
                                        }
                                    }
                                }
                            }
                            if($ai_command_image != '')
                            {
                                $query_words = $ai_command_image;
                                $image_query = $ai_command_image;
                                $image_query_set = true;
                            }
                            if(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'textrazor')
                            {
                                if(isset($aiomatic_Main_Settings['textrazor_key']) && trim($aiomatic_Main_Settings['textrazor_key']) != '')
                                {
                                    try
                                    {
                                        if(!class_exists('TextRazor'))
                                        {
                                            require_once(dirname(__FILE__) . "/res/TextRazor.php");
                                        }
                                        TextRazorSettings::setApiKey(trim($aiomatic_Main_Settings['textrazor_key']));
                                        $textrazor = new TextRazor();
                                        $textrazor->addExtractor('entities');
                                        $response = $textrazor->analyze($image_query);
                                        if (isset($response['response']['entities'])) 
                                        {
                                            foreach ($response['response']['entities'] as $entity) 
                                            {
                                                $query_words = '';
                                                if(isset($entity['entityEnglishId']))
                                                {
                                                    $query_words = $entity['entityEnglishId'];
                                                }
                                                else
                                                {
                                                    $query_words = $entity['entityId'];
                                                }
                                                if($query_words != '')
                                                {
                                                    $z_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $img_attr, 10, true);
                                                    if(!empty($z_img))
                                                    {
                                                        $get_img = $z_img;
                                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                            aiomatic_log_to_file('Royalty Free Image Generated with help of TextRazor (kw: "' . $query_words . '"): ' . $z_img);
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    catch(Exception $e)
                                    {
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                            aiomatic_log_to_file('Failed to search for keywords using TextRazor (2): ' . $e->getMessage());
                                        }
                                    }
                                }
                            }
                            elseif(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'openai')
                            {
                                if(isset($aiomatic_Main_Settings['keyword_prompts']) && trim($aiomatic_Main_Settings['keyword_prompts']) != '')
                                {
                                    if(isset($aiomatic_Main_Settings['keyword_model']) && $aiomatic_Main_Settings['keyword_model'] != '')
                                    {
                                        $kw_model = $aiomatic_Main_Settings['keyword_model'];
                                    }
                                    else
                                    {
                                        $kw_model = 'text-davinci-003';
                                    }
                                    $title_ai_command = trim($aiomatic_Main_Settings['keyword_prompts']);
                                    $title_ai_command = preg_split('/\r\n|\r|\n/', $title_ai_command);
                                    $title_ai_command = array_filter($title_ai_command);
                                    if(count($title_ai_command) > 0)
                                    {
                                        $title_ai_command = $title_ai_command[array_rand($title_ai_command)];
                                    }
                                    else
                                    {
                                        $title_ai_command = '';
                                    }
                                    $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                    if(!empty($title_ai_command))
                                    {
                                        $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    }
                                    $title_ai_command = trim($title_ai_command);
                                    if (filter_var($title_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($title_ai_command, '.txt'))
                                    {
                                        $txt_content = aiomatic_get_web_page($title_ai_command);
                                        if ($txt_content !== FALSE) 
                                        {
                                            $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                            $txt_content = array_filter($txt_content);
                                            if(count($txt_content) > 0)
                                            {
                                                $txt_content = $txt_content[array_rand($txt_content)];
                                                if(trim($txt_content) != '') 
                                                {
                                                    $title_ai_command = $txt_content;
                                                    $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                                    $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                }
                                            }
                                        }
                                    }
                                    if(empty($title_ai_command))
                                    {
                                        aiomatic_log_to_file('Empty API keyword extractor seed expression provided!');
                                        $title_ai_command = 'Type the most relevant keyword, no other text before or after it, for a blog post titled:  ' . trim(strip_tags($post_title));
                                    } 
                                    if(strlen($title_ai_command) > $max_seed_tokens * 4)
                                    {
                                        $title_ai_command = aiomatic_substr($title_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                                    }
                                    $title_ai_command = trim($title_ai_command);
                                    if(empty($title_ai_command))
                                    {
                                        aiomatic_log_to_file('Empty API title seed expression provided(3)! ' . print_r($title_ai_command, true));
                                    }
                                    else
                                    {
                                        $query_token_count = count(aiomatic_encode($title_ai_command));
                                        $available_tokens = $max_tokens - $query_token_count;
                                        if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                                        {
                                            $string_len = strlen($title_ai_command);
                                            $string_len = $string_len / 2;
                                            $string_len = intval(0 - $string_len);
                                            $title_ai_command = aiomatic_substr($title_ai_command, 0, $string_len);
                                            $title_ai_command = trim($title_ai_command);
                                            $query_token_count = count(aiomatic_encode($title_ai_command));
                                            $available_tokens = $max_tokens - $query_token_count;
                                        }
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            $api_service = aiomatic_get_api_service($token);
                                            aiomatic_log_to_file('Calling ' . $api_service . ' (' . $kw_model . ') for title text: ' . $title_ai_command);
                                        }
                                        $aierror = '';
                                        $finish_reason = '';
                                        $generated_text = aiomatic_generate_text($token, $kw_model, $title_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'keywordID' . $param, 0, $finish_reason, $aierror);
                                        if($generated_text === false)
                                        {
                                            aiomatic_log_to_file('Keyword generator error: ' . $aierror);
                                            $ai_title = '';
                                        }
                                        else
                                        {
                                            $ai_title = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                                            $ai_titles = explode(',', $ai_title);
                                            foreach($ai_titles as $query_words)
                                            {
                                                $z_img = aiomatic_get_free_image($aiomatic_Main_Settings, trim($query_words), $img_attr, 10, true);
                                                if(!empty($z_img))
                                                {
                                                    $get_img = $z_img;
                                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                        aiomatic_log_to_file('Royalty Free Image Generated with help of AI (kw: "' . $query_words . '"): ' . $z_img);
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            $api_service = aiomatic_get_api_service($token);
                                            aiomatic_log_to_file('Successfully got API keyword result from ' . $api_service . ': ' . $ai_title);
                                        }
                                    }
                                }
                            }
                            if(empty($get_img))
                            {
                                if($image_query_set == true && !empty($image_query))
                                {
                                    $get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $image_query, $img_attr, 10, true);
                                    if($get_img == '' || $get_img === false)
                                    {
                                        if(isset($aiomatic_Main_Settings['bimage']) && $aiomatic_Main_Settings['bimage'] == 'on')
                                        {
                                            $keyword_class = new Aiomatic_keywords();
                                            $image_query = $keyword_class->keywords($image_query, 1);
                                            $get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $image_query, $img_attr, 20, true);
                                        }
                                    }
                                }
                                if(empty($get_img))
                                {
                                    $keyword_class = new Aiomatic_keywords();
                                    $query_words = $keyword_class->keywords($post_title, 2);
                                    $get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $img_attr, 10, true);
                                    if($get_img == '' || $get_img === false)
                                    {
                                        if(isset($aiomatic_Main_Settings['bimage']) && $aiomatic_Main_Settings['bimage'] == 'on')
                                        {
                                            $query_words = $keyword_class->keywords($post_title, 1);
                                            $get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $img_attr, 20, true);
                                            if($get_img == '' || $get_img === false)
                                            {
                                                if(isset($aiomatic_Main_Settings['no_royalty_skip']) && $aiomatic_Main_Settings['no_royalty_skip'] == 'on')
                                                {
                                                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                        aiomatic_log_to_file('Skipping importing because no royalty free image found.');
                                                    }
                                                    unset($post_title_lines[$current_index]);
                                                    continue;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if(isset($aiomatic_Main_Settings['no_royalty_skip']) && $aiomatic_Main_Settings['no_royalty_skip'] == 'on')
                                            {
                                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                    aiomatic_log_to_file('Skipping importing because no royalty free image found.');
                                                }
                                                unset($post_title_lines[$current_index]);
                                                continue;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (isset($aiomatic_Main_Settings['spin_text']) && $aiomatic_Main_Settings['spin_text'] !== 'disabled') 
                    {
                        $already_spinned = '1';
                    }
                    $my_post                              = array();
                    $my_post['aiomatic_post_image']       = $get_img;
                    if($enable_ai_images == '2')
                    {
                        $my_post['aiomatic_local_image']      = '1';
                    }
                    else
                    {
                        $my_post['aiomatic_local_image']      = '0';
                    }
                    $my_post['aiomatic_enable_pingbacks'] = $enable_pingback;
                    $my_post['default_category']          = $default_category;
                    $my_post['post_type']                 = $post_type;
                    $my_post['comment_status']            = $accept_comments;
                    $my_post['post_status']               = $post_status;
                    $my_post['post_author']               = $post_user_name;
                    $ai_command = $orig_ai_command;
                    $ai_command = aiomatic_replaceSynergyShortcodes($ai_command);
                    if(!empty($ai_command))
                    {
                        $aicontent = replaceAIPostShortcodes($ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                    }
                    else
                    {
                        $aicontent = trim(strip_tags($post_title));
                    }
                    if (filter_var($aicontent, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($aicontent, '.txt'))
                    {
                        $txt_content = aiomatic_get_web_page($aicontent);
                        if ($txt_content !== FALSE) 
                        {
                            $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                            $txt_content = array_filter($txt_content);
                            if(count($txt_content) > 0)
                            {
                                $txt_content = $txt_content[array_rand($txt_content)];
                                if(trim($txt_content) != '') 
                                {
                                    $aicontent = $txt_content;
                                    $aicontent = aiomatic_replaceSynergyShortcodes($aicontent);
                                    $aicontent = replaceAIPostShortcodes($aicontent, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                }
                            }
                        }
                    }
                    $last_char = aiomatic_substr($aicontent, -1, null);
                    if(!ctype_punct($last_char))
                    {
                        $aicontent .= '.';
                    }
                    if(strlen($aicontent) > $max_seed_tokens * 4)
                    {
                        $aicontent = aiomatic_substr($aicontent, 0, (0-($max_seed_tokens * 4)));
                    }
                    $aicontent = trim($aicontent);
                    if(empty($aicontent))
                    {
                        aiomatic_log_to_file('Empty API seed expression provided! ' . print_r($ai_command, true));
                        break;
                    }
                    $query_token_count = count(aiomatic_encode($aicontent));
                    $available_tokens = $max_tokens - $query_token_count;
                    if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                    {
                        $string_len = strlen($aicontent);
                        $string_len = $string_len / 2;
                        $string_len = intval(0 - $string_len);
                        $aicontent = aiomatic_substr($aicontent, 0, $string_len);
                        $aicontent = trim($aicontent);
                        if(empty($aicontent))
                        {
                            aiomatic_log_to_file('Empty API seed expression provided (after processing) ' . print_r($ai_command, true));
                            break;
                        }
                        $query_token_count = count(aiomatic_encode($aicontent));
                        $available_tokens = $max_tokens - $query_token_count;
                    }
                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                    {
                        $api_service = aiomatic_get_api_service($token);
                        aiomatic_log_to_file('Calling ' . $api_service . ' (' . $model . ') for text: ' . $aicontent);
                    }
                    $aierror = '';
                    $finish_reason = '';
                    $generated_text = aiomatic_generate_text($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'contentID' . $param, 0, $finish_reason, $aierror);
                    if($generated_text === false)
                    {
                        aiomatic_log_to_file($aierror);
                        break;
                    }
                    else
                    {
                        $new_post_content = ucfirst(trim(nl2br(trim($generated_text))));
                    }
                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                    {
                        $api_service = aiomatic_get_api_service($token);
                        aiomatic_log_to_file('Successfully got API result from ' . $api_service . '.');
                    }
                    if($min_char == '')
                    {
                        $min_char = 0;
                    }
                    else
                    {
                        $min_char = intval($min_char);
                    }
                    $cnt = 1;
                    $max_fails = 10;
                    $failed_calls = 0;
                    $heading_results = $headings_arr;
                    if($headings != '' && is_numeric($headings))
                    {
                        if(count($heading_results) < $headings)
                        {
                            $heading_results_ai = aiomatic_scrape_related_questions($new_post_title, $headings, $headings_model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $headings_ai_command);
                            $heading_results = array_merge($heading_results, $heading_results_ai);
                        }
                    }
                    $ai_retry = false;
                    if($image_size == '')
                    {
                        $image_size = '256x256';
                    }
                    if(strlen($new_post_content) > $min_char)
                    {
                        $add_my_image = '';
                        $temp_get_img = '';
                        if(count($heading_results) > 0)
                        {
                            $rand_heading = '';
                            $saverand = array_rand($heading_results);
                            $rand_heading = $heading_results[$saverand];
                            unset($heading_results[$saverand]);
                            if(isset($rand_heading['q']))
                            {
                                $rand_heading['q'] = preg_replace('#^\d+\.([\s\S]*)#i', '$1', $rand_heading['q']);
                                $heading_val = '<h2>' . $rand_heading['q'] . '</h2>';
                                if($rand_heading['a'] != '')
                                {
                                    $heading_val .= '<span>' . $rand_heading['a'] . '</span>';
                                }
                                $image_query = $rand_heading['q'];
                            }
                        }
                        if($heading_val == '')
                        {
                            $temp_post = trim($new_post_content);
                        }
                        else
                        {
                            $temp_post = trim($heading_val);
                        }
                        
                        if($images != '' && is_numeric($images) && $images > $added_images)
                        {
                            $query_words = $post_title;
                            if($image_query == '')
                            {
                                $image_query = $temp_post;
                            }
                            if($enable_ai_images == '1')
                            {
                                if($orig_ai_command_image == '')
                                {
                                    $orig_ai_command_image = $image_query;
                                }
                                if($orig_ai_command_image != '')
                                {
                                    $ai_command_image = $orig_ai_command_image;
                                    $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                    $ai_command_image = array_filter($ai_command_image);
                                    if(count($ai_command_image) > 0)
                                    {
                                        $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                    }
                                    else
                                    {
                                        $ai_command_image = '';
                                    }
                                    $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                    if(!empty($ai_command_image))
                                    {
                                        $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    }
                                    else
                                    {
                                        $ai_command_image = trim(strip_tags($post_title));
                                    }
                                    $ai_command_image = trim($ai_command_image);
                                    if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                    {
                                        $txt_content = aiomatic_get_web_page($ai_command_image);
                                        if ($txt_content !== FALSE) 
                                        {
                                            $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                            $txt_content = array_filter($txt_content);
                                            if(count($txt_content) > 0)
                                            {
                                                $txt_content = $txt_content[array_rand($txt_content)];
                                                if(trim($txt_content) != '') 
                                                {
                                                    $ai_command_image = $txt_content;
                                                    $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                }
                                            }
                                        }
                                    }
                                    if(empty($ai_command_image))
                                    {
                                        aiomatic_log_to_file('Empty API image seed expression provided!');
                                    }
                                    else
                                    {
                                        if(strlen($ai_command_image) > 400)
                                        {
                                            $ai_command_image = aiomatic_substr($ai_command_image, 0, 400);
                                        }
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            $api_service = aiomatic_get_api_service($token);
                                            aiomatic_log_to_file('Calling ' . $api_service . ' for image: ' . $ai_command_image);
                                        }
                                        $aierror = '';
                                        $temp_get_imgs = aiomatic_generate_ai_image($token, 1, $ai_command_image, $image_size, 'contentImage', false, 0, $aierror);
                                        if($temp_get_imgs !== false)
                                        {
                                            foreach($temp_get_imgs as $tmpimg)
                                            {
                                                $added_images++;
                                                $added_img_list[] = $tmpimg;
                                                $temp_get_img = $tmpimg;
                                            }
                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                            {
                                                aiomatic_log_to_file('AI generated image returned: ' . $temp_get_img);
                                            }
                                        }
                                        else
                                        {
                                            aiomatic_log_to_file('Failed to generate AI image: ' . $aierror);
                                            $temp_get_img = '';
                                        }
                                    }
                                }
                                else
                                {
                                    aiomatic_log_to_file('Empty AI image query entered.');
                                }
                            }
                            elseif($enable_ai_images == '2')
                            {
                                if($orig_ai_command_image == '')
                                {
                                    $orig_ai_command_image = $image_query;
                                }
                                if($orig_ai_command_image != '')
                                {
                                    $ai_command_image = $orig_ai_command_image;
                                    $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                    $ai_command_image = array_filter($ai_command_image);
                                    if(count($ai_command_image) > 0)
                                    {
                                        $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                    }
                                    else
                                    {
                                        $ai_command_image = '';
                                    }
                                    $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                    if(!empty($ai_command_image))
                                    {
                                        $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    }
                                    else
                                    {
                                        $ai_command_image = trim(strip_tags($post_title));
                                    }
                                    $ai_command_image = trim($ai_command_image);
                                    if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                    {
                                        $txt_content = aiomatic_get_web_page($ai_command_image);
                                        if ($txt_content !== FALSE) 
                                        {
                                            $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                            $txt_content = array_filter($txt_content);
                                            if(count($txt_content) > 0)
                                            {
                                                $txt_content = $txt_content[array_rand($txt_content)];
                                                if(trim($txt_content) != '') 
                                                {
                                                    $ai_command_image = $txt_content;
                                                    $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                }
                                            }
                                        }
                                    }
                                    if(empty($ai_command_image))
                                    {
                                        aiomatic_log_to_file('Empty API image seed expression provided!');
                                    }
                                    else
                                    {
                                        if(strlen($ai_command_image) > 2000)
                                        {
                                            $ai_command_image = aiomatic_substr($ai_command_image, 0, 2000);
                                        }
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                        {
                                            $api_service = 'Stability.AI';
                                            aiomatic_log_to_file('Calling ' . $api_service . ' for image: ' . $ai_command_image);
                                        }
                                        if($image_size == '256x256')
                                        {
                                            $width = '512';
                                            $height = '512';
                                        }
                                        elseif($image_size == '512x512')
                                        {
                                            $width = '512';
                                            $height = '512';
                                        }
                                        elseif($image_size == '1024x1024')
                                        {
                                            $width = '1024';
                                            $height = '1024';
                                        }
                                        else
                                        {
                                            $width = '512';
                                            $height = '512';
                                        }
                                        $temp_get_imgs = aiomatic_generate_stability_image($ai_command_image, $height, $width, 'contentStableImage', 0, false);
                                        if($temp_get_imgs !== false)
                                        {
                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                            {
                                                aiomatic_log_to_file('AI generated image returned: ' . $temp_get_imgs[1]);
                                            }
                                            $added_images++;
                                            $added_img_list[] = $temp_get_imgs[1];
                                            $temp_get_img = $temp_get_imgs[1];
                                        }
                                        else
                                        {
                                            aiomatic_log_to_file('Failed to generate Stability.AI image.');
                                            $temp_get_img = '';
                                        }
                                    }
                                }
                                else
                                {
                                    aiomatic_log_to_file('Empty AI image query entered.');
                                }
                            }
                            elseif(count($images_arr) > 0)
                            {
                                $first_el = array_shift($images_arr);
                                $first_el = aiomatic_replaceSynergyShortcodes($first_el);
                                $added_images++;
                                $added_img_list[] = $first_el;
                                $temp_get_img = $first_el;
                            }
                            else
                            {
                                $image_query_set = false;
                                $query_words = '';
                                $ai_command_image = '';
                                if($orig_ai_command_image == '')
                                {
                                    $orig_ai_command_image = $image_query;
                                }
                                if($orig_ai_command_image != '')
                                {
                                    $ai_command_image = $orig_ai_command_image;
                                    $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                    $ai_command_image = array_filter($ai_command_image);
                                    if(count($ai_command_image) > 0)
                                    {
                                        $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                    }
                                    else
                                    {
                                        $ai_command_image = '';
                                    }
                                    $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                    if(!empty($ai_command_image))
                                    {
                                        $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    }
                                    else
                                    {
                                        $ai_command_image = trim(strip_tags($post_title));
                                    }
                                    $ai_command_image = trim($ai_command_image);
                                    if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                    {
                                        $txt_content = aiomatic_get_web_page($ai_command_image);
                                        if ($txt_content !== FALSE) 
                                        {
                                            $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                            $txt_content = array_filter($txt_content);
                                            if(count($txt_content) > 0)
                                            {
                                                $txt_content = $txt_content[array_rand($txt_content)];
                                                if(trim($txt_content) != '') 
                                                {
                                                    $ai_command_image = $txt_content;
                                                    $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                }
                                            }
                                        }
                                    }
                                }
                                if($ai_command_image != '')
                                {
                                    $query_words = $ai_command_image;
                                    $image_query = $ai_command_image;
                                    $image_query_set = true;
                                }
                                if(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'textrazor')
                                {
                                    if(isset($aiomatic_Main_Settings['textrazor_key']) && trim($aiomatic_Main_Settings['textrazor_key']) != '')
                                    {
                                        try
                                        {
                                            if(!class_exists('TextRazor'))
                                            {
                                                require_once(dirname(__FILE__) . "/res/TextRazor.php");
                                            }
                                            TextRazorSettings::setApiKey(trim($aiomatic_Main_Settings['textrazor_key']));
                                            $textrazor = new TextRazor();
                                            $textrazor->addExtractor('entities');
                                            $response = $textrazor->analyze($image_query);
                                            if (isset($response['response']['entities'])) 
                                            {
                                                foreach ($response['response']['entities'] as $entity) 
                                                {
                                                    $query_words = '';
                                                    if(isset($entity['entityEnglishId']))
                                                    {
                                                        $query_words = $entity['entityEnglishId'];
                                                    }
                                                    else
                                                    {
                                                        $query_words = $entity['entityId'];
                                                    }
                                                    if($query_words != '')
                                                    {
                                                        $z_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $img_attr, 10, false);
                                                        if(!empty($z_img))
                                                        {
                                                            $added_images++;
                                                            $added_img_list[] = $z_img;
                                                            $temp_get_img = $z_img;
                                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                                aiomatic_log_to_file('Royalty Free Image Generated with help of TextRazor (kw: "' . $query_words . '"): ' . $z_img);
                                                            }
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        catch(Exception $e)
                                        {
                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                aiomatic_log_to_file('Failed to search for keywords using TextRazor (2): ' . $e->getMessage());
                                            }
                                        }
                                    }
                                }
                                elseif(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'openai')
                                {
                                    if(isset($aiomatic_Main_Settings['keyword_prompts']) && trim($aiomatic_Main_Settings['keyword_prompts']) != '')
                                    {
                                        if(isset($aiomatic_Main_Settings['keyword_model']) && $aiomatic_Main_Settings['keyword_model'] != '')
                                        {
                                            $kw_model = $aiomatic_Main_Settings['keyword_model'];
                                        }
                                        else
                                        {
                                            $kw_model = 'text-davinci-003';
                                        }
                                        $title_ai_command = trim($aiomatic_Main_Settings['keyword_prompts']);
                                        $title_ai_command = preg_split('/\r\n|\r|\n/', $title_ai_command);
                                        $title_ai_command = array_filter($title_ai_command);
                                        if(count($title_ai_command) > 0)
                                        {
                                            $title_ai_command = $title_ai_command[array_rand($title_ai_command)];
                                        }
                                        else
                                        {
                                            $title_ai_command = '';
                                        }
                                        $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                        if(!empty($title_ai_command))
                                        {
                                            $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                        }
                                        $title_ai_command = trim($title_ai_command);
                                        if (filter_var($title_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($title_ai_command, '.txt'))
                                        {
                                            $txt_content = aiomatic_get_web_page($title_ai_command);
                                            if ($txt_content !== FALSE) 
                                            {
                                                $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                                $txt_content = array_filter($txt_content);
                                                if(count($txt_content) > 0)
                                                {
                                                    $txt_content = $txt_content[array_rand($txt_content)];
                                                    if(trim($txt_content) != '') 
                                                    {
                                                        $title_ai_command = $txt_content;
                                                        $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                                        $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                    }
                                                }
                                            }
                                        }
                                        if(empty($title_ai_command))
                                        {
                                            aiomatic_log_to_file('Empty API keyword extractor seed expression provided!');
                                            $title_ai_command = 'Type the most relevant keyword, no other text before or after it, for a blog post titled:  ' . trim(strip_tags($post_title));
                                        }
                                        if(strlen($title_ai_command) > $max_seed_tokens * 4)
                                        {
                                            $title_ai_command = aiomatic_substr($title_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                                        }
                                        $title_ai_command = trim($title_ai_command);
                                        if(empty($title_ai_command))
                                        {
                                            aiomatic_log_to_file('Empty API title seed expression provided(4)! ' . print_r($title_ai_command, true));
                                        }
                                        else
                                        {
                                            $query_token_count = count(aiomatic_encode($title_ai_command));
                                            $available_tokens = $max_tokens - $query_token_count;
                                            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                                            {
                                                $string_len = strlen($title_ai_command);
                                                $string_len = $string_len / 2;
                                                $string_len = intval(0 - $string_len);
                                                $title_ai_command = aiomatic_substr($title_ai_command, 0, $string_len);
                                                $title_ai_command = trim($title_ai_command);
                                                $query_token_count = count(aiomatic_encode($title_ai_command));
                                                $available_tokens = $max_tokens - $query_token_count;
                                            }
                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                            {
                                                $api_service = aiomatic_get_api_service($token);
                                                aiomatic_log_to_file('Calling ' . $api_service . ' for (' . $kw_model . ') title text: ' . $title_ai_command);
                                            }
                                            $aierror = '';
                                            $finish_reason = '';
                                            $generated_text = aiomatic_generate_text($token, $kw_model, $title_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'keywordID' . $param, 0, $finish_reason, $aierror);
                                            if($generated_text === false)
                                            {
                                                aiomatic_log_to_file('Keyword generator error: ' . $aierror);
                                                $ai_title = '';
                                            }
                                            else
                                            {
                                                $ai_title = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                                                $ai_titles = explode(',', $ai_title);
                                                foreach($ai_titles as $query_words)
                                                {
                                                    $z_img = aiomatic_get_free_image($aiomatic_Main_Settings, trim($query_words), $img_attr, 10, false);
                                                    if(!empty($z_img))
                                                    {
                                                        $added_images++;
                                                        $added_img_list[] = $z_img;
                                                        $temp_get_img = $z_img;
                                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                            aiomatic_log_to_file('Royalty Free Image Generated with help of AI (kw: "' . $query_words . '"): ' . $z_img);
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                            {
                                                $api_service = aiomatic_get_api_service($token);
                                                aiomatic_log_to_file('Successfully got API keyword result from ' . $api_service . ': ' . $ai_title);
                                            }
                                        }
                                    }
                                }
                                if(empty($temp_get_img))
                                {
                                    $keyword_class = new Aiomatic_keywords();
                                    $query_words = $keyword_class->keywords($image_query, 2);
                                    $temp_img_attr = '';
                                    $temp_get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $temp_img_attr, 10, false);
                                    if($temp_get_img == '' || $temp_get_img === false)
                                    {
                                        $query_words = $keyword_class->keywords($image_query, 1);
                                        $temp_get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $temp_img_attr, 20, false);
                                        if($temp_get_img == '' || $temp_get_img === false)
                                        {
                                            $temp_get_img = '';
                                        }
                                        else
                                        {
                                            if(!in_array($temp_get_img, $added_img_list))
                                            {
                                                $added_images++;
                                                $added_img_list[] = $temp_get_img;
                                            }
                                            else
                                            {
                                                $temp_get_img = '';
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if(!in_array($temp_get_img, $added_img_list))
                                        {
                                            $added_images++;
                                            $added_img_list[] = $temp_get_img;
                                        }
                                        else
                                        {
                                            $temp_get_img = '';
                                        }
                                    }
                                }
                            }
                            if($temp_get_img != '')
                            {
                                $add_my_image = '<br/><img class="aiomatic_image_class" src="' . $temp_get_img . '" alt="' . $query_words . '"><br/>';
                            }
                        }
                        if($heading_val == '')
                        {
                            $new_post_content = $add_my_image . $new_post_content;
                        }
                        else
                        {
                            $new_post_content = $add_my_image . $heading_val . ' ' . $new_post_content;
                        }
                    }
                    else
                    {
                        $ai_continue_title = $post_title;
                        while(strlen(strip_tags($new_post_content)) < $min_char)
                        {
                            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) < $cnt)
                            {
                                break;
                            }
                            $just_set_fallback = false;
                            $image_query = '';
                            $heading_val = '';
                            if(count($heading_results) > 0)
                            {
                                $rand_heading = '';
                                $saverand = array_rand($heading_results);
                                $rand_heading = $heading_results[$saverand];
                                unset($heading_results[$saverand]);
                                if(isset($rand_heading['q']))
                                {
                                    $rand_heading['q'] = preg_replace('#^\d+\.([\s\S]*)#i', '$1', $rand_heading['q']);
                                    $heading_val = '<h2>' . $rand_heading['q'] . '</h2>' . '<span>' . $rand_heading['a'];
                                    $image_query = $rand_heading['q'];
                                }
                            }
                            
                            if($heading_val == '')
                            {
                                $temp_post = trim($new_post_content);
                            }
                            else
                            {
                                $temp_post = trim($heading_val);
                            }
                            if(strlen($temp_post) > $max_continue_tokens * 4)
                            {
                                $negative_contiue_tokens = 0 - ($max_continue_tokens * 4);
                                $newaicontent = aiomatic_substr($temp_post, $negative_contiue_tokens, null);
                            }
                            else
                            {
                                $newaicontent = $temp_post;
                            }
                            $add_me_to_text = '';
                            if($ai_retry == true)
                            {
                                $just_set_fallback = true;
                                if(count($headings_arr_copy) == 0)
                                {
                                    if (isset($aiomatic_Main_Settings['alternate_continue']) && $aiomatic_Main_Settings['alternate_continue'] == 'on')
                                    {
                                        $newaicontent = $newaicontent . ' ' . $ai_continue_title;
                                    }
                                    else
                                    {
                                        $aierror = '';
                                        $finish_reason = '';
                                        $generated_text = aiomatic_generate_text($token, $model, 'Write a People Also Asked question related to "' . $ai_continue_title . '"', AIOMATIC_DEFAULT_MAX_TOKENS, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'headingID' . $param, 0, $finish_reason, $aierror);
                                        if($generated_text === false)
                                        {
                                            aiomatic_log_to_file('Similarity finding failed: ' . $aierror);
                                            $newaicontent = $aicontent;
                                        }
                                        else
                                        {
                                            $newaicontent = ucfirst(trim(nl2br(trim($generated_text))));
                                            
                                            if(empty($newaicontent))
                                            {
                                                $newaicontent = $aicontent;
                                            }
                                            else
                                            {
                                                $newaicontent = preg_replace('#^\d+\.([\s\S]*)#i', '$1', $newaicontent);
                                                $add_me_to_text = '<h3>' . $newaicontent . '</h3> ';
                                                $ai_continue_title = $newaicontent;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    $randomIndex = array_rand($headings_arr_copy);
                                    $newaicontent = $headings_arr_copy[$randomIndex];
                                    unset($headings_arr_copy[$randomIndex]);
                                    $newaicontent = preg_replace('#^\d+\.([\s\S]*)#i', '$1', $newaicontent);
                                    $add_me_to_text = '<h3>' . $newaicontent . '</h3> ';
                                }
                            }
                            $ai_retry = false;
                            $newaicontent = trim($newaicontent);
                            $query_token_count = count(aiomatic_encode($newaicontent));
                            $available_tokens = $max_tokens - $query_token_count;
                            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                            {
                                $string_len = strlen($newaicontent);
                                $string_len = $string_len / 2;
                                $string_len = intval(0 - $string_len);
                                $newaicontent = aiomatic_substr($newaicontent, 0, $string_len);
                                $newaicontent = trim($newaicontent);
                                if(empty($newaicontent))
                                {
                                    aiomatic_log_to_file('Empty API seed expression provided (after processing) ' . print_r($temp_post, true));
                                    break;
                                }
                                $query_token_count = count(aiomatic_encode($newaicontent));
                                $available_tokens = $max_tokens - $query_token_count;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                $api_service = aiomatic_get_api_service($token);
                                $rwair = '';
                                if($just_set_fallback == true)
                                {
                                    $rwair = '(fallback)';
                                }
                                aiomatic_log_to_file('Calling ' . $api_service . ' again (' . $cnt . ')' . $rwair . ', to meet minimum character limit: ' . $min_char . ' - current char count: ' . strlen(strip_tags($new_post_content)));
                            }
                            $aiwriter = '';
                            $aierror = '';
                            $finish_reason = '';
                            $generated_text = aiomatic_generate_text($token, $model, $newaicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'contentID' . $param, 0, $finish_reason, $aierror);
                            if($generated_text === false)
                            {
                                aiomatic_log_to_file($aierror);
                                break;
                            }
                            else
                            {
                                $aiwriter = $add_me_to_text . ucfirst(trim(nl2br(trim($generated_text))));
                            }
                            $add_my_image = '';
                            $temp_get_img = '';
                            if($aiwriter == '')
                            {
                                $ai_retry = true;
                                if($just_set_fallback == true)
                                {
                                    aiomatic_log_to_file('Ending execution, already retried once');
                                    break;
                                }
                                continue;
                            }
                            if($images != '' && is_numeric($images) && $images > $added_images)
                            {
                                $image_query_set = false;
                                $query_words = '';
                                $ai_command_image = '';
                                if($orig_ai_command_image == '')
                                {
                                    $orig_ai_command_image = $image_query;
                                }
                                if($orig_ai_command_image != '')
                                {
                                    $ai_command_image = $orig_ai_command_image;
                                    $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                    $ai_command_image = array_filter($ai_command_image);
                                    if(count($ai_command_image) > 0)
                                    {
                                        $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                    }
                                    else
                                    {
                                        $ai_command_image = '';
                                    }
                                    $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                    if(!empty($ai_command_image))
                                    {
                                        $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    }
                                    else
                                    {
                                        $ai_command_image = trim(strip_tags($post_title));
                                    }
                                    $ai_command_image = trim($ai_command_image);
                                    if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                    {
                                        $txt_content = aiomatic_get_web_page($ai_command_image);
                                        if ($txt_content !== FALSE) 
                                        {
                                            $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                            $txt_content = array_filter($txt_content);
                                            if(count($txt_content) > 0)
                                            {
                                                $txt_content = $txt_content[array_rand($txt_content)];
                                                if(trim($txt_content) != '') 
                                                {
                                                    $ai_command_image = $txt_content;
                                                    $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                    $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                }
                                            }
                                        }
                                    }
                                }
                                if($ai_command_image != '')
                                {
                                    $query_words = $ai_command_image;
                                    $image_query = $ai_command_image;
                                    $image_query_set = true;
                                }
                                else
                                {
                                    $query_words = $post_title;
                                }
                                if($image_query == '')
                                {
                                    $image_query = $temp_post;
                                }
                                if($enable_ai_images == '1')
                                {
                                    if($orig_ai_command_image == '')
                                    {
                                        $orig_ai_command_image = $image_query;
                                    }
                                    if($orig_ai_command_image != '')
                                    {
                                        $ai_command_image = $orig_ai_command_image;
                                        $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                        $ai_command_image = array_filter($ai_command_image);
                                        if(count($ai_command_image) > 0)
                                        {
                                            $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                        }
                                        else
                                        {
                                            $ai_command_image = '';
                                        }
                                        $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                        if(!empty($ai_command_image))
                                        {
                                            $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                        }
                                        else
                                        {
                                            $ai_command_image = trim(strip_tags($post_title));
                                        }
                                        $ai_command_image = trim($ai_command_image);
                                        if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                        {
                                            $txt_content = aiomatic_get_web_page($ai_command_image);
                                            if ($txt_content !== FALSE) 
                                            {
                                                $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                                $txt_content = array_filter($txt_content);
                                                if(count($txt_content) > 0)
                                                {
                                                    $txt_content = $txt_content[array_rand($txt_content)];
                                                    if(trim($txt_content) != '') 
                                                    {
                                                        $ai_command_image = $txt_content;
                                                        $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                        $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                    }
                                                }
                                            }
                                        }
                                        if(empty($ai_command_image))
                                        {
                                            aiomatic_log_to_file('Empty API image seed expression provided!');
                                        }
                                        else
                                        {
                                            if(strlen($ai_command_image) > 400)
                                            {
                                                $ai_command_image = aiomatic_substr($ai_command_image, 0, 400);
                                            }
                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                            {
                                                $api_service = aiomatic_get_api_service($token);
                                                aiomatic_log_to_file('Calling ' . $api_service . ' for image: ' . $ai_command_image);
                                            }
                                            $aierror = '';
                                            $temp_get_imgs = aiomatic_generate_ai_image($token, 1, $ai_command_image, $image_size, 'contentImage', false, 0, $aierror);
                                            if($temp_get_imgs !== false)
                                            {
                                                foreach($temp_get_imgs as $tmpimg)
                                                {
                                                    $added_images++;
                                                    $added_img_list[] = $tmpimg;
                                                    $temp_get_img = $tmpimg;
                                                }
                                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                                {
                                                    aiomatic_log_to_file('AI generated image returned: ' . $temp_get_img);
                                                }
                                            }
                                            else
                                            {
                                                aiomatic_log_to_file('Failed to generate AI image: ' . $aierror);
                                                $temp_get_img = '';
                                            }
                                        }
                                    }
                                    else
                                    {
                                        aiomatic_log_to_file('Empty AI image query entered.');
                                    }
                                }
                                elseif($enable_ai_images == '2')
                                {
                                    if($orig_ai_command_image == '')
                                    {
                                        $orig_ai_command_image = $image_query;
                                    }
                                    if($orig_ai_command_image != '')
                                    {
                                        $ai_command_image = $orig_ai_command_image;
                                        $ai_command_image = preg_split('/\r\n|\r|\n/', $ai_command_image);
                                        $ai_command_image = array_filter($ai_command_image);
                                        if(count($ai_command_image) > 0)
                                        {
                                            $ai_command_image = $ai_command_image[array_rand($ai_command_image)];
                                        }
                                        else
                                        {
                                            $ai_command_image = '';
                                        }
                                        $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                        if(!empty($ai_command_image))
                                        {
                                            $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                        }
                                        else
                                        {
                                            $ai_command_image = trim(strip_tags($post_title));
                                        }
                                        $ai_command_image = trim($ai_command_image);
                                        if (filter_var($ai_command_image, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($ai_command_image, '.txt'))
                                        {
                                            $txt_content = aiomatic_get_web_page($ai_command_image);
                                            if ($txt_content !== FALSE) 
                                            {
                                                $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                                $txt_content = array_filter($txt_content);
                                                if(count($txt_content) > 0)
                                                {
                                                    $txt_content = $txt_content[array_rand($txt_content)];
                                                    if(trim($txt_content) != '') 
                                                    {
                                                        $ai_command_image = $txt_content;
                                                        $ai_command_image = aiomatic_replaceSynergyShortcodes($ai_command_image);
                                                        $ai_command_image = replaceAIPostShortcodes($ai_command_image, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                    }
                                                }
                                            }
                                        }
                                        if(empty($ai_command_image))
                                        {
                                            aiomatic_log_to_file('Empty API image seed expression provided!');
                                        }
                                        else
                                        {
                                            if(strlen($ai_command_image) > 2000)
                                            {
                                                $ai_command_image = aiomatic_substr($ai_command_image, 0, 2000);
                                            }
                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                            {
                                                $api_service = 'Stability.AI';
                                                aiomatic_log_to_file('Calling ' . $api_service . ' for image: ' . $ai_command_image);
                                            }
                                            if($image_size == '256x256')
                                            {
                                                $width = '512';
                                                $height = '512';
                                            }
                                            elseif($image_size == '512x512')
                                            {
                                                $width = '512';
                                                $height = '512';
                                            }
                                            elseif($image_size == '1024x1024')
                                            {
                                                $width = '1024';
                                                $height = '1024';
                                            }
                                            else
                                            {
                                                $width = '512';
                                                $height = '512';
                                            }
                                            $temp_get_imgs = aiomatic_generate_stability_image($ai_command_image, $height, $width, 'contentStableImage', 0, false);
                                            if($temp_get_imgs !== false)
                                            {
                                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                                {
                                                    aiomatic_log_to_file('AI generated image returned: ' . $temp_get_imgs[1]);
                                                }
                                                $added_images++;
                                                $added_img_list[] = $temp_get_imgs[1];
                                                $temp_get_img = $temp_get_imgs[1];
                                            }
                                            else
                                            {
                                                aiomatic_log_to_file('Failed to generate Stability.AI image.');
                                                $temp_get_img = '';
                                            }
                                        }
                                    }
                                    else
                                    {
                                        aiomatic_log_to_file('Empty AI image query entered.');
                                    }
                                }
                                elseif(count($images_arr) > 0)
                                {
                                    $first_el = array_shift($images_arr);
                                    $first_el = aiomatic_replaceSynergyShortcodes($first_el);
                                    $added_images++;
                                    $added_img_list[] = $first_el;
                                    $temp_get_img = $first_el;
                                }
                                else
                                {
                                    $query_words = '';
                                    if(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'textrazor')
                                    {
                                        if(isset($aiomatic_Main_Settings['textrazor_key']) && trim($aiomatic_Main_Settings['textrazor_key']) != '')
                                        {
                                            try
                                            {
                                                if(!class_exists('TextRazor'))
                                                {
                                                    require_once(dirname(__FILE__) . "/res/TextRazor.php");
                                                }
                                                TextRazorSettings::setApiKey(trim($aiomatic_Main_Settings['textrazor_key']));
                                                $textrazor = new TextRazor();
                                                $textrazor->addExtractor('entities');
                                                $response = $textrazor->analyze($image_query);
                                                if (isset($response['response']['entities'])) 
                                                {
                                                    foreach ($response['response']['entities'] as $entity) 
                                                    {
                                                        $query_words = '';
                                                        if(isset($entity['entityEnglishId']))
                                                        {
                                                            $query_words = $entity['entityEnglishId'];
                                                        }
                                                        else
                                                        {
                                                            $query_words = $entity['entityId'];
                                                        }
                                                        if($query_words != '')
                                                        {
                                                            $z_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $img_attr, 10, false);
                                                            if(!empty($z_img))
                                                            {
                                                                $added_images++;
                                                                $added_img_list[] = $z_img;
                                                                $temp_get_img = $z_img;
                                                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                                    aiomatic_log_to_file('Royalty Free Image Generated with help of TextRazor (kw: "' . $query_words . '"): ' . $z_img);
                                                                }
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            catch(Exception $e)
                                            {
                                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                    aiomatic_log_to_file('Failed to search for keywords using TextRazor (2): ' . $e->getMessage());
                                                }
                                            }
                                        }
                                    }
                                    elseif(isset($aiomatic_Main_Settings['improve_keywords']) && trim($aiomatic_Main_Settings['improve_keywords']) == 'openai')
                                    {
                                        if(isset($aiomatic_Main_Settings['keyword_prompts']) && trim($aiomatic_Main_Settings['keyword_prompts']) != '')
                                        {
                                            if(isset($aiomatic_Main_Settings['keyword_model']) && $aiomatic_Main_Settings['keyword_model'] != '')
                                            {
                                                $kw_model = $aiomatic_Main_Settings['keyword_model'];
                                            }
                                            else
                                            {
                                                $kw_model = 'text-davinci-003';
                                            }
                                            $title_ai_command = trim($aiomatic_Main_Settings['keyword_prompts']);
                                            $title_ai_command = preg_split('/\r\n|\r|\n/', $title_ai_command);
                                            $title_ai_command = array_filter($title_ai_command);
                                            if(count($title_ai_command) > 0)
                                            {
                                                $title_ai_command = $title_ai_command[array_rand($title_ai_command)];
                                            }
                                            else
                                            {
                                                $title_ai_command = '';
                                            }
                                            $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                            if(!empty($title_ai_command))
                                            {
                                                $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                            }
                                            $title_ai_command = trim($title_ai_command);
                                            if (filter_var($title_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($title_ai_command, '.txt'))
                                            {
                                                $txt_content = aiomatic_get_web_page($title_ai_command);
                                                if ($txt_content !== FALSE) 
                                                {
                                                    $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                                    $txt_content = array_filter($txt_content);
                                                    if(count($txt_content) > 0)
                                                    {
                                                        $txt_content = $txt_content[array_rand($txt_content)];
                                                        if(trim($txt_content) != '') 
                                                        {
                                                            $title_ai_command = $txt_content;
                                                            $title_ai_command = aiomatic_replaceSynergyShortcodes($title_ai_command);
                                                            $title_ai_command = replaceAIPostShortcodes($title_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                                        }
                                                    }
                                                }
                                            }
                                            if(empty($title_ai_command))
                                            {
                                                aiomatic_log_to_file('Empty API keyword extractor seed expression provided!');
                                                $title_ai_command = 'Type the most relevant keyword, no other text before or after it, for a blog post titled:  ' . trim(strip_tags($post_title));
                                            }
                                            if(strlen($title_ai_command) > $max_seed_tokens * 4)
                                            {
                                                $title_ai_command = aiomatic_substr($title_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                                            }
                                            $title_ai_command = trim($title_ai_command);
                                            if(empty($title_ai_command))
                                            {
                                                aiomatic_log_to_file('Empty API title seed expression provided(5)! ' . print_r($title_ai_command, true));
                                            }
                                            else
                                            {
                                                $query_token_count = count(aiomatic_encode($title_ai_command));
                                                $available_tokens = $max_tokens - $query_token_count;
                                                if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                                                {
                                                    $string_len = strlen($title_ai_command);
                                                    $string_len = $string_len / 2;
                                                    $string_len = intval(0 - $string_len);
                                                    $title_ai_command = aiomatic_substr($title_ai_command, 0, $string_len);
                                                    $title_ai_command = trim($title_ai_command);
                                                    $query_token_count = count(aiomatic_encode($title_ai_command));
                                                    $available_tokens = $max_tokens - $query_token_count;
                                                }
                                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                                {
                                                    $api_service = aiomatic_get_api_service($token);
                                                    aiomatic_log_to_file('Calling ' . $api_service . ' (' . $kw_model . ') for title text: ' . $title_ai_command);
                                                }
                                                $aierror = '';
                                                $finish_reason = '';
                                                $generated_text = aiomatic_generate_text($token, $kw_model, $title_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'keywordID' . $param, 0, $finish_reason, $aierror);
                                                if($generated_text === false)
                                                {
                                                    aiomatic_log_to_file('Keyword generator error: ' . $aierror);
                                                    $ai_title = '';
                                                }
                                                else
                                                {
                                                    $ai_title = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                                                    $ai_titles = explode(',', $ai_title);
                                                    foreach($ai_titles as $query_words)
                                                    {
                                                        $z_img = aiomatic_get_free_image($aiomatic_Main_Settings, trim($query_words), $img_attr, 10, false);
                                                        if(!empty($z_img))
                                                        {
                                                            $added_images++;
                                                            $added_img_list[] = $z_img;
                                                            $temp_get_img = $z_img;
                                                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                                                aiomatic_log_to_file('Royalty Free Image Generated with help of AI (kw: "' . $query_words . '"): ' . $z_img);
                                                            }
                                                            break;
                                                        }
                                                    }
                                                }
                                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                                                {
                                                    $api_service = aiomatic_get_api_service($token);
                                                    aiomatic_log_to_file('Successfully got API keyword result from ' . $api_service . ': ' . $ai_title);
                                                }
                                            }
                                        }
                                    }
                                    if(empty($temp_get_img))
                                    {
                                        $keyword_class = new Aiomatic_keywords();
                                        $query_words = $keyword_class->keywords($image_query, 2);
                                        $temp_img_attr = '';
                                        $temp_get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $temp_img_attr, 10, false);
                                        if($temp_get_img == '' || $temp_get_img === false)
                                        {
                                            $query_words = $keyword_class->keywords($image_query, 1);
                                            $temp_get_img = aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, $temp_img_attr, 20, false);
                                            if($temp_get_img == '' || $temp_get_img === false)
                                            {
                                                $temp_get_img = '';
                                            }
                                            else
                                            {
                                                if(!in_array($temp_get_img, $added_img_list))
                                                {
                                                    $added_images++;
                                                    $added_img_list[] = $temp_get_img;
                                                }
                                                else
                                                {
                                                    $temp_get_img = '';
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if(!in_array($temp_get_img, $added_img_list))
                                            {
                                                $added_images++;
                                                $added_img_list[] = $temp_get_img;
                                            }
                                            else
                                            {
                                                $temp_get_img = '';
                                            }
                                        }
                                    }
                                }
                                if($temp_get_img != '')
                                {
                                    $add_my_image = '<br/><img class="aiomatic_image_class" src="' . $temp_get_img . '" alt="' . $query_words . '"><br/>';
                                }
                            }
                            if($heading_val == '')
                            {
                                if($add_my_image == '')
                                {
                                    $add_my_image = ' ';
                                }
                                $new_post_content .= $add_my_image . trim(nl2br($aiwriter));
                            }
                            else
                            {
                                $new_post_content .= $add_my_image . $heading_val . ' ' . trim(nl2br($aiwriter)) . '</span>';
                            }
                            if($enable_ai_images == '0')
                            {
                                sleep(1);
                            }
                            $cnt++;
                        }
                    }
                    if($strip_title == '1')
                    {
                        $new_post_content = str_replace($post_title, '', $new_post_content);
                        $new_post_content = str_replace('<h2></h2>', '', $new_post_content);
                        $new_post_content = str_replace('<h3></h3>', '', $new_post_content);
                    }
                    if (isset($aiomatic_Main_Settings['swear_filter']) && $aiomatic_Main_Settings['swear_filter'] == 'on') 
                    {
                        require_once(dirname(__FILE__) . "/res/swear.php");
                        $new_post_content = aiomatic_filterwords($new_post_content);
                    }
                    if(isset($aiomatic_Main_Settings['global_ban_words']) && $aiomatic_Main_Settings['global_ban_words'] != '') {
                        $continue    = false;
                        $aiomatic_Main_Settings['global_ban_words'] = trim(trim(trim($aiomatic_Main_Settings['global_ban_words']), ','));
                        $banned_list = explode(',', $aiomatic_Main_Settings['global_ban_words']);
                        foreach ($banned_list as $banned_word) {
                            if (stripos($new_post_content, trim($banned_word)) !== FALSE) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('Skipping post "' . esc_html($new_post_title) . '", because it\'s content contains global banned word: ' . $banned_word);
                                }
                                $continue = true;
                                break;
                            }
                            if (stripos($new_post_title, trim($banned_word)) !== FALSE) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('Skipping post "' . esc_html($new_post_title) . '", because it\'s title contains global banned word: ' . $banned_word);
                                }
                                $continue = true;
                                break;
                            }
                        }
                        if ($continue === true) {
                            continue;
                        }
                    }
                    if(isset($aiomatic_Main_Settings['global_req_words']) && $aiomatic_Main_Settings['global_req_words'] != '')
                    {
                        if(isset($aiomatic_Main_Settings['require_only_one']) && $aiomatic_Main_Settings['require_only_one'] == 'on')
                        {
                            $continue      = true;
                            $aiomatic_Main_Settings['global_req_words'] = trim(trim(trim($aiomatic_Main_Settings['global_req_words']), ','));
                            $required_list = explode(',', $aiomatic_Main_Settings['global_req_words']);
                            foreach ($required_list as $required_word) {
                                if (stripos($new_post_content, trim($required_word)) !== FALSE || stripos($new_post_title, trim($required_word)) !== FALSE) {
                                    $continue = false;
                                    break;
                                }
                            }
                            if ($continue === true) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('Skipping post "' . esc_html($new_post_title) . '", because it\'s content doesn\'t contain global required words.');
                                }
                                continue;
                            }
                        }
                        else
                        {
                            $continue      = false;
                            $aiomatic_Main_Settings['global_req_words'] = trim(trim(trim($aiomatic_Main_Settings['global_req_words']), ','));
                            $required_list = explode(',', $aiomatic_Main_Settings['global_req_words']);
                            foreach ($required_list as $required_word) {
                                if (stripos($new_post_content, trim($required_word)) === FALSE && stripos($new_post_title, trim($required_word)) === FALSE) {
                                    $continue = true;
                                    break;
                                }
                            }
                            if ($continue === true) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('Skipping post "' . esc_html($new_post_title) . '", because it\'s content doesn\'t contain global required words.');
                                }
                                continue;
                            }
                        }
                    }
                    $arr = aiomatic_spin_and_translate($new_post_title, $new_post_content, '3', $skip_spin, $skip_translate);
                    if($arr[0] != $new_post_title)
                    {
                        $new_post_title = $arr[0];
                        if (!isset($aiomatic_Main_Settings['do_not_check_duplicates']) || $aiomatic_Main_Settings['do_not_check_duplicates'] != 'on') 
                        {
                            $posts = get_posts(
                                array(
                                    'post_type'              => $post_type,
                                    'title'                  => html_entity_decode($new_post_title),
                                    'post_status'            => 'all',
                                    'numberposts'            => 1,
                                    'update_post_term_cache' => false,
                                    'update_post_meta_cache' => false,           
                                    'orderby'                => 'post_date ID',
                                    'order'                  => 'ASC',
                                )
                            );
                            if ( ! empty( $posts ) ) {
                                $zap = $posts[0];
                            } else {
                                $zap = null;
                            }
                            if($zap !== null)
                            {
                                aiomatic_log_to_file('Post with specified title already existing (after spin/translate), skipping it: ' . $new_post_title);
                                unset($post_title_lines[$current_index]);
                                continue;
                            }
                        }
                    }
                    $new_post_content            = $arr[1];
                    if (isset($aiomatic_Main_Settings['spin_text']) && $aiomatic_Main_Settings['spin_text'] !== 'disabled') 
                    {
                        $already_spinned = '1';
                    }
                    if ($auto_categories == 'content') {
                        $extra_categories            = aiomatic_extractKeyWords($new_post_content);
                        $extra_categories            = implode(',', $extra_categories);
                    }
                    elseif ($auto_categories == 'title') {
                        $extra_categories            = aiomatic_extractKeyWords($new_post_title);
                        $extra_categories            = implode(',', $extra_categories);
                    }
                    elseif ($auto_categories == 'both') {
                        $extra_categories            = aiomatic_extractKeyWords($new_post_content);
                        $extra_categories            = implode(',', $extra_categories);
                        $extra_categories2            = aiomatic_extractKeyWords($new_post_title);
                        $extra_categories2            = implode(',', $extra_categories2);
                        if($extra_categories2 != '')
                        {
                            $extra_categories .= ',' . $extra_categories2;
                        }
                    }
                    elseif ($auto_categories == 'ai') 
                    {
                        $category_ai_command = $orig_ai_command_category;
                        $category_ai_command = preg_split('/\r\n|\r|\n/', $category_ai_command);
                        $category_ai_command = array_filter($category_ai_command);
                        if(count($category_ai_command) > 0)
                        {
                            $category_ai_command = $category_ai_command[array_rand($category_ai_command)];
                        }
                        else
                        {
                            $category_ai_command = '';
                        }
                        $category_ai_command = aiomatic_replaceSynergyShortcodes($category_ai_command);
                        if(!empty($category_ai_command))
                        {
                            $category_ai_command = replaceAIPostShortcodes($category_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                            $category_ai_command = aiomatic_replacetopics($category_ai_command, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        }
                        else
                        {
                            $category_ai_command = trim(strip_tags('Write a comma separated list of categories, for the post title: %%post_title%%'));
                        }
                        $category_ai_command = trim($category_ai_command);
                        if (filter_var($category_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($category_ai_command, '.txt'))
                        {
                            $txt_content = aiomatic_get_web_page($category_ai_command);
                            if ($txt_content !== FALSE) 
                            {
                                $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                $txt_content = array_filter($txt_content);
                                if(count($txt_content) > 0)
                                {
                                    $txt_content = $txt_content[array_rand($txt_content)];
                                    if(trim($txt_content) != '') 
                                    {
                                        $category_ai_command = $txt_content;
                                        $category_ai_command = aiomatic_replaceSynergyShortcodes($category_ai_command);
                                        $category_ai_command = replaceAIPostShortcodes($category_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                        $category_ai_command = aiomatic_replacetopics($category_ai_command, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    }
                                }
                            }
                        }
                        if(empty($category_ai_command))
                        {
                            aiomatic_log_to_file('Empty API post category seed expression provided!');
                        }
                        else
                        {
                            if(strlen($category_ai_command) > $max_seed_tokens * 4)
                            {
                                $category_ai_command = aiomatic_substr($category_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                            }
                            $category_ai_command = trim($category_ai_command);
                            if(empty($category_ai_command))
                            {
                                aiomatic_log_to_file('Empty API category seed expression provided! ' . print_r($category_ai_command, true));
                                break;
                            }
                            $query_token_count = count(aiomatic_encode($category_ai_command));
                            $available_tokens = $max_tokens - $query_token_count;
                            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                            {
                                $string_len = strlen($category_ai_command);
                                $string_len = $string_len / 2;
                                $string_len = intval(0 - $string_len);
                                $category_ai_command = aiomatic_substr($category_ai_command, 0, $string_len);
                                $category_ai_command = trim($category_ai_command);
                                if(empty($category_ai_command))
                                {
                                    aiomatic_log_to_file('Empty API seed expression provided (after processing) ' . print_r($category_ai_command, true));
                                    break;
                                }
                                $query_token_count = count(aiomatic_encode($category_ai_command));
                                $available_tokens = $max_tokens - $query_token_count;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $category_model . ') for category generator: ' . $category_ai_command);
                            }
                            $aierror = '';
                            $finish_reason = '';
                            $generated_text = aiomatic_generate_text($token, $category_model, $category_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'categoryID' . $param, 0, $finish_reason, $aierror);
                            if($generated_text === false)
                            {
                                aiomatic_log_to_file('Category generator error: ' . $aierror);
                                break;
                            }
                            else
                            {
                                $extra_categories = $generated_text;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Successfully got API category result from ' . $api_service . ': ' . $generated_text);
                            }
                        }
                    }
                    else
                    {
                        $extra_categories = '';
                    }
                    $my_post['extra_categories'] = $extra_categories;
                    
                    $item_tags                   = aiomatic_extractKeyWords($new_post_content, 3);
                    $item_tags                   = implode(',', $item_tags);
                    $title_tags                   = aiomatic_extractKeyWords($new_post_title, 3);
                    $title_tags                   = implode(',', $title_tags);
                    $item_create_tag_sp = $spintax->Parse($item_create_tag);
                    if ($can_create_tag == 'content') {
                        $post_the_tags = ($item_create_tag_sp != '' ? $item_create_tag_sp . ',' : '') . $item_tags;
                        $my_post['extra_tags']       = $item_tags;
                    } else if ($can_create_tag == 'title') {
                        $post_the_tags = ($item_create_tag_sp != '' ? $item_create_tag_sp . ',' : '') . $title_tags;
                        $my_post['extra_tags']       = $title_tags;
                    } else if ($can_create_tag == 'both') {
                        $post_the_tags = ($item_create_tag_sp != '' ? $item_create_tag_sp . ',' : '') . ($item_tags != '' ? $item_tags . ',' : '') . $title_tags;
                        $my_post['extra_tags']       = ($item_tags != '' ? $item_tags . ',' : '') . $title_tags;
                    } else if ($can_create_tag == 'ai') {
                        $ai_tags = '';
                        $tag_ai_command = $orig_ai_command_tag;
                        $tag_ai_command = preg_split('/\r\n|\r|\n/', $tag_ai_command);
                        $tag_ai_command = array_filter($tag_ai_command);
                        if(count($tag_ai_command) > 0)
                        {
                            $tag_ai_command = $tag_ai_command[array_rand($tag_ai_command)];
                        }
                        else
                        {
                            $tag_ai_command = '';
                        }
                        $tag_ai_command = aiomatic_replaceSynergyShortcodes($tag_ai_command);
                        if(!empty($tag_ai_command))
                        {
                            $tag_ai_command = replaceAIPostShortcodes($tag_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                            $tag_ai_command = aiomatic_replacetopics($tag_ai_command, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                        }
                        else
                        {
                            $tag_ai_command = trim(strip_tags('Write a comma separated list of tags, for the post title: %%post_title%%'));
                        }
                        $tag_ai_command = trim($tag_ai_command);
                        if (filter_var($tag_ai_command, FILTER_VALIDATE_URL) !== false && aiomatic_endsWith($tag_ai_command, '.txt'))
                        {
                            $txt_content = aiomatic_get_web_page($tag_ai_command);
                            if ($txt_content !== FALSE) 
                            {
                                $txt_content = preg_split('/\r\n|\r|\n/', $txt_content);
                                $txt_content = array_filter($txt_content);
                                if(count($txt_content) > 0)
                                {
                                    $txt_content = $txt_content[array_rand($txt_content)];
                                    if(trim($txt_content) != '') 
                                    {
                                        $tag_ai_command = $txt_content;
                                        $tag_ai_command = aiomatic_replaceSynergyShortcodes($tag_ai_command);
                                        $tag_ai_command = replaceAIPostShortcodes($tag_ai_command, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                        $tag_ai_command = aiomatic_replacetopics($tag_ai_command, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    }
                                }
                            }
                        }
                        if(empty($tag_ai_command))
                        {
                            aiomatic_log_to_file('Empty API post tag seed expression provided!');
                        }
                        else
                        {
                            if(strlen($tag_ai_command) > $max_seed_tokens * 4)
                            {
                                $tag_ai_command = aiomatic_substr($tag_ai_command, 0, (0 - ($max_seed_tokens * 4)));
                            }
                            $tag_ai_command = trim($tag_ai_command);
                            if(empty($tag_ai_command))
                            {
                                aiomatic_log_to_file('Empty API tag seed expression provided! ' . print_r($tag_ai_command, true));
                                break;
                            }
                            $query_token_count = count(aiomatic_encode($tag_ai_command));
                            $available_tokens = $max_tokens - $query_token_count;
                            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                            {
                                $string_len = strlen($tag_ai_command);
                                $string_len = $string_len / 2;
                                $string_len = intval(0 - $string_len);
                                $tag_ai_command = aiomatic_substr($tag_ai_command, 0, $string_len);
                                $tag_ai_command = trim($tag_ai_command);
                                if(empty($tag_ai_command))
                                {
                                    aiomatic_log_to_file('Empty API seed expression provided (after processing) ' . print_r($tag_ai_command, true));
                                    break;
                                }
                                $query_token_count = count(aiomatic_encode($tag_ai_command));
                                $available_tokens = $max_tokens - $query_token_count;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $tag_model . ') for tag generator: ' . $tag_ai_command);
                            }
                            $aierror = '';
                            $finish_reason = '';
                            $generated_text = aiomatic_generate_text($token, $tag_model, $tag_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'tagID' . $param, 0, $finish_reason, $aierror);
                            if($generated_text === false)
                            {
                                aiomatic_log_to_file('Tag generator error: ' . $aierror);
                                break;
                            }
                            else
                            {
                                $ai_tags = $generated_text;
                            }
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                            {
                                $api_service = aiomatic_get_api_service($token);
                                aiomatic_log_to_file('Successfully got API tag result from ' . $api_service . ': ' . $generated_text);
                            }
                        }
                        $post_the_tags = ($item_create_tag_sp != '' ? $item_create_tag_sp . ',' : '') . $ai_tags;
                        $my_post['extra_tags']       = $ai_tags;
                    } else {
                        $post_the_tags = $item_create_tag_sp;
                        $my_post['extra_tags']       = '';
                    }
                    $my_post['tags_input'] = $post_the_tags;
                    $new_post_content        = html_entity_decode($new_post_content);
                    $new_post_content = str_replace('</ iframe>', '</iframe>', $new_post_content);
                    if ($videos == '1') 
                    {
                        if (isset($aiomatic_Main_Settings['yt_app_id']) && trim($aiomatic_Main_Settings['yt_app_id']) != '') {
                            $items = array();
                            $za_app = explode(',', $aiomatic_Main_Settings['yt_app_id']);
                            $za_app = trim($za_app[array_rand($za_app)]);
                            $feed_uri = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&key=' . $za_app;
                            $feed_uri .= '&maxResults=10';
                            $feed_uri .= '&q='.urlencode(trim(stripslashes(str_replace('&quot;', '"', $new_post_title))));
                            $ch  = curl_init();
                            if ($ch !== FALSE) {
                                if (isset($aiomatic_Main_Settings['proxy_url']) && $aiomatic_Main_Settings['proxy_url'] != '') {
                                    curl_setopt($ch, CURLOPT_PROXY, $aiomatic_Main_Settings['proxy_url']);
                                    if (isset($aiomatic_Main_Settings['proxy_auth']) && $aiomatic_Main_Settings['proxy_auth'] != '') {
                                        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $aiomatic_Main_Settings['proxy_auth']);
                                    }
                                }
                                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                                curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                                curl_setopt($ch, CURLOPT_HTTPGET, 1);
                                curl_setopt($ch, CURLOPT_REFERER, get_site_url());
                                curl_setopt($ch, CURLOPT_URL, $feed_uri);
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                                $exec = curl_exec($ch);
                                curl_close($ch);
                                if ($exec !== FALSE) {
                                    $json  = json_decode($exec);
                                    if(isset($json->items))
                                    {
                                        $items = $json->items;
                                        if (count($items) == 0) 
                                        {
                                            $feed_uri = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&key=' . $za_app;
                                            $feed_uri .= '&maxResults=10';
                                            $keyword_class = new Aiomatic_keywords();
                                            $new_post_title = $keyword_class->keywords($new_post_title, 2);
                                            $feed_uri .= '&q='.urlencode(trim(stripslashes(str_replace('&quot;', '"', $new_post_title))));
                                            $ch  = curl_init();
                                            if ($ch !== FALSE) {
                                                if (isset($aiomatic_Main_Settings['proxy_url']) && $aiomatic_Main_Settings['proxy_url'] != '') {
                                                    curl_setopt($ch, CURLOPT_PROXY, $aiomatic_Main_Settings['proxy_url']);
                                                    if (isset($aiomatic_Main_Settings['proxy_auth']) && $aiomatic_Main_Settings['proxy_auth'] != '') {
                                                        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $aiomatic_Main_Settings['proxy_auth']);
                                                    }
                                                }
                                                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                                                curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                                                curl_setopt($ch, CURLOPT_HTTPGET, 1);
                                                curl_setopt($ch, CURLOPT_REFERER, get_site_url());
                                                curl_setopt($ch, CURLOPT_URL, $feed_uri);
                                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                                                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                                                $exec = curl_exec($ch);
                                                curl_close($ch);
                                                if ($exec === FALSE) {
                                                    $json  = json_decode($exec);
                                                    if(isset($json->items))
                                                    {
                                                        $items = $json->items;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                            aiomatic_log_to_file('YouTube API returned error: ' . $exec);
                                        }
                                    }
                                }
                            }
                            if(isset($items[0]->id->videoId))
                            {
                                $rand_ind = array_rand($items);
                                $video_id = $items[$rand_ind]->id->videoId;
                                if (isset($aiomatic_Main_Settings['player_width']) && $aiomatic_Main_Settings['player_width'] !== '') {
                                    $width = esc_attr($aiomatic_Main_Settings['player_width']);
                                }
                                else
                                {
                                    $width = 580;
                                }
                                if (isset($aiomatic_Main_Settings['player_height']) && $aiomatic_Main_Settings['player_height'] !== '') {
                                    $height = esc_attr($aiomatic_Main_Settings['player_height']);
                                }
                                else
                                {
                                    $height = 380;
                                }
                                $new_post_content .= '<br/><br/><div class="automaticx-video-container"><iframe allow="autoplay" width="' . $width . '" height="' . $height . '" src="https://www.youtube.com/embed/' . $video_id . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>';
                            }
                        }
                        else
                        {
                            $new_post_content .= aiomatic_get_youtube_video(trim(stripslashes(str_replace('&quot;', '"', $new_post_title))), '');
                        }
                    }
                    if ($strip_by_regex !== '')
                    {
                        $xstrip_by_regex = preg_split('/\r\n|\r|\n/', $strip_by_regex);
                        $xreplace_regex = preg_split('/\r\n|\r|\n/', $replace_regex);
                        $xcnt = 0;
                        foreach($xstrip_by_regex as $sbr)
                        {
                            if(isset($xreplace_regex[$xcnt]))
                            {
                                $repreg = $xreplace_regex[$xcnt];
                            }
                            else
                            {
                                $repreg = '';
                            }
                            $xcnt++;
                            $temp_cont = preg_replace("~" . $sbr . "~i", $repreg, $new_post_content);
                            if($temp_cont !== NULL)
                            {
                                $new_post_content = $temp_cont;
                            }
                        }
                    }
                    $post_prepender = replaceAIPostShortcodes($post_prepend, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                    $post_prepender = aiomatic_replacetopics($post_prepender, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                    $post_appender = replaceAIPostShortcodes($post_append, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                    $post_appender = aiomatic_replacetopics($post_appender, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                    $post_appender = aiomatic_replaceSynergyShortcodes($post_appender);
                    $post_prepender = aiomatic_replaceSynergyShortcodes($post_prepender);
                    if($ret_content == 1)
                    {
                        return array($post_prepender . ' ' . $new_post_content . ' ' . $post_appender, $new_post_title);
                    }
                    $the_final_cont = $post_prepender . ' ' . $new_post_content . ' ' . $post_appender;
                    $zlang = 'en_US';
                    if (isset($aiomatic_Main_Settings['kw_lang']) && !empty($aiomatic_Main_Settings['kw_lang'])) {
                        $zlang = $aiomatic_Main_Settings['kw_lang'];
                    }
                    $rel_search = array('post_title', 'post_content');
                    if (isset($aiomatic_Main_Settings['rel_search']) && is_array($aiomatic_Main_Settings['rel_search'])) {
                        $rel_search = $aiomatic_Main_Settings['rel_search'];
                    }
                    if($max_links !== '' && $inboundlinker !== null)
                    {
                        try
                        {
                            $the_final_cont = $inboundlinker->add_inbound_links($the_final_cont, $max_links, $link_post_types, $zlang, $rel_search, null);
                        }
                        catch(Exception $ex)
                        {
                            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                aiomatic_log_to_file('Failed to add inbound links to content: ' . $ex->getMessage());
                            }
                        }
                    }
                    $my_post['post_content'] = $the_final_cont;
                    $my_post['post_title']           = $new_post_title;
                    $my_post['aiomatic_source_title']   = $post_title;
                    $my_post['aiomatic_timestamp']   = aiomatic_get_date_now();
                    $my_post['aiomatic_post_format'] = $post_format;
                    if (isset($default_category) && $default_category !== 'aiomatic_no_category_12345678' && $default_category[0] !== 'aiomatic_no_category_12345678') 
                    {
                        if(is_array($default_category))
                        {
                            $cextra = '';
                            foreach($default_category as $dc)
                            {
                                $cextra .= ',' . get_cat_name($dc);
                            }
                            $extra_categories_temp = trim( $cextra . ',' . $extra_categories, ',');
                        }
                        else
                        {
                            $extra_categories_temp = trim(get_cat_name($default_category) . ',' .$extra_categories, ',');
                        }
                    }
                    else
                    {
                        $extra_categories_temp = $extra_categories;
                    }
                    $block_arr = array();
                    $custom_arr = array();
                    if($custom_fields != '')
                    {
                        if(stristr($custom_fields, '=>') != false)
                        {
                            $rule_arr = explode(',', trim($custom_fields));
                            foreach($rule_arr as $rule)
                            {
                                $my_args = explode('=>', trim($rule));
                                if(isset($my_args[1]))
                                {
                                    $my_args[1] = do_shortcode($my_args[1]);
                                    $my_args[0] = do_shortcode($my_args[0]);
                                    $custom_field_content = trim($my_args[1]);
                                    $custom_field_content = replaceAIPostShortcodes($custom_field_content, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    $custom_field_content = aiomatic_replacetopics($custom_field_content, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    $custom_field_content = aiomatic_replaceSynergyShortcodes($custom_field_content);
                                    $custom_field_content = $spintax->Parse($custom_field_content, $block_arr);
                                    $custom_field_content = aiomatic_replaceContentShortcodes($custom_field_content, $img_attr, $ai_command);
                                    if(stristr($my_args[1], 'serialize_') !== false)
                                    {
                                        $custom_arr[trim($my_args[0])] = array(str_replace('serialize_', '', $custom_field_content));
                                    }
                                    else
                                    {
                                        if(stristr($my_args[0], '[') !== false && stristr($my_args[0], ']') !== false)
                                        {
                                            preg_match_all('#([^\[\]]*?)\[([^\[\]]*?)\]#', $my_args[0], $cfm);
                                            if(isset($cfm[2][0]))
                                            {
                                                if(isset($custom_arr[trim($cfm[1][0])]) && is_array($custom_arr[trim($cfm[1][0])]))
                                                {
                                                    $custom_arr[trim($cfm[1][0])] = array_merge($custom_arr[trim($cfm[1][0])], array(trim($cfm[2][0]) => $custom_field_content));
                                                }
                                                else
                                                {
                                                    $custom_arr[trim($cfm[1][0])] = array(trim($cfm[2][0]) => $custom_field_content);
                                                }
                                            }
                                            else
                                            {
                                                $custom_arr[trim($my_args[0])] = $custom_field_content;
                                            }
                                        }
                                        else
                                        {
                                            $custom_arr[trim($my_args[0])] = $custom_field_content;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    $custom_arr = array_merge($custom_arr, array('aiomatic_auto_post_spinned' => $already_spinned, 'aiomatic_post_cats' => $extra_categories_temp, 'aiomatic_post_tags' => $post_the_tags));
                    $my_post['meta_input'] = $custom_arr;
                    $custom_tax_arr = array();
                    if($custom_tax != '')
                    {
                        if(stristr($custom_tax, '=>') != false)
                        {
                            $rule_arr = explode(';', trim($custom_tax));
                            foreach($rule_arr as $rule)
                            {
                                $my_args = explode('=>', trim($rule));
                                if(isset($my_args[1]))
                                {
                                    $custom_tax_content = trim($my_args[1]);
                                    $custom_tax_content = replaceAIPostShortcodes($custom_tax_content, $post_link, $post_title, $blog_title, $post_excerpt, $final_content, $user_name, $featured_image, $post_cats, $post_tagz, $postID, $img_attr, $old_title, $post_title_keywords, $custom_shortcodes);
                                    $custom_tax_content = aiomatic_replacetopics($custom_tax_content, $post_title, $content_language, $writing_style, $writing_tone, $post_topic, $post_sections, $current_section, $section_count, $paragraph_count, $post_title_keywords, $custom_shortcodes);
                                    $custom_tax_content = aiomatic_replaceSynergyShortcodes($custom_tax_content);
                                    $custom_tax_content = $spintax->Parse($custom_tax_content, $block_arr);
                                    $custom_tax_content = aiomatic_replaceContentShortcodes($custom_tax_content, $img_attr, $ai_command);
                                    if(isset($custom_tax_arr[trim($my_args[0])]))
                                    {
                                        $custom_tax_arr[trim($my_args[0])] .= ',' . $custom_tax_content;
                                    }
                                    else
                                    {
                                        $custom_tax_arr[trim($my_args[0])] = $custom_tax_content;
                                    }
                                }
                            }
                        }
                    }
                    if(count($custom_tax_arr) > 0)
                    {
                        $my_post['taxo_input'] = $custom_tax_arr;
                    }
                    if ($enable_pingback == '1') {
                        $my_post['ping_status'] = 'open';
                    } else {
                        $my_post['ping_status'] = 'closed';
                    }
                    if($min_time != '' && $max_time != '')
                    {
                        $t1 = strtotime($min_time);
                        $t2 = strtotime($max_time);
                        if($t1 != false && $t2 != false)
                        {
                            $int = rand($t1, $t2);
                            $my_post['post_date'] = date('Y-m-d H:i:s', $int);
                        }
                    }
                    elseif($min_time != '')
                    {
                        $t1 = strtotime($min_time);
                        if($t1 != false)
                        {
                            $my_post['post_date'] = date('Y-m-d H:i:s', $t1);
                        }
                    }
                    elseif($max_time != '')
                    {
                        $t1 = strtotime($max_time);
                        if($t1 != false)
                        {
                            $my_post['post_date'] = date('Y-m-d H:i:s', $t1);
                        }
                    }
                    $post_array[] = $my_post;
                    $count++;
                }
                else
                {
                    aiomatic_log_to_file('Unknown posting mode submitted: ' . $posting_mode . '!');
                    if($auto == 1)
                    {
                        aiomatic_clearFromList($param);
                    }
                    return 'fail';
                }
            }
            foreach ($post_array as $post) {
                remove_filter('content_save_pre', 'wp_filter_post_kses');
                remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
                $post_id = wp_insert_post($post, true);
                add_filter('content_save_pre', 'wp_filter_post_kses');
                add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
                if (!is_wp_error($post_id)) {
                    if($post_id === 0)
                    {
                        aiomatic_log_to_file('An error occurred while inserting post into wp database! Title:' . $post['post_title']);
                        continue;
                    }
                    $posts_inserted++;
                    $default_categories = array();
                    if($remove_default == '1' && ($auto_categories != 'disabled' || (isset($default_category) && $default_category !== 'aiomatic_no_category_12345678' && $default_category[0] !== 'aiomatic_no_category_12345678')))
                    {
                        $default_categories = wp_get_post_categories($post_id);
                    }
                    if(isset($post['taxo_input']))
                    {
                        foreach($post['taxo_input'] as $taxn => $taxval)
                        {
                            $taxn = trim($taxn);
                            $taxval = trim($taxval);
                            if(is_taxonomy_hierarchical($taxn))
                            {
                                $taxval = array_map('trim', explode(',', $taxval));
                                for($ii = 0; $ii < count($taxval); $ii++)
                                {
                                    if(!is_numeric($taxval[$ii]))
                                    {
                                        $xtermid = get_term_by('name', $taxval[$ii], $taxn);
                                        if($xtermid !== false)
                                        {
                                            $taxval[$ii] = intval($xtermid->term_id);
                                        }
                                        else
                                        {
                                            wp_insert_term( $taxval[$ii], $taxn);
                                            $xtermid = get_term_by('name', $taxval[$ii], $taxn);
                                            if($xtermid !== false)
                                            {
                                                if($wpml_lang != '' && function_exists('pll_set_term_language'))
                                                {
                                                    pll_set_term_language($xtermid->term_id, $wpml_lang); 
                                                }
                                                elseif($wpml_lang != '' && has_filter('wpml_object_id'))
                                                {
                                                    $wpml_element_type = apply_filters( 'wpml_element_type', $taxn );
                                                    $pars['element_id'] = $xtermid->term_id;
                                                    $pars['element_type'] = $wpml_element_type;
                                                    $pars['language_code'] = $wpml_lang;
                                                    $pars['trid'] = FALSE;
                                                    $pars['source_language_code'] = NULL;
                                                    do_action('wpml_set_element_language_details', $pars);
                                                }
                                                $taxval[$ii] = intval($xtermid->term_id);
                                            }
                                        }
                                    }
                                }
                                wp_set_post_terms($post_id, $taxval, $taxn, true);
                            }
                            else
                            {
                                wp_set_post_terms($post_id, trim($taxval), $taxn, true);
                            }
                        }
                    }
                    if (isset($post['aiomatic_post_format']) && $post['aiomatic_post_format'] != '' && $post['aiomatic_post_format'] != 'post-format-standard') {
                        wp_set_post_terms($post_id, $post['aiomatic_post_format'], 'post_format', true);
                    }
                    $featured_path = '';
                    $get_img = $post['aiomatic_post_image'];
                    if ($get_img != '') {
                        if($post['aiomatic_local_image'] == '1')
                        {
                            $local_get_img = $get_img[0];
                            if (!aiomatic_assign_featured_image_path($local_get_img, $post_id)) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('aiomatic_assign_featured_image_path failed for ' . $local_get_img);
                                }
                            } else {
                                $featured_path = $get_img[1];
                            }
                        }
                        else
                        {
                            if (!aiomatic_generate_featured_image($get_img, $post_id)) {
                                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                    aiomatic_log_to_file('aiomatic_generate_featured_image failed for ' . $get_img);
                                }
                            } else {
                                $featured_path = $get_img;
                            }
                        }
                    }
                    if($featured_path == '')
                    {
                        if ($image_url != '') {
                            $replacement = str_replace(array('[', ']'), '', $my_post['post_title']);
                            $image_url_temp = str_replace('%%item_title%%', $replacement, $image_url);
                            $image_url_temp = preg_replace_callback('#%%random_image\[([^\]]*?)\](\[\d+\])?%%#', function ($matches) {
                                if(isset($matches[2]))
                                {
                                    $chance = trim($matches[2], '[]');
                                }
                                else
                                {
                                    $chance = '';
                                }
                                $my_img = aiomatic_get_random_image_google($matches[1], 0, 0, $chance);
                                return $my_img;
                            }, $image_url_temp);
                            $img_rulx = $spintax->Parse(trim($image_url_temp));
                            $img_rulx = explode(',', $img_rulx);
                            $img_rulx = trim($img_rulx[array_rand($img_rulx)]);
                            if(is_numeric($img_rulx))
                            {
                                $featured_path = aiomatic_assign_featured_image($img_rulx, $post_id);
                            }
                            else
                            {
                                if($img_rulx != '')
                                {
                                    if (!aiomatic_generate_featured_image($img_rulx, $post_id)) {
                                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                                            aiomatic_log_to_file('aiomatic_generate_featured_image failed to default value: ' . $img_rulx . '!');
                                        }
                                    } else {
                                        $featured_path = $img_rulx;
                                    }
                                }
                            }
                        }
                    }
                    if ($auto_categories != 'disabled') {
                        if ($post['extra_categories'] != '') {
                            $extra_cats = explode(',', $post['extra_categories']);
                            foreach($extra_cats as $extra_cat)
                            {
                                $termid = aiomatic_create_terms('category', '0', trim($extra_cat));
                                wp_set_post_terms($post_id, $termid, 'category', true);
                                if($wpml_lang != '' && function_exists('pll_set_term_language'))
                                {
                                    foreach($termid as $tx)
                                    {
                                        pll_set_term_language($tx, $wpml_lang); 
                                    }
                                }
                                elseif($wpml_lang != '' && has_filter('wpml_object_id'))
                                {
                                    $wpml_element_type = apply_filters( 'wpml_element_type', 'product_cat' );
                                    foreach($termid as $tx)
                                    {
                                        $pars['element_id'] = $tx;
                                        $pars['element_type'] = $wpml_element_type;
                                        $pars['language_code'] = $wpml_lang;
                                        $pars['trid'] = FALSE;
                                        $pars['source_language_code'] = NULL;
                                        do_action('wpml_set_element_language_details', $pars);
                                    }
                                }
                            }
                        }
                    }
                    if (isset($default_category) && $default_category !== 'aiomatic_no_category_12345678' && $default_category[0] !== 'aiomatic_no_category_12345678') {
                        $cats   = array();
                        if(is_array($default_category))
                        {
                            foreach($default_category as $dc)
                            {
                                $cats[] = $dc;
                            }
                        }
                        else
                        {
                            $cats[] = $default_category;
                        }
                        global $sitepress;
                        if($wpml_lang != '' && has_filter('wpml_current_language') && $sitepress != null)
                        {
                            $current_language = apply_filters( 'wpml_current_language', NULL );
                            $sitepress->switch_lang($wpml_lang);
                        }
                        wp_set_post_categories($post_id, $cats, true);
                        if($wpml_lang != '' && has_filter('wpml_current_language') && $sitepress != null)
                        {
                            $sitepress->switch_lang($current_language);
                        }
                    }
                    $tax_rez = wp_set_object_terms( $post_id, 'aiomatic_' . $param, 'coderevolution_post_source', true);
                    if (is_wp_error($tax_rez)) {
                        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                            aiomatic_log_to_file('wp_set_object_terms failed for: ' . $post_id . '!');
                        }
                    }
                    if($remove_default == '1' && ($auto_categories != 'disabled' || (isset($default_category) && $default_category !== 'aiomatic_no_category_12345678' && $default_category[0] !== 'aiomatic_no_category_12345678')))
                    {
                        $new_categories = wp_get_post_categories($post_id);
                        if(isset($default_categories) && !($default_categories == $new_categories))
                        {
                            foreach($default_categories as $dc)
                            {
                                $rem_cat = get_category( $dc );
                                wp_remove_object_terms( $post_id, $rem_cat->slug, 'category' );
                            }
                        }
                    }
                    aiomatic_addPostMeta($post_id, $post, $param, $featured_path, $post_topic);
                    if($wpml_lang != '' && (class_exists('SitePress') || function_exists('wpml_object_id')))
                    {
                        $wpml_element_type = apply_filters( 'wpml_element_type', $post_type );
                        $pars['element_id'] = $post_id;
                        $pars['element_type'] = $wpml_element_type;
                        $pars['language_code'] = $wpml_lang;
                        $pars['source_language_code'] = NULL;
                        do_action('wpml_set_element_language_details', $pars);

                        global $wp_filesystem;
                        if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
                            include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
                            wp_filesystem($creds);
                        }
                        if($wp_filesystem->exists(WP_PLUGIN_DIR . '/sitepress-multilingual-cms/inc/wpml-api.php'))
                        {
                            include_once( WP_PLUGIN_DIR . '/sitepress-multilingual-cms/inc/wpml-api.php' );
                        }
                        $wpml_lang = trim($wpml_lang);
                        if(function_exists('wpml_update_translatable_content'))
                        {
                            wpml_update_translatable_content('post_' . $post_type, $post_id, $wpml_lang);
                            if($my_post['post_title'] != '')
                            {
                                global $sitepress;
                                global $wpdb;
                                $keyid = md5($my_post['post_title']);
                                $keyName = $keyid . '_wpml';
                                $rezxxxa = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}postmeta WHERE `meta_key` = '$keyName' limit 1", ARRAY_A );
                                if(count($rezxxxa) != 0)
                                {
                                    $metaRow = $rezxxxa[0];
                                    $metaValue = $metaRow['meta_value'];
                                    $metaParts = explode('_', $metaValue);
                                    $sitepress->set_element_language_details($post_id, 'post_'.$my_post['post_type'] , $metaParts[0], $wpml_lang, $metaParts[1] ); 
                                }
                                else
                                {
                                    $ptrid = $sitepress->get_element_trid($post_id);
                                    update_post_meta($post_id, $keyid.'_wpml', $ptrid.'_'.$wpml_lang );
                                }
                            }
                            
                        }
                    }
                    elseif($wpml_lang != '' && function_exists('pll_set_post_language'))
                    {
                        pll_set_post_language($post_id, $wpml_lang);
                    }
                } else {
                    aiomatic_log_to_file('Failed to insert post into wp database! Title:' . $post['post_title'] . '! Error: ' . $post_id->get_error_message() . 'Error code: ' . $post_id->get_error_code() . 'Error data: ' . $post_id->get_error_data());
                    continue;
                }
            }
            unset($post_array);
        }
        catch (Exception $e) {
            aiomatic_log_to_file('Exception thrown ' . esc_html($e->getMessage()) . '!');
            if($auto == 1)
            {
                aiomatic_clearFromList($param);
            }
            return 'fail';
        }
        
        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
            aiomatic_log_to_file('Rule ID ' . esc_html($param) . ' succesfully run! ' . esc_html($posts_inserted) . ' posts created!');
        }
        if (isset($aiomatic_Main_Settings['send_email']) && $aiomatic_Main_Settings['send_email'] == 'on' && $aiomatic_Main_Settings['email_address'] !== '') {
            try {
                $to        = $aiomatic_Main_Settings['email_address'];
                $subject   = '[aiomatic] Rule running report - ' . aiomatic_get_date_now();
                $message   = 'Rule ID ' . esc_html($param) . ' succesfully run! ' . esc_html($posts_inserted) . ' posts created!';
                $headers[] = 'From: AIomatic Plugin <aiomatic@noreply.net>';
                $headers[] = 'Reply-To: noreply@aiomatic.com';
                $headers[] = 'X-Mailer: PHP/' . phpversion();
                $headers[] = 'Content-Type: text/html';
                $headers[] = 'Charset: ' . get_option('blog_charset', 'UTF-8');
                wp_mail($to, $subject, $message, $headers);
            }
            catch (Exception $e) {
                if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
                    aiomatic_log_to_file('Failed to send mail: Exception thrown ' . esc_html($e->getMessage()) . '!');
                }
            }
        }
    }
    if ($posts_inserted == 0) {
        if($auto == 1)
                {
                    aiomatic_clearFromList($param);
                }
        return 'nochange';
    } else {
        if($auto == 1)
                {
                    aiomatic_clearFromList($param);
                }
        return 'ok';
    }
}
?>