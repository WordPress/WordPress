"use strict";
String.prototype.aitrim = function() {
    return this.replace(/^\s+|\s+$/g, "");
};
function aiisAlphaNumeric(str) {
    var code, i, len;
    for (i = 0, len = str.length; i < len; i++) {
      code = str.charCodeAt(i);
      if (!(code > 47 && code < 58) && // numeric (0-9)
          !(code > 64 && code < 91) && // upper alpha (A-Z)
          !(code > 96 && code < 123)) { // lower alpha (a-z)
        return false;
      }
    }
    return true;
}
var input = document.getElementById("aiomatic_chat_input");
if(input !== undefined && input !== null)
{
    input.addEventListener("keydown", function (e) {
        if (e.key === "Enter" && !e.shiftKey) { 
            e.preventDefault(); 
            openaichatfunct();
            return false;
        }
    });
}
function airemovePrefix(mainString, substring) 
{
    if (mainString.startsWith(substring)) 
    {
      return mainString.slice(substring.length);
    } else 
    {
      return mainString;
    }
}
function airemoveAfter(mainString, substring) {
    var index = mainString.indexOf(substring);
    if (index !== -1) {
      return mainString.slice(0, index);
    } else {
      return mainString;
    }
}
async function openaichatfunct() {
    jQuery('#aichatsubmitbut').attr('disabled', true);
    var input_textj = jQuery('#aiomatic_chat_input');
    var input_text = '';
    jQuery('#openai-chat-response').html('<div class="automaticx-dual-ring"></div>');
    /*
    if(input_text === '')
    {
        jQuery('#aichatsubmitbut').attr('disabled', false);
        return;
    }
    */
    input_text = input_textj.val();
    input_textj.val('');
    if(aiomatic_chat_ajax_object.enable_moderation == '1')
    {
        var isflagged = false;
        await jQuery.ajax({
            type: 'POST',
            url: aiomatic_chat_ajax_object.ajax_url,
            data: {
                action: 'aiomatic_moderate_text',
                text: input_text,
                nonce: aiomatic_chat_ajax_object.moderation_nonce,
                model: aiomatic_chat_ajax_object.moderation_model
            },
            success: function(response) {
                if(response.status == 'success')
                {
                    const resp = JSON.parse(response.data);
                    if(resp.results[0].flagged != undefined)
                    {
                        if(resp.results[0].flagged == true)
                        {
                            jQuery('#aichatsubmitbut').attr('disabled', false);
                            jQuery('#openai-chat-response').html('<div class="text-primary highlight-text-fail" role="status">' + aiomatic_chat_ajax_object.flagged_message + '</div>');
                            isflagged = true;
                        }
                    }
                    else
                    {
                        console.log('Invalid response from moderation ' + response);
                    }
                }
                else
                {
                    console.log('Moderation returned an error: ' + response.msg);
                }
            },
            error: function(error) {
                console.log('Moderation failed: ' + error.responseText);
            },
        });
        if(isflagged == true)
        {
            return;
        }
    }
    var user_message_preppend = aiomatic_chat_ajax_object.user_message_preppend;
    var ai_message_preppend = aiomatic_chat_ajax_object.ai_message_preppend;
    var x_input_text = jQuery('#aiomatic_chat_history').html();
    var remember_string = x_input_text.replace(/<div class="ai-bubble ai-other">([\s\S]*?)<\/div>/g, ai_message_preppend + "$1\n");
    remember_string = remember_string.replace(/<div class="ai-bubble ai-mine">([\s\S]*?)<\/div>/g, user_message_preppend + "$1\n");
    remember_string = remember_string.replace(/<div class="ai-speech">([\s\S]*?)<\/div>/g, '');
    remember_string = remember_string.aitrim();
    remember_string = remember_string.slice(-12000);
    var nlregex = /<br\s*[\/]?>/gi;
    remember_string = remember_string.replace(nlregex, "\n");
    if(input_text.aitrim() != '')
    {
        input_text = input_text.replace(/(?:\r\n|\r|\n)/g, '<br>');
        jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-mine">' + input_text + '</div>');
    }
    var model = aiomatic_chat_ajax_object.model;
    var temp = aiomatic_chat_ajax_object.temp;
    var top_p = aiomatic_chat_ajax_object.top_p;
    var presence = aiomatic_chat_ajax_object.presence;
    var frequency = aiomatic_chat_ajax_object.frequency;
    var instant_response = aiomatic_chat_ajax_object.instant_response;
    var chat_preppend_text = aiomatic_chat_ajax_object.chat_preppend_text;
    var user_token_cap_per_day = aiomatic_chat_ajax_object.user_token_cap_per_day;
    var user_id = aiomatic_chat_ajax_object.user_id;
    var persistent = aiomatic_chat_ajax_object.persistent;
    if(model == 'default' || model == '')
    {
        model = jQuery( "#model-chat-selector option:selected" ).text();
    }
    if(temp == 'default' || temp == '')
    {
        temp = jQuery('#temperature-chat-input').val();
    }
    if(top_p == 'default' || top_p == '')
    {
        top_p = jQuery('#top_p-chat-input').val();
    }
    if(presence == 'default' || presence == '')
    {
        presence = jQuery('#presence-chat-input').val();
    }
    if(frequency == 'default' || frequency == '')
    {
        frequency = jQuery('#frequency-chat-input').val();
    }
    var lastch = input_text.charAt(input_text.length - 1);
    if(aiisAlphaNumeric(lastch))
    {
        input_text += '.';
    }
    if(user_message_preppend != '')
    {
        input_text = user_message_preppend + ' ' + input_text;
    }
    if(ai_message_preppend != '')
    {
        input_text = input_text + ' ' + ai_message_preppend;
    }
    if(chat_preppend_text != '')
    {
        remember_string = chat_preppend_text + '\n' + remember_string;
    }
    jQuery.ajax({
        type: 'POST',
        url: aiomatic_chat_ajax_object.ajax_url,
        data: {
            action: 'aiomatic_chat_submit',
            input_text: input_text,
            nonce: aiomatic_chat_ajax_object.nonce,
            model: model,
            temp: temp,
            top_p: top_p,
            presence: presence,
            frequency: frequency,
            user_token_cap_per_day: user_token_cap_per_day,
            remember_string: remember_string,
            user_id: user_id
        },
        success: function(response) {
            if(response.status == 'success')
            {
                if(response.data == '')
                {
                    jQuery('#openai-chat-response').html('<div class="text-primary" role="status">AI considers this as the end of the text. Please try using a different text input.</div>');
                }
                else
                {
                    if(ai_message_preppend != '')
                    {
                        response.data = airemovePrefix(response.data.aitrim(), ai_message_preppend);
                        response.data = response.data.aitrim();
                    }
                    if(user_message_preppend != '')
                    {
                        response.data = airemoveAfter(response.data.aitrim(), user_message_preppend);
                        response.data = response.data.aitrim();
                    }
                    response.data = response.data.replace(/\n/g, '<br>');
                    var x_input_text = jQuery('#aiomatic_chat_history').html();
                    if((persistent != 'off' && persistent != '0' && persistent != '') && user_id != '0')
                    {
                        jQuery.ajax({
                            type: 'POST',
                            url: aiomatic_chat_ajax_object.ajax_url,
                            data: {
                                action: 'aiomatic_user_meta_save',
                                nonce: aiomatic_chat_ajax_object.persistentnonce,
                                persistent: persistent,
                                x_input_text: x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>',
                                user_id: user_id
                            },
                            success: function() {
                            },
                            error: function(error) {
                                console.log('Error while saving persistent user log: ' + error.responseText);
                            },
                        });
                    }
                    if(instant_response == 'true')
                    {
                        if(aiomatic_chat_ajax_object.text_speech == 'elevenlabs')
                        {
                            let speechData = new FormData();
                            speechData.append('nonce', aiomatic_chat_ajax_object.nonce);
                            speechData.append('x_input_text', response.data);
                            speechData.append('action', 'aiomatic_get_elevenlabs_voice_chat');
                            var speechRequest = new XMLHttpRequest();
                            speechRequest.open("POST", aiomatic_chat_ajax_object.ajax_url);
                            speechRequest.responseType = "arraybuffer";
                            speechRequest.onload = function () {
                                var blob = new Blob([speechRequest.response], {type: "audio/mpeg"});
                                var fr = new FileReader();
                                fr.onload = function () {
                                    var fileText = this.result;
                                    try {
                                        var errorMessage = JSON.parse(fileText);
                                        console.log('ElevenLabs API failed: ' + errorMessage.msg);
                                        jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>');
                                        // Clear the response container
                                        jQuery('#openai-chat-response').html('&nbsp;');
                                        // Enable the submit button
                                        jQuery('#aichatsubmitbut').attr('disabled', false);
                                    } catch (errorBlob) {
                                        var blobUrl = URL.createObjectURL(blob);
                                        var audioElement = new Audio(blobUrl);
                                        audioElement.controls = true;
                                        audioElement.style.marginTop = "2px";
                                        audioElement.style.width = "100%";
                                        audioElement.addEventListener("error", function(event) 
                                        {
                                            console.error("Error loading or playing the audio: ", event);
                                        });
                                        var aiomatic_speech = audioElement.outerHTML;
                                        jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>' + '<div class="ai-speech">' + aiomatic_speech + '</div>');
                                        // Clear the response container
                                        jQuery('#openai-chat-response').html('&nbsp;');
                                        // Enable the submit button
                                        jQuery('#aichatsubmitbut').attr('disabled', false);
                                        audioElement.play();
                                    }
                                }
                                fr.readAsText(blob);
                            }
                            speechRequest.send(speechData);
                        }
                        else
                        {
                            if(aiomatic_chat_ajax_object.text_speech == 'google')
                            {
                                let speechData = new FormData();
                                speechData.append('nonce', aiomatic_chat_ajax_object.nonce);
                                speechData.append('action', 'aiomatic_get_google_voice_chat');
                                speechData.append('x_input_text', response.data);
                                var speechRequest = new XMLHttpRequest();
                                speechRequest.open("POST", aiomatic_chat_ajax_object.ajax_url);
                                speechRequest.onload = function () {
                                    var result = speechRequest.responseText;
                                    try {
                                        var jsonresult = JSON.parse(result);
                                        if(jsonresult.status === 'success'){
                                            var byteCharacters = atob(jsonresult.audio);
                                            const byteNumbers = new Array(byteCharacters.length);
                                            for (let i = 0; i < byteCharacters.length; i++) {
                                                byteNumbers[i] = byteCharacters.charCodeAt(i);
                                            }
                                            const byteArray = new Uint8Array(byteNumbers);
                                            const blob = new Blob([byteArray], {type: 'audio/mp3'});
                                            const blobUrl = URL.createObjectURL(blob);
                                            var audioElement = new Audio(blobUrl);
                                            audioElement.controls = true;
                                            audioElement.style.marginTop = "2px";
                                            audioElement.style.width = "100%";
                                            audioElement.addEventListener("error", function(event) 
                                            {
                                                console.error("Error loading or playing the audio: ", event);
                                            });
                                            var aiomatic_speech = audioElement.outerHTML;
                                            jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>' + '<div class="ai-speech">' + aiomatic_speech + '</div>');
                                            // Clear the response container
                                            jQuery('#openai-chat-response').html('&nbsp;');
                                            // Enable the submit button
                                            jQuery('#aichatsubmitbut').attr('disabled', false);
                                            audioElement.play();
                                        }
                                        else{
                                            var errorMessageDetail = 'Google: ' + jsonresult.msg;
                                            console.log('Google Text-to-Speech error: ' + errorMessageDetail);
                                            jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>');
                                            // Clear the response container
                                            jQuery('#openai-chat-response').html('&nbsp;');
                                            // Enable the submit button
                                            jQuery('#aichatsubmitbut').attr('disabled', false);
                                        }
                                    }
                                    catch (errorSpeech){
                                        console.log('Exception in Google Text-to-Speech API: ' + errorSpeech);
                                        jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>');
                                        // Clear the response container
                                        jQuery('#openai-chat-response').html('&nbsp;');
                                        // Enable the submit button
                                        jQuery('#aichatsubmitbut').attr('disabled', false);
                                    }
                                }
                                speechRequest.send(speechData);
                            }
                            else
                            {
                                jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>');
                                // Clear the response container
                                jQuery('#openai-chat-response').html('&nbsp;');
                                // Enable the submit button
                                jQuery('#aichatsubmitbut').attr('disabled', false);
                            }
                        }
                    }
                    else
                    {
                        jQuery('#openai-chat-response').html('<div class="aiomatic-dots-bars-2"></div>');
                        var i = 0;
                        function typeWriter() {
                            if (i < response.data.length) {
                                // Append the response to the input field
                                jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-other">' + response.data.substring(0, i + 1) + '</div>');
                                i++;
                                setTimeout(typeWriter, 50);
                            } else {
                                // Clear the response container
                                jQuery('#openai-chat-response').html('&nbsp;');
                                // Enable the submit button
                                jQuery('#aichatsubmitbut').attr('disabled', false);
                            }
                        }
                        typeWriter();
                    }
                }
            }
            else
            {
                jQuery('#openai-chat-response').html('<div class="text-primary highlight-text-fail" role="status">' + response.msg + '</div>');
            }
            jQuery('#aichatsubmitbut').attr('disabled', false);
        },
        error: function(error) {
            console.log('Error: ' + error.responseText);
            // Clear the response container
            jQuery('#openai-chat-response').html('<div class="text-primary highlight-text-fail" role="status">Failed to generate content, try again later.</div>');
            // Enable the submit button
            jQuery('#aichatsubmitbut').attr('disabled', false);
        },
    });
}
var recognition;
var recognizing = false;
jQuery(document).ready(function() {
    if(aiomatic_chat_ajax_object.enable_copy == 'on')
    {
        jQuery(document).on('click', '.ai-bubble', function (event) {
            var finder = jQuery(event.target);
            if(finder !== null)
            {
                var jsf = finder.html();
                var nlregex = /<br\s*[\/]?>/gi;
                jsf = jsf.replace(nlregex, "\n");
                navigator.clipboard.writeText(jsf);
            }
            var popup = jQuery("<div class='popup'>Text copied!</div>");
            popup.appendTo("body");
            popup.css({
                "position": "absolute",
                "top": event.pageY + 10,
                "left": event.pageX + 10
            });
            jQuery(document).mousemove(function(event) {
                popup.css({
                    "position": "absolute",
                    "top": event.pageY + 10,
                    "left": event.pageX + 10
                });
            });
            setTimeout(function() {
                popup.remove();
            }, 3000);
        });
    }
    if(aiomatic_chat_ajax_object.scroll_bot == 'on')
    {
        jQuery('#aiomatic_chat_history').on('DOMSubtreeModified', function(){
            var psconsole = jQuery('#aiomatic_chat_history');
            if(psconsole.length)
            {
                psconsole.scrollTop(psconsole[0].scrollHeight - psconsole.height());
            }
        });
    }
    if(jQuery('#aiomatic_chat_templates').length)
    {
        jQuery('#aiomatic_chat_templates').change(function()
        {
            jQuery('#aiomatic_chat_input').val(jQuery( "#aiomatic_chat_templates" ).val());
        });
    }
    else
    {
        // Check if the browser supports the Web Speech API
        if ('webkitSpeechRecognition' in window) {
            recognition = new webkitSpeechRecognition();
            recognition.continuous = true;
            recognition.interimResults = true;

            // Start the speech recognition when the button is clicked
            jQuery('#openai-chat-speech-button').click(function() {
                if (recognizing) {
                    recognition.stop();
                    recognizing = false;
                } else {
                    recognition.start();
                    recognizing = true;
                }
            });

            // Handle the speech recognition results
            recognition.onresult = function(event) {
                for (var i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        jQuery('#aiomatic_chat_input').val(jQuery('#aiomatic_chat_input').val() + " " + event.results[i][0].transcript);
                    }
                }
                
            };
        }
    }
});