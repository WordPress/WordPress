"use strict";
jQuery(document).ready(function ($)
{
    function AiomaticValidateEmail(input) 
    {
        var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (input.match(validRegex)) {
          return true;
        } else {
          return false;
        }
    }
    function AiomaticisValidUrl(string) {
        try {
          new URL(string);
          return true;
        } catch (err) {
          return false;
        }
      }
    function aiomatichtmlDecode(input) {
        var doc = new DOMParser().parseFromString(input, "text/html");
        return doc.documentElement.textContent;
    }
    function aiomaticBasicEditor(){
        var basicEditor = true;
        if(tinyMCE === null)
        {
            return basicEditor;
        }
        var editor = tinyMCE.get('aiomatic-prompt-result');
        var inputp = document.getElementById('wp-aiomatic-prompt-result-wrap');
        if ( inputp !== null && inputp.classList.contains('tmce-active') && editor ) {
            basicEditor = false;
        }
        return basicEditor;
    }
    function aiomaticSetContent(value){
        if (aiomaticBasicEditor()) {
            document.getElementById('aiomatic-prompt-result').value = aiomatichtmlDecode(value);
        } else {
            var editor = tinyMCE.get('aiomatic-prompt-result');
            editor.setContent(aiomatichtmlDecode(value));
        }
    }
    function aiomaticLoadingBtn(btn){
        document.querySelector('#aiomatic-generate-button').disabled = true;
        btn.addClass('button--loading');
    }
    function aiomaticRmLoading(btn){
        btn.removeAttr('disabled');
        btn.removeClass('button--loading');
    }
    $(document).on('click','#aiomatic-generate-button', function(e){
        e.preventDefault();
        jQuery('#openai-response').html('<div class="text-primary highlight-text-fail" role="status"></div>');
        var aiomaticGenerateBtn = $('#aiomatic-generate-button');
        var aiomaticMaxToken = document.getElementById('aiomatic-engine');
        var max_tokens = aiomaticMaxToken.value;
        var aiomaticTemperature = document.getElementById('aiomatic-temperature');
        var aiomaticTypeInput = document.getElementById('aiomatic-form-type');
        var aiomaticType = aiomaticTypeInput.value;
        var temperature = aiomaticTemperature.value;
        var aiomaticTopP = document.getElementById('aiomatic-top_p');
        var top_p = aiomaticTopP.value;
        var aiomaticFP = document.getElementById('aiomatic-frequency_penalty');
        var frequency_penalty = aiomaticFP.value;
        var aiomaticPP = document.getElementById('aiomatic-presence_penalty');
        var presence_penalty = aiomaticPP.value;
        var error_message = false;
        var aiomaticPromptTitle = document.getElementById('aiomatic-prompt');
        var prompt = aiomaticPromptTitle.value;
        var modelex = document.getElementById("aiomatic-engine");
        var model = modelex.options[modelex.selectedIndex].value;
        if(prompt === ''){
            error_message = 'Please insert prompt';
        }
        else if(max_tokens === ''){
            error_message = 'Please enter max tokens';
        }
        else if(parseFloat(max_tokens) < 1 || parseFloat(max_tokens) > 8000){
            error_message = 'Please enter a valid max tokens value between 1 and 8000';
        }
        else if(temperature === ''){
            error_message = 'Please enter temperature';
        }
        else if(parseFloat(temperature) < 0 || parseFloat(temperature) > 1){
            error_message = 'Please enter a valid temperature value between 0 and 1';
        }
        else if(top_p === ''){
            error_message = 'Please enter Top P';
        }
        else if(parseFloat(top_p) < 0 || parseFloat(top_p) > 1){
            error_message = 'Please enter a valid Top P value between 0 and 1';
        }
        else if(frequency_penalty === ''){
            error_message = 'Please enter frequency penalty';
        }
        else if(parseFloat(frequency_penalty) < 0 || parseFloat(frequency_penalty) > 2){
            error_message = 'Please enter a valid frequency penalty value between 0 and 2';
        }
        else if(presence_penalty === ''){
            error_message = 'Please enter presence penalty';
        }
        else if(parseFloat(presence_penalty) < 0 || parseFloat(presence_penalty) > 2){
            error_message = 'Please enter a valid presence penalty value between 0 and 2';
        }
        let formin = $('.aiomatic-form-input');
        formin.each(function(){
            let name = $(this).attr('aiomatic-name');
            let value = $(this).val();
            let type = $(this).attr('data-type');
            let min = $(this).attr('data-min');
            let max = $(this).attr('data-max');
            let required = $(this).attr('data-required');
            if(aiomatic_completition_ajax_object.min_len != '')
            {
                if(value.length < parseInt(aiomatic_completition_ajax_object.min_len, 10))
                {
                    error_message = name + ': You need to enter a longer input value, minimum is: ' + aiomatic_completition_ajax_object.min_len;
                }
            }
            if(aiomatic_completition_ajax_object.max_len != '')
            {
                if(value.length > parseInt(aiomatic_completition_ajax_object.max_len, 10))
                {
                    error_message = name + ': You need to enter a shorter input value, maximum is: ' + aiomatic_completition_ajax_object.max_len;
                }
            }
            if(min != '')
            {
                if(min > parseInt(value, 10))
                {
                    error_message = name + ': You need to enter a value larger than ' + min;
                }
            }
            if(max != '')
            {
                if(max < parseInt(value, 10))
                {
                    error_message = name + ': You need to enter a value smaller than ' + max;
                }
            }
            if(type == 'email')
            {
                if(!AiomaticValidateEmail(value))
                {
                    error_message = name + ': Invalid email address submitted: ' + value;
                }
            }
            if(type == 'url')
            {
                if(!AiomaticisValidUrl(value))
                {
                    error_message = name + ': Invalid URL submitted: ' + value;
                }
            }
            if(required == 'yes' && value == '')
            {
                error_message = name + ': This field is required';
            }
            prompt = prompt.replace('%%' + name + '%%', value);
        });
        if(prompt === ''){
            error_message = 'Empty prompt was returned';
        }
        if(error_message){
            jQuery('#openai-response').html('<div class="text-primary highlight-text-fail" role="status">' + error_message + '</div>');
        }
        else{
            aiomaticLoadingBtn(aiomaticGenerateBtn);
            var image_placeholder = aiomatic_completition_ajax_object.image_placeholder;
            jQuery("#aiomatic_form_response").attr("src", image_placeholder).fadeIn();
            if(aiomaticType == 'text')
            {
                aiomaticSetContent('');
            }
            document.getElementById('openai-response').innerHTML = '';
            jQuery.ajax({
                type: 'POST',
                url: aiomatic_completition_ajax_object.ajax_url,
                data: {
                    action: 'aiomatic_form_submit',
                    input_text: prompt,
                    nonce: aiomatic_completition_ajax_object.nonce,
                    model: model,
                    temp: temperature,
                    top_p: top_p,
                    presence: presence_penalty,
                    aiomaticType: aiomaticType,
                    frequency: frequency_penalty,
                    user_token_cap_per_day: '',
                    user_id: aiomatic_completition_ajax_object.user_id
                },
                success: function(response) {
                    if(response.status == 'success')
                    {
                        if(response.data == '')
                        {
                            jQuery('#openai-response').html('<div class="text-primary" role="status">AI considers this as the end of the text. Please try using a different text input.</div>');
                        }
                        else
                        {
                            jQuery('#openai-response').html('');
                            if(aiomaticType == 'text')
                            {
                                aiomaticSetContent(response.data);
                            }
                            else
                            {
                                if(aiomaticType == 'image')
                                {
                                    jQuery("#aiomatic_form_response").attr("src", aiomatichtmlDecode(response.data)).fadeIn();
                                }
                                else
                                {
                                    jQuery("#aiomatic_form_response").attr("src", "data:image/gif;base64," + aiomatichtmlDecode(response.data)).fadeIn();
                                }
                            }
                        }
                    }
                    else
                    {
                        jQuery('#openai-response').html('<div class="text-primary highlight-text-fail" role="status">' + response.msg + '</div>');
                    }
                    aiomaticRmLoading(aiomaticGenerateBtn);
                },
                error: function(error) {
                    console.log('Error: ' + error.responseText);
                    jQuery("#aiomatic_form_response").attr("src", '').fadeIn();
                    // Clear the response container
                    jQuery('#openai-response').html('<div class="text-primary highlight-text-fail" role="status">Failed to generate content, try again later.</div>');
                    aiomaticRmLoading(aiomaticGenerateBtn);
                },
            });
        }
    });
});