"use strict";
function updateCSSAttribute(css_attr_name, css_attr_value, original_css_code) {
  const regex = new RegExp(`((?<!-)${css_attr_name}\\s*:\\s*[^;]+;?)`);
  const match = original_css_code.match(regex);
  var updated_css_code = original_css_code;
  if (match) {
    // If the attribute is found in the CSS code, replace its value
    updated_css_code = original_css_code.replace(regex, `${css_attr_name}: ${css_attr_value}`);
    return updated_css_code;
  } else {
    // If the attribute is not found, append a new CSS attribute to the code
    const new_css_attribute = `${css_attr_name}: ${css_attr_value}`;
    if(original_css_code == '')
    {
        updated_css_code = new_css_attribute;
    }
    else
    {
        if(original_css_code.endsWith(';'))
        {
            updated_css_code = `${original_css_code}${new_css_attribute}`;
        }
        else
        {
            updated_css_code = `${original_css_code};${new_css_attribute}`;
        }
    }
    return updated_css_code;
  }
}
function fontSizeChanged()
{
    var selected = jQuery('#font_size').find('option:selected').attr('value');
    var text_input = jQuery('#aiomatic_chat_history');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('font-size', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function fontSizeChanged_b()
{
    var selected = jQuery('#font_size_b').find('option:selected').attr('value');
    var text_input = jQuery('#aiomatic_chat_history');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/font_size="([^"]*?)"/g, 'font_size="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('font-size', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function widthChanged()
{
    var selected = jQuery('#width').val();
    var text_input = jQuery('.openai-ai-form');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('width', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function widthChanged_b()
{
    var selected = jQuery('#width_b').val();
    var text_input = jQuery('.openai-ai-form');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/width="([^"]*?)"/g, 'width="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('width', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function heightChanged()
{
    var selected = jQuery('#height').val();
    var text_input = jQuery('#aiomatic_chat_history');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('height', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function heightChanged_b()
{
    var selected = jQuery('#height_b').val();
    var text_input = jQuery('#aiomatic_chat_history');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/height="([^"]*?)"/g, 'height="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('height', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function minheightChanged()
{
    var selected = jQuery('#minheight').val();
    var text_input = jQuery('#aiomatic_chat_history');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('min-height', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function minheightChanged_b()
{
    var selected = jQuery('#minheight_b').val();
    var text_input = jQuery('#aiomatic_chat_history');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/minheight="([^"]*?)"/g, 'minheight="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('min-height', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function backgroundChanged()
{
    var selected = jQuery('#background').val();
    var text_input = jQuery('#aiomatic_chat_history');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function backgroundChanged_b()
{
    var selected = jQuery('#background_b').val();
    var text_input = jQuery('#aiomatic_chat_history');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/background="([^"]*?)"/g, 'background="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function userfontcolorChanged()
{
    var selected = jQuery('#user_font_color').val();
    var text_input = jQuery('.ai-mine');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function userfontcolorChanged_b()
{
    var selected = jQuery('#user_font_color_b').val();
    var text_input = jQuery('.ai-mine');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/user_font_color="([^"]*?)"/g, 'user_font_color="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function userbackgroundcolorChanged()
{
    var selected = jQuery('#user_background_color').val();
    var text_input = jQuery('.ai-mine');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function userbackgroundcolorChanged_b()
{
    var selected = jQuery('#user_background_color_b').val();
    var text_input = jQuery('.ai-mine');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/user_background_color="([^"]*?)"/g, 'user_background_color="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function aifontcolorChanged()
{
    var selected = jQuery('#ai_font_color').val();
    var text_input = jQuery('.ai-other');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function aifontcolorChanged_b()
{
    var selected = jQuery('#ai_font_color_b').val();
    var text_input = jQuery('.ai-other');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/ai_font_color="([^"]*?)"/g, 'ai_font_color="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function aibackgroundcolorChanged()
{
    var selected = jQuery('#ai_background_color').val();
    var text_input = jQuery('.ai-other');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function aibackgroundcolorChanged_b()
{
    var selected = jQuery('#ai_background_color_b').val();
    var text_input = jQuery('.ai-other');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/ai_background_color="([^"]*?)"/g, 'ai_background_color="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function bordercolorChanged()
{
    var selected = jQuery('#input_border_color').val();
    var text_input = jQuery('#aiomatic_chat_input');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('border-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function bordercolorChanged_b()
{
    var selected = jQuery('#input_border_color_b').val();
    var text_input = jQuery('#aiomatic_chat_input');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/input_border_color="([^"]*?)"/g, 'input_border_color="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('border-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function placeholderChanged_b()
{
    var selected = jQuery('#placeholder_b').val();
    var text_input = jQuery('#aiomatic_chat_input');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/placeholder="([^"]*?)"/g, 'placeholder="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        text_input.attr("placeholder", selected);
    }
}
function modelChanged_b()
{
    var selected = jQuery('#model_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/model="([^"]*?)"/g, 'model="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function temperatureChanged_b()
{
    var selected = jQuery('#temperature_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/temperature="([^"]*?)"/g, 'temperature="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function toppChanged_b()
{
    var selected = jQuery('#top_p_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/top_p="([^"]*?)"/g, 'top_p="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function presenceChanged_b()
{
    var selected = jQuery('#presence_penalty_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/presence_penalty="([^"]*?)"/g, 'presence_penalty="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function frequencyChanged_b()
{
    var selected = jQuery('#frequency_penalty_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/frequency_penalty="([^"]*?)"/g, 'frequency_penalty="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function contextChanged_b()
{
    var selected = jQuery('#context_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/chat_preppend_text="([^"]*?)"/g, 'chat_preppend_text="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function userChanged_b()
{
    var selected = jQuery('#user_name_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/user_message_preppend="([^"]*?)"/g, 'user_message_preppend="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function aiChanged_b()
{
    var selected = jQuery('#ai_name_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/ai_message_preppend="([^"]*?)"/g, 'ai_message_preppend="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function messageChanged_b()
{
    var selected = jQuery('#ai_message_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/ai_first_message="([^"]*?)"/g, 'ai_first_message="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function instantChanged_b()
{
    if(jQuery('#instant_response_b').is(":checked"))
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/instant_response="([^"]*?)"/g, 'instant_response="true"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
    else
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/instant_response="([^"]*?)"/g, 'instant_response="false"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
    }
}
function modeChanged_b()
{
    var selected = jQuery('#chat_mode_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/chat_mode="([^"]*?)"/g, 'chat_mode="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        text_input.prop('value', selected);
        text_input.text(selected);
    }
}
function persistentChanged_b()
{
    var selected = jQuery('#persistent_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/persistent="([^"]*?)"/g, 'persistent="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        text_input.prop('value', selected);
        text_input.text(selected);
    }
}
function templateChanged_b()
{
    var selected = jQuery('#template_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/prompt_templates="([^"]*?)"/g, 'prompt_templates="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        text_input.prop('value', selected);
        text_input.text(selected);
    }
}
function editableChanged_b()
{
    var selected = jQuery('#prompt_editable_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/prompt_editable="([^"]*?)"/g, 'prompt_editable="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        text_input.prop('value', selected);
        text_input.text(selected);
    }
}
function frontChanged_b()
{
    var selected = jQuery('#enable_front_end_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/show_in_window="([^"]*?)"/g, 'show_in_window="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        text_input.prop('value', selected);
        text_input.text(selected);
    }
}
function locationChanged_b()
{
    var selected = jQuery('#window_location_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/window_location="([^"]*?)"/g, 'window_location="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        text_input.prop('value', selected);
        text_input.text(selected);
    }
}
function submitChanged_b()
{
    var selected = jQuery('#submit_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/submit="([^"]*?)"/g, 'submit="' + selected.replace('"', "'") + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        text_input.prop('value', selected);
        text_input.text(selected);
    }
}
function submitcolorChanged()
{
    var selected = jQuery('#submit_color').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
    var text_input = jQuery('#aiimagechatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function submitcolorChanged_b()
{
    var selected = jQuery('#submit_color_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/submit_color="([^"]*?)"/g, 'submit_color="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
    var text_input = jQuery('#aiimagechatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('background-color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function submittextcolorChanged()
{
    var selected = jQuery('#submit_text_color').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
    var text_input = jQuery('#aiimagechatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function submittextcolorChanged_b()
{
    var selected = jQuery('#submit_text_color_b').val();
    var text_input = jQuery('#aichatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var customized_chatbot = jQuery('#customized_chatbot').text();
        if(customized_chatbot !== undefined)
        {
            customized_chatbot = customized_chatbot.replace(/submit_text_color="([^"]*?)"/g, 'submit_text_color="' + selected + '"');
            jQuery('#customized_chatbot').text(customized_chatbot);
        }
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
    var text_input = jQuery('#aiimagechatsubmitbut');
    if(selected != undefined && text_input !== null)
    {
        var origCSS = text_input.attr("style");
        if(origCSS === undefined)
        {
            origCSS = "";
        }
        var updatedCSS = updateCSSAttribute('color', selected + '!important;', origCSS);
        text_input.attr('style', updatedCSS);
    }
}
function aiomaticLoading2(btn){
    btn.attr('disabled','disabled');
    if(!btn.find('spinner').length){
        btn.append('<span class="spinner"></span>');
    }
    btn.find('.spinner').css('visibility','unset');
}
function aiomatic_sync_voices_elevenlabs()
{
    var data = {
        action: 'aiomatic_get_elevenlabs_voices',
        nonce: aiomatic_object.nonce
    };
    var elevenlabs_sync = jQuery('#elevenlabs_sync');
    jQuery.ajax({
        url: aiomatic_object.ajax_url,
        data: data,
        dataType: 'JSON',
        type: 'POST',
        beforeSend: function (){
            aiomaticLoading2(elevenlabs_sync);
        },
        success: function (res){
            if(res.status === 'success'){
                alert('ElevenLabs Voices synced successfully.');
                window.location.reload();
            }
            else{
                alert(res.msg);
                aiomaticRmLoading(elevenlabs_sync);
            }
        },
        error: function (r, s, error){
            alert('Error in ElevenLabs sync: ' + error);
            aiomaticRmLoading(elevenlabs_sync);
        }
    });
}
function aiomatic_sync_voices_google()
{
    var data = {
        action: 'aiomatic_get_google_voices',
        nonce: aiomatic_object.nonce
    };
    var google_sync = jQuery('#google_sync');
    jQuery.ajax({
        url: aiomatic_object.ajax_url,
        data: data,
        dataType: 'JSON',
        type: 'POST',
        beforeSend: function (){
            aiomaticLoading2(google_sync);
        },
        success: function (res){
            if(res.status === 'success'){
                alert('Google Text-to-Speech Voices synced successfully.');
                window.location.reload();
            }
            else{
                alert(res.msg);
                aiomaticRmLoading(google_sync);
            }
        },
        error: function (r, s, error){
            alert('Error in Google Text-to-Speech sync: ' + error);
            aiomaticRmLoading(google_sync);
        }
    });
}
function aiomatic_text_changed()
{
    var selected = jQuery('#chatbot_text_speech').val();
    if(selected == 'google')
    {
        jQuery(".hideeleven").hide();
        jQuery(".hidegoogle").show();
    }
    if(selected == 'elevenlabs')
    {
        jQuery(".hideeleven").show();
        jQuery(".hidegoogle").hide();
    }
    if(selected == 'off')
    {
        jQuery(".hideeleven").hide();
        jQuery(".hidegoogle").hide();
    }
}
jQuery(document).ready(function(){
    aiomatic_text_changed();
});