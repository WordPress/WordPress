"use strict";
jQuery(document).ready(function ($)
{
    $("#checkedAll").change(function() {
        if (this.checked) {
            $(".aiomatic-select-embedding").each(function() {
                this.checked=true;
            });
        } else {
            $(".aiomatic-select-embedding").each(function() {
                this.checked=false;
            });
        }
    });
    function aiomaticLoading(btn)
    {
        btn.attr('disabled','disabled');
        if(!btn.find('spinner').length){
            btn.append('<span class="spinner"></span>');
        }
        btn.find('.spinner').css('visibility','unset');
    }
    function aiomaticDisable(btn)
    {
        btn.prop('disabled', true);
    }
    function aiomaticEnable(btn)
    {
        btn.removeAttr('disabled');
    }
    function aiomaticRmLoading(btn)
    {
        btn.removeAttr('disabled');
        btn.find('.spinner').remove();
    }
    $('#aiomatic_sync_embeddings').click(function (){
        var btn = $(this);
        aiomaticLoading(btn);
        location.reload();
    });
    $('#aiomatic_save_embeddings').click(function (){
        if(confirm('Are you sure you want to download ALL embeddings in a CSV file?'))
        {
            var btn = $(this);
            aiomaticLoading(btn);
            var data = {
                action: 'aiomatic_download_embeddings',
                nonce: aiomatic_object.nonce,
            };
            $.ajax({
                url: aiomatic_object.ajax_url,
                data: data,
                dataType: 'JSON',
                type: 'POST',
                success: function (res){
                    aiomaticRmLoading(btn);
                    if(res.status === 'success'){
                        try
                        {
                            let csvContent = "data:text/csv;charset=utf-8," 
                                + res.rows.map(e => e.join(",")).join("\n");
                            var encodedUri = encodeURI(csvContent);
                            var link = document.createElement("a");
                            link.setAttribute("href", encodedUri);
                            link.setAttribute("download", "embeddings.csv");
                            document.body.appendChild(link);
                            link.click();
                        }
                        catch(e)
                        {
                            alert(e);
                        }
                    }
                    else{
                        alert(res.msg);
                    }
                },
                error: function (r, s, error){
                    aiomaticRmLoading(btn);
                    alert('Error in processing embedding saving: ' + error);
                }
            });
        }
    });
    $('#aiomatic_upload_embeddings').click(function (){
        if(confirm('Are you sure you want to add embeddings from the CSV file?'))
        {
            var aiomatic_csv_upload = $('#aiomatic_csv_upload');
            var btn = $(this);
            aiomaticLoading(btn);
            var data = {
                action: 'aiomatic_upload_embeddings',
                nonce: aiomatic_object.nonce,
            };
            if(aiomatic_csv_upload[0].files.length === 0){
                alert('Please select a file!');
            }
            else{
                var aiomatic_max_file_size = aiomatic_object.maxfilesize;
                var aiomatic_file = aiomatic_csv_upload[0].files[0];
                var aiomatic_file_extension = aiomatic_file.name.substr( (aiomatic_file.name.lastIndexOf('.') +1) );
                if(aiomatic_file_extension !== 'csv'){
                    aiomatic_csv_upload.val('');
                    alert('This feature only accepts csv file type!');
                }
                else if(aiomatic_file.size > aiomatic_max_file_size){
                    aiomatic_csv_upload.val('');
                    alert('Dataset allowed maximum size (MB): '+ aiomatic_max_size_in_mb)
                }
                else{
                    var reader = new FileReader();
                    reader.readAsText(aiomatic_file, "UTF-8");
                    reader.onload = function (evt) {
                        var formData = new FormData();
                        formData.append('action', 'aiomatic_embeddings_upload');
                        formData.append('xfile', evt.target.result);
                        formData.append('nonce', aiomatic_object.nonce);
                        $.ajax({
                            url: aiomatic_object.ajax_url,
                            type: 'POST',
                            dataType: 'JSON',
                            data: formData,
                            success: function(res) {
                                if(res.status === 'success'){
                                    aiomaticRmLoading(btn);
                                    alert('File uploaded successfully!');
                                }
                                else{
                                    aiomaticRmLoading(btn);
                                    alert('An error occured: ' + JSON.stringify(res));
                                }
                            },
                            cache: false,
                            contentType: false,
                            processData: false,
                            error: function (r, s, error){
                                aiomaticRmLoading(btn);
                                    alert('Unable to upload file: ' + error);
                            }
                        });
                    }
                    reader.onerror = function (evt) {
                        alert("Error reading file: " + aiomatic_file.name + ' - ' + reader.error);
                    }
                }
            }
        }
    });
    $('#aiomatic_deleteall_embeddings').click(function (){
        if(confirm('Are you sure you want to delete ALL embeddings?'))
        {
            var btn = $(this);
            aiomaticLoading(btn);
            var data = {
                action: 'aiomatic_deleteall_embedding',
                nonce: aiomatic_object.nonce,
            };
            $.ajax({
                url: aiomatic_object.ajax_url,
                data: data,
                dataType: 'JSON',
                type: 'POST',
                success: function (res){
                    aiomaticRmLoading(btn);
                    if(res.status === 'success'){
                        $('.aiomatic-embeddings-success').show();
                        $('.aiomatic-embeddings-content').val('');
                        setTimeout(function (){
                            $('.aiomatic-embeddings-success').hide();
                        },2000);
                        location.reload();
                    }
                    else{
                        alert(res.msg);
                    }
                },
                error: function (r, s, error){
                    aiomaticRmLoading(btn);
                    alert('Error in processing embedding removal: ' + error);
                }
            });
        }
    });
    $('#aiomatic_delete_selected_embeddings').click(function (){
        if(confirm('Are you sure you want to delete selected embeddings?'))
        {
            var btn = $(this);
            aiomaticLoading(btn);
            var ids = [];
            $('.aiomatic-select-embedding:checked').each(function (idx, item) {
                ids.push($(item).val())
            });
            if (ids.length) {
                var data = {
                    action: 'aiomatic_delete_selected_embedding',
                    nonce: aiomatic_object.nonce,
                    ids: ids
                };
                $.ajax({
                    url: aiomatic_object.ajax_url,
                    data: data,
                    dataType: 'JSON',
                    type: 'POST',
                    success: function (res){
                        aiomaticRmLoading(btn);
                        if(res.status === 'success'){
                            $('.aiomatic-embeddings-success').show();
                            $('.aiomatic-embeddings-content').val('');
                            setTimeout(function (){
                                $('.aiomatic-embeddings-success').hide();
                            },2000);
                            location.reload();
                        }
                        else{
                            alert(res.msg);
                        }
                    },
                    error: function (r, s, error){
                        aiomaticRmLoading(btn);
                        alert('Error in processing embedding removal: ' + error);
                    }
                });
            } else {
                alert('No embeddings selected');
                aiomaticRmLoading(btn);
            }
        }
    });
    $('#aiomatic_embeddings_form').on('submit', function (e)
    {
        var form = $('#aiomatic_embeddings_form');
        var btn = form.find('button');
        var content = $('.aiomatic-embeddings-content').val();
        if(content === ''){
            alert('Please insert an embedding value!');
        }
        else{
            var data = form.serialize();
            $.ajax({
                url: aiomatic_object.ajax_url,
                data: data,
                dataType: 'JSON',
                type: 'POST',
                beforeSend: function (){
                    aiomaticLoading(btn);
                },
                success: function (res){
                    aiomaticRmLoading(btn);
                    if(res.status === 'success'){
                        $('.aiomatic-embeddings-success').show();
                        $('.aiomatic-embeddings-content').val('');
                        setTimeout(function (){
                            $('.aiomatic-embeddings-success').hide();
                        },2000)
                    }
                    else{
                        alert(res.msg);
                    }
                },
                error: function (r, s, error){
                    aiomaticRmLoading(btn);
                    alert('Error in processing embedding saving: ' + error);
                }
            });
        }
        return false;
    });
    $(".aiomatic_delete_embedding").click(function(e) {
        if(confirm('Are you sure you want to delete this embedding?'))
        {
            var embeddingid = $(this).attr("delete-id");
            if(embeddingid == '')
            {
                alert('Incorrect delete id submitted');
            }
            else
            {
                e.preventDefault();
                var data = {
                    action: 'aiomatic_delete_embedding',
                    embeddingid: embeddingid,
                    nonce: aiomatic_object.nonce,
                };
                jQuery.ajax({
                    url: aiomatic_object.ajax_url,
                    data: data,
                    dataType: 'JSON',
                    type: 'POST',
                    beforeSend: function (){
                        aiomaticDisable($('#aiomatic_delete_embedding_' + embeddingid));
                    },
                    success: function (res){
                        if(res.status === 'success'){
                            location.reload();
                        }
                        else{
                            alert(res.msg);
                            location.reload();
                        }
                    },
                    error: function (r, s, error){
                        alert('Error in processing embedding saving: ' + error);
                        location.reload();
                    }
                });
            }
        }
    });
});