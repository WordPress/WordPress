"use strict";
function actionsChangedManual(selectedValue)
{
    if (selectedValue==='run')
    {
        if(unsaved){
            alert("You have unsaved changes on this page. Please save your changes before manually running rules!");
            return;
        }
        runNowManual();
    }
}
var unsaved = false;
jQuery(document).ready(function () {
    aiomatic_edit_changed();
    jQuery(":input").change(function(){
        var classes = this.className;
        var classes = this.className.split(' ');
        var found = jQuery.inArray('actions', classes) > -1;
        if (this.id != 'select-shortcode' && this.id != 'PreventChromeAutocomplete' && this.id != 'actions' && !found)
        {
            unsaved = true;
        }
    });
    jQuery("#process_event").change(function(){
        var pe = jQuery( "#process_event" ).val();
        if(pe == 'publish')
        {
            jQuery( ".hidethis" ).show();
        }
        else
        {
            jQuery( ".hidethis" ).hide();
        }
    });
    function unloadPage(){ 
        if(unsaved){
            return "You have unsaved changes on this page. Do you want to leave this page and discard your changes or stay on this page?";
        }
    }
    window.onbeforeunload = unloadPage;
    var pe = jQuery( "#process_event" ).val();
    if(pe == 'publish')
    {
        jQuery( ".hidethis" ).show();
    }
    else
    {
        jQuery( ".hidethis" ).hide();
    }
});
function aiomatic_edit_changed()
{
    var auto_edit = jQuery( "#auto_edit" ).val();
    if(auto_edit == 'wp')
    {
        jQuery( ".hideexternal" ).hide();
        jQuery( ".hidewp" ).show();
    }
    else
    {
        if(auto_edit == 'external')
        {
            jQuery( ".hideexternal" ).show();
            jQuery( ".hidewp" ).hide();
        }
        else
        {
            jQuery( ".hideexternal" ).hide();
            jQuery( ".hidewp" ).hide();
        }
    }
}
function runNowManual()
{
    if (confirm("Are you sure you want to run bulk AI post editing?") == true) 
    {
        document.getElementById("run_img").style.visibility = "visible";
        document.getElementById("run_img").src= mycustomsettings.plugin_dir_url + "images/running.gif";
        var data = {
            action: 'aiomatic_run_my_bulk_action',
            nonce: mycustomsettings.nonce
        };
        jQuery.post(mycustomsettings.ajaxurl, data, function(response) 
        {
            if(response.trim() == 'ok')
            {
                document.getElementById("run_img").src= mycustomsettings.plugin_dir_url + "images/ok.gif";
            }
            else
            {
                if(response.trim() == 'nochange')
                {
                    document.getElementById("run_img").src= mycustomsettings.plugin_dir_url + "images/nochange.gif";
                }
                else
                {
                    document.getElementById("run_img").src= mycustomsettings.plugin_dir_url + "images/failed.gif";
                }
            }
        }).fail( function(xhr) 
        {
            console.log('Error occured in processing: ' + xhr.statusText + ' - please check plugin\'s \'Activity and Logging\' menu for details. Ajax URL: ' + mycustomsettings.ajaxurl);
            document.getElementById("run_img").src= mycustomsettings.plugin_dir_url + "images/failed.gif";
        });
    } else {
        return;
    }
}