"use strict";
function aiomatic_save_template()
{
    let template_name = prompt("Enter a name for the new template: ", "Template 1");
    if (template_name != null && template_name != "") 
    {
        if(template_name == 'Default Template')
        {
            alert('This name is reserved, it cannot be used');
            return;
        }
        var template_options = {};
        template_options['title'] = jQuery("#title").val();
        template_options['topics'] = jQuery("#aiomatic_topics").val();
        template_options['submit_status'] = jQuery( "#submit_status option:selected" ).text();
        template_options['submit_type'] = jQuery( "#submit_type option:selected" ).text();
        template_options['post_sticky'] = jQuery( "#post_sticky option:selected" ).text();
        template_options['post_author'] = jQuery( "#post_author option:selected" ).text();
        template_options['post_date'] = jQuery("#post_date").val();
        template_options['post_category'] = jQuery('#post_category option:selected').toArray().map(item => item.value);
        template_options['post_tags'] = jQuery("#post_tags").val();
        template_options['language'] = jQuery("#language").val();
        template_options['writing_style'] = jQuery("#writing_style").val();
        template_options['writing_tone'] = jQuery("#writing_tone").val();
        template_options['sections_count'] = jQuery( "#section_count option:selected" ).text();
        template_options['paragraph_count'] = jQuery( "#paragraph_count option:selected" ).text();
        template_options['model'] = jQuery( "#model option:selected" ).text();
        template_options['max_tokens'] = jQuery("#max_tokens").val();
        template_options['temperature'] = jQuery("#temperature").val();
        template_options['prompt_title'] = jQuery("#prompt_title").val();
        template_options['prompt_sections'] = jQuery("#prompt_sections").val();
        template_options['prompt_content'] = jQuery("#prompt_content").val();
        template_options['prompt_excerpt'] = jQuery("#prompt_excerpt").val();
        jQuery.ajax({
            type: 'POST',
            url: aiomatic_ajax_object.ajax_url,
            data: {
                action: 'aiomatic_save_template',
                template_name: template_name,
                template_options: template_options,
                nonce: aiomatic_ajax_object.nonce
            },
            success: function(response) {
                if (response.success) {
                    jQuery('#template_manager').append(jQuery('<option>', {
                        value: template_name,
                        text: template_name
                    }));
                    alert("Template saved successfully!");
                } else {
                    alert('Error: ' + response.data.message);
                }
            },
            error: function(error) {
                alert("An error occurred while saving template: " + error);
            }
        });
    }
}
function aiomatic_delete_template()
{
    if (confirm("Are you sure you want to delete this template?")) 
    {
        var template_name = jQuery( "#template_manager option:selected" ).text();
        if (template_name != null && template_name != "") 
        {
            if(template_name == 'Default Template')
            {
                alert('This is the default template, it cannot be deleted');
                return;
            }
            jQuery.ajax({
                type: 'POST',
                url: aiomatic_ajax_object.ajax_url,
                data: {
                    action: 'aiomatic_delete_template',
                    template_name: template_name,
                    nonce: aiomatic_ajax_object.nonce
                },
                success: function(response) {
                    if (response.success) {
                        jQuery("#template_manager option[value='" + template_name.replace("'", "\'") + "']").remove();
                        alert("Template deleted successfully!");
                    } else {
                        alert('Error: ' + response.data.message);
                    }
                },
                error: function(error) {
                    alert("An error occurred while saving template: " + error);
                }
            });
        }
        else
        {
            alert('No template selected');
        }
    }
}
function aiomatic_load_template()
{
    if (confirm("Are you sure you want to load this template?")) 
    {
        var template_name = jQuery( "#template_manager option:selected" ).text();
        if (template_name != null && template_name != "") 
        {
            jQuery.ajax({
                type: 'POST',
                url: aiomatic_ajax_object.ajax_url,
                data: {
                    action: 'aiomatic_load_template',
                    template_name: template_name,
                    nonce: aiomatic_ajax_object.nonce
                },
                success: function(response) {
                    if (response.success) {
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#title").val(response.data.content['title']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#aiomatic_topics").val(response.data.content['topics']);
                        }
                        if(response.data.content['submit_status'] !== undefined)
                        {
                            jQuery("#submit_status option").each(function() 
                            {
                                if(jQuery(this).text() == response.data.content['submit_status']) {
                                    jQuery(this).prop('selected', true);            
                                }                        
                            });
                        }
                        if(response.data.content['submit_type'] !== undefined)
                        {
                            jQuery("#submit_type option").each(function() 
                            {
                                if(jQuery(this).text() == response.data.content['submit_type']) {
                                    jQuery(this).prop('selected', true);            
                                }                        
                            });
                        }
                        if(response.data.content['post_sticky'] !== undefined)
                        {
                            jQuery("#post_sticky option").each(function() 
                            {
                                if(jQuery(this).text() == response.data.content['post_sticky']) {
                                    jQuery(this).prop('selected', true);            
                                }                        
                            });
                        }
                        if(response.data.content['post_author'] !== undefined)
                        {
                            jQuery("#post_author option").each(function() 
                            {
                                if(jQuery(this).text() == response.data.content['post_author']) {
                                    jQuery(this).prop('selected', true);            
                                }                        
                            });
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#post_date").val(response.data.content['post_date']);
                        }
                        if(response.data.content['post_author'] !== undefined)
                        {
                            jQuery("#post_category option").each(function() 
                            {
                                if(response.data.content['post_category'].includes(jQuery(this).val()))
                                {
                                    jQuery(this).prop('selected', true);     
                                }
                                else
                                {
                                    jQuery(this).prop('selected', false);  
                                }            
                            });
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#post_tags").val(response.data.content['post_tags']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#language").val(response.data.content['language']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#writing_style").val(response.data.content['writing_style']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#writing_tone").val(response.data.content['writing_tone']);
                        }
                        if(response.data.content['post_author'] !== undefined)
                        {
                            jQuery("#sections_count option").each(function() 
                            {
                                if(jQuery(this).text() == response.data.content['sections_count']) {
                                    jQuery(this).prop('selected', true);            
                                }                        
                            });
                        }
                        if(response.data.content['post_author'] !== undefined)
                        {
                            jQuery("#paragraph_count option").each(function() 
                            {
                                if(jQuery(this).text() == response.data.content['paragraph_count']) {
                                    jQuery(this).prop('selected', true);            
                                }                        
                            });
                        }
                        if(response.data.content['post_author'] !== undefined)
                        {
                            jQuery("#model option").each(function() 
                            {
                                if(jQuery(this).text() == response.data.content['model']) {
                                    jQuery(this).prop('selected', true);            
                                }                        
                            });
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#max_tokens").val(response.data.content['max_tokens']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#temperature").val(response.data.content['temperature']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#prompt_title").val(response.data.content['prompt_title']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#prompt_sections").val(response.data.content['prompt_sections']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#prompt_content").val(response.data.content['prompt_content']);
                        }
                        if(response.data.content['title'] !== undefined)
                        {
                            jQuery("#prompt_excerpt").val(response.data.content['prompt_excerpt']);
                        }
                        alert("Template loaded successfully!");
                    } else {
                        alert('Error: ' + response.data.message);
                    }
                },
                error: function(error) {
                    alert("An error occurred while loading template: " + error);
                }
            });
        }
        else
        {
            alert('No template selected');
        }
    }
}
function aiomatic_call_func()
{
    const model_holder = document.getElementById("model_holder");
    if(model_holder !== null)
    {
        const btn = document.getElementById("aiomatic_toggle_model");
        if(btn !== null)
        {
            if (btn.value === "Show") {
                model_holder.style.display = "block";
                btn.value = "Hide";
            } else {
                model_holder.style.display = "none";
                btn.value = "Show";
            }
        }
        else
        {
            console.log('aiomatic_toggle_model not found');
        }
    }
    else
    {
        console.log('model_holder not found');
    }
}
function aiomatic_prompt_func()
{
    const prompt_holder = document.getElementById("prompt_holder");
    if(model_holder !== null)
    {
        const btn = document.getElementById("aiomatic_toggle_prompt");
        if(btn !== null)
        {
            if (btn.value === "Show") {
                prompt_holder.style.display = "block";
                btn.value = "Hide";
            } else {
                prompt_holder.style.display = "none";
                btn.value = "Show";
            }
        }
        else
        {
            console.log('aiomatic_toggle_prompt not found');
        }
    }
    else
    {
        console.log('prompt_holder not found');
    }
}
function aiomatic_all_empty() {
    var aiomatic_topics = document.getElementById("aiomatic_topics");
    var generate_all = document.getElementById("generate_all");
    var generate_title = document.getElementById("generate_title");
    if(generate_title !== null && generate_all !== null && aiomatic_topics !== null)
    {
        if(aiomatic_topics.value === "") { 
            generate_all.disabled = true; 
            generate_title.disabled = true; 
        } else { 
            generate_all.disabled = false;
            generate_title.disabled = false;
        }
    }
    else
    {
        console.log('generate_all/aiomatic_topics/generate_title not found');
    }
}
function aiomatic_title_empty() {
    var title = document.getElementById("title");
    var generate_sections = document.getElementById("generate_sections");
    var generate_paragraphs = document.getElementById("generate_paragraphs");
    var generate_excerpt = document.getElementById("generate_excerpt");
    var post_publish = document.getElementById("post_publish");
    if(title !== null && generate_sections !== null && generate_paragraphs !== null && generate_excerpt !== null && post_publish !== null && post_content !== null)
    {
        if(title.value === "") { 
            generate_sections.disabled = true; 
            generate_paragraphs.disabled = true; 
            generate_excerpt.disabled = true; 
            post_publish.disabled = true; 
        } else { 
            generate_sections.disabled = false;
            generate_paragraphs.disabled = false;
            generate_excerpt.disabled = false;
            if(window.parent.tinymce.get('post_content').getContent() === "") { 
                post_publish.disabled = true;
            }
            else
            {
                post_publish.disabled = false;
            }
        }
    }
    else
    {
        console.log('title/generate_sections/generate_paragraphs/generate_excerpt/post_publish/post_content not found');
    }
}
function aiomatic_content_empty() {
    var title = document.getElementById("title");
    var post_publish = document.getElementById("post_publish");
    if(title !== null && post_publish !== null && post_content !== null)
    {
        if(title.value === "") { 
            post_publish.disabled = true; 
        } else { 
            if(window.parent.tinymce.get('post_content').getContent() === "") { 
                post_publish.disabled = true;
            }
            else
            {
                post_publish.disabled = false;
            }
        }
    }
    else
    {
        console.log('title/post_publish/post_content not found');
    }
}
function aiomatic_displayTimer(element){
    var start = 1;
    var minutes = 0;
    var extraSeconds = 0;
    var setTimer = setInterval(function () {
        start++;
        minutes = Math.floor(start / 60);
        extraSeconds = start % 60;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        extraSeconds = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
        element.val(minutes + ':' + extraSeconds);
    }, 1000);
    return setTimer;
}

function aiomatic_generate_ai_text($, isthis, promptid, thisid, thisres, istiny, noenable, ajaxchain)
{
    var origvar = $(isthis).attr('value');
    var myInterval = aiomatic_displayTimer($(isthis));
    $("#generate_sections").prop( "disabled", true );
    $("#generate_all").prop( "disabled", true );
    $("#generate_title").prop( "disabled", true );
    $("#generate_paragraphs").prop( "disabled", true );
    $("#generate_excerpt").prop( "disabled", true );
    $("#post_publish").prop( "disabled", true );

    var prompt_prompt = $("#" + promptid).val();
    var title = $("#title").val();
    var sections_count = $( "#section_count option:selected" ).text();
    var paragraph_count = $( "#paragraph_count option:selected" ).text();
    var model = $( "#model option:selected" ).text();
    var max_tokens = $("#max_tokens").val();
    var language = $("#language").val();
    var topics = $("#aiomatic_topics").val();
    var sections = $("#post_sections").val();
    var writing_style = $("#writing_style").val();
    var writing_tone = $("#writing_tone").val();
    var temperature = $("#temperature").val();
    $.ajax({
        type: 'POST',
        url: aiomatic_ajax_object.ajax_url,
        data: {
            action: 'aiomatic_write_text',
            prompt: prompt_prompt,
            title: title,
            model: model,
            max_tokens: max_tokens,
            language: language,
            temperature: temperature,
            writing_style: writing_style,
            writing_tone: writing_tone,
            sections_count: sections_count,
            paragraph_count: paragraph_count,
            topics: topics,
            sections: sections,
            nonce: aiomatic_ajax_object.nonce
        },
        success: function(response) {
            if (response.success) {
                if(istiny === true)
                {
                    window.parent.tinymce.get(thisres).setContent(response.data.content);
                }
                else
                {
                    $("#" + thisres).val(response.data.content);
                }
                if(ajaxchain == true)
                {
                    if(promptid == 'prompt_title')
                    {
                        aiomatic_generate_ai_text($, $('#generate_sections'), 'prompt_sections', 'generate_sections', 'post_sections', false, true, true);
                    }
                    else if(promptid == 'prompt_sections')
                    {
                        aiomatic_generate_ai_text($, $('#generate_paragraphs'), 'prompt_content', 'generate_paragraphs', 'post_content', true, true, true);
                    }
                    else if(promptid == 'prompt_content')
                    {
                        aiomatic_generate_ai_text($, $('#generate_excerpt'), 'prompt_excerpt', 'generate_excerpt', 'post_excerpt', false, false, false);
                    }
                }
            } else {
                alert('Error: ' + JSON.stringify(response));
            }
            clearInterval(myInterval);
            $("#" + thisid).attr('value', origvar);
            if(noenable !== true)
            {
                $("#generate_sections").prop( "disabled", false );
                $("#generate_all").prop( "disabled", false );
                $("#generate_title").prop( "disabled", false );
                $("#generate_paragraphs").prop( "disabled", false );
                $("#generate_excerpt").prop( "disabled", false );
                aiomatic_title_empty();
            }
        },
        error: function(error) {
            $("#" + thisid).attr('value', origvar);
            $("#generate_sections").prop( "disabled", false );
            $("#generate_all").prop( "disabled", false );
            $("#generate_title").prop( "disabled", false );
            $("#generate_paragraphs").prop( "disabled", false );
            $("#generate_excerpt").prop( "disabled", false );
            aiomatic_title_empty();
        }
    });
}
jQuery(document).ready(function($) { 
    $('#aiomatic-dismiss-button').on('click', function(e) {
        e.preventDefault();
        $.ajax({
            url: aiomatic_ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'aiomatic_dismiss_admin_notice',
                nonce: aiomatic_ajax_object.nonce
            },
            success: function(response) {
                $('#tutorialbox').hide();
            },
            error: function(error) 
            {
                alert('Error in ajax: ' + error.responseText);
            }
        });
    });
    if(window.tinyMCE !== undefined)
    {
        if(!window.tinyMCE.activeEditor)
        {
            window.tinyMCE.execCommand('mceToggleEditor', false, 'post_content');
        }
    }
    (function ($) {
        $('#aiomatic-dialog').dialog({
          title: 'Post Pulished Successfully',
          dialogClass: 'wp-dialog',
          autoOpen: false,
          draggable: false,
          width: 'auto',
          modal: true,
          resizable: false,
          closeOnEscape: true,
          position: {
            my: "center",
            at: "center",
            of: window
          },
          open: function () {
            $(document).on("click",".ui-widget-overlay", function(){
              $('#aiomatic-dialog').dialog('close');
            });
            $(document).on("click","#aiomatic-close-button", function(){
                $('#aiomatic-dialog').dialog('close');
            });
          },
          create: function () {
            $('.ui-dialog-titlebar-close').addClass('ui-button');
          },
        });
      })(jQuery);

      
    $(document.body).on("click","#aiomatic-success-button", function (e) {
        if (this.getAttribute("adminurl") !== null) {
            if (this.getAttribute("postid") !== null && this.getAttribute("postid") !== '') {
                window.location.href = this.getAttribute("adminurl") + this.getAttribute("postid") + '&action=edit';
            }
            else
            {
                console.log('Incorrect post ID provided!');
            }
        }
        else
        {
            console.log('Incorrect admin URL provided!');
        }
    });
    $('#generate_title').click(function()
    {
        aiomatic_generate_ai_text($, this, 'prompt_title', 'generate_title', 'title', false, false, false);
    });
    $('#generate_sections').click(function()
    {
        aiomatic_generate_ai_text($, this, 'prompt_sections', 'generate_sections', 'post_sections', false, false, false);
    });
    $('#generate_paragraphs').click(function()
    {
        aiomatic_generate_ai_text($, this, 'prompt_content', 'generate_paragraphs', 'post_content', true, false, false);
    });
    $('#generate_excerpt').click(function()
    {
        aiomatic_generate_ai_text($, this, 'prompt_excerpt', 'generate_excerpt', 'post_excerpt', false, false, false);
    });
    $('#generate_all').click(function()
    {
        $(this).attr('value', 'Working...');
        aiomatic_generate_ai_text($, $('#generate_title'), 'prompt_title', 'generate_title', 'title', false, true, true);
        $(this).attr('value', 'Generate All');
    });
    if(window.tinyMCE !== undefined)
    {
        var ed = window.tinyMCE.activeEditor;
        if(ed !== null)
        {
            ed.onKeyUp.add(function()
            {
                aiomatic_content_empty();
            });
        }
    }
    $('#aiomatic-single-post').submit(function(event) {
      event.preventDefault();
      var post_publish = document.getElementById("post_publish");
      var title = document.getElementById("title");
      var generate_sections = document.getElementById("generate_sections");
      var generate_paragraphs = document.getElementById("generate_paragraphs");
      var generate_excerpt = document.getElementById("generate_excerpt");
      var form = $(this);
      var title = form.find('#title').val();
      var content = window.parent.tinymce.get('post_content').getContent();
      var excerpt = form.find('#post_excerpt').val();
      var submit_status = form.find('#submit_status').val();
      var submit_type = form.find('#submit_type').val();
      var post_sticky = form.find('#post_sticky').val();
      var post_date = form.find('#post_date').val();
      var post_author = form.find('#post_author').val();
      var aiomatic_image_id = form.find('#aiomatic_image_id').val();
      var post_category = document.getElementById('post_category').selectedOptions;
      post_category = Array.from(post_category).map(({ value }) => value);
      post_category = JSON.stringify(post_category);
      var post_tags = form.find('#post_tags').val();
      var nonce = form.find('#create_post_nonce').val();
      $("#title").val("");
      window.parent.tinymce.get('post_content').setContent("");
      $("#post_excerpt").val("");
      $("#post_sections").val("");
      if(post_publish !== null && generate_sections !== null && generate_excerpt !== null && generate_paragraphs !== null)
      {
        post_publish.disabled = true; 
        generate_sections.disabled = true;
        generate_excerpt.disabled = true;
        generate_paragraphs.disabled = true; 
      }
      $.ajax({
        type: 'POST',
        url: aiomatic_ajax_object.ajax_url,
        data: {
          action: 'create_post',
          title: title,
          content: content,
          excerpt: excerpt,
          submit_status: submit_status,
          submit_type: submit_type,
          post_sticky: post_sticky,
          post_author: post_author,
          post_date: post_date,
          post_category: post_category,
          post_tags: post_tags,
          aiomatic_image_id: aiomatic_image_id,
          nonce: nonce
        },
        success: function(response) {
          if (response.success) {
            document.getElementById("aiomatic-success-button").setAttribute("postid", response.data.post_id);
            $('#aiomatic-dialog').dialog('open');
          } else {
            alert('Error: ' + response.data.message);
          }
        },
        error: function(error) 
        {
            alert('Error in post publishing: ' + error.responseText);
        }
      });
    });
    aiomatic_all_empty();
    aiomatic_title_empty();
  });