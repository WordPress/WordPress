"use strict";
var initial = '';
function mainChanged()
{
    if(jQuery("#ai_rewriter").val() == 'enabled')
    {            
        jQuery(".hideMain").show();
    }
    else
    {
        jQuery(".hideMain").hide();
    }
}
function mainChanged2()
{
    if(jQuery("#ai_featured_image").val() == 'enabled')
    {            
        jQuery(".hideMain2").show();
    }
    else
    {
        jQuery(".hideMain2").hide();
    }
}
function mainChanged3()
{
    if(jQuery("#append_spintax").val() == 'append' || jQuery("#append_spintax").val() == 'preppend')
    {            
        jQuery(".hideMain3").show();
    }
    else
    {
        jQuery(".hideMain3").hide();
    }
}
function mainChanged4()
{
    if(jQuery("#add_links").val() == 'enabled')
    {            
        jQuery(".hideMain4").show();
    }
    else
    {
        jQuery(".hideMain4").hide();
    }
}
function mainChanged5()
{
    if(jQuery("#add_comments").val() == 'enabled')
    {            
        jQuery(".hideMain5").show();
    }
    else
    {
        jQuery(".hideMain5").hide();
    }
}
function mainChanged6()
{
    if(jQuery("#add_seo").val() == 'enabled')
    {            
        jQuery(".hideMain6").show();
    }
    else
    {
        jQuery(".hideMain6").hide();
    }
}
function loadMe()
{
    mainChanged();
    toggleCats();
    mainChanged2();
    mainChanged3();
    mainChanged4();
    mainChanged5();
    mainChanged6();
}
window.onload = loadMe;
var unsaved = false;
jQuery(document).ready(function () {
    jQuery(":input").change(function(){
        var classes = this.className;
        var classes = this.className.split(' ');
        var found = jQuery.inArray('actions', classes) > -1;
        if (this.id != 'select-shortcode' && this.id != 'PreventChromeAutocomplete' && this.id != 'actions' && !found)
        {
            unsaved = true;
        }
    });
    function unloadPage(){ 
        if(unsaved){
            return "You have unsaved changes on this page. Do you want to leave this page and discard your changes or stay on this page?";
        }
    }
    window.onbeforeunload = unloadPage;
});
function toggleCats()
{
    if(jQuery('#hideCats').is(":visible"))
    {            
        jQuery(".hideCats").hide();
    }
    else
    {
        jQuery(".hideCats").show();
    }
}