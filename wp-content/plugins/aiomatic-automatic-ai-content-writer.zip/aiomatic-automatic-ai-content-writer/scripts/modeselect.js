"use strict";
var modeselect = document.getElementById("posting_mode");
if(modeselect != null)
{
    var pvalue = modeselect.value;
    if(pvalue == 'title')
    {
        document.querySelectorAll('.hidetitle').forEach(function(el) {
            el.style.display = 'table-row';
        });
        document.querySelectorAll('.hidetopic').forEach(function(el) {
            el.style.display = 'none';
        });
    }
    else if(pvalue == 'topic')
    {
        document.querySelectorAll('.hidetitle').forEach(function(el) {
            el.style.display = 'none';
        });
        document.querySelectorAll('.hidetopic').forEach(function(el) {
            el.style.display = 'table-row';
        });
    }
    modeselect.onchange = function(evt) {
        var value = evt.target.value;
        if(value == 'title')
        {
            document.querySelectorAll('.hidetitle').forEach(function(el) {
                el.style.display = 'table-row';
            });
            document.querySelectorAll('.hidetopic').forEach(function(el) {
                el.style.display = 'none';
            });
        }
        else if(value == 'topic')
        {
            document.querySelectorAll('.hidetitle').forEach(function(el) {
                el.style.display = 'none';
            });
            document.querySelectorAll('.hidetopic').forEach(function(el) {
                el.style.display = 'table-row';
            });
        }
    }
}
jQuery('#ai-toggle-video').click(function() {
    jQuery(this).text(function(i, text){
        return text === varsx.showme ? varsx.hideme : varsx.showme;
    })
    jQuery('#ai-video-container').slideToggle();
});
function hideTOC(number)
{
    if(jQuery('#single_content_call' + number).is(":checked"))
    {
        jQuery('.hideTOC' + number).hide();
    }
    else
    {
        jQuery('.hideTOC' + number).show();
    }
}
function createModeSelect(i) {
    
    if(jQuery('#single_content_call' + i).is(":checked"))
    {
        jQuery('.hideTOC' + i).hide();
    }
    else
    {
        jQuery('.hideTOC' + i).show();
    }
    var pvalue = document.getElementById("posting_mode" + i).value;
    if(pvalue == 'title')
    {
        document.querySelectorAll('.hidetitle' + i).forEach(function(el) {
            el.style.display = 'table-row';
        });
        document.querySelectorAll('.hidetopic' + i).forEach(function(el) {
            el.style.display = 'none';
        });
    }
    else if(pvalue == 'topic')
    {
        document.querySelectorAll('.hidetitle' + i).forEach(function(el) {
            el.style.display = 'none';
        });
        document.querySelectorAll('.hidetopic' + i).forEach(function(el) {
            el.style.display = 'table-row';
        });
    }

    var modeselect = document.getElementById("posting_mode" + i);
    if(modeselect != null)
    {
        modeselect.onchange = function(evt) {
            var value = evt.target.value;
            if(value == 'title')
            {
                document.querySelectorAll('.hidetitle' + i).forEach(function(el) {
                    el.style.display = 'table-row';
                });
                document.querySelectorAll('.hidetopic' + i).forEach(function(el) {
                    el.style.display = 'none';
                });
            }
            else if(value == 'topic')
            {
                document.querySelectorAll('.hidetitle' + i).forEach(function(el) {
                    el.style.display = 'none';
                });
                document.querySelectorAll('.hidetopic' + i).forEach(function(el) {
                    el.style.display = 'table-row';
                });
            }
        }
    }
}