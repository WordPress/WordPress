"use strict";
String.prototype.aitrim = function() {
    return this.replace(/^\s+|\s+$/g, "");
};
var input = document.getElementById("aiomatic_image_chat_input");
    input.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) { 
        e.preventDefault(); 
        openaiimagechatfunct();
        return false;
    }
});
async function openaiimagechatfunct() {
    jQuery('#aiimagechatsubmitbut').attr('disabled', true);
    var input_textj = jQuery('#aiomatic_image_chat_input');
    var input_text = '';
    jQuery('#openai-image-chat-response').html('<div class="automaticx-dual-ring"></div>');
    input_text = input_textj.val();
    input_textj.val('');
    if(aiomatic_chat_image_ajax_object.enable_moderation == '1')
    {
        var isflagged = false;
        await jQuery.ajax({
            type: 'POST',
            url: aiomatic_chat_image_ajax_object.ajax_url,
            data: {
                action: 'aiomatic_moderate_text',
                text: input_text,
                nonce: aiomatic_chat_image_ajax_object.moderation_nonce,
                model: aiomatic_chat_image_ajax_object.moderation_model
            },
            success: function(response) {
                if(response.status == 'success')
                {
                    const resp = JSON.parse(response.data);
                    if(resp.results[0].flagged != undefined)
                    {
                        if(resp.results[0].flagged == true)
                        {
                            jQuery('#aichatsubmitbut').attr('disabled', false);
                            jQuery('#openai-image-chat-response').html('<div class="text-primary highlight-text-fail" role="status">' + aiomatic_chat_ajax_object.flagged_message + '</div>');
                            isflagged = true;
                        }
                    }
                    else
                    {
                        console.log('Invalid response from moderation ' + response);
                    }
                }
                else
                {
                    console.log('Moderation returned an error: ' + response.msg);
                }
            },
            error: function(error) {
                console.log('Moderation failed: ' + error.responseText);
            },
        });
        if(isflagged == true)
        {
            return;
        }
    }
    var user_token_cap_per_day = aiomatic_chat_image_ajax_object.user_token_cap_per_day;
    var user_id = aiomatic_chat_image_ajax_object.user_id;
    var persistent = aiomatic_chat_image_ajax_object.persistent;
    if(input_text == '')
    {
        jQuery('#aiimagechatsubmitbut').attr('disabled', false);
        jQuery('#openai-image-chat-response').html('<div class="text-primary highlight-text-fail" role="status">Please add a text in the input field.</div>');
        console.log('Instruction cannot be empty.');
        return;
    }
    var x_input_text = jQuery('#aiomatic_chat_history').html();
    if(input_text.aitrim() != '')
    {
        jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-mine">' + input_text + '</div>');
    }
    
    jQuery.ajax({
        type: 'POST',
        url: aiomatic_chat_image_ajax_object.ajax_url,
        data: {
            action: 'aiomatic_image_chat_submit',
            input_text: input_text,
            user_token_cap_per_day: user_token_cap_per_day,
            nonce: aiomatic_chat_image_ajax_object.nonce,
            user_id: user_id
        },
        success: function(response) {
            if(response.status == 'success')
            {
                if(response.data == '')
                {
                    jQuery('#openai-image-chat-response').html('<div class="text-primary" role="status">No image was generated. Please try using a different text input.</div>');
                }
                else
                {
                    var x_input_text = jQuery('#aiomatic_chat_history').html();
                    if((persistent == 'on' || persistent == '1') && user_id != '0')
                    {
                        jQuery.ajax({
                            type: 'POST',
                            url: aiomatic_chat_image_ajax_object.ajax_url,
                            data: {
                                action: 'aiomatic_user_meta_save',
                                nonce: aiomatic_chat_image_ajax_object.persistentnonce,
                                x_input_text: x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>',
                                user_id: user_id
                            },
                            success: function() {
                            },
                            error: function(error) {
                                console.log('Error while saving persistent user log: ' + error.responseText);
                            },
                        });
                    }
                    jQuery('#aiomatic_chat_history').html(x_input_text + '<div class="ai-bubble ai-other">' + response.data + '</div>');
                    // Clear the response container
                    jQuery('#openai-image-chat-response').html('&nbsp;');
                    // Enable the submit button
                    jQuery('#aiimagechatsubmitbut').attr('disabled', false);
                }
            }
            else
            {
                jQuery('#openai-image-chat-response').html('<div class="text-primary highlight-text-fail" role="status">' + response.msg + '</div>');
            }
            jQuery('#aiimagechatsubmitbut').attr('disabled', false);
        },
        error: function(error) {
            console.log('Error: ' + error.responseText);
            // Clear the response container
            jQuery('#openai-image-chat-response').html('<div class="text-primary highlight-text-fail" role="status">Failed to generate content, try again later.</div>');
            // Enable the submit button
            jQuery('#aiimagechatsubmitbut').attr('disabled', false);
        },
    });
}
var recognition;
var recognizing = false;
jQuery(document).ready(function() {
    
    if(aiomatic_chat_image_ajax_object.scroll_bot == 'on')
    {
        jQuery('#aiomatic_chat_history').on('DOMSubtreeModified', function(){
            var psconsole = jQuery('#aiomatic_chat_history');
            if(psconsole.length)
            {
                psconsole.scrollTop(psconsole[0].scrollHeight - psconsole.height());
            }
        });
    }
    if(jQuery('#aiomatic_image_chat_templates').length)
    {
        jQuery('#aiomatic_image_chat_templates').change(function()
        {
            jQuery('#aiomatic_image_chat_input').val(jQuery( "#aiomatic_image_chat_templates" ).val());
        });
    }
    else
    {
        // Check if the browser supports the Web Speech API
        if ('webkitSpeechRecognition' in window) {
            recognition = new webkitSpeechRecognition();
            recognition.continuous = true;
            recognition.interimResults = true;

            // Start the speech recognition when the button is clicked
            jQuery('#openai-image-chat-speech-button').click(function() {
                if (recognizing) {
                    recognition.stop();
                    recognizing = false;
                } else {
                    recognition.start();
                    recognizing = true;
                }
            });

            // Handle the speech recognition results
            recognition.onresult = function(event) {
                for (var i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        jQuery('#aiomatic_image_chat_input').val(jQuery('#aiomatic_image_chat_input').val() + " " + event.results[i][0].transcript);
                    }
                }
                
            };
        }
    }
});