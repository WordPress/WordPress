<?php
/** 
Plugin Name: Aiomatic - Automatic AI Content Writer
Plugin URI: //1.envato.market/aiomatic
Description: This plugin will generate content for you, even in your sleep using AI
Author: CodeRevolution
Version: 1.4.3
Author URI: //coderevolution.ro
License: Commercial. For personal use only. Not to give away or resell.
Text Domain: aiomatic-automatic-ai-content-writer
*/
/*  
Copyright 2016 - 2023 CodeRevolution
*/
defined('ABSPATH') or die();
use Orhanerday\OpenAi\OpenAi;
require_once (dirname(__FILE__) . "/res/other/plugin-dash.php"); 
require_once (dirname(__FILE__) . "/aiomatic-helpers.php"); 
require_once (dirname(__FILE__) . "/aiomatic-shortcodes-file.php"); 
require_once (dirname(__FILE__) . "/aiomatic-ajax-actions.php"); 
require_once (dirname(__FILE__) . "/aiomatic-spin-translate.php"); 
require_once (dirname(__FILE__) . "/aiomatic-do-post.php"); 
require_once (dirname(__FILE__) . "/aiomatic-rules.php"); 
const AIOMATIC_MODELS = array('text-davinci-003', 'text-davinci-002', 'text-curie-001', 'text-babbage-001', 'text-ada-001');
const AIOMATIC_MODELS_CHAT = array('gpt-3.5-turbo', 'gpt-3.5-turbo-0301', 'gpt-4', 'gpt-4-0314', 'gpt-4-32k', 'gpt-4-32k-0314');
const AIOMATIC_EDIT_MODELS = array('text-davinci-edit-001', 'code-davinci-edit-001');
const AIOMATIC_AZURE_MODELS = array('gpt-3.5-turbo', 'gpt-4', 'gpt-4-32k', 'text-davinci-003', 'text-davinci-002', 'text-curie-001', 'text-babbage-001', 'text-ada-001', 'text-embedding-ada-002');
const AIOMATIC_CHATGPT_MAX_TOKENS = 4000;
const AIOMATIC_GPT4_MAX_TOKENS = 8100;
const AIOMATIC_GPT4_32_MAX_TOKENS = 32500;
const AIOMATIC_DAVINCI_MAX_TOKENS = 4000;
const AIOMATIC_EDIT_MAX_TOKENS = 3000;
const AIOMATIC_DEFAULT_MAX_TOKENS = 2048;
const AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS = 50;
const AIOMATIC_IS_DEBUG = false;
const AZURE_API_VERSION = '?api-version=2023-03-15-preview';
const AZURE_DALLE_API_VERSION = '?api-version=2022-08-03-preview';
function aiomatic_get_version() {
    $plugin_data = get_file_data( __FILE__  , array('Version' => 'Version'), false);
    return $plugin_data['Version'];
}

add_action('wp_head', 'aiomatic_wp_head_seo',1);
function aiomatic_wp_head_seo()
{
    if(is_single())
    {
        $aiomatic_meta_description = get_post_meta(get_the_ID(), 'aiomatic_html_meta', true);
        $aiomatic_seo_option = false;
        $seo_plugin_activated = aiomatic_seo_plugins_active();
        if($seo_plugin_activated !== false) 
        {
            $aiomatic_seo_option = get_option($seo_plugin_activated, false);
        }
        if(!empty($aiomatic_meta_description) && !$aiomatic_seo_option)
        {
            ?>
            <meta name="description" content="<?php echo esc_html($aiomatic_meta_description)?>">
            <meta name="og:description" content="<?php echo esc_html($aiomatic_meta_description)?>">
            <?php
        }
    }
}

function aiomatic_get_max_tokens($model)
{
    if(strstr($model, '-edit-') !== false && strstr($model, ':ft-') === false)
    {
        $max_tokens = AIOMATIC_EDIT_MAX_TOKENS;
    }
    elseif(strstr($model, 'davinci') !== false && strstr($model, ':ft-') === false)
    {
        $max_tokens = AIOMATIC_DAVINCI_MAX_TOKENS;
    }
    elseif(strstr($model, 'turbo') !== false && strstr($model, ':ft-') === false)
    {
        $max_tokens = AIOMATIC_CHATGPT_MAX_TOKENS;
    }
    elseif(strstr($model, 'gpt-4-32k') !== false && strstr($model, ':ft-') === false)
    {
        $max_tokens = AIOMATIC_GPT4_32_MAX_TOKENS;
    }
    elseif(strstr($model, 'gpt-4') !== false && strstr($model, ':ft-') === false)
    {
        $max_tokens = AIOMATIC_GPT4_MAX_TOKENS;
    }
    else
    {
        $max_tokens = AIOMATIC_DEFAULT_MAX_TOKENS;
    }
    return $max_tokens;
}
function aiomatic_load_textdomain() {
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['app_id']) && trim($aiomatic_Main_Settings['app_id']) != '') 
    {
        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
        $appids = array_filter($appids);
        $token = $appids[array_rand($appids)];
        require_once(dirname(__FILE__) . "/res/Embeddings.php");
        new Aiomatic_Embeddings($token);
        if (isset($aiomatic_Main_Settings['aiomatic_enabled']) && $aiomatic_Main_Settings['aiomatic_enabled'] === 'on') 
        {
            $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
            if (isset($aiomatic_Chatbot_Settings['enable_front_end']) && $aiomatic_Chatbot_Settings['enable_front_end'] != '') 
            {
                if(($aiomatic_Chatbot_Settings['enable_front_end'] === 'front' || $aiomatic_Chatbot_Settings['enable_front_end'] === 'both'))
                {
                    add_action( 'wp_footer', 'aiomatic_inject_chat' );
                }
                if(($aiomatic_Chatbot_Settings['enable_front_end'] === 'back' || $aiomatic_Chatbot_Settings['enable_front_end'] === 'both'))
                {
                    add_action( 'admin_footer', 'aiomatic_inject_chat' );
                }
            }
        }
    }
    load_plugin_textdomain( 'aiomatic-automatic-ai-content-writer', false, basename( dirname( __FILE__ ) ) . '/languages' ); 
}
add_action( 'init', 'aiomatic_load_textdomain' );

function aiomatic_inject_chat()
{
    echo aiomatic_chat_shortcode(array( 'temperature' => '', 'top_p' => '', 'presence_penalty' => '', 'frequency_penalty' => '', 'model' => '', 'instant_response' => '', 'window' => 'true' ));;
}

function aiomatic_is_gutenberg() 
{
    global $post;
    if(isset($post->ID) && function_exists('has_blocks') && has_blocks($post->ID))
    {
        return true;    
    } 
    else 
    {
        return false;
    }
}

function aiomatic_enqueue_plugin_scripts($plugin_array)
{
    $plugin_array["aiomatic_editor"] =  plugin_dir_url(__FILE__) . "scripts/classic-editor.js";
    return $plugin_array;
}

function aiomatic_register_buttons_editor($buttons)
{
    array_push($buttons, "aiomatic");
    return $buttons;
}
function aiomatic_classic_mce_inline_script() 
{
    global $pagenow;
    if ($pagenow !== 'post.php' && $pagenow !== 'post-new.php' && $pagenow !== 'admin.php') {
        return;
    }
	aiomatic_add_inline_js_object();
}
function aiomatic_add_inline_js_object () 
{
    $aiomatic_build_plugin_js_config = aiomatic_build_plugin_js_config();
    wp_enqueue_script('aiomatic-admin-footer-script', plugins_url('scripts/admin-footer.js', __FILE__), array('jquery'), false, true);
	wp_add_inline_script( 'aiomatic-admin-footer-script', 'var aiomatic =' . json_encode($aiomatic_build_plugin_js_config) );
	wp_enqueue_script( 'aiomatic-admin-footer-script');
}
function aiomatic_build_plugin_js_config() 
{
    $assistant_placement = 'below';
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['assistant_placement']) && $aiomatic_Main_Settings['assistant_placement'] != '') 
    {
        $assistant_placement = $aiomatic_Main_Settings['assistant_placement'];
    }
    $nonce = wp_create_nonce('wp_rest' );
    $prompts  = aiomatic_get_assistant();
    if(!is_array($prompts))
    {
        $prompts = array();
    }
    $aiomaticScriptVars = array(
        'nonce'  =>  $nonce,
        'ajaxurl' => admin_url('admin-ajax.php'),
        'prompts' => $prompts,
        'placement' => $assistant_placement,
        'xicon' => plugins_url('/images/icon.png', __FILE__)
    );
    return $aiomaticScriptVars;
}

$plugin = plugin_basename(__FILE__);
if(is_admin())
{
    if(!aiomatic_is_gutenberg())
    {
        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
        if (isset($aiomatic_Main_Settings['aiomatic_enabled']) && $aiomatic_Main_Settings['aiomatic_enabled'] == 'on')
        {
            if (!isset($aiomatic_Main_Settings['assistant_disable']) || $aiomatic_Main_Settings['assistant_disable'] != 'on')
            {
                add_filter("mce_external_plugins", "aiomatic_enqueue_plugin_scripts");
                add_action('admin_head', 'aiomatic_classic_mce_inline_script');
                add_filter("mce_buttons", "aiomatic_register_buttons_editor");
            }
        }
    }
    if($_SERVER["REQUEST_METHOD"]==="POST" && !empty($_POST["coderevolution_max_input_var_data"])) 
    {
        $vars = explode("&", $_POST["coderevolution_max_input_var_data"]);
        $coderevolution_max_input_var_data = array();
        foreach($vars as $var) {
            parse_str($var, $variable);
            aiomatic_assign_var($_POST, $variable, true);
        }
        unset($_POST["coderevolution_max_input_var_data"]);
    }
    require(dirname(__FILE__) . "/res/aiomatic-main.php");
    require(dirname(__FILE__) . "/res/aiomatic-rules-list.php");
    require(dirname(__FILE__) . "/res/aiomatic-single-list.php");
    require(dirname(__FILE__) . "/res/aiomatic-spinner-list.php");
    require(dirname(__FILE__) . "/res/aiomatic-playground.php");
    require(dirname(__FILE__) . "/res/aiomatic-images.php");
    require(dirname(__FILE__) . "/res/aiomatic-chatbot.php");
    require(dirname(__FILE__) . "/res/aiomatic-shortcodes.php");
    require(dirname(__FILE__) . "/res/aiomatic-training.php");
    require(dirname(__FILE__) . "/res/aiomatic-embeddings.php");
    require(dirname(__FILE__) . "/res/aiomatic-limits-statistics.php");
    require(dirname(__FILE__) . "/res/aiomatic-logs.php");
    $plugin_slug = explode('/', $plugin);
    $plugin_slug = $plugin_slug[0];
    if(isset($_POST[$plugin_slug . '_register']) && isset($_POST[$plugin_slug. '_register_code']) && trim($_POST[$plugin_slug . '_register_code']) != '')
    {
        update_option('coderevolution_settings_changed', 1);
        if(strlen(trim($_POST[$plugin_slug . '_register_code'])) != 36 || strstr($_POST[$plugin_slug . '_register_code'], '-') == false)
        {
            aiomatic_log_to_file('Invalid registration code submitted: ' . $_POST[$plugin_slug . '_register_code']);
        }
        else
        {
            $ch = curl_init('https://wpinitiate.com/verify-purchase/purchase.php');
            if($ch !== false)
            {
                $data           = array();
                $data['code']   = trim($_POST[$plugin_slug . '_register_code']);
                $data['siteURL']   = get_bloginfo('url');
                $data['siteName']   = get_bloginfo('name');
                $data['siteEmail']   = get_bloginfo('admin_email');
                $fdata = "";
                foreach ($data as $key => $val) {
                    $fdata .= "$key=" . urlencode(trim($val)) . "&";
                }
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $fdata);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                $result = curl_exec($ch);
                
                if($result === false)
                {
                    aiomatic_log_to_file('Failed to get verification response: ' . curl_error($ch));
                }
                else
                {
                    $rj = json_decode($result, true);
                    if(isset($rj['error']))
                    {
                        update_option('coderevolution_settings_changed', $rj['error']);
                    }
                    elseif(isset($rj['item_name']))
                    {
                        $rj['code'] = $_POST[$plugin_slug . '_register_code'];
                        if($rj['item_id'] == '38877369' || $rj['item_id'] == '13371337' || $rj['item_id'] == '19200046')
                        {
                            update_option($plugin_slug . '_registration', $rj);
                            update_option('coderevolution_settings_changed', 2);
                        }
                        else
                        {
                            aiomatic_log_to_file('Invalid response from purchase code verification (are you sure you inputed the right purchase code?): ' . print_r($rj, true));
                        }
                    }
                    else
                    {
                        aiomatic_log_to_file('Invalid json from purchase code verification: ' . print_r($result, true));
                    }
                }
                curl_close($ch);
            }
            else
            {
                aiomatic_log_to_file('Failed to init curl when trying to make purchase verification.');
            }
        }
    }
    if(isset($_POST[$plugin_slug . '_revoke_license']) && trim($_POST[$plugin_slug . '_revoke_license']) != '')
    {
        $ch = curl_init('https://wpinitiate.com/verify-purchase/revoke.php');
        if($ch !== false)
        {
            $data           = array();
            $data['siteURL']   = get_bloginfo('url');
            $fdata = "";
            foreach ($data as $key => $val) {
                $fdata .= "$key=" . urlencode(trim($val)) . "&";
            }
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fdata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            $result = curl_exec($ch);
            
            if($result === false)
            {
                aiomatic_log_to_file('Failed to revoke verification response: ' . curl_error($ch));
                update_option($plugin_slug . '_registration', false);
            }
            else
            {
                update_option($plugin_slug . '_registration', false);
            }
        }
        else
        {
            aiomatic_log_to_file('Failed to init curl to revoke verification response.');
        }
    }
    $uoptions = get_option($plugin_slug . '_registration', array());
    if(isset($uoptions['item_id']) && isset($uoptions['item_name']) && isset($uoptions['created_at']) && isset($uoptions['buyer']) && isset($uoptions['licence']) && isset($uoptions['supported_until']))
    {
        require "update-checker/plugin-update-checker.php";
        $fwdu3dcarPUC = Puc_v4_Factory::buildUpdateChecker("https://wpinitiate.com/auto-update/?action=get_metadata&slug=aiomatic-automatic-ai-content-writer", __FILE__, "aiomatic-automatic-ai-content-writer");
    }
    else
    {
        add_action("after_plugin_row_{$plugin}", function( $plugin_file, $plugin_data, $status ) {
            $plugin_url = 'https://codecanyon.net/item/aiomatic-automatic-ai-content-writer/38877369';
            echo '<tr class="active"><td>&nbsp;</td><td colspan="2"><p class="cr_auto_update">';
          echo sprintf( wp_kses( __( 'The plugin is not registered. Automatic updating is disabled. Please purchase a license for it from <a href="%s" target="_blank">here</a> and register  the plugin from the \'Main Settings\' menu using your purchase code. <a href="%s" target="_blank">How I find my purchase code?', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://1.envato.market/c/1264868/275988/4415?u=' . urlencode($plugin_url)), esc_url('//www.youtube.com/watch?v=NElJ5t_Wd48') );     
          echo '</a></p> </td></tr>';
        }, 10, 3 );
        add_action('admin_enqueue_scripts', 'aiomatic_admin_enqueue_all');
        add_filter("plugin_action_links_$plugin", 'aiomatic_add_activation_link');
    }
}
function aiomatic_admin_enqueue_all()
{
    $reg_css_code = '.cr_auto_update{background-color:#fff8e5;margin:5px 20px 15px 20px;border-left:4px solid #fff;padding:12px 12px 12px 12px !important;border-left-color:#ffb900;}';
    wp_register_style( 'aiomatic-plugin-reg-style', false );
    wp_enqueue_style( 'aiomatic-plugin-reg-style' );
    wp_add_inline_style( 'aiomatic-plugin-reg-style', $reg_css_code );
}
function aiomatic_add_activation_link($links)
{
    $settings_link = '<a href="admin.php?page=aiomatic_admin_settings">' . esc_html__('Activate Plugin License', 'aiomatic-automatic-ai-content-writer') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

use \Eventviva\ImageResize;

add_action('admin_menu', 'aiomatic_register_my_custom_menu_page');
add_action('network_admin_menu', 'aiomatic_register_my_custom_menu_page');
function aiomatic_register_my_custom_menu_page()
{
    add_menu_page('Aiomatic Automatic AI Content Writer', 'Aiomatic Automatic AI Content Writer', 'manage_options', 'aiomatic_admin_settings', 'aiomatic_admin_settings', plugins_url('images/icon.png', __FILE__));
    $main = add_submenu_page('aiomatic_admin_settings', esc_html__("Main Settings", 'aiomatic-automatic-ai-content-writer'), esc_html__("Main Settings", 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_admin_settings');
    add_action( 'load-' . $main, 'aiomatic_load_all_admin_js' );
    add_action( 'load-' . $main, 'aiomatic_load_main_admin_js' );
    add_action( 'load-' . $main, 'aiomatic_load_playground' );
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['aiomatic_enabled']) && $aiomatic_Main_Settings['aiomatic_enabled'] == 'on') {
        $single = add_submenu_page('aiomatic_admin_settings', esc_html__('Single AI Post Creator', 'aiomatic-automatic-ai-content-writer'), esc_html__('Single AI Post Creator', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_single_panel', 'aiomatic_single_panel');
        add_action( 'load-' . $single, 'aiomatic_load_admin_js' );
        add_action( 'load-' . $single, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $single, 'aiomatic_load_single' );
        $spin = add_submenu_page('aiomatic_admin_settings', esc_html__('Bulk AI Post Creator', 'aiomatic-automatic-ai-content-writer'), esc_html__('Bulk AI Post Creator', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_items_panel', 'aiomatic_items_panel');
        add_action( 'load-' . $spin, 'aiomatic_load_admin_js' );
        add_action( 'load-' . $spin, 'aiomatic_load_all_admin_js' );
        $auto = add_submenu_page('aiomatic_admin_settings', esc_html__('AI Content Editor', 'aiomatic-automatic-ai-content-writer'), esc_html__('AI Content Editor', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_spinner_panel', 'aiomatic_spinner_panel');
        add_action( 'load-' . $auto, 'aiomatic_load_post_admin_js' );
        add_action( 'load-' . $auto, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $auto, 'aiomatic_load_playground' );
        add_action( 'load-' . $auto, 'aiomatic_load_auto_rules_css' );
        $chatbot = add_submenu_page('aiomatic_admin_settings', esc_html__('AI Chatbot', 'aiomatic-automatic-ai-content-writer'), esc_html__('AI Chatbot', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_chatbot_panel', 'aiomatic_chatbot_panel');
        add_action( 'load-' . $chatbot, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $chatbot, 'aiomatic_load_playground' );
        add_action( 'load-' . $chatbot, 'aiomatic_load_live_preview' );
        $shortcodes = add_submenu_page('aiomatic_admin_settings', esc_html__('AI Shortcodes & Forms', 'aiomatic-automatic-ai-content-writer'), esc_html__('AI Shortcodes & Forms', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_shortcodes_panel', 'aiomatic_shortcodes_panel');
        add_action( 'load-' . $shortcodes, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $shortcodes, 'aiomatic_load_playground' );
        add_action( 'load-' . $shortcodes, 'aiomatic_load_forms' );
        $embeddings = add_submenu_page('aiomatic_admin_settings', esc_html__('AI Embeddings', 'aiomatic-automatic-ai-content-writer'), esc_html__('AI Embeddings', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_embeddings_panel', 'aiomatic_embeddings_panel');
        add_action( 'load-' . $embeddings, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $embeddings, 'aiomatic_load_playground' );
        add_action( 'load-' . $embeddings, 'aiomatic_load_embeddings' );
        $training = add_submenu_page('aiomatic_admin_settings', esc_html__('AI Model Training', 'aiomatic-automatic-ai-content-writer'), esc_html__('AI Model Training', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_openai_training', 'aiomatic_openai_training');
        add_action( 'load-' . $training, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $training, 'aiomatic_load_playground' );
        add_action( 'load-' . $training, 'aiomatic_load_training' );
        $playground = add_submenu_page('aiomatic_admin_settings', esc_html__('AI Playground', 'aiomatic-automatic-ai-content-writer'), esc_html__('AI Playground', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_playground_panel', 'aiomatic_playground_panel');
        add_action( 'load-' . $playground, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $playground, 'aiomatic_load_playground' );
        $openai_status = add_submenu_page('aiomatic_admin_settings', esc_html__('Limits & Statistics', 'aiomatic-automatic-ai-content-writer'), esc_html__('Limits & Statistics', 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_openai_status', 'aiomatic_openai_status');
        add_action( 'load-' . $openai_status, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $openai_status, 'aiomatic_load_playground' );
        add_action( 'load-' . $openai_status, 'aiomatic_load_stats' );
        $logs = add_submenu_page('aiomatic_admin_settings', esc_html__("Activity & Logging", 'aiomatic-automatic-ai-content-writer'), esc_html__("Activity & Logging", 'aiomatic-automatic-ai-content-writer'), 'manage_options', 'aiomatic_logs', 'aiomatic_logs');
        add_action( 'load-' . $logs, 'aiomatic_load_all_admin_js' );
        add_action( 'load-' . $logs, 'aiomatic_load_playground' );
        $media = add_media_page( 'Aiomatic Images', 'Aiomatic Images', 'upload_files', 'aiomatic-automatic-ai-content-writer', 'aiomatic_media_page' );
        add_action( 'load-' . $media, 'aiomatic_load_all_admin_js' );
    }
}
function aiomatic_load_post_admin_js(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_load_post_files');
}

function aiomatic_admin_load_post_files()
{
    wp_register_script('aiomatic-submitter-script', plugins_url('scripts/poster.js', __FILE__), false, '1.0.0');
    wp_enqueue_script('aiomatic-submitter-script');
}
function aiomatic_load_auto_rules_css(){
    add_action('admin_enqueue_scripts', 'aiomatic_enqueue_only_rules');
}
function aiomatic_enqueue_only_rules()
{
    wp_register_style('aiomatic-rules-style', plugins_url('styles/aiomatic-rules.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-rules-style');
    wp_enqueue_script('aiomatic-bulk-script', plugins_url('scripts/bulk-editor.js', __FILE__), array('jquery'), false, true);
    $footer_conf_settings = array(
        'plugin_dir_url' => plugin_dir_url(__FILE__),
		'nonce' => wp_create_nonce('openai-bulk-nonce'),
		'ajaxurl' => admin_url('admin-ajax.php')
    );
    wp_localize_script('aiomatic-bulk-script', 'mycustomsettings', $footer_conf_settings);
}
function aiomatic_load_admin_js(){
    add_action('admin_enqueue_scripts', 'aiomatic_enqueue_admin_js');
}
function aiomatic_enqueue_admin_js(){
    wp_enqueue_script('aiomatic-modeselect-script', plugins_url('scripts/modeselect.js', __FILE__), array('jquery'), false, true);
    $footer_conf_settingsx = array(
        'showme' => esc_html__("Show Tutorial Video", 'aiomatic-automatic-ai-content-writer'),
        'hideme' => esc_html__("Hide Tutorial Video", 'aiomatic-automatic-ai-content-writer')
    );
    wp_localize_script('aiomatic-modeselect-script', 'varsx', $footer_conf_settingsx);
    wp_enqueue_script('aiomatic-footer-script', plugins_url('scripts/footer.js', __FILE__), array('jquery'), false, true);
    $cr_miv = ini_get('max_input_vars');
	if($cr_miv === null || $cr_miv === false || !is_numeric($cr_miv))
	{
        $cr_miv = '9999999';
    }
    $footer_conf_settings = array(
        'max_input_vars' => $cr_miv,
        'plugin_dir_url' => plugin_dir_url(__FILE__),
        'ajaxurl' => admin_url('admin-ajax.php')
    );
    wp_localize_script('aiomatic-footer-script', 'mycustomsettings', $footer_conf_settings);
    wp_register_style('aiomatic-rules-style', plugins_url('styles/aiomatic-rules.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-rules-style');
}
function aiomatic_load_main_admin_js(){
    add_action('admin_enqueue_scripts', 'aiomatic_enqueue_main_admin_js');
}

function aiomatic_enqueue_main_admin_js(){
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    wp_enqueue_script('aiomatic-main-script', plugins_url('scripts/main.js', __FILE__), array('jquery'));
    if(!isset($aiomatic_Main_Settings['best_user']))
    {
        $best_user = '';
    }
    else
    {
        $best_user = $aiomatic_Main_Settings['best_user'];
    }
    if(!isset($aiomatic_Main_Settings['best_password']))
    {
        $best_password = '';
    }
    else
    {
        $best_password = $aiomatic_Main_Settings['best_password'];
    }
    $header_main_settings = array(
        'best_user' => $best_user,
        'best_password' => $best_password
    );
    wp_localize_script('aiomatic-main-script', 'mycustommainsettings', $header_main_settings);
}
function aiomatic_load_single(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_single');
    wp_enqueue_script( 'jquery-ui-dialog' );
    wp_enqueue_style( 'wp-jquery-ui-dialog' );
    wp_enqueue_media();
    wp_enqueue_script( 'aiomatic-media-loader-js', plugins_url( 'scripts/media.js' , __FILE__ ), array('jquery'), '0.1' );
}
function aiomatic_admin_single()
{
    wp_register_script('aiomatic-single-script', plugins_url('scripts/single.js', __FILE__), false, '1.0.0');
    wp_enqueue_script('aiomatic-single-script');
    wp_localize_script('aiomatic-single-script', 'aiomatic_ajax_object', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('openai-single-nonce')
	));
}
function aiomatic_load_all_admin_js(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_load_files');
}
function aiomatic_load_playground(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_load_playground');
}
function aiomatic_load_live_preview(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_load_live_preview');
}
function aiomatic_load_stats(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_load_stats');
}
function aiomatic_load_embeddings(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_load_embeddings');
}
function aiomatic_load_forms(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_load_forms');
    add_action('admin_footer', 'aiomatic_admin_footer');
}
function aiomatic_load_training(){
    add_action('admin_enqueue_scripts', 'aiomatic_admin_load_training');
    add_action('admin_footer', 'aiomatic_admin_footer');
}
add_filter("plugin_action_links_$plugin", 'aiomatic_add_rating_link');
function aiomatic_add_rating_link($links)
{
    $settings_link = '<a href="//codecanyon.net/downloads" target="_blank" title="Rate">
            <i class="wdi-rate-stars"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="#ffb900" stroke="#ffb900" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="#ffb900" stroke="#ffb900" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="#ffb900" stroke="#ffb900" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="#ffb900" stroke="#ffb900" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="#ffb900" stroke="#ffb900" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg></i></a>';
    array_push($links, $settings_link);
    return $links;
}
add_filter("plugin_action_links_$plugin", 'aiomatic_add_support_link');
function aiomatic_add_support_link($links)
{
    $settings_link = '<a href="//coderevolution.ro/knowledge-base/" target="_blank">' . esc_html__('Support', 'aiomatic-automatic-ai-content-writer') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
add_filter("plugin_action_links_$plugin", 'aiomatic_add_settings_link');
function aiomatic_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=aiomatic_admin_settings">' . esc_html__('Settings', 'aiomatic-automatic-ai-content-writer') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

function aiomatic_display_posts_off( $out, $pairs, $atts ) {
	$out['display_posts_off'] = apply_filters( 'display_posts_shortcode_inception_override', true );
	return $out;
}

add_filter('cron_schedules', 'aiomatic_add_cron_schedule');
function aiomatic_add_cron_schedule($schedules)
{
    $schedules['aiomatic_cron_ten'] = array(
        'interval' => 600,
        'display' => esc_html__('Kronos Cron 10 Minute', 'aiomatic-automatic-ai-content-writer')
    );
    $schedules['aiomatic_cron_sfert'] = array(
        'interval' => 900,
        'display' => esc_html__('Kronos Cron Quarter Hour', 'aiomatic-automatic-ai-content-writer')
    );
    $schedules['aiomatic_cron_half'] = array(
        'interval' => 1800,
        'display' => esc_html__('Kronos Cron Half Hour', 'aiomatic-automatic-ai-content-writer')
    );
    $schedules['aiomatic_cron'] = array(
        'interval' => 3600,
        'display' => esc_html__('Aiomatic Cron', 'aiomatic-automatic-ai-content-writer')
    );
    $schedules['minutely'] = array(
        'interval' => 60,
        'display' => esc_html__('Once A Minute', 'aiomatic-automatic-ai-content-writer')
    );
    $schedules['weekly']        = array(
        'interval' => 604800,
        'display' => esc_html__('Once Weekly', 'aiomatic-automatic-ai-content-writer')
    );
    $schedules['monthly']       = array(
        'interval' => 2592000,
        'display' => esc_html__('Once Monthly', 'aiomatic-automatic-ai-content-writer')
    );
    return $schedules;
}

register_deactivation_hook(__FILE__, 'aiomatic_my_deactivation');
function aiomatic_my_deactivation()
{
    wp_clear_scheduled_hook('aiomaticaction');
    wp_clear_scheduled_hook('aiomaticactionclear');
    $running = array();
    update_option('aiomatic_running_list', $running, false);
}
add_action('aiomaticaction', 'aiomatic_cron');
add_action('aiomaticeditaction', 'aiomatic_do_bulk_post');
add_action('aiomaticactionclear', 'aiomatic_auto_clear_log');

add_action('add_meta_boxes', 'aiomatic_add_meta_box');
function aiomatic_add_meta_box()
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['aiomatic_enabled']) && $aiomatic_Main_Settings['aiomatic_enabled'] === 'on') {
        foreach ( get_post_types( '', 'names' ) as $post_type ) {
            add_meta_box('aiomatic_meta_box_function_add', esc_html__('AIomatic AI Content Writer', 'aiomatic-automatic-ai-content-writer'), 'aiomatic_meta_box_function', $post_type, 'advanced', 'default', array('__back_compat_meta_box' => true));
        }
        
    }
}

add_action('admin_enqueue_scripts', 'aiomatic_admin_do_post');
function aiomatic_admin_do_post()
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['no_media_library']) || $aiomatic_Main_Settings['no_media_library'] !== 'on') 
    {
        global $post;
        wp_enqueue_script('aiomatic-media-tab', plugins_url('scripts/media-ai-script.js', __FILE__), array( 'jquery' ), false, true);
        $no_stable = '0';
        if (!isset($aiomatic_Main_Settings['stability_app_id']) || trim($aiomatic_Main_Settings['stability_app_id']) == '') 
        {
            $no_stable = '1';
        }
        $image_placeholder = plugins_url('images/loading.gif', __FILE__);
        wp_localize_script('aiomatic-media-tab', 'aiomatic_img_ajax_object', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('openai-ajax-nonce'),
            'image_placeholder' => $image_placeholder,
            'postId' => $post ? $post->ID : '',
            'no_stable' => $no_stable
        ));
    }
    wp_enqueue_script('aiomatic-poster-script', plugins_url('scripts/postnow.js', __FILE__), array('jquery'), false, true);
    wp_localize_script('aiomatic-poster-script', 'aiomatic_poster_object', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
}
function aiomatic_meta_box_function($post)
{
    wp_register_style('aiomatic-browser-style', plugins_url('styles/aiomatic-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-browser-style');
    $ech = '<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle"><div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Post will be edited respecting the configurations you made in the \'AI Content Editor\' plugin menu section.", 'aiomatic-automatic-ai-content-writer') . '</div></div>&nbsp;<span id="aiomatic_span">Manually Edit/Add AI Content: </span><br/><br/><form id="aiomatic_form"><input class="button button-primary button-large" type="button" name="aiomatic_submit_post" id="aiomatic_submit_post" value="' . esc_html__('Edit/Add AI Content!', 'aiomatic-automatic-ai-content-writer') . '" onclick="aiomatic_post_now(' . $post->ID . ');"/></form><br/><hr/>';
    echo $ech;
}

function aiomatic_cron_schedule()
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['aiomatic_enabled']) && $aiomatic_Main_Settings['aiomatic_enabled'] === 'on') 
    {
        $aiomatic_Spinner_Settings = get_option('aiomatic_Spinner_Settings', false);
        if(!isset($aiomatic_Spinner_Settings['auto_run_interval']))
        {
            $aiomatic_Spinner_Settings['auto_run_interval'] = 'daily';
        }
        if(isset($aiomatic_Spinner_Settings['auto_edit']) && $aiomatic_Spinner_Settings['auto_edit'] == 'wp' && $aiomatic_Spinner_Settings['auto_run_interval'] != 'No')
        {
            if (!wp_next_scheduled('aiomaticeditaction')) 
            {
                wp_schedule_event(time(), $aiomatic_Spinner_Settings['auto_run_interval'], 'aiomaticeditaction');
            }
        }
        else
        {
            if (wp_next_scheduled('aiomaticeditaction')) 
            {
                wp_clear_scheduled_hook('aiomaticeditaction');
            }
        }
        if (!wp_next_scheduled('aiomaticaction')) {
            $unlocker = get_option('aiomatic_minute_running_unlocked', false);
            if($unlocker == '1')
            {
                $rez = wp_schedule_event(time(), 'minutely', 'aiomaticaction');
            }
            else
            {
                $rez = wp_schedule_event(time(), 'hourly', 'aiomaticaction');
            }
            if ($rez === FALSE) {
                aiomatic_log_to_file('[Scheduler] Failed to schedule aiomaticaction to aiomatic_cron!');
            }
        }
        
        if (isset($aiomatic_Main_Settings['enable_logging']) && $aiomatic_Main_Settings['enable_logging'] === 'on' && isset($aiomatic_Main_Settings['auto_clear_logs']) && $aiomatic_Main_Settings['auto_clear_logs'] !== 'No') {
            if (!wp_next_scheduled('aiomaticactionclear')) {
                $rez = wp_schedule_event(time(), $aiomatic_Main_Settings['auto_clear_logs'], 'aiomaticactionclear');
                if ($rez === FALSE) {
                    aiomatic_log_to_file('[Scheduler] Failed to schedule aiomaticactionclear to ' . $aiomatic_Main_Settings['auto_clear_logs'] . '!');
                }
                add_option('aiomatic_schedule_time', $aiomatic_Main_Settings['auto_clear_logs']);
            } else {
                if (!get_option('aiomatic_schedule_time')) {
                    wp_clear_scheduled_hook('aiomaticactionclear');
                    $rez = wp_schedule_event(time(), $aiomatic_Main_Settings['auto_clear_logs'], 'aiomaticactionclear');
                    add_option('aiomatic_schedule_time', $aiomatic_Main_Settings['auto_clear_logs']);
                    if ($rez === FALSE) {
                        aiomatic_log_to_file('[Scheduler] Failed to schedule aiomaticactionclear to ' . $aiomatic_Main_Settings['auto_clear_logs'] . '!');
                    }
                } else {
                    $the_time = get_option('aiomatic_schedule_time');
                    if ($the_time != $aiomatic_Main_Settings['auto_clear_logs']) {
                        wp_clear_scheduled_hook('aiomaticactionclear');
                        delete_option('aiomatic_schedule_time');
                        $rez = wp_schedule_event(time(), $aiomatic_Main_Settings['auto_clear_logs'], 'aiomaticactionclear');
                        add_option('aiomatic_schedule_time', $aiomatic_Main_Settings['auto_clear_logs']);
                        if ($rez === FALSE) {
                            aiomatic_log_to_file('[Scheduler] Failed to schedule aiomaticactionclear to ' . $aiomatic_Main_Settings['auto_clear_logs'] . '!');
                        }
                    }
                }
            }
        } else {
            if (!wp_next_scheduled('aiomaticactionclear')) {
                delete_option('aiomatic_schedule_time');
            } else {
                wp_clear_scheduled_hook('aiomaticactionclear');
                delete_option('aiomatic_schedule_time');
            }
        }
    } else {
        if (wp_next_scheduled('aiomaticaction')) {
            wp_clear_scheduled_hook('aiomaticaction');
        }
        
        if (!wp_next_scheduled('aiomaticactionclear')) {
            delete_option('aiomatic_schedule_time');
        } else {
            wp_clear_scheduled_hook('aiomaticactionclear');
            delete_option('aiomatic_schedule_time');
        }
    }
}
function aiomatic_cron()
{
    $GLOBALS['wp_object_cache']->delete('aiomatic_rules_list', 'options');
    if (!get_option('aiomatic_rules_list')) {
        $rules = array();
    } else {
        $rules = get_option('aiomatic_rules_list');
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['run_after']) && $aiomatic_Main_Settings['run_after'] != '' && isset($aiomatic_Main_Settings['run_before']) && $aiomatic_Main_Settings['run_before'] != '') 
    {
        $exit = true;
        $mytime = date("H:i");
        $min_time = $aiomatic_Main_Settings['run_after'];
        $max_time = $aiomatic_Main_Settings['run_before'];
        $date1 = DateTime::createFromFormat('H:i', $mytime);
        $date2 = DateTime::createFromFormat('H:i', $min_time);
        $date3 = DateTime::createFromFormat('H:i', $max_time);
        if ($date1 > $date2 && $date1 < $date3)
        {
            $exit = false;
        }
        if($exit == true)
        {
            return;
        }
    }
    $unlocker = get_option('aiomatic_minute_running_unlocked', false);
    if (!empty($rules)) {
        $cont = 0;
        foreach ($rules as $request => $bundle[]) {
            $bundle_values   = array_values($bundle);
            $myValues        = $bundle_values[$cont];
            $array_my_values = array_values($myValues);for($iji=0;$iji<count($array_my_values);++$iji){if(is_string($array_my_values[$iji])){$array_my_values[$iji]=stripslashes($array_my_values[$iji]);}}
            $schedule        = isset($array_my_values[0]) ? $array_my_values[0] : '24';
            $active          = isset($array_my_values[1]) ? $array_my_values[1] : '0';
            $last_run        = isset($array_my_values[2]) ? $array_my_values[2] : aiomatic_get_date_now();
            if ($active == '1') {
                $now                = aiomatic_get_date_now();
                if($unlocker == '1')
                {
                    $nextrun        = aiomatic_add_minute($last_run, $schedule);
                    $aiomatic_hour_diff = (int) aiomatic_minute_diff($now, $nextrun);
                }
                else
                {
                    $nextrun        = aiomatic_add_hour($last_run, $schedule);
                    $aiomatic_hour_diff = (int) aiomatic_hour_diff($now, $nextrun);
                }
                if ($aiomatic_hour_diff >= 0) {
                    aiomatic_run_rule($cont);
                }
            }
            $cont = $cont + 1;
        }
    }
    $running = array();
    update_option('aiomatic_running_list', $running);
}

function aiomatic_extractKeyWords($string, $count = 10)
{
    $stopwords = array();
    $string = trim(preg_replace('/\s\s+/iu', '\s', strtolower($string)));
    $string = wp_strip_all_tags($string);
    $matchWords   = array_filter(explode(' ', $string), function($item) use ($stopwords)
    {
        return !($item == '' || in_array($item, $stopwords) || strlen($item) <= 2 || (function_exists('ctype_alnum') && ctype_alnum(trim(str_replace(' ', '', $item))) === FALSE) || is_numeric($item));
    });
    $wordCountArr = array_count_values($matchWords);
    arsort($wordCountArr);
    return array_keys(array_slice($wordCountArr, 0, $count));
}

function aiomatic_log_to_file($str)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['enable_logging']) && $aiomatic_Main_Settings['enable_logging'] == 'on') {
        $d = date("j-M-Y H:i:s e", current_time( 'timestamp' ));
        error_log("[$d] " . $str . "<br/>\r\n", 3, WP_CONTENT_DIR . '/aiomatic_info.log');
    }
}
function aiomatic_delete_all_posts()
{
    $failed                 = false;
    $number                 = 0;
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $post_list = array();
    $postsPerPage = 50000;
    $paged = 0;
    do
    {
        $postOffset = $paged * $postsPerPage;
        $query = array(
            'post_status' => array(
                'publish',
                'draft',
                'pending',
                'trash',
                'private',
                'future'
            ),
            'post_type' => array(
                'any'
            ),
            'numberposts' => $postsPerPage,
            'meta_key' => 'aiomatic_parent_rule',
            'fields' => 'ids',
            'offset'  => $postOffset
        );
        $got_me = get_posts($query);
        $post_list = array_merge($post_list, $got_me);
        $paged++;
    }while(!empty($got_me));
    wp_suspend_cache_addition(true);
    foreach ($post_list as $post) {
        $index = get_post_meta($post, 'aiomatic_parent_rule', true);
        if (isset($index) && $index !== '') {
            $args             = array(
                'post_parent' => $post
            );
            $post_attachments = get_children($args);
            if (isset($post_attachments) && !empty($post_attachments)) {
                foreach ($post_attachments as $attachment) {
                    wp_delete_attachment($attachment->ID, true);
                }
            }
            $res = wp_delete_post($post, true);
            if ($res === false) {
                $failed = true;
            } else {
                $number++;
            }
        }
    }
    wp_suspend_cache_addition(false);
    if ($failed === true) {
        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
            aiomatic_log_to_file('[PostDelete] Failed to delete all posts!');
        }
    } else {
        if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) {
            aiomatic_log_to_file('[PostDelete] Successfuly deleted ' . esc_html($number) . ' posts!');
        }
    }
}
function aiomatic_replaceContentShortcodes($the_content, $img_attr, $rule_keywords)
{
    $matches = array();
    $i = 0;
    preg_match_all('~%regex\(\s*\"([^"]+?)\s*"\s*[,;]\s*\"([^"]*)\"\s*(?:[,;]\s*\"([^"]*?)\s*\")?(?:[,;]\s*\"([^"]*?)\s*\")?(?:[,;]\s*\"([^"]*?)\s*\")?\)%~si', $the_content, $matches);
    if (is_array($matches) && count($matches) && is_array($matches[0])) {
        for($i = 0; $i < count($matches[0]); $i++)
        {
            if (isset($matches[0][$i])) $fullmatch = $matches[0][$i];
            if (isset($matches[1][$i])) $search_in = aiomatic_replaceContentShortcodes($matches[1][$i], $img_attr, $rule_keywords);
            if (isset($matches[2][$i])) $matchpattern = $matches[2][$i];
            if (isset($matches[3][$i])) $element = $matches[3][$i];
            if (isset($matches[4][$i])) $delimeter = $matches[4][$i];if (isset($matches[5][$i])) $counter = $matches[5][$i];
            if (isset($matchpattern)) {
               if (preg_match('<^[\/#%+~[\]{}][\s\S]*[\/#%+~[\]{}]$>', $matchpattern, $z)) {
                  $ret = preg_match_all($matchpattern, $search_in, $submatches, PREG_PATTERN_ORDER);
               }
               else {
                  $ret = preg_match_all('~'.$matchpattern.'~si', $search_in, $submatches, PREG_PATTERN_ORDER);
               }
            }
            if (isset($submatches)) {
               if (is_array($submatches)) {
                  $empty_elements = array_keys($submatches[0], "");
                  foreach ($empty_elements as $e) {
                     unset($submatches[0][$e]);
                  }
                  $submatches[0] = array_unique($submatches[0]);
                  if (!is_numeric($element)) {
                     $element = 0;
                  }if (!is_numeric($counter)) {
                     $counter = 0;
                  }
                  if(isset($submatches[(int)($element)]))
                  {
                      $matched = $submatches[(int)($element)];
                  }
                  else
                  {
                      $matched = '';
                  }
                  $matched = array_unique((array)$matched);
                  if (empty($delimeter) || $delimeter == 'null') {
                     if (isset($matched[$counter])) $matched = $matched[$counter];
                  }
                  else {
                     $matched = implode($delimeter, $matched);
                  }
                  if (empty($matched)) {
                     $the_content = str_replace($fullmatch, '', $the_content);
                  } else {
                     $the_content = str_replace($fullmatch, $matched, $the_content);
                  }
               }
            }
        }
    }
    $pcxxx = explode('<!- template ->', $the_content);
    $the_content = $pcxxx[array_rand($pcxxx)];
    $the_content = str_replace('%%random_sentence%%', aiomatic_random_sentence_generator(), $the_content);
    $the_content = str_replace('%%random_sentence2%%', aiomatic_random_sentence_generator(false), $the_content); 
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['custom_html'])) {
        $the_content = str_replace('%%custom_html%%', $aiomatic_Main_Settings['custom_html'], $the_content);
    }
    if (isset($aiomatic_Main_Settings['custom_html2'])) {
        $the_content = str_replace('%%custom_html2%%', $aiomatic_Main_Settings['custom_html2'], $the_content);
    }
    $img_attr = str_replace('%%image_source_name%%', '', $img_attr);
    $img_attr = str_replace('%%image_source_url%%', '', $img_attr);
    $img_attr = str_replace('%%image_source_website%%', '', $img_attr);
    $the_content = str_replace('%%royalty_free_image_attribution%%', $img_attr, $the_content);
    $the_content = str_replace('%%keyword_search%%', $rule_keywords, $the_content);   
    $the_content = aiomatic_replaceSynergyShortcodes($the_content);
    $the_content = apply_filters('aiomatic_replace_aicontent_shortcode', $the_content);
    return $the_content;
}

function aiomatic_replaceTitleShortcodes($the_content)
{
    $matches = array();
    $i = 0;
    preg_match_all('~%regex\(\s*\"([^"]+?)\s*"\s*[,;]\s*\"([^"]*)\"\s*(?:[,;]\s*\"([^"]*?)\s*\")?(?:[,;]\s*\"([^"]*?)\s*\")?(?:[,;]\s*\"([^"]*?)\s*\")?\)%~si', $the_content, $matches);
    if (is_array($matches) && count($matches) && is_array($matches[0])) {
        for($i = 0; $i < count($matches[0]); $i++)
        {
            if (isset($matches[0][$i])) $fullmatch = $matches[0][$i];
            if (isset($matches[1][$i])) $search_in = aiomatic_replaceTitleShortcodes($matches[1][$i]);
            if (isset($matches[2][$i])) $matchpattern = $matches[2][$i];
            if (isset($matches[3][$i])) $element = $matches[3][$i];
            if (isset($matches[4][$i])) $delimeter = $matches[4][$i];if (isset($matches[5][$i])) $counter = $matches[5][$i];
            if (isset($matchpattern)) {
               if (preg_match('<^[\/#%+~[\]{}][\s\S]*[\/#%+~[\]{}]$>', $matchpattern, $z)) {
                  $ret = preg_match_all($matchpattern, $search_in, $submatches, PREG_PATTERN_ORDER);
               }
               else {
                  $ret = preg_match_all('~'.$matchpattern.'~si', $search_in, $submatches, PREG_PATTERN_ORDER);
               }
            }
            if (isset($submatches)) {
               if (is_array($submatches)) {
                  $empty_elements = array_keys($submatches[0], "");
                  foreach ($empty_elements as $e) {
                     unset($submatches[0][$e]);
                  }
                  $submatches[0] = array_unique($submatches[0]);
                  if (!is_numeric($element)) {
                     $element = 0;
                  }if (!is_numeric($counter)) {
                     $counter = 0;
                  }
                  if(isset($submatches[(int)($element)]))
                  {
                      $matched = $submatches[(int)($element)];
                  }
                  else
                  {
                      $matched = '';
                  }
                  $matched = array_unique((array)$matched);
                  if (empty($delimeter) || $delimeter == 'null') {
                     if (isset($matched[$counter])) $matched = $matched[$counter];
                  }
                  else {
                     $matched = implode($delimeter, $matched);
                  }
                  if (empty($matched)) {
                     $the_content = str_replace($fullmatch, '', $the_content);
                  } else {
                     $the_content = str_replace($fullmatch, $matched, $the_content);
                  }
               }
            }
        }
    }
    $pcxxx = explode('<!- template ->', $the_content);
    $the_content = $pcxxx[array_rand($pcxxx)];
    $the_content = str_replace('%%random_sentence%%', aiomatic_random_sentence_generator(), $the_content);
    $the_content = str_replace('%%random_sentence2%%', aiomatic_random_sentence_generator(false), $the_content);
    $the_content = aiomatic_replaceSynergyShortcodes($the_content);
    $the_content = apply_filters('aiomatic_replace_aicontent_shortcode', $the_content);
    return $the_content;
}

function aiomatic_clearFromList($param)
{
    $GLOBALS['wp_object_cache']->delete('aiomatic_running_list', 'options');
    $running = get_option('aiomatic_running_list');
    if($running !== false)
    {
        $key     = array_search($param, $running);
        if ($key !== FALSE) {
            unset($running[$key]);
            update_option('aiomatic_running_list', $running);
        }
    }
}

function aiomatic_generate_title($content)
{
    $regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
    $content        = preg_replace($regexEmoticons, '', $content);
    $regexSymbols   = '/[\x{1F300}-\x{1F5FF}]/u';
    $content        = preg_replace($regexSymbols, '', $content);
    $regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
    $content        = preg_replace($regexTransport, '', $content);
    $regexMisc      = '/[\x{2600}-\x{26FF}]/u';
    $content        = preg_replace($regexMisc, '', $content);
    $regexDingbats  = '/[\x{2700}-\x{27BF}]/u';
    $content        = preg_replace($regexDingbats, '', $content);
    $pattern        = "/[a-zA-Z]*[:\/\/]*[A-Za-z0-9\-_]+\.+[A-Za-z0-9\.\/%&=\?\-_]+/i";
    $replacement    = "";
    $content        = preg_replace($pattern, $replacement, $content);
    $return         = trim(trim(trim(wp_trim_words($content, 14)), '.'), ',');
    return $return;
}
function aiomatic_replaceSynergyShortcodes($the_content)
{
    $regex = '#%%([a-z0-9]+?)(?:_title)?_(\d+?)_(\d+?)%%#';
    $rezz = preg_match_all($regex, $the_content, $matches);
    if ($rezz === FALSE) {
        return $the_content;
    }
    if(isset($matches[1][0]))
    {
        $two_var_functions = array('pdfomatic');
        $three_var_functions = array('bhomatic', 'crawlomatic', 'dmomatic', 'ezinomatic', 'fbomatic', 'flickomatic', 'imguromatic', 'iui', 'instamatic', 'linkedinomatic', 'mediumomatic', 'pinterestomatic', 'echo', 'spinomatic', 'tumblomatic', 'wordpressomatic', 'wpcomomatic', 'youtubomatic', 'mastermind', 'businessomatic');
        $four_var_functions = array('contentomatic', 'quoramatic', 'newsomatic', 'aliomatic', 'amazomatic', 'blogspotomatic', 'bookomatic', 'careeromatic', 'cbomatic', 'cjomatic', 'craigomatic', 'ebayomatic', 'etsyomatic', 'rakutenomatic', 'learnomatic', 'eventomatic', 'gameomatic', 'gearomatic', 'giphyomatic', 'gplusomatic', 'hackeromatic', 'imageomatic', 'midas', 'movieomatic', 'nasaomatic', 'ocartomatic', 'okomatic', 'playomatic', 'recipeomatic', 'redditomatic', 'soundomatic', 'mp3omatic', 'ticketomatic', 'tmomatic', 'trendomatic', 'tuneomatic', 'twitchomatic', 'twitomatic', 'vimeomatic', 'viralomatic', 'vkomatic', 'walmartomatic', 'bestbuyomatic', 'wikiomatic', 'xlsxomatic', 'yelpomatic', 'yummomatic');
        for ($i = 0; $i < count($matches[1]); $i++)
        {
            $replace_me = false;
            if(in_array($matches[1][$i], $four_var_functions))
            {
                $za_function = $matches[1][$i] . '_run_rule';
                if(function_exists($za_function))
                {
                    $xreflection = new ReflectionFunction($za_function);
                    if($xreflection->getNumberOfParameters() >= 4)
                    {  
                        $rule_runner = $za_function($matches[3][$i], $matches[2][$i], 0, 1);
                        if($rule_runner != 'fail' && $rule_runner != 'nochange' && $rule_runner != 'ok' && $rule_runner !== false)
                        {
                            if(is_array($rule_runner))
                            {
                                $the_content = str_replace('%%' . $matches[1][$i] . '_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner[0], $the_content);
                                $the_content = str_replace('%%' . $matches[1][$i] . '_title_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner[1], $the_content);
                            }
                            else
                            {
                                $the_content = str_replace('%%' . $matches[1][$i] . '_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner, $the_content);
                                $the_content = str_replace('%%' . $matches[1][$i] . '_title_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', '', $the_content);
                            }
                            $replace_me = true;
                        }
                    }
                    $xreflection = null;
                    unset($xreflection);
                }
            }
            elseif(in_array($matches[1][$i], $three_var_functions))
            {
                $za_function = $matches[1][$i] . '_run_rule';
                if(function_exists($za_function))
                {
                    $xreflection = new ReflectionFunction($za_function);
                    if($xreflection->getNumberOfParameters() >= 3)
                    {
                        $rule_runner = $za_function($matches[3][$i], 0, 1);
                        if($rule_runner != 'fail' && $rule_runner != 'nochange' && $rule_runner != 'ok' && $rule_runner !== false)
                        {
                            if(is_array($rule_runner))
                            {
                                $the_content = str_replace('%%' . $matches[1][$i] . '_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner[0], $the_content);
                                $the_content = str_replace('%%' . $matches[1][$i] . '_title_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner[1], $the_content);
                            }
                            else
                            {
                                $the_content = str_replace('%%' . $matches[1][$i] . '_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner, $the_content);
                                $the_content = str_replace('%%' . $matches[1][$i] . '_title_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', '', $the_content);
                            }
                            $replace_me = true;
                        }
                    }
                    $xreflection = null;
                    unset($xreflection);
                }
            }
            elseif(in_array($matches[1][$i], $two_var_functions))
            {
                $za_function = $matches[1][$i] . '_run_rule';
                if(function_exists($za_function))
                {
                    $xreflection = new ReflectionFunction($za_function);
                    if($xreflection->getNumberOfParameters() >= 2)
                    {
                        $rule_runner = $za_function($matches[3][$i], 1);
                        if($rule_runner != 'fail' && $rule_runner != 'nochange' && $rule_runner != 'ok' && $rule_runner !== false)
                        {
                            if(is_array($rule_runner))
                            {
                                $the_content = str_replace('%%' . $matches[1][$i] . '_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner[0], $the_content);
                                $the_content = str_replace('%%' . $matches[1][$i] . '_title_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner[1], $the_content);
                            }
                            else
                            {
                                $the_content = str_replace('%%' . $matches[1][$i] . '_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', $rule_runner, $the_content);
                                $the_content = str_replace('%%' . $matches[1][$i] . '_title_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', '', $the_content);
                            }
                            $replace_me = true;
                        }
                    }
                    $xreflection = null;
                    unset($xreflection);
                }
            }
            if($replace_me == false)
            {
                $the_content = str_replace('%%' . $matches[1][$i] . '_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', '', $the_content);
                $the_content = str_replace('%%' . $matches[1][$i] . '_title_' . $matches[2][$i] . '_' . $matches[3][$i] . '%%', '', $the_content);
            }
        }
    }
    return $the_content;
}
class Aiomatic_keywords{ 
    public static $charset = 'UTF-8';
    public static $banned_words = array('adsbygoogle', 'able', 'about', 'above', 'act', 'add', 'afraid', 'after', 'again', 'against', 'age', 'ago', 'agree', 'all', 'almost', 'alone', 'along', 'already', 'also', 'although', 'always', 'am', 'amount', 'an', 'and', 'anger', 'angry', 'animal', 'another', 'answer', 'any', 'appear', 'apple', 'are', 'arrive', 'arm', 'arms', 'around', 'arrive', 'as', 'ask', 'at', 'attempt', 'aunt', 'away', 'back', 'bad', 'bag', 'bay', 'be', 'became', 'because', 'become', 'been', 'before', 'began', 'begin', 'behind', 'being', 'bell', 'belong', 'below', 'beside', 'best', 'better', 'between', 'beyond', 'big', 'body', 'bone', 'born', 'borrow', 'both', 'bottom', 'box', 'boy', 'break', 'bring', 'brought', 'bug', 'built', 'busy', 'but', 'buy', 'by', 'call', 'came', 'can', 'cause', 'choose', 'close', 'close', 'consider', 'come', 'consider', 'considerable', 'contain', 'continue', 'could', 'cry', 'cut', 'dare', 'dark', 'deal', 'dear', 'decide', 'deep', 'did', 'die', 'do', 'does', 'dog', 'done', 'doubt', 'down', 'during', 'each', 'ear', 'early', 'eat', 'effort', 'either', 'else', 'end', 'enjoy', 'enough', 'enter', 'even', 'ever', 'every', 'except', 'expect', 'explain', 'fail', 'fall', 'far', 'fat', 'favor', 'fear', 'feel', 'feet', 'fell', 'felt', 'few', 'fill', 'find', 'fit', 'fly', 'follow', 'for', 'forever', 'forget', 'from', 'front', 'gave', 'get', 'gives', 'goes', 'gone', 'good', 'got', 'gray', 'great', 'green', 'grew', 'grow', 'guess', 'had', 'half', 'hang', 'happen', 'has', 'hat', 'have', 'he', 'hear', 'heard', 'held', 'hello', 'help', 'her', 'here', 'hers', 'high', 'hill', 'him', 'his', 'hit', 'hold', 'hot', 'how', 'however', 'I', 'if', 'ill', 'in', 'indeed', 'instead', 'into', 'iron', 'is', 'it', 'its', 'just', 'keep', 'kept', 'knew', 'know', 'known', 'late', 'least', 'led', 'left', 'lend', 'less', 'let', 'like', 'likely', 'likr', 'lone', 'long', 'look', 'lot', 'make', 'many', 'may', 'me', 'mean', 'met', 'might', 'mile', 'mine', 'moon', 'more', 'most', 'move', 'much', 'must', 'my', 'near', 'nearly', 'necessary', 'neither', 'never', 'next', 'no', 'none', 'nor', 'not', 'note', 'nothing', 'now', 'number', 'of', 'off', 'often', 'oh', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'out', 'please', 'prepare', 'probable', 'pull', 'pure', 'push', 'put', 'raise', 'ran', 'rather', 'reach', 'realize', 'reply', 'require', 'rest', 'run', 'said', 'same', 'sat', 'saw', 'say', 'see', 'seem', 'seen', 'self', 'sell', 'sent', 'separate', 'set', 'shall', 'she', 'should', 'side', 'sign', 'since', 'so', 'sold', 'some', 'soon', 'sorry', 'stay', 'step', 'stick', 'still', 'stood', 'such', 'sudden', 'suppose', 'take', 'taken', 'talk', 'tall', 'tell', 'ten', 'than', 'thank', 'that', 'the', 'their', 'them', 'then', 'there', 'therefore', 'these', 'they', 'this', 'those', 'though', 'through', 'till', 'to', 'today', 'told', 'tomorrow', 'too', 'took', 'tore', 'tought', 'toward', 'tried', 'tries', 'trust', 'try', 'turn', 'two', 'under', 'until', 'up', 'upon', 'us', 'use', 'usual', 'various', 'verb', 'very', 'visit', 'want', 'was', 'we', 'well', 'went', 'were', 'what', 'when', 'where', 'whether', 'which', 'while', 'white', 'who', 'whom', 'whose', 'why', 'will', 'with', 'within', 'without', 'would', 'yes', 'yet', 'you', 'young', 'your', 'br', 'img', 'p','lt', 'gt', 'quot', 'copy');
    public static $min_word_length = 4;
    
    public static function text($text, $length = 160)
    {
        return self::limit_chars(self::clean($text), $length,'',TRUE);
    } 

    public static function keywords($text, $max_keys = 3)
    {
        include (dirname(__FILE__) . "/res/diacritics.php");
        $wordcount = array_count_values(str_word_count(self::clean($text), 1, $diacritics));
        foreach ($wordcount as $key => $value) 
        {
            if ( (strlen($key)<= self::$min_word_length) OR in_array($key, self::$banned_words))
                unset($wordcount[$key]);
        }
        uasort($wordcount,array('self','cmp'));
        $wordcount = array_slice($wordcount,0, $max_keys);
        return implode(' ', array_keys($wordcount));
    } 

    private static function clean($text)
    { 
        $text = html_entity_decode($text,ENT_QUOTES,self::$charset);
        $text = strip_tags($text);
        $text = preg_replace('/\s\s+/', ' ', $text);
        $text = str_replace (array('\r\n', '\n', '+'), ',', $text);
        return trim($text); 
    } 

    private static function cmp($a, $b) 
    {
        if ($a == $b) return 0; 

        return ($a < $b) ? 1 : -1; 
    } 

    private static function limit_chars($str, $limit = 100, $end_char = NULL, $preserve_words = FALSE)
    {
        $end_char = ($end_char === NULL) ? '&#8230;' : $end_char;
        $limit = (int) $limit;
        if (trim($str) === '' OR strlen($str) <= $limit)
            return $str;
        if ($limit <= 0)
            return $end_char;
        if ($preserve_words === FALSE)
            return rtrim(substr($str, 0, $limit)).$end_char;
        if ( ! preg_match('/^.{0,'.$limit.'}\s/us', $str, $matches))
            return $end_char;
        return rtrim($matches[0]).((strlen($matches[0]) === strlen($str)) ? '' : $end_char);
    }
}

function aiomatic_scrape_related_questions($query, $headings, $model, $temperature, $top_p, $presence_penalty, $frequency_penalty, $max_tokens, $headings_ai_command)
{
    $headings = intval($headings);
    $results = array();
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['valueserp_auth']) && trim($aiomatic_Main_Settings['valueserp_auth']) != '')
    {
        $serpapi = 'https://api.valueserp.com/search?q=' . urlencode($query) . '&api_key=' . trim($aiomatic_Main_Settings['valueserp_auth']);
        $html_data = aiomatic_get_web_page($serpapi);
        if ($html_data !== FALSE) 
        {
            $json = json_decode($html_data);
            if ($json !== FALSE) 
            {
                if(isset($json->related_searches[0]->query))
                {
                    foreach($json->related_searches as $qq)
                    {
                        $answer = '';
                        if(isset($qq->answer))
                        {
                            $answer = $qq->answer;
                        }
                        $rec = array("q" => $qq->query, "a" => $answer, "l" => $qq->link);
                        if(!isset($results[$qq->query]))
                        {
                            $results[$qq->query] = $rec;
                        }
                        if(count($results) >= $headings)
                        {
                            break;
                        }
                    }
                    if(count($results) > 0 && count($results) < $headings)
                    {
                        $ok = true;
                        while($ok && count($results) < $headings)
                        {
                            $last_elem = end($results);
                            $serpapi = 'https://api.valueserp.com/search?q=' . urlencode($last_elem['q']) . '&api_key=' . trim($aiomatic_Main_Settings['valueserp_auth']);
                            $html_data = aiomatic_get_web_page($serpapi);
                            if ($html_data !== FALSE) 
                            {
                                $json = json_decode($html_data);
                                if ($json !== FALSE) 
                                {
                                    if(isset($json->related_searches[0]->query))
                                    {
                                        $count_before = count($results);
                                        foreach($json->related_searches as $qq)
                                        {
                                            $answer = '';
                                            if(isset($qq->answer))
                                            {
                                                $answer = $qq->answer;
                                            }
                                            $rec = array("q" => $qq->query, "a" => $answer, "l" => $qq->link);
                                            if(!isset($results[$qq->query]))
                                            {
                                                $results[$qq->query] = $rec;
                                            }
                                            if(count($results) >= $headings)
                                            {
                                                break;
                                            }
                                        }
                                        $count_after = count($results);
                                        if($count_after == $count_before)
                                        {
                                            $ok = false;
                                        }
                                    }
                                    else
                                    {
                                        $ok = false;
                                    }
                                }
                                else
                                {
                                    $ok = false;
                                }
                            }
                            else
                            {
                                $ok = false;
                            }
                        }
                    }
                }
            }
        }
    }
    if (isset($aiomatic_Main_Settings['serpapi_auth']) && trim($aiomatic_Main_Settings['serpapi_auth']) != '')
    {
        $serpapi = 'https://serpapi.com/search.json?q=' . urlencode($query) . '&api_key=' . trim($aiomatic_Main_Settings['serpapi_auth']);
        $html_data = aiomatic_get_web_page($serpapi);
        if ($html_data !== FALSE) 
        {
            $json = json_decode($html_data);
            if ($json !== FALSE) 
            {
                if(isset($json->related_questions[0]->question))
                {
                    foreach($json->related_questions as $qq)
                    {
                        $answer = '';
                        if(isset($qq->snippet))
                        {
                            $answer = $qq->snippet;
                        }
                        elseif(isset($qq->title))
                        {
                            $answer = $qq->title;
                            if(isset($qq->list))
                            {
                                $answer .= ' ';
                                foreach($qq->list as $ll)
                                {
                                    $answer .= trim($ll, ' .') . ', ';
                                }
                                $answer = trim($answer, ' ,');
                            }
                        }
                        $rec = array("q" => $qq->question, "a" => $answer, "l" => $qq->link);
                        if(!isset($results[$qq->question]))
                        {
                            $results[$qq->question] = $rec;
                        }
                        if(count($results) >= $headings)
                        {
                            break;
                        }
                    }
                    if(count($results) > 0 && count($results) < $headings)
                    {
                        $ok = true;
                        while($ok && count($results) < $headings)
                        {
                            $last_elem = end($results);
                            $serpapi = 'https://serpapi.com/search.json?q=' . urlencode($last_elem['q']) . '&api_key=' . trim($aiomatic_Main_Settings['serpapi_auth']);
                            $html_data = aiomatic_get_web_page($serpapi);
                            if ($html_data !== FALSE) 
                            {
                                $json = json_decode($html_data);
                                if ($json !== FALSE) 
                                {
                                    if(isset($json->related_questions[0]->question))
                                    {
                                        $count_before = count($results);
                                        foreach($json->related_questions as $qq)
                                        {
                                            $answer = '';
                                            if(isset($qq->snippet))
                                            {
                                                $answer = $qq->snippet;
                                            }
                                            elseif(isset($qq->title))
                                            {
                                                $answer = $qq->title;
                                                if(isset($qq->list))
                                                {
                                                    $answer .= ' ';
                                                    foreach($qq->list as $ll)
                                                    {
                                                        $answer .= trim($ll, ' .') . ', ';
                                                    }
                                                    $answer = trim($answer, ' ,');
                                                }
                                            }
                                            $rec = array("q" => $qq->question, "a" => $answer, "l" => $qq->link);
                                            if(!isset($results[$qq->question]))
                                            {
                                                $results[$qq->question] = $rec;
                                            }
                                            if(count($results) >= $headings)
                                            {
                                                break;
                                            }
                                        }
                                        $count_after = count($results);
                                        if($count_after == $count_before)
                                        {
                                            $ok = false;
                                        }
                                    }
                                    else
                                    {
                                        $ok = false;
                                    }
                                }
                                else
                                {
                                    $ok = false;
                                }
                            }
                            else
                            {
                                $ok = false;
                            }
                        }
                    }
                }
            }
        }
    }
    if (!isset($aiomatic_Main_Settings['bing_off']) || trim($aiomatic_Main_Settings['bing_off']) != 'on')
    {
        if(count($results) < $headings)
        {
            require_once (dirname(__FILE__) . "/res/simple_html_dom.php");
            $url = "https://www.bing.com/search?q=" . urlencode($query);
            $related_expre = 'div[data-tag="RelatedQnA.Item"]';
            $html_data = aiomatic_get_web_page($url);
            if ($html_data !== FALSE) 
            {
                $html_dom_original_html = aiomatic_str_get_html($html_data);
                if($html_dom_original_html !== false && method_exists($html_dom_original_html, 'find'))
                {
                    $ret = $html_dom_original_html->find( trim($related_expre) );
                    foreach ($ret as $element ) 
                    {
                        $q = $element->find("div",0);
                        if($q !== null)
                        {
                            $q = $q->children(0);
                            if($q !== null)
                            {
                                $q = $q->children(0);
                                if($q !== null)
                                {
                                    $q = $q->children(0);
                                    if($q !== null)
                                    {
                                        $q = $q->plaintext;
                                    }
                                }
                            }
                        }
                        $a = $element->find("div",0);
                        if($a !== null)
                        {
                            $a = $a->children(1);
                            if($a !== null)
                            {
                                $a = $a->children(0);
                                if($a !== null)
                                {
                                    $a = $a->children(0);
                                    if($a !== null)
                                    {
                                        $a = $a->children(0);
                                        if($a !== null)
                                        {
                                            $a = $a->plaintext;
                                        }
                                    }
                                }
                            }
                        }
                        $l = $element->find("div",0);
                        if($l !== null)
                        {
                            $l = $l->children(1);
                            if($l !== null)
                            {
                                $l = $l->children(0);
                                if($l !== null)
                                {
                                    $l = $l->children(0);
                                    if($l !== null)
                                    {
                                        $l = $l->children(1);
                                        if($l !== null)
                                        {
                                            $l = $l->children(0);
                                            if($l !== null)
                                            {
                                                $l = $l->children(0);
                                                if($l !== null)
                                                {
                                                    $l = $l->children(0);
                                                    if($l !== null)
                                                    {
                                                        $l = $l->children(0);
                                                        if($l !== null)
                                                        {
                                                            $l = $l->getAttribute('href');
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if($q !== null && $a !== null && $l !== null)
                        {
                            $rec = array("q" => $q, "a" => $a, "l" => $l);
                            if(!isset($results[$q]))
                            {
                                $results[$q] = $rec;
                            }
                            if(count($results) >= $headings)
                            {
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                    $html_dom_original_html->clear();
                    unset($html_dom_original_html);
                }
            }
            if(count($results) > 0 && count($results) < $headings)
            {
                $ok = true;
                while($ok && count($results) < $headings)
                {
                    $last_elem = end($results);
                    sleep(1);
                    $url = "https://www.bing.com/search?q=" . urlencode($last_elem['q']);
                    $html_data = aiomatic_get_web_page($url);
                    if ($html_data !== FALSE) 
                    {
                        $html_dom_original_html = aiomatic_str_get_html($html_data);
                        if($html_dom_original_html !== false && method_exists($html_dom_original_html, 'find'))
                        {
                            $ret = $html_dom_original_html->find( trim($related_expre) );
                            if(!is_array($ret) || count($ret) == 0)
                            {
                                $html_dom_original_html->clear();
                                unset($html_dom_original_html);
                                break;
                            }
                            $count_before = count($results);
                            foreach ($ret as $element ) 
                            {
                                $q = $element->find("div",0);
                                if($q !== null)
                                {
                                    $q = $q->children(0);
                                    if($q !== null)
                                    {
                                        $q = $q->children(0);
                                        if($q !== null)
                                        {
                                            $q = $q->children(0);
                                            if($q !== null)
                                            {
                                                $q = $q->plaintext;
                                            }
                                        }
                                    }
                                }
                                $a = $element->find("div",0);
                                if($a !== null)
                                {
                                    $a = $a->children(1);
                                    if($a !== null)
                                    {
                                        $a = $a->children(0);
                                        if($a !== null)
                                        {
                                            $a = $a->children(0);
                                            if($a !== null)
                                            {
                                                $a = $a->children(0);
                                                if($a !== null)
                                                {
                                                    $a = $a->plaintext;
                                                }
                                            }
                                        }
                                    }
                                }
                                $l = $element->find("div",0);
                                if($l !== null)
                                {
                                    $l = $l->children(1);
                                    if($l !== null)
                                    {
                                        $l = $l->children(0);
                                        if($l !== null)
                                        {
                                            $l = $l->children(0);
                                            if($l !== null)
                                            {
                                                $l = $l->children(1);
                                                if($l !== null)
                                                {
                                                    $l = $l->children(0);
                                                    if($l !== null)
                                                    {
                                                        $l = $l->children(0);
                                                        if($l !== null)
                                                        {
                                                            $l = $l->children(0);
                                                            if($l !== null)
                                                            {
                                                                $l = $l->children(0);
                                                                if($l !== null)
                                                                {
                                                                    $l = $l->getAttribute('href');
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if($q !== null && $a !== null && $l !== null)
                                {
                                    $rec = array("q" => $q, "a" => $a, "l" => $l);
                                    if(!isset($results[$q]))
                                    {
                                        $results[$q] = $rec;
                                    }
                                    if(count($results) >= $headings)
                                    {
                                        break;
                                    }
                                }
                                else
                                {
                                    break;
                                }
                            }
                            $count_after = count($results);
                            if($count_after == $count_before)
                            {
                                $ok = false;
                            }
                            $html_dom_original_html->clear();
                            unset($html_dom_original_html);
                        }
                        else
                        {
                            $ok = false;
                        }
                    }
                    else
                    {
                        $ok == false;
                    }
                }
            }
        }
    }
    if (!isset($aiomatic_Main_Settings['ai_off']) || trim($aiomatic_Main_Settings['ai_off']) != 'on')
    {
        if(count($results) < $headings)
        {
            $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
            if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
            {
                return $results;
            }
            $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
            $appids = array_filter($appids);
            $token = $appids[array_rand($appids)];
            if(empty($headings_ai_command))
            {
                $headings_ai_command = 'Write ' . ($headings - count($results)) . ' PAA related questions, each on a new line, for the title: "' . $query . '"';
            }
            else
            {
                $headings_ai_command = str_replace('%%needed_heading_count%%', $headings - count($results), $headings_ai_command);
                $headings_ai_command = str_replace('%%post_title%%', $query, $headings_ai_command);
            }
            $query_token_count = count(aiomatic_encode($headings_ai_command));
            $available_tokens = $max_tokens - $query_token_count;
            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
            {
                $string_len = strlen($headings_ai_command);
                $string_len = $string_len / 2;
                $string_len = intval(0 - $string_len);
                $headings_ai_command = aiomatic_substr($headings_ai_command, 0, $string_len);
                $headings_ai_command = trim($headings_ai_command);
                $query_token_count = count(aiomatic_encode($headings_ai_command));
                $available_tokens = $max_tokens - $query_token_count;
            }
            if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
            {
                $api_service = aiomatic_get_api_service($token);
                aiomatic_log_to_file('Calling ' . $api_service . ' (' . $model . ') for headings generator: ' . $headings_ai_command);
            }
            $aierror = '';
            $finish_reason = '';
            $generated_text = aiomatic_generate_text($token, $model, $headings_ai_command, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'shortcodeHeadingsArticle', 0, $finish_reason, $aierror);
            if($generated_text === false)
            {
                aiomatic_log_to_file('Title generator error: ' . $aierror);
                return $results;
            }
            else
            {
                $generated_text = ucfirst(trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\'')));
                $generated_text_arr = preg_split('/\r\n|\r|\n/', $generated_text);
                $generated_text_arr = array_filter($generated_text_arr);
                foreach($generated_text_arr as $gen_head)
                {
                    $rec = array("q" => $gen_head, "a" => '', "l" => '');
                    if(!isset($results[$gen_head]))
                    {
                        $results[$gen_head] = $rec;
                    }
                    if(count($results) >= $headings)
                    {
                        break;
                    }
                }
            }
        }
    }
    return $results;
}
function aiomatic_is_aiomaticapi_key($token)
{
    $token_prepro = explode('_', $token);
    if(isset($token_prepro[1]) && strlen($token_prepro[1]) > 10 && is_numeric($token_prepro[0]))
    {
        return true;
    }
    return false;
}
function aiomatic_is_trained_model($model)
{
    if(stristr($model, ':ft-') !== false)
    {
        return true;
    }
    return false;
}
function aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, $retry_count, &$finish_reason, &$error, $no_internet = false)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $embeddings_enabled = false;
    $internet_enabled = false;
    $max_tokens = aiomatic_get_max_tokens($model);
    if(stristr($env, 'singlePostWriter') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_single']) && $aiomatic_Main_Settings['embeddings_single'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_single']) && $aiomatic_Main_Settings['internet_single'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'shortcodeHeadingsArticle') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_related']) && $aiomatic_Main_Settings['embeddings_related'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_related']) && $aiomatic_Main_Settings['internet_related'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'formsText') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_forms']) && $aiomatic_Main_Settings['embeddings_forms'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_forms']) && $aiomatic_Main_Settings['internet_forms'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'aiAssistantWriter') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_assistant']) && $aiomatic_Main_Settings['embeddings_assistant'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_assistant']) && $aiomatic_Main_Settings['internet_assistant'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'shortcodeContentArticle') !== false || stristr($env, 'shortcodeHeadingArticle') !== false || stristr($env, 'shortcodeKeywordArticle') !== false || stristr($env, 'shortcodeCompletion') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_article_short']) && $aiomatic_Main_Settings['embeddings_article_short'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_article_short']) && $aiomatic_Main_Settings['internet_article_short'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'shortcodeChat') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_chat_short']) && $aiomatic_Main_Settings['embeddings_chat_short'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_chat_short']) && $aiomatic_Main_Settings['internet_chat_short'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'shortcodeCEditor') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_edit_short']) && $aiomatic_Main_Settings['embeddings_edit_short'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_edit_short']) && $aiomatic_Main_Settings['internet_edit_short'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'keywordCompletion') !== false || stristr($env, 'titleCEditor') !== false || stristr($env, 'contentCEditor') !== false || stristr($env, 'contentCompletion') !== false || stristr($env, 'headingCompletion') !== false || stristr($env, 'excerptCEditor') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_edit']) && $aiomatic_Main_Settings['embeddings_edit'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_edit']) && $aiomatic_Main_Settings['internet_edit'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'tagID') !== false || stristr($env, 'categoryID') !== false || stristr($env, 'keywordID') !== false || stristr($env, 'titleID') !== false || stristr($env, 'contentID') !== false || stristr($env, 'headingID') !== false || stristr($env, 'topicContentWriter') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_bulk']) && $aiomatic_Main_Settings['embeddings_bulk'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_bulk']) && $aiomatic_Main_Settings['internet_bulk'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    if($no_internet !== true && $internet_enabled == true)
    {
        if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
        {
            aiomatic_log_to_file('Getting internet search results for : ' . $aicontent);
        }
        $internet_prompt = '';
        if(isset($aiomatic_Main_Settings['internet_prompt']) && $aiomatic_Main_Settings['internet_prompt'] != '')
        {
            $internet_prompt = $aiomatic_Main_Settings['internet_prompt'];
        }
        if(stristr($internet_prompt, '%%web_results%%') !== false)
        {
            $internet_rez = aiomatic_internet_result($aicontent);
            shuffle($internet_rez);
            if (isset($aiomatic_Main_Settings['results_num']) && trim($aiomatic_Main_Settings['results_num']) != '')
            {
                $results = intval(trim($aiomatic_Main_Settings['results_num']));
            }
            else
            {
                $results = 3;
            }
            $gotcnt = 0;
            $internet_results = '';
            foreach($internet_rez as $emb)
            {
                if($gotcnt >= $results)
                {
                    break;
                }
                if (isset($aiomatic_Main_Settings['internet_single_template']) && trim($aiomatic_Main_Settings['internet_single_template']) != '')
                {
                    $internet_single_template = $aiomatic_Main_Settings['internet_single_template'];
                }
                else
                {
                    $internet_single_template = '[%%result_counter%%]: %%result_title%% %%result_snippet%% ' . PHP_EOL . 'URL: %%result_link%%';
                }
                $internet_single_template = str_replace('%%result_counter%%', $gotcnt + 1, $internet_single_template);
                $internet_single_template = str_replace('%%result_title%%', $emb['title'], $internet_single_template);
                $internet_single_template = str_replace('%%result_snippet%%', $emb['snippet'], $internet_single_template);
                $internet_single_template = str_replace('%%result_link%%', $emb['link'], $internet_single_template);
                $internet_results .= $internet_single_template . PHP_EOL;
                $gotcnt++;
            }
        }
        else
        {
            $internet_results = '';
        }
        if($internet_results == '')
        {
            if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
            {
                aiomatic_log_to_file('Internet search failed for text completion, no data returned!');
            }
        }
        else
        {
            if($internet_prompt != '')
            {
                $internet_prompt = str_ireplace('%%original_query%%', $aicontent, $internet_prompt);
                $internet_prompt = str_ireplace('%%current_date%%', date('Y-m-d'), $internet_prompt);
                $internet_prompt = str_ireplace('%%web_results%%', $internet_results, $internet_prompt);
                if($internet_prompt != '')
                {
                    $internet_tokens = count(aiomatic_encode($internet_prompt));
                    if($internet_tokens > $max_tokens - 300)
                    {
                        aiomatic_log_to_file('Negative available tokens resulted after internet results, skipping it.');
                    }
                    else
                    {
                        if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
                        {
                            aiomatic_log_to_file('Changing prompt to: ' . $internet_prompt);
                        }
                        $aicontent = $internet_prompt;
                        $available_tokens = $max_tokens - $internet_tokens;
                    }
                }
            }
        }
    }
    $aiomatic_embedding_content = '';
    if($embeddings_enabled == true)
    {
        $embed_rez = aiomatic_embeddings_result($aicontent, $token);
        if($embed_rez['status'] == 'error')
        {
            if($embed_rez['data'] != 'No results found' && $embed_rez['data'] != 'No data returned')
            {
                aiomatic_log_to_file('Embeddings failed: ' . print_r($embed_rez, true));
            }
        }
        else
        {
            $aiomatic_embedding_content = $embed_rez['data'];
            $aicontent_temp = '"' . $aiomatic_embedding_content . '" ' . $aicontent;
            $suffix_tokens = count(aiomatic_encode($aicontent_temp));
            $available_tokens = $available_tokens - $suffix_tokens;
            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
            {
                aiomatic_log_to_file('Negative available tokens resulted after embeddings, skipping it.');
            }
            else
            {
                $aicontent = $aicontent_temp;
            }
        }
    }
    if(!aiomatic_is_aiomaticapi_key($token))
    {
        if(aiomatic_is_trained_model($model))
        {
            if (isset($aiomatic_Main_Settings['prompt_suffix']) && $aiomatic_Main_Settings['prompt_suffix'] != '')
            {
                $prompt_suffix = $aiomatic_Main_Settings['prompt_suffix'];
            }
            else
            {
                $prompt_suffix = ' ->';
            }
            if(!aiomatic_endsWith($aicontent, $prompt_suffix))
            {
                $aicontent_temp = $aicontent . $prompt_suffix;
                $suffix_tokens = count(aiomatic_encode($aicontent_temp));
                $available_tokens = $available_tokens - $suffix_tokens;
                if($available_tokens <= 0)
                {
                    aiomatic_log_to_file('Negative available tokens resulted after prompt suffix addition: ' . $prompt_suffix);
                }
                else
                {
                    $aicontent = $aicontent_temp;
                }
            }
        }
    }
    $content_tokens = count(aiomatic_encode($aicontent));
    $total_tokens = $content_tokens + $available_tokens;
    if($total_tokens > $max_tokens)
    {
        $available_tokens = $max_tokens - $content_tokens;
        if($available_tokens < AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
        {
            $string_len = strlen($aicontent);
            $string_len = $string_len / 2;
            $string_len = intval(0 - $string_len);
            $aicontent = aiomatic_substr($aicontent, 0, $string_len);
            $aicontent = trim($aicontent);
            if(empty($aicontent))
            {
                $error = 'Empty prompt returned after content trimming!';
                return false;
            }
            $query_token_count = count(aiomatic_encode($aicontent));
            $available_tokens = $max_tokens - $query_token_count;
        }
    }
    $aiomatic_Limit_Settings = get_option('aiomatic_Limit_Settings', false);
    $stop = null;
    $session = aiomatic_get_session_id();
    $mode = 'text';
    $maxResults = 1;
    $query = new Aiomatic_Query($aicontent, $available_tokens, $model, $temperature, $stop, $env, $mode, $token, $session, $maxResults, '');
    $ok = apply_filters( 'aiomatic_ai_allowed', true, $aiomatic_Limit_Settings );
    if ( $ok !== true ) {
        $error = $ok;
        return false;
    }
    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on' && AIOMATIC_IS_DEBUG === true)
    {
        aiomatic_log_to_file('Generating AI completion text using model: ' . $model . ' and prompt: ' . $aicontent);
    }
    $delay = '';
    if (isset($aiomatic_Main_Settings['request_delay']) && $aiomatic_Main_Settings['request_delay'] != '') 
    {
        if(stristr($aiomatic_Main_Settings['request_delay'], ',') !== false)
        {
            $tempo = explode(',', $aiomatic_Main_Settings['request_delay']);
            if(isset($tempo[1]) && is_numeric(trim($tempo[1])) && is_numeric(trim($tempo[0])))
            {
                $delay = rand(trim($tempo[0]), trim($tempo[1]));
            }
        }
        else
        {
            if(is_numeric(trim($aiomatic_Main_Settings['request_delay'])))
            {
                $delay = intval(trim($aiomatic_Main_Settings['request_delay']));
            }
        }
    }
    if($delay != '' && is_numeric($delay))
    {
        usleep(intval($delay) * 1000);
    }
    if($temperature < 0 || $temperature > 1)
    {
        $temperature = 1;
    }
    if($top_p < 0 || $top_p > 1)
    {
        $top_p = 1;
    }
    if($presence_penalty < -2 || $presence_penalty > 2)
    {
        $presence_penalty = 0;
    }
    if($frequency_penalty < -2 || $frequency_penalty > 2)
    {
        $frequency_penalty = 0;
    }
    if(aiomatic_is_aiomaticapi_key($token))
    {
        $pargs = array();
        $api_url = 'https://aiomaticapi.com/apis/ai/v1/text/';
        $pargs['apikey'] = trim($token);
        $pargs['model'] = trim($model);
        $pargs['temperature'] = $temperature;
        $pargs['top_p'] = $top_p;
        $pargs['presence_penalty'] = $presence_penalty;
        $pargs['frequency_penalty'] = $frequency_penalty;
        $pargs['prompt'] = trim($aicontent);
        $ai_response = aiomatic_get_web_page_api($api_url, $pargs);
        if($ai_response === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to get AiomaticAPI response!';
                return false;
            }
        }
        $ai_json = json_decode($ai_response);
        if($ai_json === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to decode AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->error))
        {
            if (stristr($ai_json->error, '[RATE LIMITED]') === false && isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after error failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error while processing AI response: ' . $ai_json->error;
                return false;
            }
        }
        if(!isset($ai_json->result))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after parse failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to parse AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->remainingtokens))
        {
            set_transient('aiomaticapi_tokens', $ai_json->remainingtokens, 86400);
        }
        apply_filters( 'aiomatic_ai_reply', $ai_json->result, $query );
        return $ai_json->result;
    }
    elseif (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        if (!isset($aiomatic_Main_Settings['azure_endpoint']) || trim($aiomatic_Main_Settings['azure_endpoint']) == '') 
        {
            $error = 'You need to enter an Azure Endpoint for this to work!';
            return false;
        }
        if(in_array($model, AIOMATIC_AZURE_MODELS) === false)
        {
            $error = 'This model is not currently supported by Azure API: ' . $model;
            return false;
        }
        if(aiomatic_is_trained_model($model))
        {
            $error = 'Fine-tuned models are not supported for Azure API';
            return false;
        }
        $localAzureDeployments = array();
        $depl_arr = aiomatic_get_deployments($token);
        foreach($depl_arr as $dar)
        {
            $localAzureDeployments[trim($dar->model)] = trim($dar->id);
        }
        $azureDeployment = '';
        foreach ( $localAzureDeployments as $dmodel => $dname ) 
        {
            if ( $dmodel === str_replace('.', '', $model) || $dmodel === $model ) {
                $azureDeployment = $dname;
                break;
            }
        }
        if ( $azureDeployment == '' ) 
        {
            $new_dep = aiomatic_update_deployments_azure($token);
            if($new_dep !== false)
            {
                $localAzureDeployments = array();
                foreach($new_dep as $dar)
                {
                    $localAzureDeployments[trim($dar->model)] = trim($dar->id);
                }
                foreach ( $localAzureDeployments as $dmodel => $dname ) 
                {
                    if ( $dmodel === str_replace('.', '', $model) || $dmodel === $model ) {
                        $azureDeployment = $dname;
                        break;
                    }
                }
            }
            if ( $azureDeployment == '' ) 
            {
                $error = 'No added Azure deployment found for model: ' . $model . ' - you need to add this model in your Azure Portal as a Deployment';
                return false;
            }
        }
        $apiurl = trailingslashit(trim($aiomatic_Main_Settings['azure_endpoint'])) . 'openai/deployments/' . $azureDeployment . '/completions' . AZURE_API_VERSION;
        $base_params = [
            'model' => str_replace('.', '', $model),
            'prompt' => $aicontent,
            'temperature' => $temperature,
            'top_p' => $top_p,
            'presence_penalty' => $presence_penalty,
            'frequency_penalty' => $frequency_penalty
        ];
        if (!isset($aiomatic_Main_Settings['no_max']) || $aiomatic_Main_Settings['no_max'] != 'on')
        {
            $base_params['max_tokens'] = $available_tokens;
        }
        try
        {
            $send_json = aiomatic_safe_json_encode($base_params);
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode API payload: ' . print_r($base_params, true);
            return false;
        }
        $api_call = wp_remote_post(
            $apiurl,
            array(
                'headers' => array( 'Content-Type' => 'application/json', 'api-key' => $token ),
                'body'        => $send_json,
                'method'      => 'POST',
                'data_format' => 'body',
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial failure: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to get initial API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                }
                else
                {
                    $error = 'Error: Failed to decode initial API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            if(isset($result->error))
            {
                $result = $result->error;
            }
            if(isset($result->type))
            {
                if($result->type == 'insufficient_quota')
                {
                    $error = 'Error: You exceeded your OpenAI quota limit, please wait a period for the quota to refill (initial call).';
                    return false;
                }
                elseif($result->type == 'invalid_request_error')
                {
                    $error = 'Error: Invalid request submitted to the completions API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                    return false;
                }
                else
                {
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after type failure: ' . print_r($api_call['body'], true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                    }
                    else
                    {
                        $error = 'Error: An error occurred when initially calling OpenAI API: ' . print_r($result, true);
                        return false;
                    }
                }
            }
            if(!isset($result->choices[0]->text))
            {
                delete_option('aiomatic_deployments_list');
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after choices failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                }
                else
                {
                    $error = 'Error: Choices not found in initial API result: ' . print_r($result, true);
                    return false;
                }
            }
            else
            {
                apply_filters( 'aiomatic_ai_reply', $result, $query );
                $finish_reason = $result->choices[0]->finish_reason;
                if($is_chat == true)
                {
                    $chat_max_characters = 16000;
                    $max_continue_characters = 4000;
                    if($finish_reason == 'stop')
                    {
                        if (empty($result->choices[0]->text) && isset($aiomatic_Main_Settings['max_chat_retry']) && $aiomatic_Main_Settings['max_chat_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_chat_retry']) && intval($aiomatic_Main_Settings['max_chat_retry']) > $retry_count)
                        {
                            aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after AI writer ended conversation.');
                            return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                        }
                        else
                        {
                            return $result->choices[0]->text;
                        }
                    }
                    else
                    {
                        $return_text = $result->choices[0]->text;
                        $aicontent .= $return_text;
                        $complet_retry_count = 0;
                        while($finish_reason != 'stop' && strlen($return_text) < $chat_max_characters)
                        {
                            if (isset($aiomatic_Main_Settings['max_chat_retry']) && $aiomatic_Main_Settings['max_chat_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_chat_retry']) && intval($aiomatic_Main_Settings['max_chat_retry']) > $complet_retry_count)
                            {
                                break;
                            }
                            $complet_retry_count++;
                            if(strlen($aicontent) > $max_continue_characters)
                            {
                                $aicontent = aiomatic_substr($aicontent, 0, (0 - $max_continue_characters));
                            }
                            $aicontent = trim($aicontent);
                            if(empty($aicontent))
                            {
                                break;
                            }
                            $query_token_count = count(aiomatic_encode($aicontent));
                            $available_tokens = $max_tokens - $query_token_count;
                            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                            {
                                $string_len = strlen($aicontent);
                                $string_len = $string_len / 2;
                                $string_len = intval(0 - $string_len);
                                $aicontent = aiomatic_substr($aicontent, 0, $string_len);
                                $aicontent = trim($aicontent);
                                if(empty($aicontent))
                                {
                                    break;
                                }
                                $query_token_count = count(aiomatic_encode($aicontent));
                                $available_tokens = $max_tokens - $query_token_count;
                            }
                            $ok = apply_filters( 'aiomatic_ai_allowed', true, $aiomatic_Limit_Settings );
                            if ( $ok !== true ) {
                                aiomatic_log_to_file('Rate limited: ' . $ok);
                                break;
                            }
                            $aierror = '';
                            $generated_text = aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, 0, $finish_reason, $aierror, $no_internet);
                            if($generated_text === false)
                            {
                                aiomatic_log_to_file('Chat response completion error: ' . $aierror);
                                break;
                            }
                            else
                            {
                                $return_text .= $generated_text;
                                $aicontent .= $generated_text;
                            }
                        }
                        return $return_text;
                    }
                }
                else
                {
                    return $result->choices[0]->text;
                }
            }
        }
    }
    else
    {
        $base_params = [
            'model' => $model,
            'prompt' => $aicontent,
            'temperature' => $temperature,
            'top_p' => $top_p,
            'presence_penalty' => $presence_penalty,
            'frequency_penalty' => $frequency_penalty
        ];
        if (!isset($aiomatic_Main_Settings['no_max']) || $aiomatic_Main_Settings['no_max'] != 'on')
        {
            $base_params['max_tokens'] = $available_tokens;
        }
        if(aiomatic_is_trained_model($model))
        {
            if (isset($aiomatic_Main_Settings['completion_suffix']) && $aiomatic_Main_Settings['completion_suffix'] != '')
            {
                $base_params['stop'] = $aiomatic_Main_Settings['completion_suffix'];
            }
            else
            {
                $base_params['stop'] = ' ###';
            }
        }
        try
        {
            $send_json = aiomatic_safe_json_encode($base_params);
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode API payload: ' . print_r($base_params, true);
            return false;
        }
        $api_call = wp_remote_post(
            'https://api.openai.com/v1/completions',
            array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ),
                'body'        => $send_json,
                'method'      => 'POST',
                'data_format' => 'body',
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial failure: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to get initial API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                }
                else
                {
                    $error = 'Error: Failed to decode initial API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            if(isset($result->error))
            {
                $result = $result->error;
            }
            if(isset($result->type))
            {
                if($result->type == 'insufficient_quota')
                {
                    $error = 'Error: You exceeded your OpenAI quota limit, please wait a period for the quota to refill (initial call).';
                    return false;
                }
                elseif($result->type == 'invalid_request_error')
                {
                    $error = 'Error: Invalid request submitted to the completions API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                    return false;
                }
                else
                {
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after type failure: ' . print_r($api_call['body'], true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                    }
                    else
                    {
                        $error = 'Error: An error occurred when initially calling OpenAI API: ' . print_r($result, true);
                        return false;
                    }
                }
            }
            if(!isset($result->choices[0]->text))
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after choices failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                }
                else
                {
                    $error = 'Error: Choices not found in initial API result: ' . print_r($result, true);
                    return false;
                }
            }
            else
            {
                apply_filters( 'aiomatic_ai_reply', $result, $query );
                $finish_reason = $result->choices[0]->finish_reason;
                if($is_chat == true)
                {
                    $chat_max_characters = 16000;
                    $max_continue_characters = 4000;
                    if($finish_reason == 'stop')
                    {
                        if (empty($result->choices[0]->text) && isset($aiomatic_Main_Settings['max_chat_retry']) && $aiomatic_Main_Settings['max_chat_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_chat_retry']) && intval($aiomatic_Main_Settings['max_chat_retry']) > $retry_count)
                        {
                            aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after AI writer ended conversation.');
                            return aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                        }
                        else
                        {
                            return $result->choices[0]->text;
                        }
                    }
                    else
                    {
                        $return_text = $result->choices[0]->text;
                        $aicontent .= $return_text;
                        $complet_retry_count = 0;
                        while($finish_reason != 'stop' && strlen($return_text) < $chat_max_characters)
                        {
                            if (isset($aiomatic_Main_Settings['max_chat_retry']) && $aiomatic_Main_Settings['max_chat_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_chat_retry']) && intval($aiomatic_Main_Settings['max_chat_retry']) > $complet_retry_count)
                            {
                                break;
                            }
                            $complet_retry_count++;
                            if(strlen($aicontent) > $max_continue_characters)
                            {
                                $aicontent = aiomatic_substr($aicontent, 0, (0 - $max_continue_characters));
                            }
                            $aicontent = trim($aicontent);
                            if(empty($aicontent))
                            {
                                break;
                            }
                            $query_token_count = count(aiomatic_encode($aicontent));
                            $available_tokens = $max_tokens - $query_token_count;
                            if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                            {
                                $string_len = strlen($aicontent);
                                $string_len = $string_len / 2;
                                $string_len = intval(0 - $string_len);
                                $aicontent = aiomatic_substr($aicontent, 0, $string_len);
                                $aicontent = trim($aicontent);
                                if(empty($aicontent))
                                {
                                    break;
                                }
                                $query_token_count = count(aiomatic_encode($aicontent));
                                $available_tokens = $max_tokens - $query_token_count;
                            }
                            $ok = apply_filters( 'aiomatic_ai_allowed', true, $aiomatic_Limit_Settings );
                            if ( $ok !== true ) {
                                aiomatic_log_to_file('Rate limited: ' . $ok);
                                break;
                            }
                            $aierror = '';
                            $generated_text = aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, 0, $finish_reason, $aierror, $no_internet);
                            if($generated_text === false)
                            {
                                aiomatic_log_to_file('Chat response completion error: ' . $aierror);
                                break;
                            }
                            else
                            {
                                $return_text .= $generated_text;
                                $aicontent .= $generated_text;
                            }
                        }
                        return $return_text;
                    }
                }
                else
                {
                    return $result->choices[0]->text;
                }
            }
        }
    }
    $error = 'Failed to finish API call correctly.';
    return false;
}
function aiomatic_generate_text($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, $retry_count, &$finish_reason, &$error, $no_internet = false)
{
    if(aiomatic_is_chatgpt_model($model))
    {
        $chatgpt_obj = array();
        $role = 'user';
        $chatgpt_obj[] = array("role" => $role, "content" => $aicontent);
        $additional_tokens = count(aiomatic_encode($role . ': '));
        if($available_tokens - $additional_tokens <= 0)
        {
            $error = 'Not enough tokens for the call: ' . $aicontent;
            return false;
        }
        else
        {
            $available_tokens = $available_tokens - $additional_tokens;
        }
        $response_text = aiomatic_generate_text_chat($token, $model, $chatgpt_obj, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, $retry_count, $finish_reason, $error, $no_internet);
        if($response_text === false)
        {
            return false;
        }
        if(stristr($response_text, '<body') !== false)
        {
            preg_match_all("/<body[^>]*>([\s\S]*?)<\s*\/body>/i", $response_text, $matches);
            if(isset($matches[1][0]))
            {
                $response_text = trim($matches[1][0]);
            }
        }
        if($is_chat == false)
        {
            $response_text = aiomatic_clean_language_model_texts($response_text);
            $response_text= trim($response_text);
        }
    }
    else
    {
        $response_text = aiomatic_generate_text_completion($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, $retry_count, $finish_reason, $error, $no_internet);
    }
    return $response_text;
}
function aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, $retry_count, &$finish_reason, &$error, $no_internet = false)
{
    if(!is_array($aicontent))
    {
        $error = 'Only arrays are supported for chat text: ' . $aicontent;
        return false;
    }
    if(empty($aicontent))
    {
        $error = 'Empty array submitted to AI chat';
        return false;
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $embeddings_enabled = false;
    $internet_enabled = false;
    $max_tokens = aiomatic_get_max_tokens($model);
    if(stristr($env, 'singlePostWriter') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_single']) && $aiomatic_Main_Settings['embeddings_single'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_single']) && $aiomatic_Main_Settings['internet_single'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'shortcodeHeadingsArticle') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_related']) && $aiomatic_Main_Settings['embeddings_related'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_related']) && $aiomatic_Main_Settings['internet_related'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'formsText') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_forms']) && $aiomatic_Main_Settings['embeddings_forms'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_forms']) && $aiomatic_Main_Settings['internet_forms'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'aiAssistantWriter') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_assistant']) && $aiomatic_Main_Settings['embeddings_assistant'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_assistant']) && $aiomatic_Main_Settings['internet_assistant'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'shortcodeContentArticle') !== false || stristr($env, 'shortcodeHeadingArticle') !== false || stristr($env, 'shortcodeKeywordArticle') !== false || stristr($env, 'shortcodeCompletion') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_article_short']) && $aiomatic_Main_Settings['embeddings_article_short'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_article_short']) && $aiomatic_Main_Settings['internet_article_short'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'shortcodeChat') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_chat_short']) && $aiomatic_Main_Settings['embeddings_chat_short'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_chat_short']) && $aiomatic_Main_Settings['internet_chat_short'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'shortcodeCEditor') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_edit_short']) && $aiomatic_Main_Settings['embeddings_edit_short'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_edit_short']) && $aiomatic_Main_Settings['internet_edit_short'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'keywordCompletion') !== false || stristr($env, 'titleCEditor') !== false || stristr($env, 'contentCEditor') !== false || stristr($env, 'contentCompletion') !== false || stristr($env, 'headingCompletion') !== false || stristr($env, 'excerptCEditor') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_edit']) && $aiomatic_Main_Settings['embeddings_edit'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_edit']) && $aiomatic_Main_Settings['internet_edit'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    elseif(stristr($env, 'tagID') !== false || stristr($env, 'categoryID') !== false || stristr($env, 'keywordID') !== false || stristr($env, 'titleID') !== false || stristr($env, 'contentID') !== false || stristr($env, 'headingID') !== false || stristr($env, 'topicContentWriter') !== false)
    {
        if(isset($aiomatic_Main_Settings['embeddings_bulk']) && $aiomatic_Main_Settings['embeddings_bulk'] == 'on')
        {
            $embeddings_enabled = true;
        }
        if(isset($aiomatic_Main_Settings['internet_bulk']) && $aiomatic_Main_Settings['internet_bulk'] == 'on')
        {
            $internet_enabled = true;
        }
    }
    $aitext = '';
    foreach($aicontent as $aimess)
    {
        $aitext .= $aimess['content'] . '\n';
    }
    $aitext = rtrim($aitext);
    $aiomatic_embedding_content = '';
    if($no_internet !== true && $internet_enabled == true)
    {
        if($no_internet !== true && $internet_enabled == true)
        {
            if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
            {
                aiomatic_log_to_file('Getting internet search results for chat');
            }
            $internet_prompt = '';
            if(isset($aiomatic_Main_Settings['internet_prompt']) && $aiomatic_Main_Settings['internet_prompt'] != '')
            {
                $internet_prompt = $aiomatic_Main_Settings['internet_prompt'];
            }
            if(stristr($internet_prompt, '%%web_results%%') !== false)
            {
                $internet_rez = aiomatic_internet_result($aicontent[0]['content']);
                shuffle($internet_rez);
                if (isset($aiomatic_Main_Settings['results_num']) && trim($aiomatic_Main_Settings['results_num']) != '')
                {
                    $results = intval(trim($aiomatic_Main_Settings['results_num']));
                }
                else
                {
                    $results = 3;
                }
                $gotcnt = 0;
                $internet_results = '';
                foreach($internet_rez as $emb)
                {
                    if($gotcnt >= $results)
                    {
                        break;
                    }
                    if (isset($aiomatic_Main_Settings['internet_single_template']) && trim($aiomatic_Main_Settings['internet_single_template']) != '')
                    {
                        $internet_single_template = $aiomatic_Main_Settings['internet_single_template'];
                    }
                    else
                    {
                        $internet_single_template = '[%%result_counter%%]: %%result_title%% %%result_snippet%% ' . PHP_EOL . 'URL: %%result_link%%';
                    }
                    $internet_single_template = str_replace('%%result_counter%%', $gotcnt + 1, $internet_single_template);
                    $internet_single_template = str_replace('%%result_title%%', $emb['title'], $internet_single_template);
                    $internet_single_template = str_replace('%%result_snippet%%', $emb['snippet'], $internet_single_template);
                    $internet_single_template = str_replace('%%result_link%%', $emb['link'], $internet_single_template);
                    $internet_results .= $internet_single_template . PHP_EOL;
                    $gotcnt++;
                }
            }
            else
            {
                $internet_results = '';
            }
            if($internet_results == '')
            {
                if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
                {
                    aiomatic_log_to_file('Internet search failed for chat, no data returned!');
                }
            }
            else
            {
                if($internet_prompt != '')
                {
                    $internet_prompt = str_ireplace('%%original_query%%', $aicontent[0]['content'], $internet_prompt);
                    $internet_prompt = str_ireplace('%%current_date%%', date('Y-m-d'), $internet_prompt);
                    $internet_prompt = str_ireplace('%%web_results%%', $internet_results, $internet_prompt);
                    if($internet_prompt != '')
                    {
                        $aicontent_copy = $aicontent;
                        $aicontent_copy[0]['content'] = $internet_prompt;
                        $prompt_tokens = 0;
                        //check if there are enough tokens
                        foreach($aicontent_copy as $aimess)
                        {
                            $prompt_tokens += count(aiomatic_encode($aimess['content'])) + count(aiomatic_encode($aimess['role']));
                        }
                        if($max_tokens - AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS > $prompt_tokens)
                        {
                            $aicontent = $aicontent_copy;
                            $available_tokens = $max_tokens - $prompt_tokens;
                        }
                        else
                        {
                            if(strlen($internet_prompt) > 1000)
                            {
                                $internet_prompt = aiomatic_substr($internet_prompt, 0, 1000);
                                $aicontent_copy[0]['content'] = $internet_prompt;
                                $prompt_tokens = 0;
                                //check if there are enough tokens
                                foreach($aicontent_copy as $aimess)
                                {
                                    $prompt_tokens += count(aiomatic_encode($aimess['content'])) + count(aiomatic_encode($aimess['role']));
                                }
                            }
                            if($max_tokens - AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS > $prompt_tokens)
                            {
                                $aicontent = $aicontent_copy;
                                $available_tokens = $max_tokens - $prompt_tokens;
                            }
                            else
                            {
                                if($max_tokens - 100 > $prompt_tokens)
                                {
                                    $aicontent = $aicontent_copy;
                                    $available_tokens = $max_tokens - $prompt_tokens;
                                }
                                else
                                {
                                    aiomatic_log_to_file('Negative available tokens resulted after internet search, skipping it.');
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if($embeddings_enabled == true)
    {
        $embed_rez = aiomatic_embeddings_result($aitext, $token);
        if($embed_rez['status'] == 'error')
        {
            if($embed_rez['data'] != 'No results found' && $embed_rez['data'] != 'No data returned')
            {
                aiomatic_log_to_file('Embeddings failed for chat: ' . print_r($embed_rez, true));
            }
        }
        else
        {
            $prompt_tokens = 0;
            $aicontent_copy = $aicontent;
            $aicontent_copy[0]['content'] = $embed_rez['data'];
            $prompt_tokens = 0;
            //check if there are enough tokens
            foreach($aicontent_copy as $aimess)
            {
                $prompt_tokens += count(aiomatic_encode($aimess['content'])) + count(aiomatic_encode($aimess['role']));
            }
            if($max_tokens - AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS > $prompt_tokens)
            {
                $aicontent = $aicontent_copy;
                $available_tokens = $max_tokens - $prompt_tokens;
            }
            else
            {
                if(strlen($embed_rez['data']) > 1000)
                {
                    $embed_rez['data'] = aiomatic_substr($embed_rez['data'], 0, 1000);
                    $aicontent_copy[0]['content'] = $embed_rez['data'];
                    $prompt_tokens = 0;
                    //check if there are enough tokens
                    foreach($aicontent_copy as $aimess)
                    {
                        $prompt_tokens += count(aiomatic_encode($aimess['content'])) + count(aiomatic_encode($aimess['role']));
                    }
                }
                if($max_tokens - AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS > $prompt_tokens)
                {
                    $aicontent = $aicontent_copy;
                    $available_tokens = $max_tokens - $prompt_tokens;
                }
                else
                {
                    if($max_tokens - 100 > $prompt_tokens)
                    {
                        $aicontent = $aicontent_copy;
                        $available_tokens = $max_tokens - $prompt_tokens;
                    }
                    else
                    {
                        aiomatic_log_to_file('Negative available tokens resulted after internet search, skipping it.');
                    }
                }
            }
        }
    }
    $content_tokens = count(aiomatic_encode($aitext));
    $total_tokens = $content_tokens + $available_tokens;
    if($total_tokens > $max_tokens)
    {
        $available_tokens = $max_tokens - $content_tokens;
        if($available_tokens < AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
        {
            $string_len = strlen($aitext);
            $string_len = $string_len / 2;
            $string_len = intval(0 - $string_len);
            $aitext = aiomatic_substr($aitext, 0, $string_len);
            $aitext = trim($aitext);
            if(empty($aitext))
            {
                $error = 'Empty prompt returned after content trimming!';
                return false;
            }
            $query_token_count = count(aiomatic_encode($aitext));
            $available_tokens = $max_tokens - $query_token_count;
        }
    }
    $aiomatic_Limit_Settings = get_option('aiomatic_Limit_Settings', false);
    $stop = null;
    $session = aiomatic_get_session_id();
    $mode = 'text';
    $maxResults = 1;
    $query = new Aiomatic_Query($aitext, $available_tokens, $model, $temperature, $stop, $env, $mode, $token, $session, $maxResults, '');
    $ok = apply_filters( 'aiomatic_ai_allowed', true, $aiomatic_Limit_Settings );
    if ( $ok !== true ) {
        $error = $ok;
        return false;
    }
    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on' && AIOMATIC_IS_DEBUG === true)
    {
        aiomatic_log_to_file('Generating chat AI text using model: ' . $model . ' and prompt: ' . $aitext);
    }
    $delay = '';
    if (isset($aiomatic_Main_Settings['request_delay']) && $aiomatic_Main_Settings['request_delay'] != '') 
    {
        if(stristr($aiomatic_Main_Settings['request_delay'], ',') !== false)
        {
            $tempo = explode(',', $aiomatic_Main_Settings['request_delay']);
            if(isset($tempo[1]) && is_numeric(trim($tempo[1])) && is_numeric(trim($tempo[0])))
            {
                $delay = rand(trim($tempo[0]), trim($tempo[1]));
            }
        }
        else
        {
            if(is_numeric(trim($aiomatic_Main_Settings['request_delay'])))
            {
                $delay = intval(trim($aiomatic_Main_Settings['request_delay']));
            }
        }
    }
    if($delay != '' && is_numeric($delay))
    {
        usleep(intval($delay) * 1000);
    }
    if($temperature < 0 || $temperature > 1)
    {
        $temperature = 1;
    }
    if($top_p < 0 || $top_p > 1)
    {
        $top_p = 1;
    }
    if($presence_penalty < -2 || $presence_penalty > 2)
    {
        $presence_penalty = 0;
    }
    if($frequency_penalty < -2 || $frequency_penalty > 2)
    {
        $frequency_penalty = 0;
    }
    if(aiomatic_is_aiomaticapi_key($token))
    {
        $pargs = array();
        $api_url = 'https://aiomaticapi.com/apis/ai/v1/chat/';
        $pargs['apikey'] = trim($token);
        $pargs['model'] = trim($model);
        $pargs['temperature'] = $temperature;
        $pargs['top_p'] = $top_p;
        $pargs['presence_penalty'] = $presence_penalty;
        $pargs['frequency_penalty'] = $frequency_penalty;
        $pargs['messages'] = $aicontent;
        $ai_response = aiomatic_get_web_page_api($api_url, $pargs);
        if($ai_response === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to get AiomaticAPI response!';
                return false;
            }
        }
        $ai_json = json_decode($ai_response);
        if($ai_json === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to decode AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->error))
        {
            if (stristr($ai_json->error, '[RATE LIMITED]') === false && isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after error failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error while processing AI response: ' . $ai_json->error;
                return false;
            }
        }
        if(!isset($ai_json->result->content))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after parse failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to parse AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->remainingtokens))
        {
            set_transient('aiomaticapi_tokens', $ai_json->remainingtokens, 86400);
        }
        apply_filters( 'aiomatic_ai_reply', $ai_json->result, $query );
        return $ai_json->result->content;
    }
    elseif (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        if (!isset($aiomatic_Main_Settings['azure_endpoint']) || trim($aiomatic_Main_Settings['azure_endpoint']) == '') 
        {
            $error = 'You need to enter an Azure Endpoint for this to work!';
            return false;
        }
        if(in_array($model, AIOMATIC_AZURE_MODELS) === false)
        {
            $error = 'This model is not currently supported by Azure API: ' . $model;
            return false;
        }
        if(aiomatic_is_trained_model($model))
        {
            $error = 'Fine-tuned models are not supported for Azure API';
            return false;
        }
        $localAzureDeployments = array();
        $depl_arr = aiomatic_get_deployments($token);
        foreach($depl_arr as $dar)
        {
            $localAzureDeployments[trim($dar->model)] = trim($dar->id);
        }
        $azureDeployment = '';
        foreach ( $localAzureDeployments as $dmodel => $dname ) 
        {
            if ( $dmodel === str_replace('.', '', $model) || $dmodel === $model ) {
                $azureDeployment = $dname;
                break;
            }
        }
        if ( $azureDeployment == '' ) 
        {
            $new_dep = aiomatic_update_deployments_azure($token);
            if($new_dep !== false)
            {
                $localAzureDeployments = array();
                foreach($new_dep as $dar)
                {
                    $localAzureDeployments[trim($dar->model)] = trim($dar->id);
                }
                foreach ( $localAzureDeployments as $dmodel => $dname ) 
                {
                    if ( $dmodel === str_replace('.', '', $model) || $dmodel === $model ) {
                        $azureDeployment = $dname;
                        break;
                    }
                }
            }
            if ( $azureDeployment == '' ) 
            {
                $error = 'No added Azure deployment found for model: ' . $model . ' - you need to add this model in your Azure Portal as a Deployment';
                return false;
            }
        }
        $apiurl = trailingslashit(trim($aiomatic_Main_Settings['azure_endpoint'])) . 'openai/deployments/' . $azureDeployment . '/chat/completions' . AZURE_API_VERSION;
        $base_params = [
            'model' => str_replace('.', '', $model),
            'messages' => $aicontent,
            'temperature' => $temperature,
            'top_p' => $top_p,
            'presence_penalty' => $presence_penalty,
            'frequency_penalty' => $frequency_penalty
        ];
        if (!isset($aiomatic_Main_Settings['no_max']) || $aiomatic_Main_Settings['no_max'] != 'on')
        {
            $base_params['max_tokens'] = $available_tokens;
        }
        if(aiomatic_is_trained_model($model))
        {
            if (isset($aiomatic_Main_Settings['completion_suffix']) && $aiomatic_Main_Settings['completion_suffix'] != '')
            {
                $base_params['stop'] = $aiomatic_Main_Settings['completion_suffix'];
            }
            else
            {
                $base_params['stop'] = ' ###';
            }
        }
        try
        {
            $send_json = aiomatic_safe_json_encode($base_params);
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in chat API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode chat API payload: ' . print_r($base_params, true);
            return false;
        }
        $api_call = wp_remote_post(
            $apiurl,
            array(
                'headers' => array( 'Content-Type' => 'application/json', 'api-key' => $token ),
                'body'        => $send_json,
                'method'      => 'POST',
                'data_format' => 'body',
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after initial failure: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to get initial chat API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after decode failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                }
                else
                {
                    $error = 'Error: Failed to decode initial chat API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            if(isset($result->error))
            {
                $result = $result->error;
            }
            if(isset($result->type))
            {
                if($result->type == 'insufficient_quota')
                {
                    $error = 'Error: You exceeded your OpenAI quota limit, please wait a period for the quota to refill (chat initial call).';
                    return false;
                }
                elseif($result->type == 'invalid_request_error')
                {
                    $error = 'Error: Invalid request submitted to the chat API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                    return false;
                }
                else
                {
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after type failure: ' . print_r($api_call['body'], true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                    }
                    else
                    {
                        $error = 'Error: An error occurred when initially calling OpenAI chat API: ' . print_r($result, true);
                        return false;
                    }
                }
            }
            if(!isset($result->choices[0]->message->content))
            {
                delete_option('aiomatic_deployments_list');
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after choices failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                }
                else
                {
                    $error = 'Error: Choices not found in initial Azure chat API result: ' . print_r($result, true);
                    return false;
                }
            }
            else
            {
                apply_filters( 'aiomatic_ai_reply', $result, $query );
                $finish_reason = $result->choices[0]->finish_reason;
                if($is_chat == true)
                {
                    if (empty($result->choices[0]->message->content) && isset($aiomatic_Main_Settings['max_chat_retry']) && $aiomatic_Main_Settings['max_chat_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_chat_retry']) && intval($aiomatic_Main_Settings['max_chat_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after AI writer ended conversation.');
                        return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                    }
                    else
                    {
                        return $result->choices[0]->message->content;
                    }
                }
                else
                {
                    return $result->choices[0]->message->content;
                }
            }
        }
    }
    else
    {
        $base_params = [
            'model' => $model,
            'messages' => $aicontent,
            'temperature' => $temperature,
            'top_p' => $top_p,
            'presence_penalty' => $presence_penalty,
            'frequency_penalty' => $frequency_penalty
        ];
        if (!isset($aiomatic_Main_Settings['no_max']) || $aiomatic_Main_Settings['no_max'] != 'on')
        {
            $base_params['max_tokens'] = $available_tokens;
        }
        if(aiomatic_is_trained_model($model))
        {
            if (isset($aiomatic_Main_Settings['completion_suffix']) && $aiomatic_Main_Settings['completion_suffix'] != '')
            {
                $base_params['stop'] = $aiomatic_Main_Settings['completion_suffix'];
            }
            else
            {
                $base_params['stop'] = ' ###';
            }
        }
        try
        {
            $send_json = aiomatic_safe_json_encode($base_params);
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in chat API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode chat API payload: ' . print_r($base_params, true);
            return false;
        }
        $api_call = wp_remote_post(
            'https://api.openai.com/v1/chat/completions',
            array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ),
                'body'        => $send_json,
                'method'      => 'POST',
                'data_format' => 'body',
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after initial failure: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
            }
            else
            {
                $error = 'Error: Failed to get initial chat API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after decode failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                }
                else
                {
                    $error = 'Error: Failed to decode initial chat API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            if(isset($result->error))
            {
                $result = $result->error;
            }
            if(isset($result->type))
            {
                if($result->type == 'insufficient_quota')
                {
                    $error = 'Error: You exceeded your OpenAI quota limit, please wait a period for the quota to refill (chat initial call).';
                    return false;
                }
                elseif($result->type == 'invalid_request_error')
                {
                    $error = 'Error: Invalid request submitted to the chat API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                    return false;
                }
                else
                {
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after type failure: ' . print_r($api_call['body'], true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                    }
                    else
                    {
                        $error = 'Error: An error occurred when initially calling OpenAI chat API: ' . print_r($result, true);
                        return false;
                    }
                }
            }
            if(!isset($result->choices[0]->message->content))
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after choices failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                }
                else
                {
                    $error = 'Error: Choices not found in initial OpenAI chat API result: ' . print_r($result, true);
                    return false;
                }
            }
            else
            {
                apply_filters( 'aiomatic_ai_reply', $result, $query );
                $finish_reason = $result->choices[0]->finish_reason;
                if($is_chat == true)
                {
                    if (empty($result->choices[0]->message->content) && isset($aiomatic_Main_Settings['max_chat_retry']) && $aiomatic_Main_Settings['max_chat_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_chat_retry']) && intval($aiomatic_Main_Settings['max_chat_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after AI writer ended conversation.');
                        return aiomatic_generate_text_chat($token, $model, $aicontent, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, $is_chat, $env, intval($retry_count) + 1, $finish_reason, $error, $no_internet);
                    }
                    else
                    {
                        return $result->choices[0]->message->content;
                    }
                }
                else
                {
                    return $result->choices[0]->message->content;
                }
            }
        }
    }
    $error = 'Failed to finish chat API call correctly.';
    return false;
}

function aiomatic_get_models($token, $retry_count, &$error)
{
    $delay = '';
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        $error = 'Azure API is not currently supported for model listing.';
        return false;
    }
    if (isset($aiomatic_Main_Settings['request_delay']) && $aiomatic_Main_Settings['request_delay'] != '') 
    {
        if(stristr($aiomatic_Main_Settings['request_delay'], ',') !== false)
        {
            $tempo = explode(',', $aiomatic_Main_Settings['request_delay']);
            if(isset($tempo[1]) && is_numeric(trim($tempo[1])) && is_numeric(trim($tempo[0])))
            {
                $delay = rand(trim($tempo[0]), trim($tempo[1]));
            }
        }
        else
        {
            if(is_numeric(trim($aiomatic_Main_Settings['request_delay'])))
            {
                $delay = intval(trim($aiomatic_Main_Settings['request_delay']));
            }
        }
    }
    if($delay != '' && is_numeric($delay))
    {
        usleep($delay);
    }
    if(aiomatic_is_aiomaticapi_key($token))
    {
        $pargs = array();
        $api_url = 'https://aiomaticapi.com/apis/ai/v1/models/';
        $pargs['apikey'] = trim($token);
        $ai_response = aiomatic_get_web_page_api($api_url, $pargs);
        if($ai_response === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') AiomaticAPI model API call after initial failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_get_models($token, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to get AiomaticAPI response!';
                return false;
            }
        }
        $ai_json = json_decode($ai_response);
        if($ai_json === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') AiomaticAPI model API call after decode failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_get_models($token, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to decode AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->error))
        {
            if (stristr($ai_json->error, '[RATE LIMITED]') === false && isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') AiomaticAPI model API call after error failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_get_models($token, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error while processing AI response: ' . $ai_json->error;
                return false;
            }
        }
        if(!isset($ai_json->result))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') AiomaticAPI model API call after result failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_get_models($token, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to parse AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->remainingtokens))
        {
            set_transient('aiomaticapi_tokens', $ai_json->remainingtokens, 86400);
        }
        return $ai_json->result;
    }
    else
    {
        $api_call = wp_remote_get(
            'https://api.openai.com/v1/models',
            array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ),
                'data_format' => 'body',
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') model API call after initial failure: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_get_models($token, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to get initial API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') model API call after decode failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_get_models($token, intval($retry_count) + 1, $error);
                }
                else
                {
                    $error = 'Error: Failed to decode initial API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            if(isset($result->error))
            {
                $result = $result->error;
            }
            if(isset($result->type))
            {
                if($result->type == 'insufficient_quota')
                {
                    $error = 'Error: You exceeded your OpenAI quota limit, please wait a period for the quota to refill (initial call).';
                    return false;
                }
                elseif($result->type == 'invalid_request_error')
                {
                    $error = 'Error: Invalid request submitted to the models API! Result: ' . print_r($result, true);
                    return false;
                }
                else
                {
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') model API call after type failure: ' . print_r($api_call['body'], true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_get_models($token, intval($retry_count) + 1, $error);
                    }
                    else
                    {
                        $error = 'Error: An error occurred when initially calling OpenAI models API: ' . print_r($result, true);
                        return false;
                    }
                }
            }
            if(!isset($result->data[0]->id))
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') model API call after choices failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_get_models($token, intval($retry_count) + 1, $error);
                }
                else
                {
                    $error = 'Error: Choices not found in initial API result: ' . print_r($result, true);
                    return false;
                }
            }
            else
            {
                return $result->data;
            }
        }
    }
    $error = 'Failed to finish API call correctly.';
    return false;
}

function aiomatic_edit_text($token, $model, $instruction, $aicontent, $temperature, $top_p, $env, $retry_count, &$error)
{
    $aiomatic_Limit_Settings = get_option('aiomatic_Limit_Settings', false);
    $stop = null;
    $session = aiomatic_get_session_id();
    $mode = 'edit';
    $maxResults = 1;
    $available_tokens = 1000;
    $query = new Aiomatic_Query($aicontent, $available_tokens, $model, $temperature, $stop, $env, $mode, $token, $session, $maxResults, '');
    $ok = apply_filters( 'aiomatic_ai_allowed', true, $aiomatic_Limit_Settings );
    if ( $ok !== true ) {
        $error = $ok;
        return false;
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        $error = 'Azure API is not currently supported for edit endpoints.';
        return false;
    }
    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on' && AIOMATIC_IS_DEBUG === true)
    {
        aiomatic_log_to_file('Generating AI editing using model: ' . $model . ' using instruction: "' . $instruction . '" and text: "' . $aicontent . '"');
    }
    $delay = '';
    if (isset($aiomatic_Main_Settings['request_delay']) && $aiomatic_Main_Settings['request_delay'] != '') 
    {
        if(stristr($aiomatic_Main_Settings['request_delay'], ',') !== false)
        {
            $tempo = explode(',', $aiomatic_Main_Settings['request_delay']);
            if(isset($tempo[1]) && is_numeric(trim($tempo[1])) && is_numeric(trim($tempo[0])))
            {
                $delay = rand(trim($tempo[0]), trim($tempo[1]));
            }
        }
        else
        {
            if(is_numeric(trim($aiomatic_Main_Settings['request_delay'])))
            {
                $delay = intval(trim($aiomatic_Main_Settings['request_delay']));
            }
        }
    }
    if($delay != '' && is_numeric($delay))
    {
        usleep($delay);
    }
    if(aiomatic_is_aiomaticapi_key($token))
    {
        $pargs = array();
        $api_url = 'https://aiomaticapi.com/apis/ai/v1/edit/';
        $pargs['apikey'] = trim($token);
        $pargs['temperature'] = $temperature;
        $pargs['top_p'] = $top_p;
        $pargs['instruction'] = trim($instruction);
        $pargs['input'] = trim($aicontent);
        $pargs['model'] = trim($model);
        $ai_response = aiomatic_get_web_page_api($api_url, $pargs);
        if($ai_response === false)
        {
            $error = 'Error: Failed to get AiomaticAPI response!';
            return false;
        }
        $ai_json = json_decode($ai_response);
        if($ai_json === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode edit failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_edit_text($token, $model, $instruction, $aicontent, $temperature, $top_p, $env, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to decode AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->error))
        {
            if (stristr($ai_json->error, '[RATE LIMITED]') === false && isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after error edit failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_edit_text($token, $model, $instruction, $aicontent, $temperature, $top_p, $env, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error while processing AI response: ' . $ai_json->error;
                return false;
            }
        }
        if(!isset($ai_json->result))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after result edit failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_edit_text($token, $model, $instruction, $aicontent, $temperature, $top_p, $env, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to parse AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->remainingtokens))
        {
            set_transient('aiomaticapi_tokens', $ai_json->remainingtokens, 86400);
        }
        apply_filters( 'aiomatic_ai_reply', $ai_json->result, $query );
        return $ai_json->result;
    }
    else
    {
        try
        {
            $send_json = aiomatic_safe_json_encode( [
                'model' => $model,
                'input' => $aicontent,
                'instruction' => $instruction,
                'temperature' => $temperature,
                'top_p' => $top_p
            ] );
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode API payload: ' . print_r($aicontent, true);
            return false;
        }
        $api_call = wp_remote_post(
            'https://api.openai.com/v1/edits',
            array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ),
                'body'        => $send_json,
                'method'      => 'POST',
                'data_format' => 'body',
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial edit failure: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_edit_text($token, $model, $instruction, $aicontent, $temperature, $top_p, $env, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to get initial API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode edit failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_edit_text($token, $model, $instruction, $aicontent, $temperature, $top_p, $env, intval($retry_count) + 1, $error);
                }
                else
                {
                    $error = 'Error: Failed to decode initial API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            if(isset($result->error))
            {
                $result = $result->error;
            }
            if(isset($result->type))
            {
                if($result->type == 'insufficient_quota')
                {
                    $error = 'Error: You exceeded your OpenAI quota limit, please wait a period for the quota to refill (initial call).';
                    return false;
                }
                elseif($result->type == 'invalid_request_error')
                {
                    $error = 'Error: Invalid request submitted to the edits API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                    return false;
                }
                else
                {
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial edit failure: ' . print_r($api_call['body'], true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_edit_text($token, $model, $instruction, $aicontent, $temperature, $top_p, $env, intval($retry_count) + 1, $error);
                    }
                    else
                    {
                        $error = 'Error: An error occurred when initially calling OpenAI API: ' . print_r($result, true);
                        return false;
                    }
                }
            }
            if(!isset($result->choices[0]->text))
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after choices edit failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_edit_text($token, $model, $instruction, $aicontent, $temperature, $top_p, $env, intval($retry_count) + 1, $error);
                }
                else
                {
                    $error = 'Error: Choices not found in initial API result: ' . print_r($result, true);
                    return false;
                }
            }
            else
            {
                apply_filters( 'aiomatic_ai_reply', $result, $query );
                return $result->choices[0]->text;
            }
        }
    }
    $error = 'Failed to finish API call correctly.';
    return false;
}

function aiomatic_embeddings_aiomaticapi($token, $model, $input, $retry_count, &$error)
{
    if(aiomatic_is_aiomaticapi_key($token))
    {
        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
        $pargs = array();
        $api_url = 'https://aiomaticapi.com/apis/ai/v1/embeddings/';
        $pargs['apikey'] = trim($token);
        $pargs['input'] = trim($input);
        $pargs['model'] = trim($model);
        $ai_response = aiomatic_get_web_page_api($api_url, $pargs);
        if($ai_response === false)
        {
            $error = 'Error: Failed to get AiomaticAPI response!';
            return false;
        }
        $ai_json = json_decode($ai_response);
        if($ai_json === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode embeddings failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_embeddings_aiomaticapi($token, $model, $input, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to decode AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->error))
        {
            if (stristr($ai_json->error, '[RATE LIMITED]') === false && isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after error embeddings failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_embeddings_aiomaticapi($token, $model, $input, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error while processing AI response: ' . $ai_json->error;
                return false;
            }
        }
        if(!isset($ai_json->result))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after result embeddings failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_embeddings_aiomaticapi($token, $model, $input, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to parse AiomaticAPI response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->remainingtokens))
        {
            set_transient('aiomaticapi_tokens', $ai_json->remainingtokens, 86400);
        }
        return $ai_json->result;
    }
    $error = 'This function works only for AiomaticAPI keys!';
    return false;
}

function aiomatic_embeddings_azure($token, $model, $input, $retry_count, &$error)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        if (!isset($aiomatic_Main_Settings['azure_endpoint']) || trim($aiomatic_Main_Settings['azure_endpoint']) == '') 
        {
            $error = 'You need to enter an Azure Endpoint for this to work!';
            return false;
        }
        if(in_array($model, AIOMATIC_AZURE_MODELS) === false)
        {
            $error = 'This model is not currently supported by Azure API: ' . $model;
            return false;
        }
        if(aiomatic_is_trained_model($model))
        {
            $error = 'Fine-tuned models are not supported for Azure API';
            return false;
        }
        $localAzureDeployments = array();
        $depl_arr = aiomatic_get_deployments($token);
        foreach($depl_arr as $dar)
        {
            $localAzureDeployments[trim($dar->model)] = trim($dar->id);
        }
        $azureDeployment = '';
        foreach ( $localAzureDeployments as $dmodel => $dname ) 
        {
            if ( $dmodel === str_replace('.', '', $model) || $dmodel === $model ) {
                $azureDeployment = $dname;
                break;
            }
        }
        if ( $azureDeployment == '' ) 
        {
            $new_dep = aiomatic_update_deployments_azure($token);
            if($new_dep !== false)
            {
                $localAzureDeployments = array();
                foreach($new_dep as $dar)
                {
                    $localAzureDeployments[trim($dar->model)] = trim($dar->id);
                }
                foreach ( $localAzureDeployments as $dmodel => $dname ) 
                {
                    if ( $dmodel === str_replace('.', '', $model) || $dmodel === $model ) {
                        $azureDeployment = $dname;
                        break;
                    }
                }
            }
            if ( $azureDeployment == '' ) 
            {
                $error = 'No added Azure deployment found for model: ' . $model . ' - you need to add this model in your Azure Portal as a Deployment';
                return false;
            }
        }
        $apiurl = trailingslashit(trim($aiomatic_Main_Settings['azure_endpoint'])) . 'openai/deployments/' . $azureDeployment . '/embeddings' . AZURE_API_VERSION;
        $base_params = [
            'model' => str_replace('.', '', $model),
            'input' => $input
        ];
        try
        {
            $send_json = aiomatic_safe_json_encode($base_params);
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in chat API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode chat API payload: ' . print_r($base_params, true);
            return false;
        }
        $api_call = wp_remote_post(
            $apiurl,
            array(
                'headers' => array( 'Content-Type' => 'application/json', 'api-key' => $token ),
                'body'        => $send_json,
                'method'      => 'POST',
                'data_format' => 'body',
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after initial failure: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_embeddings_azure($token, $model, $input, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to get initial chat API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after decode failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_embeddings_azure($token, $model, $input, intval($retry_count) + 1, $error);
                }
                else
                {
                    $error = 'Error: Failed to decode initial chat API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            if(isset($result->error))
            {
                $result = $result->error;
            }
            if(isset($result->type))
            {
                if($result->type == 'insufficient_quota')
                {
                    $error = 'Error: You exceeded your OpenAI quota limit, please wait a period for the quota to refill (chat initial call).';
                    return false;
                }
                elseif($result->type == 'invalid_request_error')
                {
                    $error = 'Error: Invalid request submitted to the chat API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                    return false;
                }
                else
                {
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after type failure: ' . print_r($api_call['body'], true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_embeddings_azure($token, $model, $input, intval($retry_count) + 1, $error);
                    }
                    else
                    {
                        $error = 'Error: An error occurred when initially calling OpenAI chat API: ' . print_r($result, true);
                        return false;
                    }
                }
            }
            if(!isset($result->data))
            {
                delete_option('aiomatic_deployments_list');
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') chat API call after choices failure: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_embeddings_azure($token, $model, $input, intval($retry_count) + 1, $error);
                }
                else
                {
                    $error = 'Error: Choices not found in initial chat API result: ' . print_r($result, true);
                    return false;
                }
            }
            else
            {
                $zempty = array();
                $result->data[0]->usage = (object)$zempty;
                $result->data[0]->usage->total_tokens = count(aiomatic_encode($input));
                return $result->data;
            }
        }
    }
    else
    {
        $error = 'This method is available only when Azure API is used in the plugin!';
        return false;
    }
    $error = 'Unexpected embedding error occured';
    return false;
}

function aiomatic_get_deployments($token)
{
    $deployments_option_value = get_option('aiomatic_deployments_list', false);
	if(!empty($deployments_option_value))
	{
		return $deployments_option_value;
	}
    $error = '';
    $deployments = aiomatic_list_deployments_azure($token, $error);
    if(is_array($deployments))
    {
        update_option('aiomatic_deployments_list', $deployments);
        return $deployments;
    }
    else
    {
        aiomatic_log_to_file('Failed to list deployments from Azure, error: ' . $error);
    }
	return false;
}
function aiomatic_update_deployments_azure($token)
{
    $error = '';
    $deployments = aiomatic_list_deployments_azure($token, $error);
    if(is_array($deployments))
    {
        update_option('aiomatic_deployments_list', $deployments);
        return $deployments;
    }
    else
    {
        aiomatic_log_to_file('Failed to update deployments from Azure, error: ' . $error);
    }
    return false;
}
function aiomatic_list_deployments_azure($token, &$error)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        if (!isset($aiomatic_Main_Settings['azure_endpoint']) || trim($aiomatic_Main_Settings['azure_endpoint']) == '') 
        {
            $error = 'You need to enter an Azure Endpoint for this to work!';
            return false;
        }
        $apiurl = trailingslashit(trim($aiomatic_Main_Settings['azure_endpoint'])) . 'openai/deployments' . AZURE_API_VERSION;
        $base_params = [];
        try
        {
            $send_json = aiomatic_safe_json_encode($base_params);
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in deployment listing API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode deployment listing API payload: ' . print_r($base_params, true);
            return false;
        }
        $api_call = wp_remote_get(
            $apiurl,
            array(
                'headers' => array( 'Content-Type' => 'application/json', 'api-key' => $token ),
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            $error = 'Error: Failed to get initial deployment listing API response: ' . print_r($api_call, true);
            return false;
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                $error = 'Error: Failed to decode initial deployment listing API response: ' . print_r($api_call, true);
                return false;
            }
            if(isset($result->error))
            {
                $result = $result->error;
            }
            if(isset($result->type))
            {
                if($result->type == 'insufficient_quota')
                {
                    $error = 'Error: You exceeded your OpenAI quota limit, please wait a period for the quota to refill (deployment listing initial call).';
                    return false;
                }
                elseif($result->type == 'invalid_request_error')
                {
                    $error = 'Error: Invalid request submitted to the deployment listing API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                    return false;
                }
                else
                {
                    $error = 'Error: An error occurred when initially calling OpenAI deployment listing API: ' . print_r($result, true);
                    return false;
                }
            }
            if(!isset($result->data))
            {
                $error = 'Error: Choices not found in initial deployment listing API result: ' . print_r($result, true);
                return false;
            }
            else
            {
                return $result->data;
            }
        }
    }
    else
    {
        $error = 'This method is available only when Azure API is used in the plugin!';
        return false;
    }
    $error = 'Unexpected embedding error occured';
    return false;
}

function aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, $retry_count, &$error)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $aiomatic_Limit_Settings = get_option('aiomatic_Limit_Settings', false);
    $stop = null;
    $session = aiomatic_get_session_id();
    $mode = 'image';
    $maxResults = 1;
    $temperature = 1;
    $model = 'dall-e';
    $query = new Aiomatic_Query($prompt, 1000, $model, $temperature, $stop, $env, $mode, $token, $session, $maxResults, $size);
    $ok = apply_filters( 'aiomatic_ai_allowed', true, $aiomatic_Limit_Settings );
    if ( $ok !== true ) {
        $error = $ok;
        return false;
    }
    $delay = '';
    $prompt = trim($prompt);
    if($prompt == '')
    {
        return false;
    }
    if(strlen($prompt) > 1000)
    {
        $prompt = aiomatic_substr($prompt, 0, 1000);
    }
    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on' && AIOMATIC_IS_DEBUG === true)
    {
        aiomatic_log_to_file('Generating AI Image using prompt: ' . $prompt);
    }
    if (isset($aiomatic_Main_Settings['request_delay']) && $aiomatic_Main_Settings['request_delay'] != '') 
    {
        if(stristr($aiomatic_Main_Settings['request_delay'], ',') !== false)
        {
            $tempo = explode(',', $aiomatic_Main_Settings['request_delay']);
            if(isset($tempo[1]) && is_numeric(trim($tempo[1])) && is_numeric(trim($tempo[0])))
            {
                $delay = rand(trim($tempo[0]), trim($tempo[1]));
            }
        }
        else
        {
            if(is_numeric(trim($aiomatic_Main_Settings['request_delay'])))
            {
                $delay = intval(trim($aiomatic_Main_Settings['request_delay']));
            }
        }
    }
    if($delay != '' && is_numeric($delay))
    {
        usleep($delay);
    }
    if($size != '256x256' && $size != '512x512' && $size != '1024x1024')
    {
        $size = '1024x1024';
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $return_arr = array();
    if(aiomatic_is_aiomaticapi_key($token))
    {
        $pargs = array();
        $api_url = 'https://aiomaticapi.com/apis/ai/v1/image/';
        $pargs['apikey'] = trim($token);
        $pargs['prompt'] = trim($prompt);
        $pargs['size'] = $size;
        $ai_response = aiomatic_get_web_page_api($api_url, $pargs);
        if($ai_response === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial AiomaticAPI response: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to get AiomaticAPI image response!';
                return false;
            }
        }
        $ai_json = json_decode($ai_response);
        if($ai_json === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode AiomaticAPI response: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to decode AiomaticAPI image response: ' . $ai_response;
                return false;
            }
        }
        if(isset($ai_json->error))
        {
            if (stristr($ai_json->error, '[RATE LIMITED]') === false && isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after error AiomaticAPI response: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error while processing AI image response: ' . $ai_json->error;
                return false;
            }
        }
        if(!isset($ai_json->result))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after result AiomaticAPI response: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Error: Failed to parse AiomaticAPI image response: ' . $ai_response;
                return false;
            }
        }
        apply_filters( 'aiomatic_ai_reply', $ai_json->result, $query );
        if(isset($ai_json->remainingtokens))
        {
            set_transient('aiomaticapi_tokens', $ai_json->remainingtokens, 86400);
        }
        if (isset($aiomatic_Main_Settings['copy_locally']) && $aiomatic_Main_Settings['copy_locally'] == 'on' && $nocopy === false) 
        {
            $localpath = aiomatic_copy_image_locally($ai_json->result);
            if($localpath !== false)
            {
                if ((isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '') || (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== ''))
                {
                    try
                    {
                        if(!class_exists('\Eventviva\ImageResize')){require_once (dirname(__FILE__) . "/res/ImageResize/ImageResize.php");}
                        $imageRes = new ImageResize($localpath[1]);
                        $imageRes->quality_jpg = 100;
                        if ((isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '') && (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== ''))
                        {
                            $imageRes->resizeToBestFit($aiomatic_Main_Settings['ai_resize_width'], $aiomatic_Main_Settings['ai_resize_height'], true);
                        }
                        elseif (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== '')
                        {
                            $imageRes->resizeToWidth($aiomatic_Main_Settings['ai_resize_width'], true);
                        }
                        elseif (isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '')
                        {
                            $imageRes->resizeToHeight($aiomatic_Main_Settings['ai_resize_height'], true);
                        }
                        $imageRes->save($localpath[1]);
                    }
                    catch(Exception $e)
                    {
                        aiomatic_log_to_file('Failed to resize AI generated image: ' . $localpath[0] . ' to sizes ' . $aiomatic_Main_Settings['ai_resize_width'] . ' - ' . $aiomatic_Main_Settings['ai_resize_height'] . '. Exception thrown ' . esc_html($e->getMessage()) . '!');
                    }
                }
                $return_arr[] = $localpath[0];
            }
            else
            {
                $return_arr[] = $ai_json->result;
            }
        }
        else
        {
            $return_arr[] = $ai_json->result;
        }
    }
    elseif (isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure') 
    {
        if (!isset($aiomatic_Main_Settings['azure_endpoint']) || trim($aiomatic_Main_Settings['azure_endpoint']) == '') 
        {
            $error = 'You need to enter an Azure Endpoint for this to work!';
            return false;
        }
        $apiurl = trailingslashit(trim($aiomatic_Main_Settings['azure_endpoint'])) . 'dalle/text-to-image' . AZURE_DALLE_API_VERSION;
        try
        {
            $send_json = aiomatic_safe_json_encode( [
                'caption' => $prompt,
                'resolution' => $size,
                'response_format' => 'url'
            ] );
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode API payload: ' . print_r($prompt, true);
            return false;
        }
        $api_call = wp_remote_post(
            $apiurl,
            array(
                'headers' => array( 'Content-Type' => 'application/json', 'api-key' => $token ),
                'body'        => $send_json,
                'method'      => 'POST',
                'data_format' => 'body',
                'timeout'     => 10,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial DALLE response: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Failed to get DallE API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode DALLE response: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
                }
                else
                {
                    $error = 'Failed to decode initial DallE API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            else
            {
                if(isset($result->error))
                {
                    $result = $result->error;
                }
                if(isset($result->type))
                {
                    if($result->type == 'insufficient_quota')
                    {
                        $error = 'You exceeded your OpenAI quota limit, please wait a period for the quota to refill (initial call).';
                        return false;
                    }
                    elseif($result->type == 'invalid_request_error')
                    {
                        $error = 'Error: Invalid request submitted to the image API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                        return false;
                    }
                    else
                    {
                        if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                        {
                            aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after type DALLE response: ' . print_r($api_call['body'], true));
                            sleep(pow(2, $retry_count));
                            return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
                        }
                        else
                        {
                            $error = 'An error occurred when initially calling OpenAI API, no type found: ' . print_r($result, true);
                            return false;
                        }
                    }
                }
                if(!isset($result->id) || !isset($result->status))
                {
                    delete_option('aiomatic_deployments_list');
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after incorrect DALLE response: ' . print_r($result, true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
                    }
                    else
                    {
                        $error = 'Incorrect response format for Azure Dall-E images: ' . print_r($result, true);
                        return false;
                    }
                }
                else
                {
                    $retry_after = wp_remote_retrieve_header( $api_call, 'Retry-After' );
                    if(!empty($retry_after))
                    {
                        if(!is_numeric($retry_after))
                        {
                            $error = 'Incorrect value returned for the Retry-After header: ' . print_r($retry_after, true);
                            return false;
                        }
                        $retry_after = intval($retry_after);
                    }
                    else
                    {
                        $error = 'Failed to find the Retry-After header: ' . print_r($api_call, true);
                        return false;
                    }
                    $retry_url = wp_remote_retrieve_header( $api_call, 'Operation-Location' );
                    if(empty($retry_url))
                    {
                        $error = 'Failed to find the Operation-Location header: ' . print_r($api_call, true);
                        return false;
                    }
                    $final_url = '';
                    $max_wait = 300;
                    $waited = 0;
                    while($final_url == '')
                    {
                        if($waited > $max_wait)
                        {
                            $error = 'Timeout for image generator in Azure DallEAPI: ' . print_r($prompt, true);
                            return false;
                        }
                        sleep($retry_after);
                        $waited += $retry_after;
                        $api_call = wp_remote_get(
                            $retry_url,
                            array(
                                'headers' => array( 'Content-Type' => 'application/json', 'api-key' => $token ),
                                'timeout'     => 10,
                            )
                        );
                        if(is_wp_error( $api_call ))
                        {
                            $error = 'Failed to get Azure DallE API Image URL response: ' . print_r($api_call, true);
                            return false;
                        }
                        else
                        {
                            $result = json_decode( $api_call['body'] );
                            if($result === false)
                            {
                                $error = 'Failed to decode Azure DallE API Image URL response: ' . print_r($api_call['body'], true);
                                return false;
                            }
                            if(isset($result->status) && $result->status == 'Succeeded')
                            {
                                if(isset($result->result->contentUrl) && $result->result->contentUrl != '')
                                {
                                    $final_url = $result->result->contentUrl;
                                }
                                else
                                {
                                    $error = 'Corrupted response from Azure DallE API Image URL: ' . print_r($result, true);
                                    return false;
                                }
                            }
                        }
                    }
                    if($final_url == '')
                    {
                        $error = 'Failed to generate Azure DallE API Image URL for prompt: ' . print_r($prompt, true);
                        return false;
                    }
                    apply_filters( 'aiomatic_ai_reply', $final_url, $query );
                    if (isset($aiomatic_Main_Settings['copy_locally']) && $aiomatic_Main_Settings['copy_locally'] == 'on' && $nocopy === false) 
                    {
                        $localpath = aiomatic_copy_image_locally($final_url);
                        if($localpath !== false)
                        {
                            if ((isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '') || (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== ''))
                            {
                                try
                                {
                                    if(!class_exists('\Eventviva\ImageResize')){require_once (dirname(__FILE__) . "/res/ImageResize/ImageResize.php");}
                                    $imageRes = new ImageResize($localpath[1]);
                                    $imageRes->quality_jpg = 100;
                                    if ((isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '') && (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== ''))
                                    {
                                        $imageRes->resizeToBestFit($aiomatic_Main_Settings['ai_resize_width'], $aiomatic_Main_Settings['ai_resize_height'], true);
                                    }
                                    elseif (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== '')
                                    {
                                        $imageRes->resizeToWidth($aiomatic_Main_Settings['ai_resize_width'], true);
                                    }
                                    elseif (isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '')
                                    {
                                        $imageRes->resizeToHeight($aiomatic_Main_Settings['ai_resize_height'], true);
                                    }
                                    $imageRes->save($localpath[1]);
                                }
                                catch(Exception $e)
                                {
                                    aiomatic_log_to_file('Failed to resize AI generated image: ' . $localpath[0] . ' to sizes ' . $aiomatic_Main_Settings['ai_resize_width'] . ' - ' . $aiomatic_Main_Settings['ai_resize_height'] . '. Exception thrown ' . esc_html($e->getMessage()) . '!');
                                }
                            }
                            $return_arr[] = $localpath[0];
                        }
                        else
                        {
                            $return_arr[] = $final_url;
                        }
                    }
                    else
                    {
                        $return_arr[] = $final_url;
                    }
                }
            }
        }
    }
    else
    {
        try
        {
            $send_json = aiomatic_safe_json_encode( [
                'n' => intval($number),
                'prompt' => $prompt,
                'size' => $size,
                'response_format' => 'url'
            ] );
        }
        catch(Exception $e)
        {
            $error = 'Error: Exception in API payload encoding: ' . print_r($e->getMessage(), true);
            return false;
        }
        if($send_json === false)
        {
            $error = 'Error: Failed to encode API payload: ' . print_r($prompt, true);
            return false;
        }
        $api_call = wp_remote_post(
            'https://api.openai.com/v1/images/generations',
            array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ),
                'body'        => $send_json,
                'method'      => 'POST',
                'data_format' => 'body',
                'timeout'     => 999,
            )
        );
        if(is_wp_error( $api_call ))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after initial DALLE response: ' . print_r($api_call, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
            }
            else
            {
                $error = 'Failed to get DallE API response: ' . print_r($api_call, true);
                return false;
            }
        }
        else
        {
            $result = json_decode( $api_call['body'] );
            if($result === false)
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after decode DALLE response: ' . print_r($api_call['body'], true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
                }
                else
                {
                    $error = 'Failed to decode initial DallE API response: ' . print_r($api_call, true);
                    return false;
                }
            }
            else
            {
                if(isset($result->error))
                {
                    $result = $result->error;
                }
                if(isset($result->type))
                {
                    if($result->type == 'insufficient_quota')
                    {
                        $error = 'You exceeded your OpenAI quota limit, please wait a period for the quota to refill (initial call).';
                        return false;
                    }
                    elseif($result->type == 'invalid_request_error')
                    {
                        $error = 'Error: Invalid request submitted to the image API: ' . print_r($send_json, true) . ' result: ' . print_r($result, true);
                        return false;
                    }
                    else
                    {
                        if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                        {
                            aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after type DALLE response: ' . print_r($api_call['body'], true));
                            sleep(pow(2, $retry_count));
                            return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
                        }
                        else
                        {
                            $error = 'An error occurred when initially calling OpenAI API, no type found: ' . print_r($result, true);
                            return false;
                        }
                    }
                }
                if(!isset($result->data))
                {
                    if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                    {
                        aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') API call after data DALLE response: ' . print_r($api_call['body'], true));
                        sleep(pow(2, $retry_count));
                        return aiomatic_generate_ai_image($token, $number, $prompt, $size, $env, $nocopy, intval($retry_count) + 1, $error);
                    }
                    else
                    {
                        $error = 'An error occurred when initially calling OpenAI data API: ' . print_r($result, true);
                        return false;
                    }
                }
                else
                {
                    foreach($result->data as $rdata)
                    {
                        apply_filters( 'aiomatic_ai_reply', $rdata->url, $query );
                        if (isset($aiomatic_Main_Settings['copy_locally']) && $aiomatic_Main_Settings['copy_locally'] == 'on' && $nocopy === false) 
                        {
                            $localpath = aiomatic_copy_image_locally($rdata->url);
                            if($localpath !== false)
                            {
                                if ((isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '') || (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== ''))
                                {
                                    try
                                    {
                                        if(!class_exists('\Eventviva\ImageResize')){require_once (dirname(__FILE__) . "/res/ImageResize/ImageResize.php");}
                                        $imageRes = new ImageResize($localpath[1]);
                                        $imageRes->quality_jpg = 100;
                                        if ((isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '') && (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== ''))
                                        {
                                            $imageRes->resizeToBestFit($aiomatic_Main_Settings['ai_resize_width'], $aiomatic_Main_Settings['ai_resize_height'], true);
                                        }
                                        elseif (isset($aiomatic_Main_Settings['ai_resize_width']) && $aiomatic_Main_Settings['ai_resize_width'] !== '')
                                        {
                                            $imageRes->resizeToWidth($aiomatic_Main_Settings['ai_resize_width'], true);
                                        }
                                        elseif (isset($aiomatic_Main_Settings['ai_resize_height']) && $aiomatic_Main_Settings['ai_resize_height'] !== '')
                                        {
                                            $imageRes->resizeToHeight($aiomatic_Main_Settings['ai_resize_height'], true);
                                        }
                                        $imageRes->save($localpath[1]);
                                    }
                                    catch(Exception $e)
                                    {
                                        aiomatic_log_to_file('Failed to resize AI generated image: ' . $localpath[0] . ' to sizes ' . $aiomatic_Main_Settings['ai_resize_width'] . ' - ' . $aiomatic_Main_Settings['ai_resize_height'] . '. Exception thrown ' . esc_html($e->getMessage()) . '!');
                                    }
                                }
                                $return_arr[] = $localpath[0];
                            }
                            else
                            {
                                $return_arr[] = $rdata->url;
                            }
                        }
                        else
                        {
                            $return_arr[] = $rdata->url;
                        }
                    }
                }
            }
        }
    }
    return $return_arr;
}
function aiomatic_copy_image_locally($image_url)
{
    $upload_dir = wp_upload_dir();
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
        wp_filesystem($creds);
    }
    if(substr( $image_url, 0, 10 ) === "data:image")
    {
        $data = explode(',', $image_url);
        if(isset($data[1]))
        {
            $image_data = base64_decode($data[1]);
            if($image_data === FALSE)
            {
                return false;
            }
        }
        else
        {
            return false;
        }
        preg_match('{data:image/(.*?);}', $image_url, $ex_matches);
        if(isset($ex_matches[1]))
        {
            $image_url = 'image.' . $ex_matches[1];
        }
        else
        {
            $image_url = 'image.jpg';
        }
    }
    else
    {
        $image_data = aiomatic_get_web_page($image_url);
        if ($image_data === FALSE || strpos($image_data, '<Message>Access Denied</Message>') !== FALSE) 
        {
            return false;
        }
    }
    $filename = basename($image_url);
    $filename = explode("?", $filename);
    $filename = $filename[0];
    $filename = urlencode($filename);
    $filename = str_replace('%', '-', $filename);
    $filename = str_replace('#', '-', $filename);
    $filename = str_replace('&', '-', $filename);
    $filename = str_replace('{', '-', $filename);
    $filename = str_replace('}', '-', $filename);
    $filename = str_replace('\\', '-', $filename);
    $filename = str_replace('<', '-', $filename);
    $filename = str_replace('>', '-', $filename);
    $filename = str_replace('*', '-', $filename);
    $filename = str_replace('/', '-', $filename);
    $filename = str_replace('$', '-', $filename);
    $filename = str_replace('\'', '-', $filename);
    $filename = str_replace('"', '-', $filename);
    $filename = str_replace(':', '-', $filename);
    $filename = str_replace('@', '-', $filename);
    $filename = str_replace('+', '-', $filename);
    $filename = str_replace('|', '-', $filename);
    $filename = str_replace('=', '-', $filename);
    $filename = str_replace('`', '-', $filename);
    $file_parts = pathinfo($filename);
    if(!isset($file_parts['extension']))
    {
        $file_parts['extension'] = '';
    }
    switch($file_parts['extension'])
    {
        case "":
        if(!aiomatic_endsWith($filename, '.jpg'))
            $filename .= '.jpg';
        break;
        case NULL:
        if(!aiomatic_endsWith($filename, '.jpg'))
            $filename .= '.jpg';
        break;
    }
    if (wp_mkdir_p($upload_dir['path'] . '/localimages'))
    {
        $file = $upload_dir['path'] . '/localimages/' . $filename;
        $ret_path = $upload_dir['url'] . '/localimages/' . $filename;
    }
    else
    {
        $file = $upload_dir['basedir'] . '/' . $filename;
        $ret_path = $upload_dir['baseurl'] . '/' . $filename;
    }
    if($wp_filesystem->exists($file))
    {
        if(empty($file_parts['extension']))
        {
            $file_parts['extension'] = 'jpg';
        }
        $unid = uniqid();
        $file .= $unid . '.' . $file_parts['extension'];
        $ret_path .= $unid . '.' . $file_parts['extension'];
    }
    
    $ret = $wp_filesystem->put_contents($file, $image_data);
    if ($ret === FALSE) {
        return false;
    }
    return array($ret_path, $file);
}

function aiomatic_generate_random_token($len) {
    $characters = "abcdefghijklmnopqrstuvwxyz0123456789-";
    $word = "";
    for ($i = 0; $i < $len; $i++) {
        $word .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $word;
}
function aiomatic_file_get_contents_advanced($url, $headers = '', $referrer = 'self', $user_agent = false)
{
    $content = false;
    if (parse_url($url, PHP_URL_SCHEME) != '' && function_exists('curl_init')) 
    {
        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
        $max_redirects = 10;
        $ch = curl_init();
        if($ch !== false)
        {
            curl_setopt($ch, CURLOPT_URL, $url);
            if (strtolower($referrer) == 'self') {
                curl_setopt($ch, CURLOPT_REFERER, $url);
            } elseif (strlen($referrer)) {
                curl_setopt($ch, CURLOPT_REFERER, $referrer);
            }
            if ($user_agent) {
                curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
            } 
            curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $headers = trim($headers);
            if (strlen($headers)) {
                $headers_array = explode(PHP_EOL, $headers);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
            }
            if (isset($aiomatic_Main_Settings['proxy_url']) && $aiomatic_Main_Settings['proxy_url'] != '' && $aiomatic_Main_Settings['proxy_url'] != 'disable' && $aiomatic_Main_Settings['proxy_url'] != 'disabled') {
                $prx = explode(',', $aiomatic_Main_Settings['proxy_url']);
                $randomness = array_rand($prx);
                curl_setopt( $ch, CURLOPT_PROXY, trim($prx[$randomness]));
                if (isset($aiomatic_Main_Settings['proxy_auth']) && $aiomatic_Main_Settings['proxy_auth'] != '') 
                {
                    $prx_auth = explode(',', $aiomatic_Main_Settings['proxy_auth']);
                    if(isset($prx_auth[$randomness]) && trim($prx_auth[$randomness]) != '')
                    {
                        curl_setopt( $ch, CURLOPT_PROXYUSERPWD, trim($prx_auth[$randomness]));
                    }
                }
            }
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            if (ini_get('open_basedir') == '') 
            {
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_MAXREDIRS, $max_redirects);
            } 
            else 
            {
                $base_url = $url;
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
                $rch = curl_copy_handle($ch);
                curl_setopt($rch, CURLOPT_HEADER, true);
                curl_setopt($rch, CURLOPT_NOBODY, true);
                curl_setopt($rch, CURLOPT_FORBID_REUSE, false);
                curl_setopt($rch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($rch, CURLOPT_SSL_VERIFYPEER, false);
                do 
                {
                    curl_setopt($rch, CURLOPT_URL, $url);
                    curl_setopt($rch, CURLOPT_REFERER, $url);
                    $header = curl_exec($rch);
                    if (curl_errno($rch)) {
                        $code = 0;
                    } else {
                        $code = curl_getinfo($rch, CURLINFO_HTTP_CODE);
                        if ($code == 301 || $code == 302) {
                            preg_match('/Location:(.*?)\n/', $header, $matches);
                            $url = trim(array_pop($matches));
                            if (strlen($url) && substr($url, 0, 1) == '/') {
                                $url = $base_url . $url;
                            }
                        } else {
                            $code = 0;
                        }
                    }
                } 
                while ($code && --$max_redirects);
                curl_close($rch);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_REFERER, $url);
            }
            curl_setopt($ch, CURLOPT_HEADER, false);
            $content = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($code != 200) {
                $content = false;
            }
            curl_close($ch);
        }
    }
    if (!isset($content) || $content === false) {
        stream_context_set_default(array('ssl' => array('verify_peer' => false, 'verify_peer_name' => false), 'http' => array('method' => 'HEAD', 'timeout' => 10, 'user_agent' => $user_agent)));
        $content = file_get_contents($url);
    }
    return $content;
}
function aiomatic_get_random_image_google($keyword, $min_width = 0, $min_height = 0, $chance = '')
{
    if($chance != '' && is_numeric($chance))
    {
        $chance = intval($chance);
        if(mt_rand(0, 99) >= $chance)
        {
            return '';
        }
    }
    $gimageurl = 'https://www.google.com/search?q=' . urlencode($keyword . ' -site:depositphotos.com -site:123rf.com') . '&tbm=isch&tbs=il:cl&sa=X';
    $res = aiomatic_file_get_contents_advanced($gimageurl, '', 'self', 'Mozilla/5.0 (Windows NT 10.0;WOW64;rv:97.0) Gecko/20100101 Firefox/97.0/3871tuT2p1u-81');
    preg_match_all('/\["([\w%-\.\/:\?&=]+\.jpg|\.jpeg|\.gif|\.png|\.bmp|\.wbmp|\.webm|\.xbm)",\d+,\d+\]/i', $res, $matches);
    $items = $matches[0];
    if (count($items)) {
        shuffle($items);
        foreach ($items as $item) {
            preg_match('#\["(.*?)",(.*?),(.*?)\]#', $item, $matches);
            if (count($matches) == 4 && ($min_width > 0 || $min_width <= $matches[3]) && ($min_height > 0 || $min_height <= $matches[2])) {
                return $matches[1];
            }
        }
    }
    return '';
}
$aiomatic_fatal = false;
function aiomatic_clear_flag_at_shutdown($param)
{
    $error = error_get_last();
    if ($error !== null && $error['type'] === E_ERROR && $GLOBALS['aiomatic_fatal'] === false) {
        $GLOBALS['aiomatic_fatal'] = true;
        $running = array();
        update_option('aiomatic_running_list', $running);
        aiomatic_log_to_file('[FATAL] Exit error: ' . $error['message'] . ', file: ' . $error['file'] . ', line: ' . $error['line'] . ' - rule ID: ' . $param . '!');
        aiomatic_clearFromList($param);
    }
    else
    {
        aiomatic_clearFromList($param);
    }
}
add_filter('the_title', 'aiomatic_add_affiliate_keyword_title');
function aiomatic_add_affiliate_keyword_title($content)
{
    $rules  = get_option('aiomatic_keyword_list');
    if(!is_array($rules))
    {
       $rules = array();
    }
    if (!empty($rules)) {
        foreach ($rules as $request => $value) {
            if(isset($value[2]) && $value[2] == 'content')
            {
                continue;
            }
            if (is_array($value) && isset($value[1]) && $value[1] != '') {
                $repl = $value[1];
            } else {
                $repl = $request;
            }
            if (isset($value[3]) && $value[3] != '') {
                $max = intval($value[3]);
            }
            else
            {
                $max = -1;
            }
            if (isset($value[0]) && $value[0] != '') {
                $content = preg_replace('\'(?!((<.*?)|(<a.*?)))(\b' . preg_quote($request, '\'') . '\b)(?!(([^<>]*?)>)|([^>]*?<\/a>))\'i', '<a href="' . esc_url($value[0]) . '" target="_blank">' . esc_html($repl) . '</a>', $content, $max);
            } else {
                $content = preg_replace('\'(?!((<.*?)|(<a.*?)))(\b' . preg_quote($request, '\'') . '\b)(?!(([^<>]*?)>)|([^>]*?<\/a>))\'i', esc_html($repl), $content, $max);
            }
        }
    }
    return $content;
}
add_filter('the_content', 'aiomatic_add_affiliate_keyword');
add_filter('the_excerpt', 'aiomatic_add_affiliate_keyword');
function aiomatic_add_affiliate_keyword($content)
{
    $rules  = get_option('aiomatic_keyword_list');
    if(!is_array($rules))
    {
       $rules = array();
    }
    if (!empty($rules)) {
        foreach ($rules as $request => $value) {
            if(isset($value[2]) && $value[2] == 'title')
            {
                continue;
            }
            if (is_array($value) && isset($value[1]) && $value[1] != '') {
                $repl = $value[1];
            } else {
                $repl = $request;
            }
            if (isset($value[3]) && $value[3] != '') {
                $max = intval($value[3]);
            }
            else
            {
                $max = -1;
            }
            if (isset($value[0]) && $value[0] != '') {
                $content1 = preg_replace('\'(?!((<.*?)|(<a.*?)))(\b' . preg_quote($request, '\'') . '\b)(?!(([^<>]*?)>)|([^>]*?<\/a>))\'i', '<a href="' . esc_url($value[0]) . '" target="_blank">' . esc_html($repl) . '</a>', $content, $max);
                if($content1 !== null)
                {
                    $content = $content1;
                }
            } else {
                $content1 = preg_replace('\'(?!((<.*?)|(<a.*?)))(\b' . preg_quote($request, '\'') . '\b)(?!(([^<>]*?)>)|([^>]*?<\/a>))\'i', esc_html($repl), $content, $max);
                if($content1 !== null)
                {
                    $content = $content1;
                }
            }
        }
    }
    return $content;
}

function aiomatic_generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
function aiomatic_get_free_image($aiomatic_Main_Settings, $query_words, &$img_attr, $res_cnt = 3, $no_copy = false)
{
    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
    {
        aiomatic_log_to_file('Searching for a royalty free image for keyword: ' . $query_words);
    }
    $original_url = '';
    $rand_arr = array();
    if(isset($aiomatic_Main_Settings['pixabay_api']) && $aiomatic_Main_Settings['pixabay_api'] != '')
    {
        $rand_arr[] = 'pixabay';
    }
    if(isset($aiomatic_Main_Settings['flickr_api']) && $aiomatic_Main_Settings['flickr_api'] !== '')
    {
        $rand_arr[] = 'flickr';
    }
    if(isset($aiomatic_Main_Settings['pexels_api']) && $aiomatic_Main_Settings['pexels_api'] !== '')
    {
        $rand_arr[] = 'pexels';
    }
    if(isset($aiomatic_Main_Settings['pixabay_scrape']) && $aiomatic_Main_Settings['pixabay_scrape'] == 'on')
    {
        $rand_arr[] = 'pixabayscrape';
    }
    if(isset($aiomatic_Main_Settings['unsplash_api']) && $aiomatic_Main_Settings['unsplash_api'] == 'on')
    {
        $rand_arr[] = 'unsplash';
    }
    if(isset($aiomatic_Main_Settings['google_images']) && $aiomatic_Main_Settings['google_images'] == 'on')
    {
        $rand_arr[] = 'google';
    }
    $rez = false;
    while(($rez === false || $rez === '') && count($rand_arr) > 0)
    {
        $rand = array_rand($rand_arr);
        if($rand_arr[$rand] == 'pixabay')
        {
            unset($rand_arr[$rand]);
            if(isset($aiomatic_Main_Settings['img_ss']) && $aiomatic_Main_Settings['img_ss'] == 'on')
            {
                $img_ss = '1';
            }
            else
            {
                $img_ss = '0';
            }
            if(isset($aiomatic_Main_Settings['img_editor']) && $aiomatic_Main_Settings['img_editor'] == 'on')
            {
                $img_editor = '1';
            }
            else
            {
                $img_editor = '0';
            }
            $rez = aiomatic_get_pixabay_image($aiomatic_Main_Settings['pixabay_api'], $query_words, $aiomatic_Main_Settings['img_language'], $aiomatic_Main_Settings['imgtype'], $aiomatic_Main_Settings['scrapeimg_orientation'], $aiomatic_Main_Settings['img_order'], $aiomatic_Main_Settings['img_cat'], $aiomatic_Main_Settings['img_mwidth'], $aiomatic_Main_Settings['img_width'], $img_ss, $img_editor, $original_url, $res_cnt);
            if($rez !== false && $rez !== '')
            {
                $img_attr = str_replace('%%image_source_name%%', 'Pixabay', $img_attr);
                $img_attr = str_replace('%%image_source_url%%', $original_url, $img_attr);
                $img_attr = str_replace('%%image_source_website%%', 'https://pixabay.com/', $img_attr);
            }
        }
        elseif($rand_arr[$rand] == 'morguefile')
        {
            unset($rand_arr[$rand]);
            $rez = aiomatic_get_morguefile_image($aiomatic_Main_Settings['morguefile_api'], $aiomatic_Main_Settings['morguefile_secret'], $query_words, $original_url);
            if($rez !== false && $rez !== '')
            {
                $img_attr = str_replace('%%image_source_name%%', 'MorgueFile', $img_attr);
                $img_attr = str_replace('%%image_source_url%%', 'https://morguefile.com/', $img_attr);
                $img_attr = str_replace('%%image_source_website%%', 'https://morguefile.com/', $img_attr);
            }
        }
        elseif($rand_arr[$rand] == 'flickr')
        {
            unset($rand_arr[$rand]);
            $rez = aiomatic_get_flickr_image($aiomatic_Main_Settings, $query_words, $original_url, $res_cnt);
            if($rez !== false && $rez !== '')
            {
                $img_attr = str_replace('%%image_source_name%%', 'Flickr', $img_attr);
                $img_attr = str_replace('%%image_source_url%%', $original_url, $img_attr);
                $img_attr = str_replace('%%image_source_website%%', 'https://www.flickr.com/', $img_attr);
            }
        }
        elseif($rand_arr[$rand] == 'pexels')
        {
            unset($rand_arr[$rand]);
            $rez = aiomatic_get_pexels_image($aiomatic_Main_Settings, $query_words, $original_url, $res_cnt);
            if($rez !== false && $rez !== '')
            {
                $img_attr = str_replace('%%image_source_name%%', 'Pexels', $img_attr);
                $img_attr = str_replace('%%image_source_url%%', $original_url, $img_attr);
                $img_attr = str_replace('%%image_source_website%%', 'https://www.pexels.com/', $img_attr);
            }
        }
        elseif($rand_arr[$rand] == 'pixabayscrape')
        {
            unset($rand_arr[$rand]);
            $rez = aiomatic_scrape_pixabay_image($aiomatic_Main_Settings, $query_words, $original_url);
            if($rez !== false && $rez !== '')
            {
                $img_attr = str_replace('%%image_source_name%%', 'Pixabay', $img_attr);
                $img_attr = str_replace('%%image_source_url%%', $original_url, $img_attr);
                $img_attr = str_replace('%%image_source_website%%', 'https://pixabay.com/', $img_attr);
            }
        }
        elseif($rand_arr[$rand] == 'unsplash')
        {
            unset($rand_arr[$rand]);
            $rez = aiomatic_scrape_unsplash_image($query_words, $original_url);
            if($rez !== false && $rez !== '')
            {
                $img_attr = str_replace('%%image_source_name%%', 'Unsplash', $img_attr);
                $img_attr = str_replace('%%image_source_url%%', $original_url, $img_attr);
                $img_attr = str_replace('%%image_source_website%%', 'https://unsplash.com/', $img_attr);
            }
        }
        elseif($rand_arr[$rand] == 'google')
        {
            unset($rand_arr[$rand]);
            $original_url = 'https://google.com/';
            $rez = aiomatic_get_random_image_google($query_words, 0, 0, '');
            if($rez !== false && $rez !== '')
            {
                $img_attr = str_replace('%%image_source_name%%', 'Google Images', $img_attr);
                $img_attr = str_replace('%%image_source_url%%', $original_url, $img_attr);
                $img_attr = str_replace('%%image_source_website%%', 'https://google.com/', $img_attr);
            }
        }
        else
        {
            aiomatic_log_to_file('Unrecognized free file source: ' . $rand_arr[$rand]);
            unset($rand_arr[$rand]);
        }
    }
    $img_attr = str_replace('%%image_source_name%%', '', $img_attr);
    $img_attr = str_replace('%%image_source_url%%', '', $img_attr);
    $img_attr = str_replace('%%image_source_website%%', '', $img_attr);
    if($rez !== false && $rez !== '')
    {
        if($no_copy !== true)
        {
            if(isset($aiomatic_Main_Settings['copy_locally']) && $aiomatic_Main_Settings['copy_locally'] == 'on')
            {
                $localpath = aiomatic_copy_image_locally($rez);
                if($localpath !== false)
                {
                    $rez = $localpath[0];
                }
            }
        }
    }
    return $rez;
}
function aiomatic_scrape_pixabay_image($aiomatic_Main_Settings, $query, &$original_url)
{
    $original_url = 'https://pixabay.com';
    $featured_image = '';
    $feed_uri = 'https://pixabay.com/en/photos/';
    if($query != '')
    {
        $feed_uri .= '?q=' . urlencode($query);
    }

    if($aiomatic_Main_Settings['scrapeimgtype'] != 'all')
    {
        $feed_uri .= '&image_type=' . $aiomatic_Main_Settings['scrapeimgtype'];
    }
    if($aiomatic_Main_Settings['scrapeimg_orientation'] != '')
    {
        $feed_uri .= '&orientation=' . $aiomatic_Main_Settings['scrapeimg_orientation'];
    }
    if($aiomatic_Main_Settings['scrapeimg_order'] != '' && $aiomatic_Main_Settings['scrapeimg_order'] != 'any')
    {
        $feed_uri .= '&order=' . $aiomatic_Main_Settings['scrapeimg_order'];
    }
    if($aiomatic_Main_Settings['scrapeimg_cat'] != '')
    {
        $feed_uri .= '&category=' . $aiomatic_Main_Settings['scrapeimg_cat'];
    }
    if($aiomatic_Main_Settings['scrapeimg_height'] != '')
    {
        $feed_uri .= '&min_height=' . $aiomatic_Main_Settings['scrapeimg_height'];
    }
    if($aiomatic_Main_Settings['scrapeimg_width'] != '')
    {
        $feed_uri .= '&min_width=' . $aiomatic_Main_Settings['scrapeimg_width'];
    }
    $exec = aiomatic_get_web_page($feed_uri);
    if ($exec !== FALSE) 
    {
        preg_match_all('/<a href="([^"]+?)".+?(?:data-lazy|src)="([^"]+?\.jpg|png)"/i', $exec, $matches);
        if (!empty($matches[2])) {
            $p = array_combine($matches[1], $matches[2]);
            if(count($p) > 0)
            {
                shuffle($p);
                foreach ($p as $key => $val) {
                    $featured_image = $val;
                    if(!is_numeric($key))
                    {
                        if(substr($key, 0, 4) !== "http")
                        {
                            $key = 'https://pixabay.com' . $key;
                        }
                        $original_url = $key;
                    }
                    else
                    {
                        $original_url = 'https://pixabay.com';
                    }
                    break;
                }
            }
        }
    }
    else
    {
        aiomatic_log_to_file('Error while getting api url: ' . $feed_uri);
        return false;
    }
    return $featured_image;
}
function aiomatic_scrape_unsplash_image($query, &$original_url)
{
    $original_url = 'https://unsplash.com/';
    $feed_uri = 'https://source.unsplash.com/1600x900/';
    if($query != '')
    {
        $feed_uri .= '?' . urlencode($query);
    }
    error_reporting(0);
    ini_set('default_socket_timeout', 120);
    $exec = get_headers($feed_uri);
    error_reporting(E_ALL);
    if ($exec === FALSE || !is_array($exec))
    {
        aiomatic_log_to_file('Error while getting api url: ' . $feed_uri);
    }
    $nono = false;
    $locx = false;
    foreach($exec as $ex)
    {
        if(strstr($ex, 'Location:') !== false)
        {
            if(strstr($ex, 'source-404') !== false)
            {
                $nono = true;
            }
            $locx = $ex;
            $locx = preg_replace('/^Location: /', '', $locx);
            break;
        }
    }
    if($nono == true)
    {
        aiomatic_log_to_file('NO image found on Unsplash for query: ' . $query);
        return false;
    }
    else
    {
        if($locx == false)
        {
            aiomatic_log_to_file('Failed to parse response: ' . $feed_uri);
            return false;
        }
        $original_url = $locx;
        return $locx;
    }
}
function aiomatic_get_pexels_image($aiomatic_Main_Settings, $query, &$original_url, $max)
{
    $original_url = 'https://pexels.com';
    $featured_image = '';
    $feed_uri = 'https://api.pexels.com/v1/search?query=' . urlencode($query) . '&per_page=' . $max;
     
    {
        $ch               = curl_init();
        if ($ch === FALSE) {
            aiomatic_log_to_file('Failed to init curl for flickr!');
            return false;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: ' . $aiomatic_Main_Settings['pexels_api']));
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HTTPGET, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_URL, $feed_uri);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $exec = curl_exec($ch);
        curl_close($ch);
        if (stristr($exec, 'photos') === FALSE) {
            aiomatic_log_to_file('Unrecognized Pexels API response: ' . $exec . ' URI: ' . $feed_uri);
            return false;
        }
        $items = json_decode ( $exec, true );
        if(!isset($items['photos']))
        {
            aiomatic_log_to_file('Failed to find photo node in Pexels response: ' . $exec . ' URI: ' . $feed_uri);
            return false;
        }
        if(count($items['photos']) == 0)
        {
            return $featured_image;
        }
        $x = 0;
        shuffle($items['photos']);
        while($featured_image == '' && isset($items['photos'][$x]))
        {
            $item = $items['photos'][$x];
            if(isset($item['src']['large']))
            {
                $featured_image = $item['src']['large'];
            }
            elseif(isset($item['src']['medium']))
            {
                $featured_image = $item['src']['medium'];
            }
            elseif(isset($item['src']['small']))
            {
                $featured_image = $item['src']['small'];
            }
            elseif(isset($item['src']['portrait']))
            {
                $featured_image = $item['src']['portrait'];
            }
            elseif(isset($item['src']['landscape']))
            {
                $featured_image = $item['src']['landscape'];
            }
            elseif(isset($item['src']['original']))
            {
                $featured_image = $item['src']['original'];
            }
            elseif(isset($item['src']['tiny']))
            {
                $featured_image = $item['src']['tiny'];
            }
            if($featured_image != '')
            {
                $original_url = $item['url'];
            }
            $x++;
        }
    }
    return $featured_image;
}
function aiomatic_get_flickr_image($aiomatic_Main_Settings, $query, &$original_url, $max)
{
    $original_url = 'https://www.flickr.com';
    $featured_image = '';
    $feed_uri = 'https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=' . $aiomatic_Main_Settings['flickr_api'] . '&media=photos&per_page=' . esc_html($max) . '&format=php_serial&text=' . urlencode($query);
    if(isset($aiomatic_Main_Settings['flickr_license']) && $aiomatic_Main_Settings['flickr_license'] != '-1')
    {
        $feed_uri .= '&license=' . $aiomatic_Main_Settings['flickr_license'];
    }
    if(isset($aiomatic_Main_Settings['flickr_order']) && $aiomatic_Main_Settings['flickr_order'] != '')
    {
        $feed_uri .= '&sort=' . $aiomatic_Main_Settings['flickr_order'];
    }
    $feed_uri .= '&extras=description,license,date_upload,date_taken,owner_name,icon_server,original_format,last_update,geo,tags,machine_tags,o_dims,views,media,path_alias,url_sq,url_t,url_s,url_q,url_m,url_n,url_z,url_c,url_l,url_o';
     
    {
        $ch               = curl_init();
        if ($ch === FALSE) {
            aiomatic_log_to_file('Failed to init curl for flickr!');
            return false;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Referer: https://www.flickr.com/'));
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HTTPGET, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_URL, $feed_uri);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $exec = curl_exec($ch);
        curl_close($ch);
        if (stristr($exec, 'photos') === FALSE) {
            aiomatic_log_to_file('Unrecognized Flickr API response: ' . $exec . ' URI: ' . $feed_uri);
            return false;
        }
        $items = unserialize ( $exec );
        if(!isset($items['photos']['photo']))
        {
            aiomatic_log_to_file('Failed to find photo node in response: ' . $exec . ' URI: ' . $feed_uri);
            return false;
        }
        if(count($items['photos']['photo']) == 0)
        {
            return $featured_image;
        }
        $x = 0;
        shuffle($items['photos']['photo']);
        while($featured_image == '' && isset($items['photos']['photo'][$x]))
        {
            $item = $items['photos']['photo'][$x];
            if(isset($item['url_o']))
            {
                $featured_image = $item['url_o'];
            }
            elseif(isset($item['url_l']))
            {
                $featured_image = $item['url_l'];
            }
            elseif(isset($item['url_c']))
            {
                $featured_image = $item['url_c'];
            }
            elseif(isset($item['url_z']))
            {
                $featured_image = $item['url_z'];
            }
            elseif(isset($item['url_n']))
            {
                $featured_image = $item['url_n'];
            }
            elseif(isset($item['url_m']))
            {
                $featured_image = $item['url_m'];
            }
            elseif(isset($item['url_q']))
            {
                $featured_image = $item['url_q'];
            }
            elseif(isset($item['url_s']))
            {
                $featured_image = $item['url_s'];
            }
            elseif(isset($item['url_t']))
            {
                $featured_image = $item['url_t'];
            }
            elseif(isset($item['url_sq']))
            {
                $featured_image = $item['url_sq'];
            }
            if($featured_image != '')
            {
                $original_url = 'https://www.flickr.com/photos/' . $item['owner'] . '/' . $item['id'];
            }
            $x++;
        }
    }
    return $featured_image;
}
function aiomatic_get_morguefile_image($app_id, $app_secret, $query, &$original_url)
{
    $featured_image = '';
    if(!class_exists('aiomatic_morguefile'))
    {
        require_once (dirname(__FILE__) . "/res/morguefile/mf.api.class.php");
    }
    $query = explode(' ', $query);
    $query = $query[0];
    {
        $mf = new aiomatic_morguefile($app_id, $app_secret);
        $rez = $mf->call('/images/search/sort/page/' . $query);
        if ($rez !== FALSE) 
        {
            $chosen_one = $rez->doc[array_rand($rez->doc)];
            if (isset($chosen_one->file_path_large)) 
            {
                return $chosen_one->file_path_large;
            }
            else
            {
                return false;
            }
        }
        else
        {
            aiomatic_log_to_file('Error while getting api response from morguefile.');
            return false;
        }
    }
    return $featured_image;
}
function aiomatic_get_pixabay_image($app_id, $query, $lang, $image_type, $orientation, $order, $image_category, $max_width, $min_width, $safe_search, $editors_choice, &$original_url, $get_max = 3)
{
    $original_url = 'https://pixabay.com';
    $featured_image = '';
    $feed_uri = 'https://pixabay.com/api/?key=' . $app_id;
    if($query != '')
    {
        $feed_uri .= '&q=' . urlencode($query);
    }
    $feed_uri .= '&per_page=' . $get_max;
    if($lang != '' && $lang != 'any')
    {
        $feed_uri .= '&lang=' . $lang;
    }
    if($image_type != '')
    {
        $feed_uri .= '&image_type=' . $image_type;
    }
    if($orientation != '')
    {
        $feed_uri .= '&orientation=' . $orientation;
    }
    if($order != '')
    {
        $feed_uri .= '&order=' . $order;
    }
    if($image_category != '')
    {
        $feed_uri .= '&category=' . $image_category;
    }
    if($max_width != '')
    {
        $feed_uri .= '&max_width=' . $max_width;
    }
    if($min_width != '')
    {
        $feed_uri .= '&min_width=' . $min_width;
    }
    if($safe_search == '1')
    {
        $feed_uri .= '&safesearch=true';
    }
    if($editors_choice == '1')
    {
        $feed_uri .= '&editors_choice=true';
    }
    $feed_uri .= '&callback=' . aiomatic_generateRandomString(6);
    $exec = aiomatic_get_web_page($feed_uri);
    if ($exec !== FALSE) 
    {
        if (stristr($exec, '"hits"') !== FALSE) 
        {
            $exec = preg_replace('#^[a-zA-Z0-9]*#', '', $exec);
            $exec = trim($exec, '()');
            $json  = json_decode($exec);
            $items = $json->hits;
            if (count($items) != 0) 
            {
                shuffle($items);
                foreach($items as $item)
                {
                    $featured_image = $item->webformatURL;
                    $original_url = $item->pageURL;
                    break;
                }
            }
        }
        else
        {
            aiomatic_log_to_file('Unknow response from api: ' . $feed_uri . ' - resp: ' . $exec);
            return false;
        }
    }
    else
    {
        aiomatic_log_to_file('Error while getting api url: ' . $feed_uri);
        return false;
    }
    return $featured_image;
}

function aiomatic_addPostMeta($post_id, $post, $param, $featured_img, $post_topic)
{
    add_post_meta($post_id, 'aiomatic_parent_rule', $param);
    add_post_meta($post_id, 'aiomatic_enable_pingbacks', $post['aiomatic_enable_pingbacks']);
    add_post_meta($post_id, 'aiomatic_comment_status', $post['comment_status']);
    add_post_meta($post_id, 'aiomatic_extra_categories', $post['extra_categories']);
    add_post_meta($post_id, 'aiomatic_extra_tags', $post['extra_tags']);
    add_post_meta($post_id, 'aiomatic_featured_img', $featured_img);
    add_post_meta($post_id, 'aiomatic_timestamp', $post['aiomatic_timestamp']);
    add_post_meta($post_id, 'aiomatic_source_title', $post['aiomatic_source_title']);
    if($post_topic != '')
    {
        add_post_meta($post_id, 'aiomatic_post_topic', $post_topic);
    }
}
function aiomatic_endsWith($haystack, $needle)
{
    $length = strlen($needle);
    if ($length == 0) {
        return true;
    }

    return (substr($haystack, -$length) === $needle);
}
function aiomatic_generate_featured_image($image_url, $post_id)
{
    $upload_dir = wp_upload_dir();
    global $wp_filesystem;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
        wp_filesystem($creds);
    }
    $image_data = $wp_filesystem->get_contents($image_url);
    if ($image_data === FALSE) {
        $image_data = aiomatic_get_web_page($image_url);
        if ($image_data === FALSE || strpos($image_data, '<Message>Access Denied</Message>') !== FALSE) {
            return false;
        }
    }
    $filename = basename($image_url);
    $temp     = explode("?", $filename);
    $filename = $temp[0];
    $filename = str_replace('%', '-', $filename);
    $filename = str_replace('#', '-', $filename);
    $filename = str_replace('&', '-', $filename);
    $filename = str_replace('{', '-', $filename);
    $filename = str_replace('}', '-', $filename);
    $filename = str_replace('\\', '-', $filename);
    $filename = str_replace('<', '-', $filename);
    $filename = str_replace('>', '-', $filename);
    $filename = str_replace('*', '-', $filename);
    $filename = str_replace('/', '-', $filename);
    $filename = str_replace('$', '-', $filename);
    $filename = str_replace('\'', '-', $filename);
    $filename = str_replace('"', '-', $filename);
    $filename = str_replace(':', '-', $filename);
    $filename = str_replace('@', '-', $filename);
    $filename = str_replace('+', '-', $filename);
    $filename = str_replace('|', '-', $filename);
    $filename = str_replace('=', '-', $filename);
    $filename = str_replace('`', '-', $filename);
    $filename = stripslashes(preg_replace_callback('#(%[a-zA-Z0-9_]*)#', function($matches){ return rand(0, 9); }, preg_quote($filename)));
    $file_parts = pathinfo($filename);
    $post_title = get_the_title($post_id);
    if($post_title != '')
    {
        $post_title = remove_accents( $post_title );
        $invalid = array(
            ' '   => '-',
            '%20' => '-',
            '_'   => '-',
        );
        $post_title = str_replace( array_keys( $invalid ), array_values( $invalid ), $post_title );
        $post_title = preg_replace('/[\x{1F3F4}](?:\x{E0067}\x{E0062}\x{E0077}\x{E006C}\x{E0073}\x{E007F})|[\x{1F3F4}](?:\x{E0067}\x{E0062}\x{E0073}\x{E0063}\x{E0074}\x{E007F})|[\x{1F3F4}](?:\x{E0067}\x{E0062}\x{E0065}\x{E006E}\x{E0067}\x{E007F})|[\x{1F3F4}](?:\x{200D}\x{2620}\x{FE0F})|[\x{1F3F3}](?:\x{FE0F}\x{200D}\x{1F308})|[\x{0023}\x{002A}\x{0030}\x{0031}\x{0032}\x{0033}\x{0034}\x{0035}\x{0036}\x{0037}\x{0038}\x{0039}](?:\x{FE0F}\x{20E3})|[\x{1F415}](?:\x{200D}\x{1F9BA})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F467}\x{200D}\x{1F467})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F467}\x{200D}\x{1F466})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F467})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F466}\x{200D}\x{1F466})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F466})|[\x{1F468}](?:\x{200D}\x{1F468}\x{200D}\x{1F467}\x{200D}\x{1F467})|[\x{1F468}](?:\x{200D}\x{1F468}\x{200D}\x{1F466}\x{200D}\x{1F466})|[\x{1F468}](?:\x{200D}\x{1F468}\x{200D}\x{1F467}\x{200D}\x{1F466})|[\x{1F468}](?:\x{200D}\x{1F468}\x{200D}\x{1F467})|[\x{1F468}](?:\x{200D}\x{1F468}\x{200D}\x{1F466})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F469}\x{200D}\x{1F467}\x{200D}\x{1F467})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F469}\x{200D}\x{1F466}\x{200D}\x{1F466})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F469}\x{200D}\x{1F467}\x{200D}\x{1F466})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F469}\x{200D}\x{1F467})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F469}\x{200D}\x{1F466})|[\x{1F469}](?:\x{200D}\x{2764}\x{FE0F}\x{200D}\x{1F469})|[\x{1F469}\x{1F468}](?:\x{200D}\x{2764}\x{FE0F}\x{200D}\x{1F468})|[\x{1F469}](?:\x{200D}\x{2764}\x{FE0F}\x{200D}\x{1F48B}\x{200D}\x{1F469})|[\x{1F469}\x{1F468}](?:\x{200D}\x{2764}\x{FE0F}\x{200D}\x{1F48B}\x{200D}\x{1F468})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F9BD})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F9BC})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F9AF})|[\x{1F575}\x{1F3CC}\x{26F9}\x{1F3CB}](?:\x{FE0F}\x{200D}\x{2640}\x{FE0F})|[\x{1F575}\x{1F3CC}\x{26F9}\x{1F3CB}](?:\x{FE0F}\x{200D}\x{2642}\x{FE0F})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F692})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F680})|[\x{1F468}\x{1F469}](?:\x{200D}\x{2708}\x{FE0F})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F3A8})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F3A4})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F4BB})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F52C})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F4BC})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F3ED})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F527})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F373})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F33E})|[\x{1F468}\x{1F469}](?:\x{200D}\x{2696}\x{FE0F})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F3EB})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F393})|[\x{1F468}\x{1F469}](?:\x{200D}\x{2695}\x{FE0F})|[\x{1F471}\x{1F64D}\x{1F64E}\x{1F645}\x{1F646}\x{1F481}\x{1F64B}\x{1F9CF}\x{1F647}\x{1F926}\x{1F937}\x{1F46E}\x{1F482}\x{1F477}\x{1F473}\x{1F9B8}\x{1F9B9}\x{1F9D9}\x{1F9DA}\x{1F9DB}\x{1F9DC}\x{1F9DD}\x{1F9DE}\x{1F9DF}\x{1F486}\x{1F487}\x{1F6B6}\x{1F9CD}\x{1F9CE}\x{1F3C3}\x{1F46F}\x{1F9D6}\x{1F9D7}\x{1F3C4}\x{1F6A3}\x{1F3CA}\x{1F6B4}\x{1F6B5}\x{1F938}\x{1F93C}\x{1F93D}\x{1F93E}\x{1F939}\x{1F9D8}](?:\x{200D}\x{2640}\x{FE0F})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F9B2})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F9B3})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F9B1})|[\x{1F468}\x{1F469}](?:\x{200D}\x{1F9B0})|[\x{1F471}\x{1F64D}\x{1F64E}\x{1F645}\x{1F646}\x{1F481}\x{1F64B}\x{1F9CF}\x{1F647}\x{1F926}\x{1F937}\x{1F46E}\x{1F482}\x{1F477}\x{1F473}\x{1F9B8}\x{1F9B9}\x{1F9D9}\x{1F9DA}\x{1F9DB}\x{1F9DC}\x{1F9DD}\x{1F9DE}\x{1F9DF}\x{1F486}\x{1F487}\x{1F6B6}\x{1F9CD}\x{1F9CE}\x{1F3C3}\x{1F46F}\x{1F9D6}\x{1F9D7}\x{1F3C4}\x{1F6A3}\x{1F3CA}\x{1F6B4}\x{1F6B5}\x{1F938}\x{1F93C}\x{1F93D}\x{1F93E}\x{1F939}\x{1F9D8}](?:\x{200D}\x{2642}\x{FE0F})|[\x{1F441}](?:\x{FE0F}\x{200D}\x{1F5E8}\x{FE0F})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1E9}\x{1F1F0}\x{1F1F2}\x{1F1F3}\x{1F1F8}\x{1F1F9}\x{1F1FA}](?:\x{1F1FF})|[\x{1F1E7}\x{1F1E8}\x{1F1EC}\x{1F1F0}\x{1F1F1}\x{1F1F2}\x{1F1F5}\x{1F1F8}\x{1F1FA}](?:\x{1F1FE})|[\x{1F1E6}\x{1F1E8}\x{1F1F2}\x{1F1F8}](?:\x{1F1FD})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1EC}\x{1F1F0}\x{1F1F2}\x{1F1F5}\x{1F1F7}\x{1F1F9}\x{1F1FF}](?:\x{1F1FC})|[\x{1F1E7}\x{1F1E8}\x{1F1F1}\x{1F1F2}\x{1F1F8}\x{1F1F9}](?:\x{1F1FB})|[\x{1F1E6}\x{1F1E8}\x{1F1EA}\x{1F1EC}\x{1F1ED}\x{1F1F1}\x{1F1F2}\x{1F1F3}\x{1F1F7}\x{1F1FB}](?:\x{1F1FA})|[\x{1F1E6}\x{1F1E7}\x{1F1EA}\x{1F1EC}\x{1F1ED}\x{1F1EE}\x{1F1F1}\x{1F1F2}\x{1F1F5}\x{1F1F8}\x{1F1F9}\x{1F1FE}](?:\x{1F1F9})|[\x{1F1E6}\x{1F1E7}\x{1F1EA}\x{1F1EC}\x{1F1EE}\x{1F1F1}\x{1F1F2}\x{1F1F5}\x{1F1F7}\x{1F1F8}\x{1F1FA}\x{1F1FC}](?:\x{1F1F8})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1EA}\x{1F1EB}\x{1F1EC}\x{1F1ED}\x{1F1EE}\x{1F1F0}\x{1F1F1}\x{1F1F2}\x{1F1F3}\x{1F1F5}\x{1F1F8}\x{1F1F9}](?:\x{1F1F7})|[\x{1F1E6}\x{1F1E7}\x{1F1EC}\x{1F1EE}\x{1F1F2}](?:\x{1F1F6})|[\x{1F1E8}\x{1F1EC}\x{1F1EF}\x{1F1F0}\x{1F1F2}\x{1F1F3}](?:\x{1F1F5})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1E9}\x{1F1EB}\x{1F1EE}\x{1F1EF}\x{1F1F2}\x{1F1F3}\x{1F1F7}\x{1F1F8}\x{1F1F9}](?:\x{1F1F4})|[\x{1F1E7}\x{1F1E8}\x{1F1EC}\x{1F1ED}\x{1F1EE}\x{1F1F0}\x{1F1F2}\x{1F1F5}\x{1F1F8}\x{1F1F9}\x{1F1FA}\x{1F1FB}](?:\x{1F1F3})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1E9}\x{1F1EB}\x{1F1EC}\x{1F1ED}\x{1F1EE}\x{1F1EF}\x{1F1F0}\x{1F1F2}\x{1F1F4}\x{1F1F5}\x{1F1F8}\x{1F1F9}\x{1F1FA}\x{1F1FF}](?:\x{1F1F2})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1EC}\x{1F1EE}\x{1F1F2}\x{1F1F3}\x{1F1F5}\x{1F1F8}\x{1F1F9}](?:\x{1F1F1})|[\x{1F1E8}\x{1F1E9}\x{1F1EB}\x{1F1ED}\x{1F1F1}\x{1F1F2}\x{1F1F5}\x{1F1F8}\x{1F1F9}\x{1F1FD}](?:\x{1F1F0})|[\x{1F1E7}\x{1F1E9}\x{1F1EB}\x{1F1F8}\x{1F1F9}](?:\x{1F1EF})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1EB}\x{1F1EC}\x{1F1F0}\x{1F1F1}\x{1F1F3}\x{1F1F8}\x{1F1FB}](?:\x{1F1EE})|[\x{1F1E7}\x{1F1E8}\x{1F1EA}\x{1F1EC}\x{1F1F0}\x{1F1F2}\x{1F1F5}\x{1F1F8}\x{1F1F9}](?:\x{1F1ED})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1E9}\x{1F1EA}\x{1F1EC}\x{1F1F0}\x{1F1F2}\x{1F1F3}\x{1F1F5}\x{1F1F8}\x{1F1F9}\x{1F1FA}\x{1F1FB}](?:\x{1F1EC})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1EC}\x{1F1F2}\x{1F1F3}\x{1F1F5}\x{1F1F9}\x{1F1FC}](?:\x{1F1EB})|[\x{1F1E6}\x{1F1E7}\x{1F1E9}\x{1F1EA}\x{1F1EC}\x{1F1EE}\x{1F1EF}\x{1F1F0}\x{1F1F2}\x{1F1F3}\x{1F1F5}\x{1F1F7}\x{1F1F8}\x{1F1FB}\x{1F1FE}](?:\x{1F1EA})|[\x{1F1E6}\x{1F1E7}\x{1F1E8}\x{1F1EC}\x{1F1EE}\x{1F1F2}\x{1F1F8}\x{1F1F9}](?:\x{1F1E9})|[\x{1F1E6}\x{1F1E8}\x{1F1EA}\x{1F1EE}\x{1F1F1}\x{1F1F2}\x{1F1F3}\x{1F1F8}\x{1F1F9}\x{1F1FB}](?:\x{1F1E8})|[\x{1F1E7}\x{1F1EC}\x{1F1F1}\x{1F1F8}](?:\x{1F1E7})|[\x{1F1E7}\x{1F1E8}\x{1F1EA}\x{1F1EC}\x{1F1F1}\x{1F1F2}\x{1F1F3}\x{1F1F5}\x{1F1F6}\x{1F1F8}\x{1F1F9}\x{1F1FA}\x{1F1FB}\x{1F1FF}](?:\x{1F1E6})|[\x{00A9}\x{00AE}\x{203C}\x{2049}\x{2122}\x{2139}\x{2194}-\x{2199}\x{21A9}-\x{21AA}\x{231A}-\x{231B}\x{2328}\x{23CF}\x{23E9}-\x{23F3}\x{23F8}-\x{23FA}\x{24C2}\x{25AA}-\x{25AB}\x{25B6}\x{25C0}\x{25FB}-\x{25FE}\x{2600}-\x{2604}\x{260E}\x{2611}\x{2614}-\x{2615}\x{2618}\x{261D}\x{2620}\x{2622}-\x{2623}\x{2626}\x{262A}\x{262E}-\x{262F}\x{2638}-\x{263A}\x{2640}\x{2642}\x{2648}-\x{2653}\x{265F}-\x{2660}\x{2663}\x{2665}-\x{2666}\x{2668}\x{267B}\x{267E}-\x{267F}\x{2692}-\x{2697}\x{2699}\x{269B}-\x{269C}\x{26A0}-\x{26A1}\x{26AA}-\x{26AB}\x{26B0}-\x{26B1}\x{26BD}-\x{26BE}\x{26C4}-\x{26C5}\x{26C8}\x{26CE}-\x{26CF}\x{26D1}\x{26D3}-\x{26D4}\x{26E9}-\x{26EA}\x{26F0}-\x{26F5}\x{26F7}-\x{26FA}\x{26FD}\x{2702}\x{2705}\x{2708}-\x{270D}\x{270F}\x{2712}\x{2714}\x{2716}\x{271D}\x{2721}\x{2728}\x{2733}-\x{2734}\x{2744}\x{2747}\x{274C}\x{274E}\x{2753}-\x{2755}\x{2757}\x{2763}-\x{2764}\x{2795}-\x{2797}\x{27A1}\x{27B0}\x{27BF}\x{2934}-\x{2935}\x{2B05}-\x{2B07}\x{2B1B}-\x{2B1C}\x{2B50}\x{2B55}\x{3030}\x{303D}\x{3297}\x{3299}\x{1F004}\x{1F0CF}\x{1F170}-\x{1F171}\x{1F17E}-\x{1F17F}\x{1F18E}\x{1F191}-\x{1F19A}\x{1F201}-\x{1F202}\x{1F21A}\x{1F22F}\x{1F232}-\x{1F23A}\x{1F250}-\x{1F251}\x{1F300}-\x{1F321}\x{1F324}-\x{1F393}\x{1F396}-\x{1F397}\x{1F399}-\x{1F39B}\x{1F39E}-\x{1F3F0}\x{1F3F3}-\x{1F3F5}\x{1F3F7}-\x{1F3FA}\x{1F400}-\x{1F4FD}\x{1F4FF}-\x{1F53D}\x{1F549}-\x{1F54E}\x{1F550}-\x{1F567}\x{1F56F}-\x{1F570}\x{1F573}-\x{1F57A}\x{1F587}\x{1F58A}-\x{1F58D}\x{1F590}\x{1F595}-\x{1F596}\x{1F5A4}-\x{1F5A5}\x{1F5A8}\x{1F5B1}-\x{1F5B2}\x{1F5BC}\x{1F5C2}-\x{1F5C4}\x{1F5D1}-\x{1F5D3}\x{1F5DC}-\x{1F5DE}\x{1F5E1}\x{1F5E3}\x{1F5E8}\x{1F5EF}\x{1F5F3}\x{1F5FA}-\x{1F64F}\x{1F680}-\x{1F6C5}\x{1F6CB}-\x{1F6D2}\x{1F6D5}\x{1F6E0}-\x{1F6E5}\x{1F6E9}\x{1F6EB}-\x{1F6EC}\x{1F6F0}\x{1F6F3}-\x{1F6FA}\x{1F7E0}-\x{1F7EB}\x{1F90D}-\x{1F93A}\x{1F93C}-\x{1F945}\x{1F947}-\x{1F971}\x{1F973}-\x{1F976}\x{1F97A}-\x{1F9A2}\x{1F9A5}-\x{1F9AA}\x{1F9AE}-\x{1F9CA}\x{1F9CD}-\x{1F9FF}\x{1FA70}-\x{1FA73}\x{1FA78}-\x{1FA7A}\x{1FA80}-\x{1FA82}\x{1FA90}-\x{1FA95}]/u', '', $post_title);
        
        $post_title = preg_replace('/\.(?=.*\.)/', '', $post_title);
        $post_title = preg_replace('/-+/', '-', $post_title);
        $post_title = str_replace('-.', '.', $post_title);
        $post_title = strtolower( $post_title );
        if($post_title == '')
        {
            $post_title = uniqid();
        }
        if(isset($file_parts['extension']))
        {
            switch($file_parts['extension'])
            {
                case "":
                $filename = sanitize_title($post_title) . '.jpg';
                break;
                case NULL:
                $filename = sanitize_title($post_title) . '.jpg';
                break;
                default:
                $filename = sanitize_title($post_title) . '.' . $file_parts['extension'];
                break;
            }
        }
        else
        {
            $filename = sanitize_title($post_title) . '.jpg';
        }
    }
    else
    {
        if(isset($file_parts['extension']))
        {
            switch($file_parts['extension'])
            {
                case "":
                if(!aiomatic_endsWith($filename, '.jpg'))
                    $filename .= '.jpg';
                break;
                case NULL:
                if(!aiomatic_endsWith($filename, '.jpg'))
                    $filename .= '.jpg';
                break;
                default:
                if(!aiomatic_endsWith($filename, '.' . $file_parts['extension']))
                    $filename .= '.' . $file_parts['extension'];
                break;
            }
        }
        else
        {
            if(!aiomatic_endsWith($filename, '.jpg'))
                $filename .= '.jpg';
        }
    }
    $filename = sanitize_file_name($filename);
    if (wp_mkdir_p($upload_dir['path']))
        $file = $upload_dir['path'] . '/' . $post_id . '-' . $filename;
    else
        $file = $upload_dir['basedir'] . '/' . $post_id . '-' . $filename;
    if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
        wp_filesystem($creds);
    }
    $ret = $wp_filesystem->put_contents($file, $image_data);
    if ($ret === FALSE) {
        return false;
    }
    $wp_filetype = wp_check_filetype($filename, null);
    if($wp_filetype['type'] == '')
    {
        $wp_filetype['type'] = 'image/png';
    }
    $attachment  = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if ((isset($aiomatic_Main_Settings['resize_height']) && $aiomatic_Main_Settings['resize_height'] !== '') || (isset($aiomatic_Main_Settings['resize_width']) && $aiomatic_Main_Settings['resize_width'] !== ''))
    {
        try
        {
            if(!class_exists('\Eventviva\ImageResize')){require_once (dirname(__FILE__) . "/res/ImageResize/ImageResize.php");}
            $imageRes = new ImageResize($file);
            $imageRes->quality_jpg = 100;
            if ((isset($aiomatic_Main_Settings['resize_height']) && $aiomatic_Main_Settings['resize_height'] !== '') && (isset($aiomatic_Main_Settings['resize_width']) && $aiomatic_Main_Settings['resize_width'] !== ''))
            {
                $imageRes->resizeToBestFit($aiomatic_Main_Settings['resize_width'], $aiomatic_Main_Settings['resize_height'], true);
            }
            elseif (isset($aiomatic_Main_Settings['resize_width']) && $aiomatic_Main_Settings['resize_width'] !== '')
            {
                $imageRes->resizeToWidth($aiomatic_Main_Settings['resize_width'], true);
            }
            elseif (isset($aiomatic_Main_Settings['resize_height']) && $aiomatic_Main_Settings['resize_height'] !== '')
            {
                $imageRes->resizeToHeight($aiomatic_Main_Settings['resize_height'], true);
            }
            $imageRes->save($file);
        }
        catch(Exception $e)
        {
            aiomatic_log_to_file('Failed to resize featured image: ' . $image_url . ' to sizes ' . $aiomatic_Main_Settings['resize_width'] . ' - ' . $aiomatic_Main_Settings['resize_height'] . '. Exception thrown ' . esc_html($e->getMessage()) . '!');
        }
    }
    $attach_id   = wp_insert_attachment($attachment, $file, $post_id);
    if ($attach_id === 0) {
        return false;
    }
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $file);
    wp_update_attachment_metadata($attach_id, $attach_data);
    $res2 = set_post_thumbnail($post_id, $attach_id);
    if ($res2 === FALSE) {
        return false;
    }
    $post_title = get_the_title($post_id);
    if($post_title != '')
    {
        update_post_meta($attach_id, '_wp_attachment_image_alt', $post_title);
    }
    return true;
}

function aiomatic_assign_featured_image_path($filename, $post_id)
{
    $wp_filetype = wp_check_filetype($filename, null);
    if($wp_filetype['type'] == '')
    {
        $wp_filetype['type'] = 'image/png';
    }
    $post_title = get_the_title($post_id);
    $attachment  = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => $post_title,
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if ((isset($aiomatic_Main_Settings['resize_height']) && $aiomatic_Main_Settings['resize_height'] !== '') || (isset($aiomatic_Main_Settings['resize_width']) && $aiomatic_Main_Settings['resize_width'] !== ''))
    {
        try
        {
            if(!class_exists('\Eventviva\ImageResize')){require_once (dirname(__FILE__) . "/res/ImageResize/ImageResize.php");}
            $imageRes = new ImageResize($filename);
            $imageRes->quality_jpg = 100;
            if ((isset($aiomatic_Main_Settings['resize_height']) && $aiomatic_Main_Settings['resize_height'] !== '') && (isset($aiomatic_Main_Settings['resize_width']) && $aiomatic_Main_Settings['resize_width'] !== ''))
            {
                $imageRes->resizeToBestFit($aiomatic_Main_Settings['resize_width'], $aiomatic_Main_Settings['resize_height'], true);
            }
            elseif (isset($aiomatic_Main_Settings['resize_width']) && $aiomatic_Main_Settings['resize_width'] !== '')
            {
                $imageRes->resizeToWidth($aiomatic_Main_Settings['resize_width'], true);
            }
            elseif (isset($aiomatic_Main_Settings['resize_height']) && $aiomatic_Main_Settings['resize_height'] !== '')
            {
                $imageRes->resizeToHeight($aiomatic_Main_Settings['resize_height'], true);
            }
            $imageRes->save($filename);
        }
        catch(Exception $e)
        {
            aiomatic_log_to_file('Failed to resize featured image: ' . $filename . ' to sizes ' . $aiomatic_Main_Settings['resize_width'] . ' - ' . $aiomatic_Main_Settings['resize_height'] . '. Exception thrown ' . esc_html($e->getMessage()) . '!');
        }
    }
    $attach_id   = wp_insert_attachment($attachment, $filename, $post_id);
    if ($attach_id === 0) {
        return false;
    }
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $filename);
    wp_update_attachment_metadata($attach_id, $attach_data);
    $res2 = set_post_thumbnail($post_id, $attach_id);
    if ($res2 === FALSE) {
        return false;
    }
    if($post_title != '')
    {
        update_post_meta($attach_id, '_wp_attachment_image_alt', $post_title);
    }
    return true;
}

function aiomatic_hour_diff($date1, $date2)
{
    $date1 = new DateTime($date1);
    $date2 = new DateTime($date2);
    
    $number1 = (int) $date1->format('U');
    $number2 = (int) $date2->format('U');
    return ($number1 - $number2) / 60;
}

function aiomatic_minute_diff($date1, $date2)
{
    $date1 = new DateTime($date1);
    $date2 = new DateTime($date2);
    
    $number1 = (int) $date1->format('U');
    $number2 = (int) $date2->format('U');
    return ($number1 - $number2);
}

function aiomatic_add_minute($date, $minute)
{
    $date1 = new DateTime($date);
    $date1->modify("$minute minutes");
    $date1 = (array)$date1;
    foreach ($date1 as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return $date;
}
function aiomatic_add_hour($date, $hour)
{
    $date1 = new DateTime($date);
    $date1->modify("$hour hours");
    $date1 = (array)$date1;
    foreach ($date1 as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return $date;
}

function aiomatic_wp_custom_css_files($src, $cont)
{
    wp_enqueue_style('aiomatic-thumbnail-css-' . $cont, $src, __FILE__);
}

function aiomatic_get_date_now($param = 'now')
{
    $date = new DateTime($param);
    $date = (array)$date;
    foreach ($date as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return '';
}

function aiomatic_create_terms($taxonomy, $parent, $terms_str)
{
    $terms          = explode('/', $terms_str);
    $categories     = array();
    $parent_term_id = $parent;
    foreach ($terms as $term) {
        $res = term_exists($term, $taxonomy, $parent);
        if ($res != NULL && $res != 0 && count($res) > 0 && isset($res['term_id'])) {
            $parent_term_id = $res['term_id'];
            $categories[]   = $parent_term_id;
        } else {
            $new_term = wp_insert_term($term, $taxonomy, array(
                'parent' => $parent
            ));
            if (!is_wp_error( $new_term ) && $new_term != NULL && $new_term != 0 && count($new_term) > 0 && isset($new_term['term_id'])) {
                $parent_term_id = $new_term['term_id'];
                $categories[]   = $parent_term_id;
            }
        }
    }
    
    return $categories;
}
function aiomatic_getExcerpt($the_content)
{
    $preview = aiomatic_strip_html_tags($the_content);
    $preview = wp_trim_words($preview, 55);
    return $preview;
}

function aiomatic_getPlainContent($the_content)
{
    $preview = aiomatic_strip_html_tags($the_content);
    $preview = wp_trim_words($preview, 999999);
    return $preview;
}
function aiomatic_getItemImage($img)
{
    if($img == '')
    {
        return '';
    }
    $preview = '<img src="' . esc_url($img) . '" alt="image" />';
    return $preview;
}
function aiomatic_get_session_id() {
    if ( isset( $_COOKIE['aiomatic_session_id'] ) ) {
        return $_COOKIE['aiomatic_session_id'];
    }
    return "N/A";
}
add_action( 'enqueue_block_editor_assets', 'aiomatic_enqueue_block_editor_assets' );
function aiomatic_enqueue_block_editor_assets() {
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['aiomatic_enabled']) && $aiomatic_Main_Settings['aiomatic_enabled'] == 'on')
    {
        $all_models = aiomatic_get_all_models(true);
        $all_edit_models = array_merge($all_models, AIOMATIC_EDIT_MODELS);
        wp_register_style('aiomatic-browser-style', plugins_url('styles/aiomatic-browser.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('aiomatic-browser-style');
        $block_js_display = 'scripts/display-posts.js';
        wp_enqueue_script(
            'aiomatic-display-block-js', 
            plugins_url( $block_js_display, __FILE__ ), 
            array(
                'wp-blocks',
                'wp-i18n',
                'wp-element',
            ),
            '1.0.0'
        );
        $block_js_list   = 'scripts/list-posts.js';
        wp_enqueue_script(
            'aiomatic-list-block-js', 
            plugins_url( $block_js_list, __FILE__ ), 
            array(
                'wp-blocks',
                'wp-i18n',
                'wp-element',
            ),
            '1.0.0'
        );
        $block_js_article   = 'scripts/aiomatic-article.js';
        wp_enqueue_script(
            'aiomatic-article', 
            plugins_url( $block_js_article, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        wp_localize_script('aiomatic-article', 'aiomatic_object', array(
            'models' => $all_models
        ));
        $block_js_image   = 'scripts/aiomatic-image.js';
        wp_enqueue_script(
            'aiomatic-image', 
            plugins_url( $block_js_image, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        $block_js_image   = 'scripts/aiomatic-stable-image.js';
        wp_enqueue_script(
            'aiomatic-stable-image', 
            plugins_url( $block_js_image, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        $block_js_list   = 'scripts/sidebar.js';
        wp_enqueue_script(
            'aiomatic-sidebar-js', 
            plugins_url( $block_js_list, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        wp_localize_script('aiomatic-sidebar-js', 'aiomatic', array(
            'ajaxurl' => admin_url('admin-ajax.php')
        ));
        $block_js_article   = 'scripts/aiomatic-completion.js';
        wp_enqueue_script(
            'aiomatic-completion', 
            plugins_url( $block_js_article, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        wp_localize_script('aiomatic-completion', 'aiomatic_object', array(
            'models' => $all_models
        ));
        $block_js_article   = 'scripts/aiomatic-editing.js';
        wp_enqueue_script(
            'aiomatic-editing', 
            plugins_url( $block_js_article, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        wp_localize_script('aiomatic-editing', 'aiomatic_object', array(
            'models' => $all_edit_models
        ));
        $block_js_article   = 'scripts/aiomatic-image-generator.js';
        wp_enqueue_script(
            'aiomatic-image-generator', 
            plugins_url( $block_js_article, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        $block_js_article   = 'scripts/aiomatic-stable-image-generator.js';
        wp_enqueue_script(
            'aiomatic-stable-image-generator', 
            plugins_url( $block_js_article, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        $block_js_article   = 'scripts/aiomatic-chat.js';
        wp_enqueue_script(
            'aiomatic-chat', 
            plugins_url( $block_js_article, __FILE__ ), 
            array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-data' ),
            '1.0.0'
        );
        wp_localize_script('aiomatic-chat', 'aiomatic_object', array(
            'models' => $all_models
        ));
        if (!isset($aiomatic_Main_Settings['assistant_disable']) || $aiomatic_Main_Settings['assistant_disable'] != 'on')
        {
            wp_enqueue_script(
                'aiomatic-gutenberg',
                plugins_url('/scripts/gutenberg-editor.js', __FILE__),
                array('wp-rich-text'),
                filemtime( plugin_dir_path( __FILE__ ) . '/scripts/gutenberg-editor.js' ),
                true
            );
            $assistant_placement = 'below';
            if (isset($aiomatic_Main_Settings['assistant_placement']) && $aiomatic_Main_Settings['assistant_placement'] != '') 
            {
                $assistant_placement = $aiomatic_Main_Settings['assistant_placement'];
            }
            $prompts  = aiomatic_get_assistant();
            if(!is_array($prompts))
            {
                $prompts = array();
            }
            $nonce = wp_create_nonce('wp_rest');
            wp_localize_script('aiomatic-gutenberg', 'aiomatic', array(
                'nonce'  =>  $nonce,
                'ajaxurl' => admin_url('admin-ajax.php'),
                'prompts' => $prompts,
                'placement' => $assistant_placement,
                'xicon' => plugins_url('/images/icon.png', __FILE__)
            ));
            $reg_css_code = '.aiomatic_editor_icon button{background-image: url("' . plugins_url('/images/icon.png', __FILE__) . '");background-size: 32px;background-repeat: no-repeat;background-position: center;}';
            wp_register_style( 'aiomatic-plugin-reg-style', false );
            wp_enqueue_style( 'aiomatic-plugin-reg-style' );
            wp_add_inline_style( 'aiomatic-plugin-reg-style', $reg_css_code );
        }
    }
}
function aiomatic_save_forms($formid, $title, $prompt, $model, $header, $submit, $description, $response, $max, $temperature, $topp, $presence, $frequency, $type, $aiomaticfields)
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    $forms_data = array(
        'post_type' => 'aiomatic_forms',
        'post_title' => $title,
        'post_content' => $description,
        'post_status' => 'publish'
    );
    if(!empty($formid))
    {
        $forms_data['ID'] = $formid;
    }
    if (!empty($post_type)) {
        $forms_data['post_type'] = $post_type;
    }
    $forms_data = sanitize_post($forms_data, 'db');
    remove_filter('content_save_pre', 'wp_filter_post_kses');
    remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
    if(!empty($formid))
    {
        $forms_id = wp_update_post($forms_data);
    }
    else
    {
        $forms_id = wp_insert_post($forms_data);
    }
    add_filter('content_save_pre', 'wp_filter_post_kses');
    add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
    if(is_wp_error($forms_id))
    {
        $aiomatic_result['msg'] = $forms_id->get_error_message();
    }
    elseif($forms_id === 0)
    {
        $aiomatic_result['msg'] = 'Failed to insert form to database: ' . $title;
    }
    else 
    {
        update_post_meta($forms_id, 'prompt', $prompt);
        update_post_meta($forms_id, 'model', $model);
        update_post_meta($forms_id, 'header', $header);
        update_post_meta($forms_id, 'submit', $submit);
        update_post_meta($forms_id, 'max', $max);
        update_post_meta($forms_id, 'temperature', $temperature);
        update_post_meta($forms_id, 'topp', $topp);
        update_post_meta($forms_id, 'presence', $presence);
        update_post_meta($forms_id, 'frequency', $frequency);
        update_post_meta($forms_id, 'response', $response);
        update_post_meta($forms_id, 'type', $type);
        update_post_meta($forms_id, '_aiomaticfields', $aiomaticfields);
        $aiomatic_result['status'] = 'success';
        $aiomatic_result['id'] = $forms_id;
    }
    return $aiomatic_result;
}
require(dirname(__FILE__) . "/res/StatisticsClass.php");
require(dirname(__FILE__) . "/res/QueryClass.php");
$aiomatic_stats = new Aiomatic_Statistics();
add_action('init', 'aiomatic_create_taxonomy', 0);
function aiomatic_create_taxonomy()
{
    if(AIOMATIC_IS_DEBUG === true)
    {
        $labels = array(
            'name' => 'AI Training File',
            'all_items' => 'All AI Training Files',
            'singular_name' => 'aiomatic_file',
            'add_new' => 'New AI Training File' ,
            'add_new_item' => 'Add New AI Training File',
            'edit_item' => 'Edit AI Training File',
            'new_item' => 'New AI Training File',
            'view_item' => 'View AI Training File',
            'search_items' => 'Search AI Training Files',
            'not_found' => 'No AI Training Files found',
            'not_found_in_trash' => 'No AI Training File found in Trash',
            'parent_item_colon' => 'Parent AI Training Files:',
            'menu_name' => 'AI Training Files',
        );
        $args = array(
            'labels' => $labels,
            'hierarchical' => false,
            'description' => 'AI Training Files',
            'supports' => array( 'title', 'editor', 'custom-fields' ),
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
            'show_in_admin_bar' => true,
            'show_in_rest' => false,
            'menu_position' => 66666665666666666,
            'publicly_queryable' => true,
            'exclude_from_search' => true,
            'has_archive' => false,
            'query_var' => true,
            'can_export' => true,
            'rewrite' => true,
            'capability_type' => 'post'
        );
        $admin_caps = array('capabilities' => array(
            'edit_post'          => 'manage_options',
            'read_post'          => 'manage_options',
            'delete_post'        => 'manage_options',
            'edit_posts'         => 'manage_options',
            'edit_others_posts'  => 'manage_options',
            'delete_posts'       => 'manage_options',
            'publish_posts'      => 'manage_options',
            'read_private_posts' => 'manage_options'
        ));
        $args = array_merge($args, $admin_caps);
        register_post_type( 'aiomatic_file', $args);

        $labels = array(
            'name' => 'AI Conversion File',
            'all_items' => 'All AI Conversion Files',
            'singular_name' => 'aiomatic_convert',
            'add_new' => 'New AI Conversion File' ,
            'add_new_item' => 'Add New AI Conversion File',
            'edit_item' => 'Edit AI Conversion File',
            'new_item' => 'New AI Conversion File',
            'view_item' => 'View AI Conversion File',
            'search_items' => 'Search AI Conversion Files',
            'not_found' => 'No AI Conversion Files found',
            'not_found_in_trash' => 'No AI Conversion File found in Trash',
            'parent_item_colon' => 'Parent AI Conversion Files:',
            'menu_name' => 'AI Conversion Files',
        );
        $args = array(
            'labels' => $labels,
            'hierarchical' => false,
            'description' => 'AI Conversion Files',
            'supports' => array( 'title', 'editor', 'custom-fields' ),
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
            'show_in_admin_bar' => true,
            'show_in_rest' => false,
            'menu_position' => 66666665666666666,
            'publicly_queryable' => true,
            'exclude_from_search' => true,
            'has_archive' => false,
            'query_var' => true,
            'can_export' => true,
            'rewrite' => true,
            'capability_type' => 'post'
        );
        $admin_caps = array('capabilities' => array(
            'edit_post'          => 'manage_options',
            'read_post'          => 'manage_options',
            'delete_post'        => 'manage_options',
            'edit_posts'         => 'manage_options',
            'edit_others_posts'  => 'manage_options',
            'delete_posts'       => 'manage_options',
            'publish_posts'      => 'manage_options',
            'read_private_posts' => 'manage_options'
        ));
        $args = array_merge($args, $admin_caps);
        register_post_type( 'aiomatic_convert', $args);

        $labels = array(
            'name' => 'AI Finetune',
            'all_items' => 'All AI Finetunes',
            'singular_name' => 'aiomatic_finetune',
            'add_new' => 'New AI Finetune' ,
            'add_new_item' => 'Add New AI Finetune',
            'edit_item' => 'Edit AI Finetune',
            'new_item' => 'New AI Finetune',
            'view_item' => 'View AI Finetune',
            'search_items' => 'Search AI Finetunes',
            'not_found' => 'No AI Finetunes found',
            'not_found_in_trash' => 'No AI Finetune found in Trash',
            'parent_item_colon' => 'Parent AI Finetune:',
            'menu_name' => 'AI Finetune',
        );
        $args = array(
            'labels' => $labels,
            'hierarchical' => false,
            'description' => 'AI Finetune',
            'supports' => array( 'title', 'editor', 'custom-fields' ),
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
            'show_in_admin_bar' => true,
            'show_in_rest' => false,
            'menu_position' => 66666665666666666,
            'publicly_queryable' => true,
            'exclude_from_search' => true,
            'has_archive' => false,
            'query_var' => true,
            'can_export' => true,
            'rewrite' => true,
            'capability_type' => 'post'
        );
        $admin_caps = array('capabilities' => array(
            'edit_post'          => 'manage_options',
            'read_post'          => 'manage_options',
            'delete_post'        => 'manage_options',
            'edit_posts'         => 'manage_options',
            'edit_others_posts'  => 'manage_options',
            'delete_posts'       => 'manage_options',
            'publish_posts'      => 'manage_options',
            'read_private_posts' => 'manage_options'
        ));
        $args = array_merge($args, $admin_caps);
        register_post_type( 'aiomatic_finetune', $args);
    }
    
    $labels = array(
        'name' => 'AI Embedding',
        'all_items' => 'All AI Embeddings',
        'singular_name' => 'aiomatic_embeddings',
        'add_new' => 'New AI Embedding' ,
        'add_new_item' => 'Add New AI Embeddings',
        'edit_item' => 'Edit AI Embeddings',
        'new_item' => 'New AI Embeddings',
        'view_item' => 'View AI Embeddings',
        'search_items' => 'Search AI Embeddings',
        'not_found' => 'No AI Embeddings found',
        'not_found_in_trash' => 'No AI Embeddings found in Trash',
        'parent_item_colon' => 'Parent AI Embeddings:',
        'menu_name' => 'AI Embeddings',
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => false,
        'description' => 'AI Embeddings',
        'supports' => array( 'title', 'editor', 'custom-fields' ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => false,
        'show_in_nav_menus' => false,
        'show_in_admin_bar' => false,
        'show_in_rest' => false,
        'menu_position' => 66666665666666666,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => false,
        'query_var' => true,
        'can_export' => false,
        'rewrite' => false,
        'capability_type' => 'post',
        'capabilities' => array(
            'create_posts' => false,
        )
    );
    $admin_caps = array('capabilities' => array(
        'edit_post'          => 'manage_options',
        'read_post'          => 'manage_options',
        'delete_post'        => 'manage_options',
        'edit_posts'         => 'manage_options',
        'edit_others_posts'  => 'manage_options',
        'delete_posts'       => 'manage_options',
        'publish_posts'      => 'manage_options',
        'read_private_posts' => 'manage_options'
    ));
    $args = array_merge($args, $admin_caps);
    register_post_type( 'aiomatic_embeddings', $args);

    $labels = array(
        'name' => 'AI Form',
        'all_items' => 'All AI Forms',
        'singular_name' => 'aiomatic_forms',
        'add_new' => 'New AI Form' ,
        'add_new_item' => 'Add New AI Forms',
        'edit_item' => 'Edit AI Forms',
        'new_item' => 'New AI Forms',
        'view_item' => 'View AI Forms',
        'search_items' => 'Search AI Forms',
        'not_found' => 'No AI Forms found',
        'not_found_in_trash' => 'No AI Forms found in Trash',
        'parent_item_colon' => 'Parent AI Forms:',
        'menu_name' => 'AI Forms',
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => false,
        'description' => 'AI Forms',
        'supports' => array( 'title', 'editor', 'custom-fields' ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => false,
        'show_in_nav_menus' => false,
        'show_in_admin_bar' => false,
        'show_in_rest' => false,
        'menu_position' => 66666665666666666,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => false,
        'query_var' => true,
        'can_export' => false,
        'rewrite' => false,
        'capability_type' => 'post',
        'capabilities' => array(
            'create_posts' => false,
        )
    );
    $admin_caps = array('capabilities' => array(
        'edit_post'          => 'manage_options',
        'read_post'          => 'manage_options',
        'delete_post'        => 'manage_options',
        'edit_posts'         => 'manage_options',
        'edit_others_posts'  => 'manage_options',
        'delete_posts'       => 'manage_options',
        'publish_posts'      => 'manage_options',
        'read_private_posts' => 'manage_options'
    ));
    $args = array_merge($args, $admin_caps);
    register_post_type( 'aiomatic_forms', $args);

    if ( function_exists( 'register_block_type' ) ) {
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-display', array(
            'render_callback' => 'aiomatic_display_posts_shortcode',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-list', array(
            'render_callback' => 'aiomatic_list_posts',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-article', array(
            'render_callback' => 'aiomatic_article',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-image', array(
            'render_callback' => 'aiomatic_image',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-stable-image', array(
            'render_callback' => 'aiomatic_stable_image',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-completion', array(
            'render_callback' => 'aiomatic_form_shortcode',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-editing', array(
            'render_callback' => 'aiomatic_edit_shortcode',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-image-generator', array(
            'render_callback' => 'aiomatic_image_shortcode',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-stable-image-generator', array(
            'render_callback' => 'aiomatic_stable_image_shortcode',
        ) );
        register_block_type( 'aiomatic-automatic-ai-content-writer/aiomatic-chat', array(
            'render_callback' => 'aiomatic_chat_shortcode',
        ) );
    }
    if(!taxonomy_exists('coderevolution_post_source'))
    {
        $labels = array(
            'name' => _x('Post Source', 'taxonomy general name', 'aiomatic-automatic-ai-content-writer'),
            'singular_name' => _x('Post Source', 'taxonomy singular name', 'aiomatic-automatic-ai-content-writer'),
            'search_items' => esc_html__('Search Post Source', 'aiomatic-automatic-ai-content-writer'),
            'popular_items' => esc_html__('Popular Post Source', 'aiomatic-automatic-ai-content-writer'),
            'all_items' => esc_html__('All Post Sources', 'aiomatic-automatic-ai-content-writer'),
            'parent_item' => null,
            'parent_item_colon' => null,
            'edit_item' => esc_html__('Edit Post Source', 'aiomatic-automatic-ai-content-writer'),
            'update_item' => esc_html__('Update Post Source', 'aiomatic-automatic-ai-content-writer'),
            'add_new_item' => esc_html__('Add New Post Source', 'aiomatic-automatic-ai-content-writer'),
            'new_item_name' => esc_html__('New Post Source Name', 'aiomatic-automatic-ai-content-writer'),
            'separate_items_with_commas' => esc_html__('Separate Post Source with commas', 'aiomatic-automatic-ai-content-writer'),
            'add_or_remove_items' => esc_html__('Add or remove Post Source', 'aiomatic-automatic-ai-content-writer'),
            'choose_from_most_used' => esc_html__('Choose from the most used Post Source', 'aiomatic-automatic-ai-content-writer'),
            'not_found' => esc_html__('No Post Sources found.', 'aiomatic-automatic-ai-content-writer'),
            'menu_name' => esc_html__('Post Source', 'aiomatic-automatic-ai-content-writer')
        );
        
        $args = array(
            'hierarchical' => false,
            'public' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'description' => 'Post Source',
            'labels' => $labels,
            'show_admin_column' => true,
            'update_count_callback' => '_update_post_term_count',
            'rewrite' => false
        );
        
        $add_post_type = array(
            'post',
            'page'
        );
        $xargs = array(
            'public'   => true,
            '_builtin' => false
        );
        $output = 'names'; 
        $operator = 'and';
        $post_types = get_post_types( $xargs, $output, $operator );
        if ( $post_types ) 
        {
            foreach ( $post_types  as $post_type ) {
                $add_post_type[] = $post_type;
            }
        }
        register_taxonomy('coderevolution_post_source', $add_post_type, $args);
        add_action('pre_get_posts', function($qry) {
            if (is_admin()) return;
            if (is_tax('coderevolution_post_source')){
                $qry->set_404();
            }
        });
    }
}

add_action( 'current_screen', function() {
    $embeddings_post_type = 'aiomatic_embeddings';
    $forms_post_type = 'aiomatic_forms';
    $screen = get_current_screen();
    global $pagenow;
    if ( ! in_array( $pagenow, array( 'post-new.php' ), true )
         && 'post' === $screen->base
         && ($embeddings_post_type === $screen->post_type || $forms_post_type === $screen->post_type) ) 
    {
        add_action( 'admin_footer', 'aiomatic_hide_batch_update_buttons' );
    }

});

add_filter('post_updated_messages', 'aiomatic_contact_updated_messages');
function aiomatic_contact_updated_messages( $messages ) 
{
    global $post;
    if($post->post_type == 'aiomatic_embeddings')
    {
        $messages['aiomatic_embeddings'] = array(
            0 => '',
            1 => __('Embedding updated.'),
            2 => __('Custom field updated.'),
            3 => __('Custom field deleted.'),
            4 => __('Embedding updated.'),
            5 => isset($_GET['revision']) ? sprintf( __('Embedding restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
            6 => __('Embedding published.'),
            7 => __('Embedding saved.'),
            8 => __('Embedding submitted.'),
            9 => __('Embedding scheduled for: <strong>%1$s</strong>.'),
            10 => __('Embedding draft updated.')
        );
    }
    elseif($post->post_type == 'aiomatic_forms')
    {
        $messages['aiomatic_forms'] = array(
            0 => '',
            1 => __('Form updated.'),
            2 => __('Custom field updated.'),
            3 => __('Custom field deleted.'),
            4 => __('Form updated.'),
            5 => isset($_GET['revision']) ? sprintf( __('Form restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
            6 => __('Form published.'),
            7 => __('Form saved.'),
            8 => __('Form submitted.'),
            9 => __('Form scheduled for: <strong>%1$s</strong>.'),
            10 => __('Form draft updated.')
        );
    }
    return $messages;
}
function aiomatic_hide_batch_update_buttons() {
	?>
	<script type="text/javascript">
	(function( $ ) {
		'use strict';
		$('#submitdiv .edit-post-status').remove();
		$('#submitdiv .edit-visibility').remove();
		$('#submitdiv .edit-timestamp').remove();
		$('#minor-publishing-actions').remove();
		$('#delete-action').remove();
		$('#aiomatic_meta_box_function_add').remove();
		$('#wp-content-media-buttons').remove();
	})( jQuery );
	</script>
	<?php
}

add_action('wp_loaded', 'aiomatic_run_cron', 0);
function aiomatic_run_cron()
{
    if(isset($_GET['run_aiomatic_edit']))
    {
        $aiomatic_Spinner_Settings = get_option('aiomatic_Spinner_Settings', false);
        if(isset($aiomatic_Spinner_Settings['auto_edit']) && $aiomatic_Spinner_Settings['auto_edit'] == 'external')
        {
            if(isset($aiomatic_Spinner_Settings['secret_word']) && $_GET['run_aiomatic_edit'] == urlencode($aiomatic_Spinner_Settings['secret_word']))
            {
                aiomatic_do_bulk_post();
                die();
            }
        }
    }
}
function aiomatic_disable_create_newpost() {
    global $wp_post_types;
    $wp_post_types['aiomatic_embeddings']->cap->create_posts = 'do_not_allow';
    $wp_post_types['aiomatic_forms']->cap->create_posts = 'do_not_allow';
}
add_action('init','aiomatic_disable_create_newpost');
function aiomatic_embeddings_result($aiomatic_message, $token)
{
    $result = array('status' => 'error','data' => '');
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['pinecone_app_id']) || trim($aiomatic_Main_Settings['pinecone_app_id']) == '') 
    {
        $result['data'] = 'Pinecone API key needed in plugin settings.';
        return $result;
    }
    if (!isset($aiomatic_Main_Settings['pinecone_index']) || trim($aiomatic_Main_Settings['pinecone_index']) == '') 
    {
        $result['data'] = 'Pinecone Index neededs to be added in plugin settings.';
        return $result;
    }
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        $result['data'] = 'OpenAI/AiomaticAPI API key needed in plugin settings.';
        return $result;
    }
    if (isset($aiomatic_Main_Settings['embeddings_model']) && trim($aiomatic_Main_Settings['embeddings_model']) != '') 
    {
        $embeddings_model = trim($aiomatic_Main_Settings['embeddings_model']);
    }
    else
    {
        $embeddings_model = 'text-embedding-ada-002';
    }
    if (isset($aiomatic_Main_Settings['pinecone_topk']) && trim($aiomatic_Main_Settings['pinecone_topk']) != '') 
    {
        $pinecone_topk = intval(trim($aiomatic_Main_Settings['pinecone_topk']));
        if($pinecone_topk < 1 || $pinecone_topk > 10000)
        {
            $pinecone_topk = 1;
        }
    }
    else
    {
        $pinecone_topk = 1;
    }
    if(empty($result['data'])) 
    {
        $session = aiomatic_get_session_id();
        $maxResults = 1;
        $query = new Aiomatic_Query($aiomatic_message, 2048, $embeddings_model, 0, '', 'embeddings', 'embeddings', $token, $session, $maxResults, '');
        $delay = '';
        if (isset($aiomatic_Main_Settings['request_delay']) && $aiomatic_Main_Settings['request_delay'] != '') 
        {
            if(stristr($aiomatic_Main_Settings['request_delay'], ',') !== false)
            {
                $tempo = explode(',', $aiomatic_Main_Settings['request_delay']);
                if(isset($tempo[1]) && is_numeric(trim($tempo[1])) && is_numeric(trim($tempo[0])))
                {
                    $delay = rand(trim($tempo[0]), trim($tempo[1]));
                }
            }
            else
            {
                if(is_numeric(trim($aiomatic_Main_Settings['request_delay'])))
                {
                    $delay = intval(trim($aiomatic_Main_Settings['request_delay']));
                }
            }
        }
        if($delay != '' && is_numeric($delay))
        {
            usleep($delay);
        }
        if(aiomatic_is_aiomaticapi_key($token))
        {
            $error = '';
            $response = aiomatic_embeddings_aiomaticapi($token, $embeddings_model, $aiomatic_message, 0, $error);
            if($response === false)
            {
                $result['data'] = 'Failed to call Embeddings API: ' . $error;
                return $result;
            }
            if(isset($response->error))
            {
                $result['data'] = 'Error while processing AI response: ' . $response->error;
                return $result;
            }
            if(!isset($response[0]->embedding))
            {
                $result['data'] = 'Failed to call Embeddings API: ' . print_r($response, true);
                return $result;
            }
            apply_filters( 'aiomatic_ai_reply', $response, $query );
            $embedding = $response[0]->embedding;
            if (!empty($embedding)) {
                $headers = array(
                    'Content-Type' => 'application/json',
                    'Api-Key' => trim($aiomatic_Main_Settings['pinecone_app_id'])
                );
                $response = wp_remote_post('https://' . trim($aiomatic_Main_Settings['pinecone_index']) . '/query', array(
                    'headers' => $headers,
                    'body' => json_encode(array(
                        'vector' => $embedding,
                        'topK' => $pinecone_topk
                    ))
                ));
                if (is_wp_error($response)) {
                    $result['data'] = esc_html($response->get_error_message());
                } else {
                    $body = json_decode($response['body'], true);
                    if ($body) {
                        if (isset($body['matches']) && is_array($body['matches']) && count($body['matches'])) 
                        {
                            $data = '';
                            $found = false;
                            foreach($body['matches'] as $match){
                                $aiomatic_embedding = get_post($match['id']);
                                if ($aiomatic_embedding) {
                                    $data .= empty($data) ? $aiomatic_embedding->post_content : "\n" . $aiomatic_embedding->post_content;
                                    $found = true;
                                }
                            }
                            if($found == true)
                            {
                                $result['data'] = $data;
                                $result['status'] = 'success';
                            }
                            else
                            {
                                $result['data'] = 'No results found';
                            }
                        }
                    }
                }
            }
        }
        elseif(isset($aiomatic_Main_Settings['api_selector']) && trim($aiomatic_Main_Settings['api_selector']) == 'azure')
        {
            $error = '';
            $response = aiomatic_embeddings_azure($token, $embeddings_model, $aiomatic_message, 0, $error);
            if($response === false)
            {
                $result['data'] = 'Failed to call Embeddings API: ' . $error;
                return $result;
            }
            if(isset($response->error))
            {
                $result['data'] = 'Error while processing AI response: ' . $response->error;
                return $result;
            }
            if(!isset($response[0]->embedding))
            {
                $result['data'] = 'Failed to call Embeddings API: ' . print_r($response, true);
                return $result;
            }
            apply_filters( 'aiomatic_ai_reply', $response, $query );
            $embedding = $response[0]->embedding;
            if (!empty($embedding)) {
                $headers = array(
                    'Content-Type' => 'application/json',
                    'Api-Key' => trim($aiomatic_Main_Settings['pinecone_app_id'])
                );
                $response = wp_remote_post('https://' . trim($aiomatic_Main_Settings['pinecone_index']) . '/query', array(
                    'headers' => $headers,
                    'body' => json_encode(array(
                        'vector' => $embedding,
                        'topK' => $pinecone_topk
                    ))
                ));
                if (is_wp_error($response)) {
                    $result['data'] = esc_html($response->get_error_message());
                } else {
                    $body = json_decode($response['body'], true);
                    if ($body) {
                        if (isset($body['matches']) && is_array($body['matches']) && count($body['matches'])) 
                        {
                            $data = '';
                            $found = false;
                            foreach($body['matches'] as $match){
                                $aiomatic_embedding = get_post($match['id']);
                                if ($aiomatic_embedding) {
                                    $data .= empty($data) ? $aiomatic_embedding->post_content : "\n" . $aiomatic_embedding->post_content;
                                    $found = true;
                                }
                            }
                            if($found == true)
                            {
                                $result['data'] = $data;
                                $result['status'] = 'success';
                            }
                            else
                            {
                                $result['data'] = 'No results found';
                            }
                        }
                    }
                }
            }
        }
        else
        {
            require_once (dirname(__FILE__) . "/res/openai/Url.php"); 
            require_once (dirname(__FILE__) . "/res/openai/OpenAi.php");
            $open_ai = new OpenAi($token);
            $response = $open_ai->embeddings([
                'input' => $aiomatic_message,
                'model' => $embeddings_model
            ]);
            $response = json_decode($response, true);
            if (isset($response['error']) && !empty($response['error'])) {
                $result['data'] = $response['error']['message'];
            } else {
                apply_filters( 'aiomatic_ai_reply', $response, $query );
                $embedding = $response['data'][0]['embedding'];
                if (!empty($embedding)) {
                    $headers = array(
                        'Content-Type' => 'application/json',
                        'Api-Key' => trim($aiomatic_Main_Settings['pinecone_app_id'])
                    );
                    $response = wp_remote_post('https://' . trim($aiomatic_Main_Settings['pinecone_index']) . '/query', array(
                        'headers' => $headers,
                        'body' => json_encode(array(
                            'vector' => $embedding,
                            'topK' => $pinecone_topk
                        ))
                    ));
                    if (is_wp_error($response)) {
                        $result['data'] = esc_html($response->get_error_message());
                    } else {
                        $body = json_decode($response['body'], true);
                        if ($body) {
                            if (isset($body['matches']) && is_array($body['matches']) && count($body['matches'])) 
                            {
                                $data = '';
                                $found = false;
                                foreach($body['matches'] as $match){
                                    $aiomatic_embedding = get_post($match['id']);
                                    if ($aiomatic_embedding) {
                                        $data .= empty($data) ? $aiomatic_embedding->post_content : "\n" . $aiomatic_embedding->post_content;
                                        $found = true;
                                    }
                                }
                                if($found == true)
                                {
                                    $result['data'] = $data;
                                    $result['status'] = 'success';
                                }
                                else
                                {
                                    $result['data'] = 'No results found';
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return $result;
}

function aiomatic_extract_keywords($aicontent)
{
    $generated_text = '';
    $max_tokens = 2000;
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
    {
        return $generated_text;
    }
    $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
    $aicontent = trim(strip_shortcodes(strip_tags(str_replace('"', '\'', $aicontent))));
    if (isset($aiomatic_Main_Settings['keyword_extractor_prompt']) && trim($aiomatic_Main_Settings['keyword_extractor_prompt']) != '') 
    {
        $title_ai_command = trim($aiomatic_Main_Settings['keyword_extractor_prompt']);
        $title_ai_command = str_replace('%%original_prompt%%', $aicontent, $title_ai_command);
    }
    else
    {
        $title_ai_command = 'Using which keyword or phrase should I search the internet, so I get results related to this text: "' . $aicontent . '"?';
    }
    if(isset($aiomatic_Main_Settings['internet_model']) && $aiomatic_Main_Settings['internet_model'] != '')
    {
        $kw_model = $aiomatic_Main_Settings['internet_model'];
    }
    else
    {
        $kw_model = 'text-davinci-003';
    }
    $max_tokens = aiomatic_get_max_tokens($kw_model);
    $query_token_count = count(aiomatic_encode($title_ai_command));
    $available_tokens = $max_tokens - $query_token_count;
    if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
    {
        $string_len = strlen($title_ai_command);
        $string_len = $string_len / 2;
        $string_len = intval(0 - $string_len);
        $title_ai_command = aiomatic_substr($title_ai_command, 0, $string_len);
        $title_ai_command = trim($title_ai_command);
        $query_token_count = count(aiomatic_encode($title_ai_command));
        $available_tokens = $max_tokens - $query_token_count;
    }
    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
    {
        $api_service = aiomatic_get_api_service($token);
        aiomatic_log_to_file('Calling ' . $api_service . ' (' . $kw_model . ') for internet access kws: ' . $title_ai_command);
    }
    $aierror = '';
    $finish_reason = '';
    $generated_text = aiomatic_generate_text($token, $kw_model, $title_ai_command, $available_tokens, 1, 1, 0, 0, false, 'shortcodeKeywordArticle', 0, $finish_reason, $aierror, true);
    if($generated_text === false)
    {
        aiomatic_log_to_file('Keywords generator error: ' . $aierror);
        return '';
    }
    else
    {
        $generated_text = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
    }
    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
    {
        aiomatic_log_to_file('Successfully got API keyword result (for internet access):' . $generated_text);
    }
    return $generated_text;
}
function aiomatic_internet_result($query)
{
    $query = trim(preg_replace('/\s\s+/', ' ', $query));
    $internet_search = array();
    $aikws = aiomatic_extract_keywords($query);
    if(!empty($aikws))
    {
        $query = $aikws;
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['valueserp_auth']) && trim($aiomatic_Main_Settings['valueserp_auth']) != '')
    {
        $serpapi = 'https://api.valueserp.com/search?q=' . urlencode($query) . '&api_key=' . trim($aiomatic_Main_Settings['valueserp_auth']);
        $html_data = aiomatic_get_web_page($serpapi);
        if ($html_data !== FALSE) 
        {
            $json = json_decode($html_data);
            if ($json !== FALSE) 
            {
                if(isset($json->organic_results))
                {
                    foreach($json->organic_results as $jsx)
                    {
                        if(isset($jsx->title))
                        {
                            if(!isset( $jsx->snippet))
                            {
                                $jsx->snippet = '';
                            }
                            $internet_search[] = array('title' => $jsx->title, 'link' => $jsx->link, 'snippet' => $jsx->snippet);
                        }
                    }
                }
            }
        }
    }
    if (isset($aiomatic_Main_Settings['serpapi_auth']) && trim($aiomatic_Main_Settings['serpapi_auth']) != '')
    {
        $serpapi = 'https://serpapi.com/search.json?q=' . urlencode($query) . '&api_key=' . trim($aiomatic_Main_Settings['serpapi_auth']);
        $html_data = aiomatic_get_web_page($serpapi);
        if ($html_data !== FALSE) 
        {
            $json = json_decode($html_data);
            if ($json !== FALSE) 
            {
                if(isset($json->organic_results))
                {
                    foreach($json->organic_results as $jsx)
                    {
                        if(isset($jsx->title))
                        {
                            if(!isset( $jsx->snippet))
                            {
                                $jsx->snippet = '';
                            }
                            $internet_search[] = array('title' => $jsx->title, 'link' => $jsx->link, 'snippet' => $jsx->snippet);
                        }
                    }
                }
            }
        }
    }
    if (count($internet_search) == 0)
    {
        $query_arr = explode(',', $query);
        $query = $query_arr[0];
        require_once (dirname(__FILE__) . "/res/Bing.php");
        $bing = new AiomaticBing($query, true);
        if(isset($bing->data))
        {
            foreach($bing->data as $bg)
            {
                $internet_search[] = array('title' => $bg['title'], 'link' => $bg['link'], 'snippet' => $bg['description']);
            }
        }
        else
        {
            $burl = "https://www.bing.com/search?q=" . urlencode($query);
            $html_data = aiomatic_get_web_page($burl);
            if ($html_data !== FALSE) 
            {
                preg_match_all('#<li class="b_algo">([\s\S]*?)<\/li>#i', $html_data, $htmlrez);
                if(isset($htmlrez[1][0]))
                {
                    preg_match_all('#<h2><a (?:target="_blank"\s)?href="([^"]*?)"[\s\S]*?>([\s\S]*?)<\/a><\/h2>[\s\S]*?b_algoSlug">([\s\S]*?)<\/span>#i', $htmlrez[1][0], $titlerez);
                    if(isset($titlerez[1][0]))
                    {
                        for($cnt = 0; $cnt < count($titlerez[1]); $cnt++)
                        {
                            $title = '';
                            $url = '';
                            $snippet = '';
                            if(isset($titlerez[1][$cnt]) && isset($titlerez[2][$cnt]) && isset($titlerez[3][$cnt]))
                            {
                                $url = $titlerez[1][$cnt];
                                $title = $titlerez[2][$cnt];
                                $snippet = $titlerez[3][$cnt];
                            }
                            if($title != '' && $url != '')
                            {
                                $internet_search[] = array('title' => strip_tags($title), 'link' => $url, 'snippet' => $snippet);
                            }
                        }
                    }
                }
            }
        }
    }
    return $internet_search;
}
add_action('upgrader_process_complete', 'aiomatic_updatePlugin', 10, 2);
function aiomatic_updatePlugin(\WP_Upgrader $upgrader, array $hook_extra)
{
    if (is_array($hook_extra) && array_key_exists('action', $hook_extra) && array_key_exists('type', $hook_extra) && array_key_exists('plugins', $hook_extra)) {
        if ($hook_extra['action'] == 'update' && $hook_extra['type'] == 'plugin' && is_array($hook_extra['plugins']) && !empty($hook_extra['plugins'])) {
            $this_plugin = plugin_basename(__FILE__);
            foreach ($hook_extra['plugins'] as $key => $plugin) {
                if ($this_plugin == $plugin) {
                    $this_plugin_updated = true;
                    break;
                }
            }
            unset($key, $plugin, $this_plugin);
            if (isset($this_plugin_updated) && $this_plugin_updated === true) {
                require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
                global $wpdb;
                global $charset_collate;
                aiomatict_register_aggregated_feed_table();
                $sql_create_table = "CREATE TABLE IF NOT EXISTS {$wpdb->aiomatict_shortcode_rez} (
                      post_id bigint(20) unsigned NOT NULL auto_increment,
                      post_hash text default '',
                      post_result text default '',
                      PRIMARY KEY  (post_id)
                 ) $charset_collate; ";
                dbDelta( $sql_create_table );
            }
        }
    }
}






register_activation_hook(__FILE__, 'aiomatic_activation_callback');
function aiomatic_activation_callback($defaults = FALSE)
{
    if (!get_option('aiomatic_posts_per_page') || $defaults === TRUE) {
        if ($defaults === FALSE) {
            add_option('aiomatic_posts_per_page', '12');
        } else {
            update_option('aiomatic_posts_per_page', '12');
        }
    }
    if (!get_option('aiomatic_Main_Settings') || $defaults === TRUE) {
        $aiomatic_Main_Settings = array(
            'aiomatic_enabled' => 'on',
            'translate' => 'disabled',
            'translate_source'  => 'disabled',
            'bing_region' => '',
            'custom_html2' => '',
            'custom_html' => '',
            'google_trans_auth' => '',
            'deppl_free' => '',
            'deepl_auth' => '',
            'serpapi_auth' => '',
            'valueserp_auth' => '',
            'yt_app_id' => '',
            'copy_locally' => 'on',
            'ai_resize_width' => '',
            'ai_resize_height' => '',
            'request_delay' => '',
            'player_height' => '',
            'player_width' => '',
            'sentence_list' => 'This is one %adjective %noun %sentence_ending
This is another %adjective %noun %sentence_ending
I %love_it %nouns , because they are %adjective %sentence_ending
My %family says this plugin is %adjective %sentence_ending
These %nouns are %adjective %sentence_ending',
            'sentence_list2' => 'Meet this %adjective %noun %sentence_ending
This is the %adjective %noun ever %sentence_ending
I %love_it %nouns , because they are the %adjective %sentence_ending
My %family says this plugin is very %adjective %sentence_ending
These %nouns are quite %adjective %sentence_ending',
            'variable_list' => 'adjective_very => %adjective;very %adjective;

adjective => clever;interesting;smart;huge;astonishing;unbelievable;nice;adorable;beautiful;elegant;fancy;glamorous;magnificent;helpful;awesome

noun_with_adjective => %noun;%adjective %noun

noun => plugin;WordPress plugin;item;ingredient;component;constituent;module;add-on;plug-in;addon;extension

nouns => plugins;WordPress plugins;items;ingredients;components;constituents;modules;add-ons;plug-ins;addons;extensions

love_it => love;adore;like;be mad for;be wild about;be nuts about;be crazy about

family => %adjective %family_members;%family_members

family_members => grandpa;brother;sister;mom;dad;grandma

sentence_ending => .;!;!!',
            'auto_clear_logs' => 'No',
            'run_after' => '',
            'max_len' => '',
            'ai_image_size' => '512x512',
            'image_chat_size' => '512x512',
            'back_color' => '#ffffff',
            'show_advanced' => '',
            'show_rich_editor' => '',
            'submit_location' => '1',
            'submit_align' => '1',
            'text_color' => '#000000',
            'but_color' => '#424242;',
            'btext_color' => '#ffffff',
            'min_len' => '',
            'kw_lang' => 'en_US',
            'pinecone_index' => '',
            'pinecone_topk' => '1',
            'embeddings_model' => 'text-embedding-ada-002',
            'run_before' => '',
            'enable_logging' => 'on',
            'app_id' => '',
            'stability_app_id' => '',
            'azure_endpoint' => '',
            'api_selector' => 'openai',
            'pinecone_app_id' => '',
            'elevenlabs_app_id' => '',
            'google_app_id' => '',
            'steps' => '50',
            'cfg_scale' => '7',
            'clip_guidance_preset' => 'NONE',
            'stable_model' => 'stable-diffusion-512-v2-0',
            'sampler' => 'auto',
            'enable_detailed_logging' => '',
            'rule_timeout' => '3600',
            'email_address' => '',
            'send_email' => '',
            'best_password' => '',
            'best_user' => '',
            'improve_keywords' => 'disabled',
            'keyword_model' => 'text-davinci-003',
            'internet_model' => 'text-davinci-003',
            'assistant_model' => 'text-davinci-003',
            'aicontent_model' => 'text-davinci-003',
            'aicontent_temperature' => '1',
            'aicontent_top_p' => '1',
            'aicontent_presence_penalty' => '0',
            'aicontent_frequency_penalty' => '0',
            'keyword_prompts' => 'Extract a comma separated list of relevant keywords from the text: \'%%post_title%%\'.',
            'spin_lang' => 'English',
            'exclude_words' => '',
            'spin_text' => 'disabled',
            'no_title' => '',
            'no_html_check' => 'on',
            'protect_html' => 'on',
            'swear_filter' => '',
            'no_media_library' => '',
            'apiKey' => '',
            'resize_height' => '',
            'resize_width' => '',
            'morguefile_api' => '',
            'morguefile_secret' => '',
            'pexels_api' => '',
            'flickr_api' => '',
            'flickr_license' => '',
            'flickr_order' => '',
            'pixabay_api' => '',
            'imgtype' => '',
            'img_order' => '',
            'img_cat' => '',
            'img_width' => '',
            'img_mwidth' => '',
            'img_ss' => '',
            'img_editor' => '',
            'img_language' => '',
            'unsplash_api' => 'on',
            'google_images' => 'on',
            'pixabay_scrape' => 'on',
            'scrapeimgtype' => '',
            'scrapeimg_orientation' => '',
            'scrapeimg_order' => '',
            'scrapeimg_cat' => '',
            'scrapeimg_width' => '',
            'scrapeimg_height' => '',
            'attr_text' => '',
            'textrazor_key' => '',
            'bimage' => '',
            'no_royalty_skip' => '',
            'proxy_url' => '',
            'proxy_auth' => '',
            'do_not_check_duplicates' => '',
            'global_req_words' => '',
            'require_only_one' => '',
            'global_ban_words' => '',
            'embeddings_related' => '',
            'embeddings_forms' => '',
            'embeddings_assistant' => '',
            'embeddings_edit_short' => '',
            'embeddings_article_short' => '',
            'embeddings_chat_short' => '',
            'embeddings_edit' => '',
            'embeddings_bulk' => '',
            'embeddings_single' => '',
            'internet_related' => '',
            'internet_edit_short' => '',
            'internet_article_short' => '',
            'internet_chat_short' => '',
            'internet_edit' => '',
            'internet_bulk' => '',
            'internet_forms' => '',
            'internet_assistant' => '',
            'results_num' => '3',
            'internet_prompt' => 'Web search results:
%%web_results%%
Current date: %%current_date%%
Instructions: Using the provided web search results, write a comprehensive reply to the given query. Make sure to cite results using <a href="(URL)">[[number]]</a> notation after the reference. If the provided search results refer to multiple subjects with the same name, write separate answers for each subject.
Query: %%original_query%%',
            'internet_single_template' => '[%%result_counter%%]: %%result_title%% %%result_snippet%%
URL: %%result_link%%',
            'internet_single' => '',
            'keyword_extractor_prompt' => 'Using which keyword or phrase should I search the internet, so I get results related to this text: "%%original_prompt%%"?',
            'alternate_continue' => '',
            'no_max' => '',
            'bing_off' => '',
            'ai_off' => '',
            'max_retry' => '5',
            'max_chat_retry' => '',
            'completion_suffix' => ' ###',
            'rel_search' => array('post_title', 'post_content'),
            'prompt_suffix' => ' ->',
            'ignored_users' => 'admin',
            'enable_tracking' => '',
            'assistant_placement' => 'below',
            'assistant_disable' => '',
            'assistant_image_size' => '512x512',
            'assistant_temperature' => '1',
            'assistant_top_p' => '1',
            'assistant_ppenalty' => '0',
            'assistant_fpenalty' => '0',
            'protect_html' => '',
            'no_content' => '',
            'tag_name' => '',
            'post_id' => '',
            'post_name' => '',
            'page_id' => '',
            'post_parent' => '',
            'post_status' => '',
            'type_post' => 'post',
            'pagename' => '',
            'search_offset' => '',
            'search_query' => '',
            'meta_name' => '',
            'meta_value' => '',
            'year' => '',
            'month' => '',
            'day' => '',
            'order' => '',
            'orderby' => '',
            'featured_image' => 'any',
            'max_posts' => '',
            'category_name' => '',
            'author_id' => '',
            'author_name' => '',
            'max_nr' => '1',
            'no_twice' => 'on',
            'secret_word' => '',
            'auto_edit' => 'disabled',
            'auto_run_interval' => 'No'
        );
        if ($defaults === FALSE) {
            add_option('aiomatic_Main_Settings', $aiomatic_Main_Settings);
        } else {
            update_option('aiomatic_Main_Settings', $aiomatic_Main_Settings);
        }
    }
    if (!get_option('aiomatic_Spinner_Settings') || $defaults === TRUE) {
        $aiomatic_Spinner_Settings = array(
            'aiomatic_spinning' => '',
            'run_background' => '',
            'post_posts' => '',
            'post_pages'  => 'on',
            'post_custom' => 'on',
            'except_type' => '',
            'disabled_categories' => array(),
            'disable_tags' => '',
            'change_status' => 'no',
            'delay_post' => '',
            'process_event' => 'publish',
            'append_spintax' => 'append',
            'ai_rewriter' => '',
            'ai_instruction' => '',
            'ai_instruction_title' => '',
            'edit_temperature' => '',
            'edit_top_p' => '',
            'max_char_chunks' => '',
            'no_title' => '',
            'rewrite_url' => '',
            'edit_model' => 'text-davinci-003',
            'no_content' => '',
            'no_excerpt' => 'on',
            'ai_instruction_excerpt' => '',
            'ai_featured_image' => 'disabled',
            'ai_featured_image_source' => '1',
            'ai_image_command' => 'A high detail photograph of %%post_title%%',
            'image_size' => '',
            'min_char' => '',
            'images' => '',
            'videos' => '',
            'add_links' => 'disabled',
            'max_links' => '3-5',
            'link_post_types' => 'post',
            'headings' => '',
            'enable_ai_images' => '',
            'headings_ai_command' => 'Write %%needed_heading_count%% PAA related questions, each on a new line, for the title: %%post_title%%',
            'headings_model' => 'text-davinci-003',
            'ai_command' => 'Write a formal article in English about: "%%post_title%%"',
            'max_seed_tokens' => '',
            'max_result_tokens' => '',
            'max_continue_tokens' => '',
            'max_tokens' => '2048',
            'temperature' => '1',
            'top_p' => '1',
            'presence_penalty' => '0',
            'frequency_penalty' => '0',
            'model' => 'text-davinci-003',
            'ai_comments' => 'Write a single comment (don\'t start a new line) for the post title: %%post_title%%
Previous comments are:
%%previous_comments%%
%%comment_author_name%%:',
            'prev_comms' => '5',
            'max_comments' => '1-2',
            'add_comments' => 'disabled',
            'comments_model' => 'text-davinci-003',
            'user_list' => '%%random_user%%',
            'url_list' => '',
            'seo_model' => 'text-davinci-003',
            'ai_seo' => 'Write a SEO meta description for the post title: %%post_title%%',
            'add_seo' => '',
        );
        if ($defaults === FALSE) {
            add_option('aiomatic_Spinner_Settings', $aiomatic_Spinner_Settings);
        } else {
            update_option('aiomatic_Spinner_Settings', $aiomatic_Spinner_Settings);
        }
    }
    if (!get_option('aiomatic_Chatbot_Settings') || $defaults === TRUE) {
        $aiomatic_Chatbot_Settings = array(
            'font_size' => '1em',
            'voice_language' => 'en-US',
            'google_voice' => '',
            'audio_profile' => '',
            'voice_speed' => '1',
            'voice_pitch' => '0',
            'chatbot_text_speech' => 'off',
            'eleven_voice' => '',
            'width' => '100%',
            'height' => 'auto',
            'minheight' => '250px',
            'background' => '#f7f7f9',
            'user_font_color' => '#ffffff',
            'user_background_color' => '#0084ff',
            'ai_font_color' => 'black',
            'ai_background_color' => '#f0f0f0',
            'input_border_color' => '#e1e3e6',
            'submit_color' => '#55a7e2',
            'submit_text_color' => '#ffffff',
            'enable_moderation' => '',
            'moderation_model' => 'text-moderation-stable',
            'flagged_message' => 'Your message has been flagged as potentially harmful or inappropriate. Please review your language and content to ensure it aligns with our values of respect and sensitivity towards others. Thank you for your cooperation.',
            'enable_copy' => '',
            'scroll_bot' => '',
            'instant_response' => 'false',
            'voice_input' => '',
            'chat_model' => 'gpt-3.5-turbo',
            'temperature' => '1',
            'top_p' => '1',
            'presence_penalty' => '0',
            'frequency_penalty' => '0',
            'chat_preppend_text' => 'Converse as if you were a Marketing Agency Assistant. Be friendly, creative. Respond only in English.',
            'ai_message_preppend' => 'AI:',
            'user_message_preppend' => 'User:',
            'ai_first_message' => 'Hi! How can I help you?',
            'chat_mode' => 'text',
            'user_token_cap_per_day' => '',
            'max_input_length' => '',
            'persistent' => 'off',
            'prompt_editable' => 'on',
            'prompt_templates' => '',
            'placeholder' => 'Enter your chat message here',
            'submit' => 'Submit',
            'window_location' => 'bottom-right', 
            'enable_front_end' => 'off',
            'window_width' => '400px',
            'not_show_urls' => '',
            'chatbot_icon' => '1',
            'chatbot_icon_html' => ''
        );
        if ($defaults === FALSE) {
            add_option('aiomatic_Chatbot_Settings', $aiomatic_Chatbot_Settings);
        } else {
            update_option('aiomatic_Chatbot_Settings', $aiomatic_Chatbot_Settings);
        }
    }
    if (!get_option('aiomatic_Limit_Settings') || $defaults === TRUE) {
        $aiomatic_Limit_Settings = array(
            'user_credits' => '',
            'guest_credits' => '',
            'limit_message_not_logged' => 'You have reached the usage limit.',
            'limit_message_rule' => 'You have reached the usage limit.',
            'limit_message_logged' => 'You have reached the usage limit.',
            'ignored_users'  => 'admin',
            'user_credit_type' => 'units',
            'guest_credit_type' => 'queries',
            'user_time_frame' => 'month',
            'guest_time_frame' => 'day',
            'is_absolute_user' => '',
            'is_absolute_guest' => '',
            'enable_limits' => ''
        );
        if ($defaults === FALSE) {
            add_option('aiomatic_Limit_Settings', $aiomatic_Limit_Settings);
        } else {
            update_option('aiomatic_Limit_Settings', $aiomatic_Limit_Settings);
        }
    }
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    global $wpdb;
    global $charset_collate;
    aiomatict_register_aggregated_feed_table();
    $sql_create_table = "CREATE TABLE IF NOT EXISTS {$wpdb->aiomatict_shortcode_rez} (
          post_id bigint(20) unsigned NOT NULL auto_increment,
          post_hash text default '',
          post_result text default '',
          PRIMARY KEY  (post_id)
     ) $charset_collate; ";
    
    dbDelta( $sql_create_table );
}
add_action( 'pre_user_query', 'aiomatict_random_user_query' );

function aiomatic_get_eleven_voices()
{
    $default_voices = array(
        '21m00Tcm4TlvDq8ikWAM' => 'Rachel',
        'AZnzlk1XvdvUeBnXmlld' => 'Domi',
        'EXAVITQu4vr4xnSDxMaL' => 'Bella',
        'ErXwobaYiN019PkySvjV' => 'Antoni',
        'MF3mGyEYCl7XYWbV9V6O' => 'Elli',
        'TxGEqnHWrfWFTfGW9XjX' => 'Josh',
        'VR6AewLTigWG4xSOukaG' => 'Arnold',
        'pNInz6obpgDQGcFmaJgB' => 'Adam',
        'yoZ06aMxZJJ28mfd3POQ' => 'Sam'
    );
    $aiomatic_elevenlabs = get_option('aiomatic_elevenlabs', false);
	if(is_array($aiomatic_elevenlabs))
	{
		return array_merge($aiomatic_elevenlabs, $default_voices);
	}
    $aiomatic_elevenlabs = aiomatic_update_elevenlabs_voices();
    if(is_array($aiomatic_elevenlabs))
    {
        update_option('aiomatic_elevenlabs', $aiomatic_elevenlabs);
        return array_merge($aiomatic_elevenlabs, $default_voices);
    }
	return $default_voices;
}

function aiomatic_get_google_voices($language)
{
    $aiomatic_elevenlabs = get_option('aiomatic_google_voices' . sanitize_title($language), false);
	if(is_array($aiomatic_elevenlabs))
	{
		return $aiomatic_elevenlabs;
	}
    $aiomatic_elevenlabs = aiomatic_update_google_voices($language);
    if(is_array($aiomatic_elevenlabs))
    {
        update_option('aiomatic_google_voices' . sanitize_title($language), $aiomatic_elevenlabs);
        return $aiomatic_elevenlabs;
    }
	return false;
}
function aiomatic_elevenlabs_stream($voice, $text)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if ((!isset($aiomatic_Main_Settings['elevenlabs_app_id']) || trim($aiomatic_Main_Settings['elevenlabs_app_id']) == ''))
    {
        $aiomatic_result = array('status' => 'error', 'msg' => 'Missing ElevenLabs API key');
        return $aiomatic_result;
    }
    else
    {
        $text = str_replace("\\",'',$text);
        $response = wp_remote_post('https://api.elevenlabs.io/v1/text-to-speech/' . $voice . '/stream', array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'xi-api-key' => trim($aiomatic_Main_Settings['elevenlabs_app_id'])
            ),
            'body' => json_encode(array('text' => $text, 'voice_settings' => array('stability' => 0.75, 'similarity_boost' => 0.75))),
            'timeout' => 1000
        ));
        if(is_wp_error($response))
        {
            $aiomatic_result = array('status' => 'error', 'msg' => $response->get_error_message());
            return $aiomatic_result;
        }
        else
        {
            return wp_remote_retrieve_body($response);
        }
    }
}
function aiomatic_google_stream($voice, $voice_language, $audio_profile, $voice_speed, $voice_pitch, $text)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong');
    if ((!isset($aiomatic_Main_Settings['google_app_id']) || trim($aiomatic_Main_Settings['google_app_id']) == ''))
    {
        $aiomatic_result = array('status' => 'error', 'msg' => 'Missing Google Text-to-Speech API key');
        return $aiomatic_result;
    }
    else
    {
        if(empty($voice_pitch))
        {
            $voice_pitch = '0';
        }
        if(empty($voice_speed))
        {
            $voice_speed = '1';
        }
        $text = str_replace("\\",'',$text);
        $params = array(
            'audioConfig' => array(
                'audioEncoding' => 'LINEAR16',
                'pitch' => $voice_pitch,
                'speakingRate' => $voice_speed,
            ),
            'input' => array(
                'text' => $text
            ),
            'voice' => array(
                'languageCode' => $voice_language,
                'name' => $voice
            )
        );
        if(!empty($audio_profile)){
            $params['audioConfig']['effectsProfileId'] = array($audio_profile);
        }
        $response = wp_remote_post('https://texttospeech.googleapis.com/v1/text:synthesize?fields=audioContent&key=' . trim($aiomatic_Main_Settings['google_app_id']), array(
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($params),
            'timeout' => 1000
        ));
        if(is_wp_error($response))
        {
            $aiomatic_result = array('status' => 'error', 'msg' => $response->get_error_message());
            return $aiomatic_result;
        }
        else
        {
            $body = wp_remote_retrieve_body($response);
            $body = json_decode($body, true);
            if(isset($body['error'])){
                $aiomatic_result['msg'] = $body['error']['message'];
            }
            elseif(isset($body['audioContent']) && !empty($body['audioContent'])){
                $aiomatic_result['audio'] = $body['audioContent'];
                $aiomatic_result['status'] = 'success';
            }
            else{
                $aiomatic_result['msg'] = esc_html__('Google did not generate any audio for this text','aiomatic-automatic-ai-content-writer');
            }
        }
    }
    return $aiomatic_result;
}

function aiomatic_update_elevenlabs_voices()
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['elevenlabs_app_id']) || trim($aiomatic_Main_Settings['elevenlabs_app_id']) == '')
    {
        aiomatic_log_to_file('You need to enter an ElevenLabs API key in the plugin\'s settings to use this feature');
        return false;
    }
    $response = wp_remote_get('https://api.elevenlabs.io/v1/voices', array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'xi-api-key' => trim($aiomatic_Main_Settings['elevenlabs_app_id'])
        )
    ));
    if(!is_wp_error($response))
    {
        $body = json_decode(wp_remote_retrieve_body($response),true);
        if($body === false)
        {
            aiomatic_log_to_file('Failed to decode response: ' . print_r($response, true));
            return false;
        }
        else
        {
            if(is_array($body) && isset($body['voices']) && is_array($body['voices']))
            {
                $option_voices = [];
                foreach($body['voices'] as $voice){
                    $option_voices[$voice['voice_id']] = $voice['name'];
                }
                return $option_voices;
            }
            else
            {
                aiomatic_log_to_file('Error while listing voices: ' . print_r($body, true));
                return false;
            }
        }
    }
    else
    {
        aiomatic_log_to_file('Failed to list ElevenLabs voices: ' . $response->get_error_message());
        return false;
    }
}
function aiomatic_update_google_voices($language)
{
    if(empty($language))
    {
        $language = 'en-US';
    }
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['google_app_id']) || trim($aiomatic_Main_Settings['google_app_id']) == '')
    {
        aiomatic_log_to_file('You need to enter an Google Text-to-Speech API key in the plugin\'s settings to use this feature');
        return false;
    }
    $response = wp_remote_get('https://texttospeech.googleapis.com/v1/voices?languageCode=' . $language . '&key=' . trim($aiomatic_Main_Settings['google_app_id']));
    if(!is_wp_error($response))
    {
        $body = json_decode(wp_remote_retrieve_body($response),true);
        if($body === false)
        {
            aiomatic_log_to_file('Failed to decode response: ' . print_r($response, true));
            return false;
        }
        else
        {
            if(is_array($body) && isset($body['voices']) && is_array($body['voices']))
            {
                return $body['voices'];
            }
            else
            {
                aiomatic_log_to_file('Error while listing voices: ' . print_r($body, true));
                return false;
            }
        }
    }
    else
    {
        aiomatic_log_to_file('Failed to list Google Text-to-Speech voices: ' . $response->get_error_message());
        return false;
    }
}
function aiomatict_random_user_query( $class ) {
    if( 'rand' == $class->query_vars['orderby'] )
        $class->query_orderby = str_replace( 'user_login', 'RAND()', $class->query_orderby );

    return $class;
}
register_deactivation_hook(__FILE__,'aiomatict_deactivate_plugin');
function aiomatict_deactivate_plugin(){
    global $wpdb;
    $wpdb->query("DROP TABLE IF EXISTS $wpdb->aiomatict_shortcode_rez");
}
function aiomatict_get_item_table_columns(){
    return array(
        'post_id'=> '%d',
        'post_hash' => '%s',
        'post_result'=> '%s'
    );
}
add_action( 'init', 'aiomatict_register_aggregated_feed_table', 1 );
add_action( 'switch_blog', 'aiomatict_register_aggregated_feed_table' );
function aiomatict_insert_item($data=array()){
    global $wpdb;        
    $data = wp_parse_args($data, array(
                 'post_hash'=> '',
                 'post_result'=> ''
    ));
    $column_formats = aiomatict_get_item_table_columns();
    $data = array_change_key_case ( $data );
    $data = array_intersect_key($data, $column_formats);
    $data_keys = array_keys($data);
    $column_formats = array_merge(array_flip($data_keys), $column_formats);
    add_filter('query', 'aiomatict_modifyInsertQuery', 10);
    $wpdb->insert($wpdb->aiomatict_shortcode_rez, $data, $column_formats);
    remove_filter('query', 'aiomatict_modifyInsertQuery', 10);
    if($wpdb->insert_id == 0)
    {
        if($wpdb->last_error != '')
        {
            $query = htmlspecialchars( print_r($wpdb->last_query, true), ENT_QUOTES );
            aiomatic_log_to_file('WordPress database error: "' . $wpdb->last_error . '" QUERY: ' . $query);
        }
    }
    return $wpdb->insert_id;
}
function aiomatict_modifyInsertQuery( $query ){
    $count 	= 0;
	$query 	= preg_replace('/^(INSERT INTO)/i', 'INSERT IGNORE INTO', $query, 1 , $count );
	return $query;
}
function aiomatict_register_aggregated_feed_table() {
    global $wpdb;
    $wpdb->aiomatict_shortcode_rez = "{$wpdb->prefix}aiomatict_shortcode_rez";
}

register_activation_hook(__FILE__, 'aiomatic_check_version');
function aiomatic_check_version()
{
    if (!function_exists('curl_init')) {
        echo '<h3>'.esc_html__('Please enable curl PHP extension. Please contact your hosting provider\'s support to help you in this matter.', 'aiomatic-automatic-ai-content-writer').'</h3>';
        die;
    }
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . esc_html__('You are not allowed to activate plugins!', 'aiomatic-automatic-ai-content-writer') . '</p>';
        die;
    }
    $php_version_required = '5.0';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(esc_html__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'aiomatic-automatic-ai-content-writer'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(esc_html__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard -> Updates to get the latest version of WordPress.', 'aiomatic-automatic-ai-content-writer'), $wp_version_required) . '</p>';
        die;
    }
}
function aiomatic_generate_stability_image($text = '', $height = '512', $width = '512', $env = '', $retry_count = 0, $returnbase64 = false)
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['stable_model']) || trim($aiomatic_Main_Settings['stable_model']) == '') 
    {
        $stable_model = 'stable-diffusion-512-v2-0';
    }
    else
    {
        $stable_model = trim($aiomatic_Main_Settings['stable_model']);
    }
    if (!isset($aiomatic_Main_Settings['stability_app_id']) || trim($aiomatic_Main_Settings['stability_app_id']) == '') 
    {
        aiomatic_log_to_file('You need to enter a Stability.AI API key in the plugin\'s "Main Settings" menu to use this feature!');
        return false;
    }
    $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['stability_app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
    $aiomatic_Limit_Settings = get_option('aiomatic_Limit_Settings', false);
    $stop = null;
    $session = aiomatic_get_session_id();
    $mode = 'stable';
    $maxResults = 1;
    $available_tokens = 1000;
    $temperature = 1;
    if($stable_model == 'stable-diffusion-xl-beta-v2-2-2')
    {
        if(intval($width) > 512)
        {
            $width = 512;
        }
        if(intval($height) > 512)
        {
            $height = 512;
        }
    }
    $query = new Aiomatic_Query($text, $available_tokens, $stable_model, $temperature, $stop, $env, $mode, $token, $session, $maxResults, $width . 'x' . $height);
    $ok = apply_filters( 'aiomatic_ai_allowed', true, $aiomatic_Limit_Settings );
    if ( $ok !== true ) {
        aiomatic_log_to_file('Image generator is rate limited: ' . $ok);
        return false;
    }
    if(strlen($text) > 2000)
    {
        $text = aiomatic_substr($text, 0, 2000);
    }
    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
    {
        aiomatic_log_to_file('Generating Stability.AI Image using prompt: ' . $text . ' height: ' . $height . ' width: ' . $width);
    }
    if(intval($height) < 512 || intval($height) > 2048)
    {
        aiomatic_log_to_file('Invalid height (512-2048): ' . $height);
        return false;
    }
    if(intval($width) < 512 || intval($width) > 2048)
    {
        aiomatic_log_to_file('Invalid width (512-2048): ' . $width);
        return false;
    }
    if(intval($width) * intval($height) > 1048576)
    {
        aiomatic_log_to_file('Width x Height must not be greater than 1 Megapixel (1048576), current is: ' . intval($width) * intval($height));
        return false;
    }
    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on' && AIOMATIC_IS_DEBUG === true)
    {
        aiomatic_log_to_file('Generating AI Stable Difussion image using model: ' . $stable_model . ' and prompt: ' . $text);
    }
    if (!isset($aiomatic_Main_Settings['steps']) || trim($aiomatic_Main_Settings['steps']) == '') 
    {
        $steps = '50';
    }
    else
    {
        $steps = trim($aiomatic_Main_Settings['steps']);
    }
    if (!isset($aiomatic_Main_Settings['cfg_scale']) || trim($aiomatic_Main_Settings['cfg_scale']) == '') 
    {
        $cfg_scale = '7';
    }
    else
    {
        $cfg_scale = trim($aiomatic_Main_Settings['cfg_scale']);
    }
    if (!isset($aiomatic_Main_Settings['clip_guidance_preset']) || trim($aiomatic_Main_Settings['clip_guidance_preset']) == '') 
    {
        $clip_guidance_preset = 'NONE';
    }
    else
    {
        $clip_guidance_preset = trim($aiomatic_Main_Settings['clip_guidance_preset']);
    }
    if (!isset($aiomatic_Main_Settings['sampler']) || trim($aiomatic_Main_Settings['sampler']) == '') 
    {
        $sampler = 'auto';
    }
    else
    {
        $sampler = trim($aiomatic_Main_Settings['sampler']);
    }
    if(intval($steps) < 10 || intval($steps) > 250)
    {
        aiomatic_log_to_file('Invalid steps count provided (10-250): ' . intval($steps));
        return false;
    }
    if(intval($cfg_scale) < 0 || intval($cfg_scale) > 35)
    {
        aiomatic_log_to_file('Invalid cfg_scale count provided (0-35): ' . intval($cfg_scale));
        return false;
    }
    $api_url = 'https://api.stability.ai/v1alpha/generation/' . $stable_model . '/text-to-image';
    $ch = curl_init();
    if($ch === false)
    {
        if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
        {
            aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') Stability API call after initial failure: ' . print_r($api_url, true));
            sleep(pow(2, $retry_count));
            return aiomatic_generate_stability_image($text, $height, $width, $env, intval($retry_count) + 1, $returnbase64);
        }
        else
        {
            aiomatic_log_to_file('Failed to create Stability curl request.');
            return false;
        }
    }
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json', 'Content-Type: application/json', 'Authorization: ' . $token));
    $post_fields = '{"samples": 1,';
    if(trim($cfg_scale) != '' && trim($cfg_scale) != '7')
    {
        $post_fields .= '"cfg_scale": ' . trim($cfg_scale) . ',';
    }
    if(trim($clip_guidance_preset) != '' && trim($clip_guidance_preset) != 'NONE')
    {
        $post_fields .= '"clip_guidance_preset": ' . trim($clip_guidance_preset) . ',';
    }
    if(trim($height) != '' && trim($height) != '512')
    {
        $post_fields .= '"height": ' . trim($height) . ',';
    }
    if(trim($width) != '' && trim($width) != '512')
    {
        $post_fields .= '"width": ' . trim($width) . ',';
    }
    if(trim($steps) != '' && trim($steps) != '50')
    {
        $post_fields .= '"steps": ' . trim($steps) . ',';
    }
    if(trim($sampler) != '' && trim($sampler) != 'auto')
    {
        $post_fields .= '"sampler": ' . trim($sampler) . ',';
    }
    $post_fields .= '"text_prompts": [{"text": "' . str_replace('"', '\'', $text) . '","weight": 1}]}';
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    $ai_response = curl_exec($ch);
    $info = curl_getinfo($ch);
    if($info['http_code'] != 200)
    {
        if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
        {
            aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') Stability API call after http_code failure: ' . print_r($api_url, true));
            sleep(pow(2, $retry_count));
            return aiomatic_generate_stability_image($text, $height, $width, $env, intval($retry_count) + 1, $returnbase64);
        }
        else
        {
            $er = ' ';
            $json_resp = json_decode($ai_response, true);
            if($json_resp !== false)
            {
                $er .= 'Error: ' . $json_resp['name'] . ': ' . $json_resp['message'];
            }
            aiomatic_log_to_file('Invalid return code from API: ' . $info['http_code'] . $er);
            aiomatic_log_to_file('PostFields: ' . $post_fields);
            return false;
        }
    }
    curl_close($ch);
    if($ai_response === false)
    {
        if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
        {
            aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') Stability API call after response failure: ' . print_r($api_url, true));
            sleep(pow(2, $retry_count));
            return aiomatic_generate_stability_image($text, $height, $width, $env, intval($retry_count) + 1, $returnbase64);
        }
        else
        {
            aiomatic_log_to_file('Failed to get AI response: ' . $api_url);
            return false;
        }
    }
    else
    {
        $json_resp = json_decode($ai_response, true);
        if($json_resp === false)
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') Stability API call after decode failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_stability_image($text, $height, $width, $env, intval($retry_count) + 1, $returnbase64);
            }
            else
            {
                aiomatic_log_to_file('Failed to decode AI response: ' . $ai_response);
                return false;
            }
        }
        if(!isset($json_resp['artifacts'][0]['base64']))
        {
            if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
            {
                aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') Stability API call after response failure: ' . print_r($api_url, true));
                sleep(pow(2, $retry_count));
                return aiomatic_generate_stability_image($text, $height, $width, $env, intval($retry_count) + 1, $returnbase64);
            }
            else
            {
                aiomatic_log_to_file('Invalid AI response: ' . $ai_response);
                return false;
            }
        }
        $seed = rand();
        if(isset($json_resp['artifacts'][0]['seed']))
        {
            $seed = $json_resp['artifacts'][0]['seed'];
        }
        $upload_dir = wp_upload_dir();
        $filename = $seed . '.png';
        if (wp_mkdir_p($upload_dir['path'] . '/localimages'))
        {
            $file = $upload_dir['path'] . '/localimages/' . $filename;
            $ret_path = $upload_dir['url'] . '/localimages/' . $filename;
        }
        else
        {
            $file = $upload_dir['basedir'] . '/' . $filename;
            $ret_path = $upload_dir['baseurl'] . '/' . $filename;
        }
        $reason = ''; 
        if(isset($json_resp['artifacts'][0]['finishReason']))
        {
            $reason = $json_resp['artifacts'][0]['finishReason'];
            if($reason == 'ERROR')
            {
                if (isset($aiomatic_Main_Settings['max_retry']) && $aiomatic_Main_Settings['max_retry'] != '' && is_numeric($aiomatic_Main_Settings['max_retry']) && intval($aiomatic_Main_Settings['max_retry']) > $retry_count)
                {
                    aiomatic_log_to_file('Retrying (' . (intval($retry_count) + 1) . ') Stability API call after error failure: ' . print_r($api_url, true));
                    sleep(pow(2, $retry_count));
                    return aiomatic_generate_stability_image($text, $height, $width, $env, intval($retry_count) + 1, $returnbase64);
                }
                else
                {
                    aiomatic_log_to_file('An error was encountered during API call: ' . $ai_response);
                    return false;
                }
            }
            elseif($reason == 'CONTENT_FILTERED')
            {
                aiomatic_log_to_file('The image was filtered, by the nudity filter, blurred parts may appear in it, prompt: ' . $ret_path);
            }
        }
        $img = $json_resp['artifacts'][0]['base64'];
        apply_filters( 'aiomatic_ai_reply', $img, $query );
        if($returnbase64 == true)
        {
            return $img;
        }
        $rezi = aiomatic_base64_to_jpeg($img, $file, $ret_path);
        return $rezi;
    }
}
function aiomatic_list_stability_engines()
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (!isset($aiomatic_Main_Settings['stability_app_id']) || trim($aiomatic_Main_Settings['stability_app_id']) == '') 
    {
        aiomatic_log_to_file('You need to enter a Stability.AI API key in the plugin\'s "Main Settings" menu to use this feature!');
        return false;
    }
    $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['stability_app_id']));
    $appids = array_filter($appids);
    $token = $appids[array_rand($appids)];
    $api_url = 'https://api.stability.ai/v1/engines/list';
    $ch = curl_init();
    if($ch === false)
    {
        aiomatic_log_to_file('Failed to create Stability curl request.');
        return false;
    }
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json', 'Authorization: ' . $token));
    $ai_response = curl_exec($ch);
    $info = curl_getinfo($ch);
    if($info['http_code'] != 200)
    {
        aiomatic_log_to_file('Invalid return code from API: ' . $info['http_code'] . ' response: ' . print_r($ai_response, true));
        return false;
    }
    curl_close($ch);
    if($ai_response === false)
    {
        aiomatic_log_to_file('Failed to get AI response: ' . $api_url);
        return false;
    }
    else
    {
        $json_resp = json_decode($ai_response, true);
        if($json_resp === false)
        {
            aiomatic_log_to_file('Failed to decode AI response: ' . $ai_response);
            return false;
        }
        aiomatic_log_to_file('Results: ' . print_r($json_resp, true));
    }
    return true;
}
add_filter( 'aiomatic_replace_aicontent_shortcode', 'aiomatic_ai_content_replace', 10, 1 );
function aiomatic_ai_content_replace($content)
{
    preg_match_all('#\[[\t\s]*aicontent(\d*)(?:[\t\s]*model=[\'"]?([^\]"\']+)[\'"]?)?[\t\s]*\]([\s\S]*?)\[\/[\t\s]*aicontent\1[\t\s]*\]#i', $content, $matches);
    if(isset($matches[0][0]) && isset($matches[1][0]) && isset($matches[2][0]))
    {
        $all_mdoels = aiomatic_get_all_models();
        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
        if (isset($aiomatic_Main_Settings['app_id']) && trim($aiomatic_Main_Settings['app_id']) != '') 
        {
            $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
            $appids = array_filter($appids);
            $token = $appids[array_rand($appids)];
            for($i = 0; $i < count($matches[0]); $i++)
            {
                if(!isset($matches[3][$i]))
                {
                    continue;
                }
                $replacement = '';
                if (isset($aiomatic_Main_Settings['aicontent_model']) && trim($aiomatic_Main_Settings['aicontent_model']) != '') 
                {
                    $model = trim($aiomatic_Main_Settings['aicontent_model']);
                }
                else
                {
                    $model = 'text-davinci-003';
                }
                if (isset($aiomatic_Main_Settings['aicontent_temperature']) && trim($aiomatic_Main_Settings['aicontent_temperature']) != '') 
                {
                    $temperature = floatval($aiomatic_Main_Settings['aicontent_temperature']);
                }
                else
                {
                    $temperature = 1;
                }
                if (isset($aiomatic_Main_Settings['aicontent_top_p']) && trim($aiomatic_Main_Settings['aicontent_top_p']) != '') 
                {
                    $top_p = floatval($aiomatic_Main_Settings['aicontent_top_p']);
                }
                else
                {
                    $top_p = 1;
                }
                if (isset($aiomatic_Main_Settings['aicontent_presence_penalty']) && trim($aiomatic_Main_Settings['aicontent_presence_penalty']) != '') 
                {
                    $presence_penalty = floatval($aiomatic_Main_Settings['aicontent_presence_penalty']);
                }
                else
                {
                    $presence_penalty = 0;
                }
                if (isset($aiomatic_Main_Settings['aicontent_frequency_penalty']) && trim($aiomatic_Main_Settings['aicontent_frequency_penalty']) != '') 
                {
                    $frequency_penalty = floatval($aiomatic_Main_Settings['aicontent_frequency_penalty']);
                }
                else
                {
                    $frequency_penalty = 0;
                }
                if(in_array(trim($matches[2][$i]), $all_mdoels))
                {
                    $model = trim($matches[2][$i]);
                }
                if(trim($matches[3][$i]) != '')
                {
                    if(stristr($matches[3][$i], 'aicontent') !== false)
                    {
                        $matches[3][$i] = aiomatic_ai_content_replace($matches[3][$i]);
                    }
                    $max_tokens = aiomatic_get_max_tokens($model);
                    $prompt = trim($matches[3][$i]);
                    $query_token_count = count(aiomatic_encode($prompt));
                    $available_tokens = $max_tokens - $query_token_count;
                    if($available_tokens < AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                    {
                        $string_len = strlen($prompt);
                        $string_len = $string_len / 2;
                        $string_len = intval(0 - $string_len);
                        $prompt = aiomatic_substr($prompt, 0, $string_len);
                        $prompt = trim($prompt);
                        $query_token_count = count(aiomatic_encode($prompt));
                        $available_tokens = $max_tokens - $query_token_count;
                    }
                    if (isset($aiomatic_Main_Settings['enable_detailed_logging'])) 
                    {
                        $api_service = aiomatic_get_api_service($token);
                        aiomatic_log_to_file('Calling ' . $api_service . ' (' . $model . ') for nested shortcode text generator: ' . $prompt);
                    }
                    $aierror = '';
                    $finish_reason = '';
                    $generated_text = aiomatic_generate_text($token, $model, $prompt, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, false, 'nestedAIShortcode', 0, $finish_reason, $aierror);
                    if($generated_text === false)
                    {
                        aiomatic_log_to_file('Failed to generate nested AI content: ' . $aierror);
                    }
                    else
                    {
                        $replacement = trim(trim(trim(trim($generated_text), '.'), ' “”‘’"\''));
                    }
                }
                $content = str_replace($matches[0][$i], $replacement, $content);
            }
        }
        else
        {
            for($i = 0; $i < count($matches[0]); $i++)
            {
                $content = str_replace($matches[0][$i], '', $content);
            }
        }
    }
    return $content;
}
add_action('admin_init', 'aiomatic_register_mysettings');
function aiomatic_register_mysettings()
{
    if(isset($_POST['aiomatic_download_forms_to_file']))
    {
        $aiomatic_form_page = 1;
        $aiomatic_forms = new WP_Query(array(
            'post_type' => 'aiomatic_forms',
            'order' => 'DESC',
            'orderby' => 'date',
            'posts_per_page' => 50,
            'paged' => $aiomatic_form_page
        ));
        $forms = array();
        while($aiomatic_forms->have_posts())
        {
            foreach ($aiomatic_forms->posts as $aiomatic_form){
                $my_form = array();
                $prompt = get_post_meta($aiomatic_form->ID, 'prompt', true);
                $model = get_post_meta($aiomatic_form->ID, 'model', true);
                $header = get_post_meta($aiomatic_form->ID, 'header', true);
                $submit = get_post_meta($aiomatic_form->ID, 'submit', true);
                $max = get_post_meta($aiomatic_form->ID, 'max', true);
                $temperature = get_post_meta($aiomatic_form->ID, 'temperature', true);
                $topp = get_post_meta($aiomatic_form->ID, 'topp', true);
                $presence = get_post_meta($aiomatic_form->ID, 'presence', true);
                $frequency = get_post_meta($aiomatic_form->ID, 'frequency', true);
                $response = get_post_meta($aiomatic_form->ID, 'response', true);
                $type = get_post_meta($aiomatic_form->ID, 'type', true);
                $aiomaticfields = get_post_meta($aiomatic_form->ID, '_aiomaticfields', true);
                if(!is_array($aiomaticfields))
                {
                   $aiomaticfields = array();
                }
                $my_form['title'] = $aiomatic_form->post_title;
                $my_form['description'] = $aiomatic_form->post_content;
                $my_form['prompt'] = $prompt;
                $my_form['model'] = $model;
                $my_form['header'] = $header;
                $my_form['submit'] = $submit;
                $my_form['max'] = $max;
                $my_form['temperature'] = $temperature;
                $my_form['topp'] = $topp;
                $my_form['presence'] = $presence;
                $my_form['frequency'] = $frequency;
                $my_form['response'] = $response;
                $my_form['type'] = $type;
                $my_form['aiomaticfields'] = $aiomaticfields;
                $forms[] = $my_form;
            }
            $aiomatic_form_page++;
            $aiomatic_forms = new WP_Query(array(
                'post_type' => 'aiomatic_forms',
                'order' => 'DESC',
                'orderby' => 'date',
                'posts_per_page' => 50,
                'paged' => $aiomatic_form_page
            ));
        }
        header("Content-type: application/x-msdownload");
        header("Content-Disposition: attachment; filename=aiomatic_forms.json");
        header("Pragma: no-cache");
        header("Expires: 0");
        echo json_encode($forms);
        exit();
    }
    require_once (dirname(__FILE__) . "/res/aiomatic-finetune.php"); 
    aiomatic_cron_schedule();
    if(isset($_GET['aiomatic_page']))
    {
        $curent_page = $_GET["aiomatic_page"];
    }
    else
    {
        $curent_page = '';
    }
    $all_rules = get_option('aiomatic_rules_list', array());
    if($all_rules === false)
    {
        $all_rules = array();
    }
    $rules_count = count($all_rules);
    $rules_per_page = get_option('aiomatic_posts_per_page', 12);
    $max_pages = ceil($rules_count/$rules_per_page);
    if($max_pages == 0)
    {
        $max_pages = 1;
    }
    $last_url = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    if(stristr($last_url, 'aiomatic_items_panel') !== false && (!is_numeric($curent_page) || $curent_page > $max_pages || $curent_page <= 0))
    {
        if(stristr($last_url, 'aiomatic_page=') === false)
        {
            if(stristr($last_url, '?') === false)
            {
                $last_url .= '?aiomatic_page=' . $max_pages;
            }
            else
            {
                $last_url .= '&aiomatic_page=' . $max_pages;
            }
        }
        else
        {
            if(isset($_GET['aiomatic_page']))
            {
                $curent_page = $_GET["aiomatic_page"];
            }
            else
            {
                $curent_page = '';
            }
            if(is_numeric($curent_page))
            {
                $last_url = str_replace('aiomatic_page=' . $curent_page, 'aiomatic_page=' . $max_pages, $last_url);
            }
            else
            {
                if(stristr($last_url, '?') === false)
                {
                    $last_url .= '?aiomatic_page=' . $max_pages;
                }
                else
                {
                    $last_url .= '&aiomatic_page=' . $max_pages;
                }
            }
        }
        aiomatic_redirect($last_url);
    }
    register_setting('aiomatic_option_group', 'aiomatic_Main_Settings');
    register_setting('aiomatic_option_group2', 'aiomatic_Spinner_Settings');
    register_setting('aiomatic_option_group3', 'aiomatic_Limit_Settings');
    register_setting('aiomatic_option_group4', 'aiomatic_Chatbot_Settings');
    register_setting('aiomatic_option_group5', 'aiomatic_Limit_Rules');
    if (is_multisite()) {
        if (!get_option('aiomatic_Main_Settings')) {
            aiomatic_activation_callback(TRUE);
        }
    }
}

add_action('wp_enqueue_scripts', 'aiomatic_wp_load_files');
add_action('admin_enqueue_scripts', 'aiomatic_wp_load_files');
function aiomatic_wp_load_files()
{
    wp_enqueue_style('cr-front-css', plugins_url('styles/front.css', __FILE__));
}
function aiomatic_admin_load_files()
{
    wp_register_style('aiomatic-browser-style', plugins_url('styles/aiomatic-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-browser-style');
    wp_register_style('aiomatic-custom-style', plugins_url('styles/coderevolution-style.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-custom-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}
function aiomatic_admin_load_playground()
{
    wp_register_script('aiomatic-playground-script', plugins_url('scripts/playground.js', __FILE__), array('jquery'), '1.0.0');
    wp_enqueue_script('aiomatic-playground-script');
    wp_localize_script('aiomatic-playground-script', 'aiomatic_object', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('openai-ajax-nonce')
	));
}
function aiomatic_admin_load_live_preview()
{
    wp_register_script('aiomatic-chat-live-preview-script', plugins_url('scripts/chat-live-preview.js', __FILE__), array('jquery'), '1.0.0');
    wp_enqueue_script('aiomatic-chat-live-preview-script');
}
function aiomatic_admin_load_stats()
{
    wp_register_script('aiomatic-stats-script', plugins_url('scripts/stats.js', __FILE__), array('jquery'), '1.0.0');
    wp_enqueue_script('aiomatic-stats-script');
    wp_localize_script('aiomatic-stats-script', 'aiomatic_object', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('openai-ajax-nonce')
	));
    wp_register_style('aiomatic-limit-style', plugins_url('styles/aiomatic-limits.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-limit-style');
}
function aiomatic_admin_load_embeddings()
{
    wp_register_script('aiomatic-embeddings-script', plugins_url('scripts/embeddings.js', __FILE__), array('jquery'), '1.0.0');
    wp_enqueue_script('aiomatic-embeddings-script');
    wp_localize_script('aiomatic-embeddings-script', 'aiomatic_object', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('openai-ajax-nonce'),
		'maxfilesize' => wp_max_upload_size(),
	));
    wp_register_style('aiomatic-embeddings-style', plugins_url('styles/embeddings.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-embeddings-style');
}
function aiomatic_admin_load_forms()
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['max_len']) && $aiomatic_Main_Settings['max_len'] != '')
    {
        $max_len = trim($aiomatic_Main_Settings['max_len']);
    }
    else
    {
        $max_len = '';
    }
    if (isset($aiomatic_Main_Settings['min_len']) && $aiomatic_Main_Settings['min_len'] != '')
    {
        $min_len = trim($aiomatic_Main_Settings['min_len']);
    }
    else
    {
        $min_len = '';
    }
    wp_register_script('aiomatic-forms-script', plugins_url('scripts/forms.js', __FILE__), array('jquery'), '1.0.0');
    wp_enqueue_script('aiomatic-forms-script');
    wp_localize_script('aiomatic-forms-script', 'aiomatic_object', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('openai-ajax-nonce'),
		'maxfilesize' => wp_max_upload_size(),
	));
    wp_register_style('aiomatic-forms-style', plugins_url('styles/forms.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-forms-style');
    //for styling for preview
    $user_id = '0';
    if(!empty($user_token_cap_per_day))
    {
        $user_id = get_current_user_id();
    }
    wp_register_style('aiomatic-form-end-style', plugins_url('styles/form-end.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-form-end-style');
    $reg_css_code = '';
    if (isset($aiomatic_Main_Settings['back_color']) && $aiomatic_Main_Settings['back_color'] != '')
    {
        $reg_css_code .= '.aiomatic-prompt-item{background-color:' . trim($aiomatic_Main_Settings['back_color']) . '!important;}';
    }
    if (isset($aiomatic_Main_Settings['text_color']) && $aiomatic_Main_Settings['text_color'] != '')
    {
        $reg_css_code .= '.aiomatic-prompt-item{color:' . trim($aiomatic_Main_Settings['text_color']) . '!important;}';
    }
    if (isset($aiomatic_Main_Settings['but_color']) && $aiomatic_Main_Settings['but_color'] != '')
    {
        $reg_css_code .= '#aiomatic-generate-button{background:' . trim($aiomatic_Main_Settings['but_color']) . '!important;}';
    }
    if (isset($aiomatic_Main_Settings['btext_color']) && $aiomatic_Main_Settings['btext_color'] != '')
    {
        $reg_css_code .= '#aiomatic-generate-button{color:' . trim($aiomatic_Main_Settings['btext_color']) . '!important;}';
    }
    if($reg_css_code != '')
    {
        wp_add_inline_style( 'aiomatic-form-end-style', $reg_css_code );
    }
    $image_placeholder = plugins_url('images/loading.gif', __FILE__);
    wp_register_script( 'aiomatic-forms-front-script', plugins_url('scripts/forms-front.js', __FILE__) );
    wp_enqueue_script( 'aiomatic-forms-front-script'  );
    wp_localize_script('aiomatic-forms-front-script', 'aiomatic_completition_ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('openai-ajax-nonce'),
        'user_id' => $user_id,
        'max_len' => $max_len,
        'min_len' => $min_len,
		'image_placeholder' => $image_placeholder,
    ));
    wp_enqueue_editor();
}
function aiomatic_admin_load_training()
{
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['prompt_suffix']) && $aiomatic_Main_Settings['prompt_suffix'] != '')
    {
        $prompt_suffix = $aiomatic_Main_Settings['prompt_suffix'];
    }
    else
    {
        $prompt_suffix = ' ->';
    }
    if (isset($aiomatic_Main_Settings['completion_suffix']) && $aiomatic_Main_Settings['completion_suffix'] != '')
    {
        $completion_suffix = $aiomatic_Main_Settings['completion_suffix'];
    }
    else
    {
        $completion_suffix = ' ###';
    }
    wp_register_script('aiomatic-training-script', plugins_url('scripts/training.js', __FILE__), array('jquery'), '1.0.0');
    wp_enqueue_script('aiomatic-training-script');
	wp_localize_script('aiomatic-training-script', 'aiomatic_object', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'maxfilesize' => wp_max_upload_size(),
        'prompt_suffix' => $prompt_suffix,
        'completion_suffix' => $completion_suffix
	));
    wp_register_style('aiomatic-training-style', plugins_url('styles/training.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('aiomatic-training-style');
}
function aiomatic_do_bulk_post()
{
    register_shutdown_function('aiomatic_clear_flag_at_shutdown', '-1');
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $aiomatic_Spinner_Settings = get_option('aiomatic_Spinner_Settings', false);
    if (isset($aiomatic_Main_Settings['rule_timeout']) && $aiomatic_Main_Settings['rule_timeout'] != '') {
        $timeout = intval($aiomatic_Main_Settings['rule_timeout']);
    } else {
        $timeout = 3600;
    }
    ini_set('memory_limit', '-1');
    ini_set('default_socket_timeout', $timeout);
    ini_set('safe_mode', 'Off');
    ini_set('max_execution_time', $timeout);
    ini_set('ignore_user_abort', 1);
    ini_set('user_agent', aiomatic_get_random_user_agent());
    if(function_exists('ignore_user_abort'))
    {
        ignore_user_abort(true);
    }
        if(function_exists('set_time_limit'))
    {
        set_time_limit($timeout);
    }
    $is_failed = false;
    if (isset($aiomatic_Main_Settings['aiomatic_enabled']) && $aiomatic_Main_Settings['aiomatic_enabled'] == 'on') {
        $query     = array(
        );
        if (isset($aiomatic_Spinner_Settings['author_id']) && $aiomatic_Spinner_Settings['author_id'] != '') {
            $query['author'] = $aiomatic_Spinner_Settings['author_id'];
        }
        if (isset($aiomatic_Spinner_Settings['author_name']) && $aiomatic_Spinner_Settings['author_name'] != '') {
            $query['author_name'] = $aiomatic_Spinner_Settings['author_name'];
        }
        if (isset($aiomatic_Spinner_Settings['category_name']) && $aiomatic_Spinner_Settings['category_name'] != '') {
            $query['category_name'] = $aiomatic_Spinner_Settings['category_name'];
        }
        if (isset($aiomatic_Spinner_Settings['tag_name']) && $aiomatic_Spinner_Settings['tag_name'] != '') {
            $query['tag'] = $aiomatic_Spinner_Settings['tag_name'];
        }
        if (isset($aiomatic_Spinner_Settings['post_id']) && $aiomatic_Spinner_Settings['post_id'] != '') {
            $postids = $aiomatic_Spinner_Settings['post_id'];
            $postids = explode(',', $postids);
            $postids = array_map('trim', $postids);
            $query['post__in'] = $postids;
        }
        if (isset($aiomatic_Spinner_Settings['post_name']) && $aiomatic_Spinner_Settings['post_name'] != '') {
            $query['name'] = $aiomatic_Spinner_Settings['post_name'];
        }
        if (isset($aiomatic_Spinner_Settings['pagename']) && $aiomatic_Spinner_Settings['pagename'] != '') {
            $query['pagename'] = $aiomatic_Spinner_Settings['pagename'];
        }
        if (isset($aiomatic_Spinner_Settings['year']) && $aiomatic_Spinner_Settings['year'] != '') {
            $query['year'] = $aiomatic_Spinner_Settings['year'];
        }
        if (isset($aiomatic_Spinner_Settings['month']) && $aiomatic_Spinner_Settings['month'] != '') {
            $query['monthnum'] = $aiomatic_Spinner_Settings['month'];
        }
        if (isset($aiomatic_Spinner_Settings['day']) && $aiomatic_Spinner_Settings['day'] != '') {
            $query['day'] = $aiomatic_Spinner_Settings['day'];
        }
        if (isset($aiomatic_Spinner_Settings['post_parent']) && $aiomatic_Spinner_Settings['post_parent'] != '') {
            $query['post_parent'] = $aiomatic_Spinner_Settings['post_parent'];
        }
        if (isset($aiomatic_Spinner_Settings['page_id']) && $aiomatic_Spinner_Settings['page_id'] != '') {
            $query['page_id'] = $aiomatic_Spinner_Settings['page_id'];
        }
        if (isset($aiomatic_Spinner_Settings['max_nr']) && $aiomatic_Spinner_Settings['max_nr'] != '') {
            $max_nr = intval($aiomatic_Spinner_Settings['max_nr']);
        }
        else
        {
            $max_nr = 0;
        }
        if (isset($aiomatic_Spinner_Settings['max_posts']) && $aiomatic_Spinner_Settings['max_posts'] != '') {
            $query['posts_per_page'] = $aiomatic_Spinner_Settings['max_posts'];
        }
        else
        {
            if($max_nr > 5)
            {
                $query['posts_per_page'] = $max_nr;
            }
        }
        if (isset($aiomatic_Spinner_Settings['search_offset']) && $aiomatic_Spinner_Settings['search_offset'] != '') {
            $query['offset'] = $aiomatic_Spinner_Settings['search_offset'];
        }
        if (isset($aiomatic_Spinner_Settings['search_query']) && $aiomatic_Spinner_Settings['search_query'] != '') {
            $query['s'] = $aiomatic_Spinner_Settings['search_query'];
        }
        if (isset($aiomatic_Spinner_Settings['meta_name']) && $aiomatic_Spinner_Settings['meta_name'] != '') {
            $query['meta_key'] = $aiomatic_Spinner_Settings['meta_name'];
        }
        if (isset($aiomatic_Spinner_Settings['meta_value']) && $aiomatic_Spinner_Settings['meta_value'] != '') {
            $query['meta_value'] = $aiomatic_Spinner_Settings['meta_value'];
        }
        if (isset($aiomatic_Spinner_Settings['order']) && $aiomatic_Spinner_Settings['order'] != 'default') {
            $query['order'] = $aiomatic_Spinner_Settings['order'];
        }
        if (isset($aiomatic_Spinner_Settings['orderby']) && $aiomatic_Spinner_Settings['orderby'] != 'default') {
            $query['orderby'] = $aiomatic_Spinner_Settings['orderby'];
        }
        if (isset($aiomatic_Spinner_Settings['featured_image']) && $aiomatic_Spinner_Settings['featured_image'] != 'any') {
            if($aiomatic_Spinner_Settings['featured_image'] == 'with')
            {
                $query['meta_query'] = array(
                    array(
                      'key' => '_thumbnail_id',
                      'compare' => 'EXISTS'
                    )
                );
            }
            elseif($aiomatic_Spinner_Settings['featured_image'] == 'without')
            {
                $query['meta_query'] = array(
                    array(
                      'key' => '_thumbnail_id',
                      'value' => '?',
                      'compare' => 'NOT EXISTS'
                    )
                );
            }
        }
        if (isset($aiomatic_Spinner_Settings['no_twice']) && $aiomatic_Spinner_Settings['no_twice'] == 'on') 
        {
            if(isset($query['meta_query']))
            {
                $query['meta_query'][] = array(
                    'key' => 'aiomatic_published',
                    'value' => '?',
                    'compare' => 'NOT EXISTS'
                );
            }
            else
            {
                $query['meta_query'] = array(
                    array(
                      'key' => 'aiomatic_published',
                      'value' => '?',
                      'compare' => 'NOT EXISTS'
                    )
                );
            }
        }
        if (isset($aiomatic_Spinner_Settings['post_status']) && $aiomatic_Spinner_Settings['post_status'] != '') {
            $query['post_status'] = array_map('trim', explode(',', $aiomatic_Spinner_Settings['post_status']));
        }
        else
        {
            $query['post_status'] = 'any';
        }
        if (isset($aiomatic_Spinner_Settings['type_post']) && $aiomatic_Spinner_Settings['type_post'] != '') {
            $query['post_type'] = array_map('trim', explode(',', $aiomatic_Spinner_Settings['type_post']));
        }
        else
        {
            $query['post_type'] = 'post';
        }
        $processed = 0;
        $post_list = get_posts($query);
        foreach ($post_list as $post) 
        {
            if($max_nr > 0 && $processed == $max_nr)
            {
                break;
            }
            $processed++;
            aiomatic_do_post($post, true);
        }
    }
    if($is_failed == true)
    {
        return 'fail';
    }
    if($processed == 0)
    {
        return 'nochange';
    }
    else
    {
        return 'ok';
    }
}
?>